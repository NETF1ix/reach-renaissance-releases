Reach Renaissance
=================

Halo: Reach multiplayer, Firefight and Campaign with the Xbox 360 menus, playable over the internet,
without opening MCC. A free fan project, not affiliated with Microsoft, Halo Studios, 343 Industries
or Bungie. It needs your own copy of the game.

What you need
  - Windows 10 or 11, 64-bit. Linux and the Steam Deck work through Proton, experimentally: see
    "Linux and Steam Deck" below.
  - Halo: The Master Chief Collection on Steam, with Halo: Reach installed and up to date. MCC doesn't
    need to be open, and nothing in MCC changes (anti-cheat settings included). The Microsoft Store /
    Game Pass version isn't supported.
  - Everyone you play with on the same Reach Renaissance version (VERSION.txt).

Start
  1. Unzip this folder anywhere (not inside the MCC folder).
  2. Double-click "Reach Renaissance.exe". The first time, the menus ask for your name.
  Windows may say "Windows protected your PC" because the program isn't signed: More info, then
  Run anyway.

Playing online
  Join: Matchmaking's server list shows public games from everywhere and games on your home network.
  Pick one and join; no router setup needed.
  Host: SETTINGS > Network, choose Host Public (anyone can find your game) or Host Online / Local
  (your network only), then Custom Games, pick map and game type, Start Game.
  First time hosting: SETTINGS > Network > Allow Reach Renaissance (Windows asks for administrator
  permission) so other players can reach your PC.
  Players you play with can see your chosen name. Like most PC games with player hosting, people
  in a game with you can learn your internet address.

If something goes wrong
  - "This MCC update's Halo: Reach isn't supported yet": MCC was updated (or isn't up to date). Reach
    Renaissance only runs on the Reach version it was checked against; wait for a new release.
  - "Could not find Halo: The Master Chief Collection": install MCC and Halo: Reach through Steam.
  - Logs: %LOCALAPPDATA%\ReachRenaissance\runs (the last 10 runs). For a bug report, zip the newest
    folder and attach it. Internet addresses in the logs are masked.
  - Your name, armor and settings are kept in %LOCALAPPDATA%\ReachRenaissance, so a newer version
    keeps them.

Linux and Steam Deck (experimental)
  Reach Renaissance runs under Proton, Steam's Windows compatibility layer. It hasn't been played on a
  Steam Deck yet, so please report what happens. On a Steam Deck, set it up in Desktop Mode.
  1. Install MCC with Halo: Reach in Steam as usual (Steam runs it with Proton).
  2. Unzip it somewhere in your home folder from a terminal (Konsole on the Deck), without sudo, for
     example (with the name of the zip you downloaded):
       mkdir -p ~/Games && bsdtar -C ~/Games -xf ~/Downloads/ReachRenaissance-v0.1.22.zip
     No bsdtar (Ubuntu, Mint, Debian, Fedora)? Use unzip, then let yourself into its folders:
       mkdir -p ~/Games && cd ~/Games && unzip -q ~/Downloads/ReachRenaissance-v0.1.22.zip
       chmod -R u+rwX ~/Games/ReachRenaissance
     (Ark and other archive apps can't read this zip's folders: they make files with names like
     ReachRenaissance\bin\... instead.)
  3. In Steam: Games > Add a Non-Steam Game to My Library > Browse, set the file type to All Files, pick
     "Reach Renaissance.exe" in ~/Games/ReachRenaissance, Add Selected Programs.
  4. Right-click it > Properties > Compatibility: tick "Force the use of a specific Steam Play
     compatibility tool" and pick Proton Experimental (or Proton 10 or newer).
  5. Play it. The first time, it offers to install Microsoft Edge WebView2 Runtime, which the menus
     need: answer Yes (a few minutes; needs the internet).
  6. On a Steam Deck, play it from Desktop Mode first, then try Gaming Mode. The Deck's controls work as
     an Xbox controller; Steam + X opens the keyboard for your name and chat.
  If MCC isn't found (MCC on an SD card, for example), pick its folder when asked (Linux folders are
  under Z:, SD cards under Z:\run\media), or put the folder in Properties > Launch Options:
    %command% "/run/media/deck/<card>/steamapps/common/Halo The Master Chief Collection"
  On a Linux desktop, play in an X11 (Xorg) session if Wayland gives trouble: Cinnamon's Wayland
  session (Linux Mint) is still experimental.
  Firewall: Linux firewalls are usually off. If yours is on (ufw, firewalld), allow TCP and UDP
  40011-40013 (hosting) and 11700-11710 (games on your home network). SETTINGS > Network can't
  check a Linux firewall.
  Logs: in Steam's folder, steamapps/compatdata/<a number>/pfx/drive_c/users/steamuser/AppData/Local/
  ReachRenaissance/runs. Launch Options PROTON_LOG=1 %command% also writes steam-<number>.log to your
  home folder.

Licenses
  The licenses folder holds the notices of other people's components this package includes.
