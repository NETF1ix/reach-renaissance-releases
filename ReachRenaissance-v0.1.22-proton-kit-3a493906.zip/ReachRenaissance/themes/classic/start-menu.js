// Start menu for the Classic 360 theme (PLAN-014), laid out like the owner's 360 screenshot of
// MENU > THE ARMORY: section list on the left, the section's items in the middle, a preview box with
// a description on the right, the player card along the bottom.
//
// Inside The Armory the right side of the menu turns see-through and the game behind it switches to
// the `armory` backdrop: the menu map's own Armory Spartan, rendered live by the engine
// (scripts/menu/build_menu_scenes.py). With `armory-data.js` (scripts/menu/extract_armory.py: the
// pieces and their ids from this PC's Mod Tools and MCC), equipping a piece saves it into the profile
// the game gets (the overlay's armor.rs, for matches) and the Armory Spartan puts it on at once
// (its model regions and colors go to host-probe's armory.rs, PLAN-015).
// Without that file the lists below are samples kept in local storage only. Challenges, Commendations
// and the Service Record open career.js's screens.
"use strict";

const StartMenu = (() => {
	const ARMOR = {
		"Helmet": ["Mark V [B]", "Air Assault", "CQB", "Commando", "EOD", "EVA", "Grenadier", "Gungnir", "Haunted", "HAZOP", "JFO", "Military Police", "Operator", "Pilot", "Recon", "Scout"],
		"Left Shoulder": ["Default", "Commando", "CQB", "EOD", "Grenadier", "Gungnir", "HAZOP", "JFO", "Jump Jet", "Operator", "Pilot", "Recon", "Security", "Sniper"],
		"Right Shoulder": ["Default", "Commando", "CQB", "EOD", "Grenadier", "Gungnir", "HAZOP", "JFO", "Jump Jet", "Operator", "Pilot", "Recon", "Security", "Sniper"],
		"Chest": ["Default", "Assault/Commando", "Collar/Breacher", "Collar/Grenadier", "Commando/Security", "Gungnir", "HP/Parafoil", "Operator", "Tactical/Patrol", "Tactical/Recon"],
		"Wrist": ["Default", "Assault/Breacher", "Assault/Sapper", "Tactical/Hardcase", "Tactical/Tacpad", "Tactical/UGPS"],
		"Utility": ["Default", "Chobham", "Hard Case", "Trauma Kit", "UGPS"],
		"Visor Color": ["Default", "Silver", "Blue", "Gold", "Black"],
		"Knee Guards": ["Default", "Grenadier", "Gungnir", "Operator"],
		"Armor Effect": ["None", "Heart Attack", "Inclement Weather", "Pestilence", "Birthday Party", "Blue Flames"],
		"Firefight Voice": ["Noble Six", "Carter", "Kat", "Jun", "Emile", "Jorge"],
		"Emblem": ["Default"],
		"Colors": ["Steel", "Red", "Blue", "Green", "Orange", "Purple", "Gold", "White", "Black"],
	};
	// Pieces the game knows, by slot: [{ name, id }] and the slot's profile offset (armory-data.js).
	const DATA = {};
	if (window.ARMORY_DATA) {
		const keep = { "Firefight Voice": ARMOR["Firefight Voice"], "Emblem": ARMOR["Emblem"] };
		for (const k of Object.keys(ARMOR)) delete ARMOR[k];
		// Reach's own colors are linear (its profile and visor color tables' floats; armory-data.js holds them as
		// round(f * 255)); the page and everything it sends are sRGB, as shown, and host-probe decodes what it gets
		// (srgb.rs). Shown raw they were darker than the game draws them, and our added colors, picked by eye,
		// came out lighter and paler in games (two-PC test, 2026-10-17; JANK_HUNT.md 14).
		const encode = (hex) => hex.replace(/../g, (h) => {
			const l = parseInt(h, 16) / 255, c = l <= 0.0031308 ? l * 12.92 : 1.055 * Math.pow(l, 1 / 2.4) - 0.055;
			return Math.round(Math.min(1, Math.max(0, c)) * 255).toString(16).padStart(2, "0");
		});
		for (const slot of window.ARMORY_DATA.slots) {
			if (slot.name === "Primary Color") Object.assign(ARMOR, keep);
			ARMOR[slot.name] = slot.items.map(i => i.name);
			DATA[slot.name] = slot;
			for (const item of slot.items) if (item.colors && !item.srgb) {
				for (const k of Object.keys(item.colors)) item.colors[k] = encode(item.colors[k]);
				item.srgb = true;
			}
		}
	}
	const SECTIONS = [
		{ name: "Spartan Armory", items: Object.keys(ARMOR), separator: Object.keys(ARMOR).indexOf("Emblem"), text: "Change the appearance of your Spartan by adding and removing armor." },
		// The Elite's own section (owner, 2026-10-17: out of Player): its pieces, presets and colors.
		{ name: "Elite Armory", items: [], go: window.ELITE_DATA && window.ELITE_DATA.slots ? { kind: "elite" } : { kind: "list", slot: "Elite Armor" },
			text: "Change the appearance of your Elite: helmet, shoulders, chest, forearms, legs and colors." },
		{ name: "Player", items: ["Service Record", "Commendations", "Player Model"], text: "Your service record and commendations." },
		{ name: "File Browser", items: [], text: "Browse your films, screenshots and map and game variants. (Not built yet.)" },
		{ name: "Controller", items: [], page: "controller", text: "See the controller layout." },
		{ name: "Keyboard", items: [], page: "keyboard", text: "See every key and mouse button the game uses, and change them." },
		{ name: "Settings", items: [], page: "audiovideo", text: "Video, audio, keyboard, controller, network and theme settings." },
		{ name: "Theme", items: [], page: "theme", text: "Choose the main menu's backdrop." },
		{ name: "Challenges", items: [], career: "challenges", text: "Complete daily and weekly challenges to earn credits." },
		// The menus' news (PLAN-022, menu-motd.js and changelog-screen.js), as on the main menu.
		{ name: "Message of the Day", items: [], menuMotd: true, text: "The latest word from the Reach Renaissance team." },
		{ name: "What's New", items: [], changelog: true, text: "What changed in each release of Reach Renaissance." },
		{ name: "Network Status", items: [], text: "Shows the state of your connection and the community servers. (Not built yet.)" },
	];
	// A newer release (the launcher's ?update=, update-banner.js): an Update entry, reachable with a
	// controller or the keyboard (the banner's buttons were mouse-only; bug sweep, 2026-10-17).
	{
		const v = new URLSearchParams(location.search).get("update");
		if (v && /^[0-9.]{1,16}$/.test(v)) SECTIONS.push({ name: "Update to " + v, items: [], update: true,
			text: "Install Reach Renaissance " + v + " now: the game closes, updates and comes back. A to start." });
	}
	const STORE = "rr.classic.armory";
	let saved = {};
	try { saved = JSON.parse(localStorage.getItem(STORE) || "{}"); } catch (e) { saved = {}; }

	// Custom armor colors from a color wheel (Primary and Secondary Color). The Armory Spartan shows the
	// exact color; the profile the game gets (matches) holds the nearest of the game's 30 colors, since
	// Reach stores colors as an index there.
	const CUSTOM = "Custom...";
	// Hidden for now (owner, 2026-10-11: "until it works as intended"); set true to bring it back.
	const WHEEL_ENABLED = false;
	const WHEEL_SLOTS = WHEEL_ENABLED ? ["Primary Color", "Secondary Color"] : [];
	// With the wheel hidden, a custom pick falls back to the game color the profile holds.
	if (!WHEEL_ENABLED) for (const slot of ["Primary Color", "Secondary Color"]) if (saved[slot] === "Custom...") delete saved[slot];
	const CUSTOM_STORE = "rr.classic.custom-colors";
	let custom = {};
	try { custom = JSON.parse(localStorage.getItem(CUSTOM_STORE) || "{}"); } catch (e) { custom = {}; }
	for (const slot of WHEEL_SLOTS) if (DATA[slot]) ARMOR[slot] = [...ARMOR[slot], CUSTOM];
	// Extra armor colors beyond Reach's 30 (owner, 2026-10-11: whiter whites, blacker blacks). They show
	// exactly on the Armory Spartan and in matches, where host-probe paints each player's Spartan with
	// that player's own exact colors on every copy (looks.rs, PLAN-016).
	const EXTRA_COLORS = { "Pure White": "ffffff", "Snow": "e6e6e6", "Jet Black": "000000", "Midnight": "080808",
		"Crimson": "a00010", "Royal Blue": "1030c0", "Emerald": "00a040", "Hot Pink": "ff3090",
		"Sunflower": "ffc000", "Neon Orange": "ff5a00", "Electric Purple": "8a20ff", "Sky": "60b8ff",
		"Graphite": "383838", "Sand": "c8a078", "Lime": "9acd32", "Plum": "5a1046", "Magenta": "c0208a", "Bubblegum": "ff9ac8" };
	// The color grid (owner, 2026-10-12: "blacks with blacks, reds with reds ... fade from black to white"):
	// rows of four, one hue per row, dark to light, black at the top and white at the bottom, the
	// game's 30 colors in their own order with ours placed among them.
	const COLOR_ROWS = [
		["Jet Black", "Midnight", "Steel", "Graphite"],
		["Brown", "Tan", "Khaki", "Sand"],
		["Sage", "Olive", "Drab", "Lime"],
		["Forest", "Green", "Emerald", "Sea Foam"],
		["Teal", "Aqua", "Cyan", "Sky"],
		["Blue", "Cobalt", "Royal Blue", "Ice"],
		["Violet", "Orchid", "Electric Purple", "Lavender"],
		["Plum", "Magenta", "Hot Pink", "Bubblegum"],
		["Maroon", "Crimson", "Brick", "Rose"],
		["Rust", "Neon Orange", "Coral", "Peach"],
		["Gold", "Yellow", "Sunflower", "Pale"],
		["Silver", "White", "Snow", "Pure White"],
	];
	const GRID_COLUMNS = 4;
	// Extra visor colors (owner, 2026-10-12: "red, green, maybe purple ... more variety"): the visor's two
	// change colors (tertiary: the tint, quaternary: the reflection), as the game's own visors have.
	// The profile keeps the nearest game visor; the exact one shows on the Armory Spartan and, through
	// host-probe looks.rs, on our Spartan in matches for every player.
	const EXTRA_VISORS = { "RED": ["d02020", "5c0a0a"], "GREEN": ["20c84a", "0a4a1c"], "PURPLE": ["9038e0", "3a1468"],
		"ORANGE": ["ff7a14", "6a2c00"], "CYAN": ["20dce6", "0a4c52"], "PINK": ["ff5ab4", "6a1e48"], "WHITE": ["f0f0f0", "8c8c8c"] };
	if (DATA["Visor Color"]) ARMOR["Visor Color"] = [...ARMOR["Visor Color"], ...Object.keys(EXTRA_VISORS)];
	const visorHex = () => EXTRA_VISORS[saved["Visor Color"]] || null;
	for (const slot of ["Primary Color", "Secondary Color"]) {
		if (!DATA[slot]) continue;
		const known = new Set([...ARMOR[slot], ...Object.keys(EXTRA_COLORS)]);
		const ordered = COLOR_ROWS.flat().filter(n => known.has(n));
		// (any game color missing from the rows keeps a place at the end)
		ARMOR[slot] = [...ordered, ...ARMOR[slot].filter(n => !ordered.includes(n))];
	}
	// The undersuit color (owner, 2026-10-12): any color of the grid, or the stock dark grey ("Default",
	// the last cell). The menu map's undersuit shader takes a tint that host-probe's armory.rs writes
	// (`color.undersuit=`). Menus only for now: matches show the stock undersuit.
	const SUIT = "Undersuit Color", SUIT_DEFAULT = "Default", SUIT_DEFAULT_SWATCH = "2b2c2e";
	if (DATA["Primary Color"]) ARMOR[SUIT] = [...ARMOR["Primary Color"].filter(n => n !== CUSTOM), SUIT_DEFAULT];
	if (ARMOR[SUIT] && !ARMOR[SUIT].includes(saved[SUIT])) saved[SUIT] = SUIT_DEFAULT;
	const suitHex = () => saved[SUIT] && saved[SUIT] !== SUIT_DEFAULT ? swatchOf(SUIT, saved[SUIT]) : null;
	// The exact color for a color slot when it isn't one of the game's 30 (an extra or a wheel pick).
	const customHex = (slot) => EXTRA_COLORS[saved[slot]] || (saved[slot] === CUSTOM && custom[slot]) || null;
	const isColorSlot = (slot) => slot === "Primary Color" || slot === "Secondary Color";
	let wheel = null; // { slot, h, s, v } while the wheel is open
	const hsvToHex = (h, sat, v) => {
		const f = (n) => { const k = (n + h / 60) % 6; return v - v * sat * Math.max(0, Math.min(k, 4 - k, 1)); };
		return [f(5), f(3), f(1)].map(c => Math.round(c * 255).toString(16).padStart(2, "0")).join("");
	};
	const hexToHsv = (hex) => {
		const [r, g, b] = [0, 2, 4].map(i => parseInt(hex.slice(i, i + 2), 16) / 255);
		const max = Math.max(r, g, b), d = max - Math.min(r, g, b);
		let h = 0;
		if (d) h = max === r ? 60 * (((g - b) / d) % 6) : max === g ? 60 * ((b - r) / d + 2) : 60 * ((r - g) / d + 4);
		return { h: (h + 360) % 360, s: max ? d / max : 0, v: max };
	};
	// The game color nearest to an RGB hex (for the profile, which only holds the 30 game colors).
	// The game color an extra color stands for (what the profile holds: other players on the stock game, and the
	// Elite, whose own colors are the profile's). Picked by hand: the nearest by plain RGB made Jet Black and
	// Midnight a dark green or brown (owner, 2026-10-17: "making elites jet black just makes them green"), Plum tan,
	// Graphite sage and Sand and Bubblegum white; Reach's 30 colors are darker than ours, so no single distance
	// picks well for all of them.
	const EXTRA_GAME_COLOR = { "Pure White": "White", "Snow": "White", "Jet Black": "Steel", "Midnight": "Steel",
		"Crimson": "Brick", "Royal Blue": "Ice", "Emerald": "Green", "Hot Pink": "Rose", "Sunflower": "Yellow",
		"Neon Orange": "Coral", "Electric Purple": "Lavender", "Sky": "Ice", "Graphite": "Steel", "Sand": "Khaki",
		"Lime": "Drab", "Plum": "Violet", "Magenta": "Rose", "Bubblegum": "Rose" };
	// CIE Lab (colors as people see them), for a wheel pick's nearest game color.
	function labOf(hex) {
		const [r, g, b] = [0, 2, 4].map(i => { const v = parseInt(hex.slice(i, i + 2), 16) / 255; return v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; });
		const f = t => t > 0.008856 ? Math.cbrt(t) : 7.787 * t + 16 / 116;
		const x = f((r * 0.4124 + g * 0.3576 + b * 0.1805) / 0.95047), y = f(r * 0.2126 + g * 0.7152 + b * 0.0722), z = f((r * 0.0193 + g * 0.1192 + b * 0.9505) / 1.08883);
		return [116 * y - 16, 500 * (x - y), 200 * (y - z)];
	}
	function nearestPreset(slot, hex) {
		const named = Object.keys(EXTRA_GAME_COLOR).find(n => EXTRA_COLORS[n] === String(hex).toLowerCase());
		const fixed = named && DATA[slot].items.find(it => it.name === EXTRA_GAME_COLOR[named]);
		if (fixed) return fixed;
		const want = labOf(hex);
		let best = null, bestD = Infinity;
		for (const it of DATA[slot].items) {
			const c = Object.values(it.colors || {})[0];
			if (!c) continue;
			const d = labOf(c).reduce((a, v, k) => a + (v - want[k]) ** 2, 0);
			if (d < bestD) { bestD = d; best = it; }
		}
		return best;
	}

	let open = false;
	let column = 0;      // 0 sections, 1 items, 2 choices
	let section = 0;
	let item = 0;
	let choice = 0;
	// Start menu section pictures (ui/<name>.png) and the word over them.
	// Where the Armory's Spartan stands: his whole body between the menu's title and the name plate's
	// bottom, right of the menu (owner's marked screenshot, 2026-10-14).
	const ARMORY_FIT = { top: 0.10, bottom: 0.85, cx: 0.667 };
	// Under Wine the page can't be see-through (no DirectComposition: html.opaque, index.html), so the game's own
	// drawing of the Armory's Spartan can't show through it: there the page draws the texture camera's picture of
	// him instead (showSpartan). That picture is already framed where the game draws him, so it isn't fitted.
	const pageOpaque = () => !!(document.documentElement && document.documentElement.classList.contains("opaque"));
	// (Elite Armory takes Reach's Player picture, an Elite; Player shows Noble Six; owner, 2026-10-17)
	const PREVIEWS = { "Spartan Armory": ["armory", "Armory"], "Elite Armory": ["player", "Elite"], "Player": ["new_user", "Player"], "File Browser": ["file_browser", "Files"],
		"Controller": ["controller", "Controls"], "Keyboard": ["controller", "Keyboard"], "Settings": ["audio", "Settings"],
		"Theme": ["placeholder", "Theme"], "Network Status": ["file_browser", "Network"],
		"Message of the Day": ["placeholder", "News"], "What's New": ["placeholder", "What's New"] };
	let armoryScene = null; // the backdrop the game behind shows: "armory" (Spartan), "armory_elite" or null

	const css = `
	.sm { position: fixed; inset: 0; display: none; font-family: var(--font); color: var(--text);
		background: radial-gradient(ellipse at 30% 20%, rgba(52, 72, 92, 0.985), rgba(14, 22, 32, 0.995) 70%); }
	.sm.open { display: block; }
	/* The 360's Start menu background (owner's Xenia references, 2026-10-12): deep teal, lighter behind
	   the lists, Reach's diamond lattice fading in from the top left, Reach's cloud texture drifting
	   faintly over it (ui/background_clouds.png), and a soft vignette (20% lighter than before). */
	.rrbg { position: absolute; inset: 0; z-index: 0 !important; pointer-events: none; overflow: hidden;
		background: radial-gradient(ellipse 80% 75% at 42% 40%, #20404f 0%, #163140 38%, #0d2230 68%, #07131d 100%); }
	.rrbg::before { content: ""; position: absolute; inset: -10%; background: url(ui/background_clouds.png) center / 70% auto repeat;
		opacity: 0.10; mix-blend-mode: screen; animation: rr-clouds 120s linear infinite; }
	@keyframes rr-clouds { from { transform: translateX(0); } to { transform: translateX(10%); } }
	.rrbg .lattice { position: absolute; inset: 0;
		background-image:
			radial-gradient(circle, rgba(170, 215, 245, 0.26) 0.14vh, transparent 0.22vh),
			repeating-linear-gradient(45deg, rgba(150, 200, 235, 0.11) 0 0.09vh, transparent 0.09vh 1.13vh),
			repeating-linear-gradient(-45deg, rgba(150, 200, 235, 0.11) 0 0.09vh, transparent 0.09vh 1.13vh);
		background-size: 1.6vh 1.6vh, auto, auto;
		-webkit-mask-image: radial-gradient(ellipse 55% 60% at 8% 8%, black 0%, rgba(0,0,0,0.55) 45%, transparent 85%);
		mask-image: radial-gradient(ellipse 55% 60% at 8% 8%, black 0%, rgba(0,0,0,0.55) 45%, transparent 85%); }
	.rrbg .vig { position: absolute; inset: 0; background: radial-gradient(ellipse 85% 85% at 50% 45%, transparent 62%, rgba(0, 0, 0, 0.42) 100%); }
	.sm, .ar { background: transparent !important; }
	.sm > *:not(.rrbg) { z-index: 2; }
	.sm .grid, .ar .dots { display: none; }
	/* Over the live Spartan: opaque on the left, see-through on the right. */
	.sm.live .rrbg, .ar:not(.cards):not(.settings) .rrbg {
		-webkit-mask-image: linear-gradient(90deg, black 0%, black 46%, rgba(0,0,0,0.6) 56%, rgba(0,0,0,0.14) 68%, rgba(0,0,0,0.14) 100%);
		mask-image: linear-gradient(90deg, black 0%, black 46%, rgba(0,0,0,0.6) 56%, rgba(0,0,0,0.14) 68%, rgba(0,0,0,0.14) 100%); }
	.sm.live .rrbg { -webkit-mask-image: linear-gradient(90deg, black 0%, black 50%, rgba(0,0,0,0.5) 64%, transparent 74%);
		mask-image: linear-gradient(90deg, black 0%, black 50%, rgba(0,0,0,0.5) 64%, transparent 74%); }
	/* Card pages: everywhere but the preview box, a window onto the live Spartan. */
	.ar.cards .rrbg { -webkit-mask-image: linear-gradient(#000, #000), linear-gradient(#000, #000); -webkit-mask-size: 100% 100%, 29vw 36.5vh;
		-webkit-mask-position: 0 0, 50.3vw 17.5vh; -webkit-mask-repeat: no-repeat; -webkit-mask-composite: xor; mask-composite: exclude; }
	/* The Spartan drawn by the page (figure.js, body.figure): the background is whole again, with the
	   player's emblem large and faint behind him (360), and he stands in front of the lists and plate. */
	body.figure .sm.live .rrbg, body.figure .ar .rrbg { -webkit-mask-image: none !important; mask-image: none !important; }
	body.figure .sm.live { background: transparent; }
	body.figure .ar.cards .box { background: radial-gradient(ellipse 80% 90% at 50% 35%, rgba(46, 84, 104, 0.96), rgba(14, 30, 42, 0.98)); }
	.rrbg .emb { display: none; position: absolute; left: 61vw; top: 41vh; width: 60vh; height: 60vh; transform: translate(-50%, -50%);
		opacity: 0.2; filter: grayscale(1) brightness(1.5); mix-blend-mode: soft-light; }
	body.figure .sm.live .rrbg .emb, body.figure .ar:not(.cards):not(.settings) .rrbg .emb { display: block; }
	/* The game draws the backdrop around him (game-backdrop.js): the page's own is hidden there. */
	body.gamedraw .sm.live .rrbg, body.gamedraw .ar:not(.cards):not(.settings) .rrbg { visibility: hidden; }
	/* The Armor Effect page: the game draws him whole, beside the cards, instead of the preview box (fxPage). */
	body.gamedraw .ar.cards.fxwhole .rrbg, .ar.fxwhole .box { visibility: hidden; }
	.sm .grid { position: absolute; inset: 0; background-image: radial-gradient(rgba(255,255,255,0.05) 1px, transparent 1.5px);
		background-size: 1.1vh 1.1vh; mask-image: linear-gradient(135deg, black, transparent 45%); -webkit-mask-image: linear-gradient(135deg, black, transparent 45%); }
	.sm h1 { position: absolute; left: 20.5vw; top: 6.5vh; margin: 0; font-size: 6vh; font-weight: 700; letter-spacing: 0.02em; }
	.sm .diamond { position: absolute; left: 16.8vw; top: 7.3vh; width: 4.5vh; height: 4.5vh; }
	.sm ul { position: absolute; margin: 0; padding: 0; list-style: none; }
	.sm li { padding: 0.45vh 0.5vw; font-size: 2.5vh; font-weight: 600; letter-spacing: 0.04em; text-transform: uppercase; color: var(--text-dim); }
	.sm li.dim { color: rgba(185, 194, 200, 0.45); }
	.sm li.sel { color: #fff; background: linear-gradient(90deg, rgba(255,255,255,0.16), rgba(255,255,255,0.04) 85%, transparent); box-shadow: inset 0.25vw 0 0 #f2f4f5; }
	.sm li.sep { margin-top: 2.6vh; border-top: 1px solid rgba(255,255,255,0.18); padding-top: 2vh; }
	.sm li .v { float: right; color: #e8ecef; text-transform: none; font-weight: 500; }
	.sm .col0 { left: 20.5vw; top: 14vh; width: 19vw; }
	.sm .col1 { left: 41vw; top: 15vh; width: 18vw; }
	.sm .col1 li { font-size: 2.3vh; }
	.sm .col2 { left: 61vw; top: 15vh; width: 18vw; max-height: 40vh; overflow-y: auto; }
	.sm .col2 li { font-size: 2.2vh; text-transform: none; }
	/* The section's picture (Reach's own Start menu pictures, ui/*.png from scripts/menu/extract_ui_pictures.py)
	   with its name across the bottom and down the side, as on the 360. */
	.sm .preview { position: absolute; left: 61vw; top: 16vh; width: 18vw; height: 38vh; border: 1px solid rgba(255,255,255,0.35);
		background: linear-gradient(160deg, rgba(60, 74, 88, 0.9), rgba(20, 26, 34, 0.9)) center / cover no-repeat; overflow: hidden;
		box-shadow: 0 0.6vh 2.4vh rgba(0,0,0,0.45); }
	.sm .preview .word { position: absolute; left: 0.6vw; right: 0; bottom: 0.4vh; font-size: 7vh; font-weight: 800; line-height: 1; color: rgba(255,255,255,0.16);
		text-transform: uppercase; white-space: nowrap; overflow: hidden; }
	.sm .preview .side { position: absolute; right: 0.5vw; top: 1vh; writing-mode: vertical-rl; font-size: 2.2vh; font-weight: 700; color: rgba(255,255,255,0.28); text-transform: uppercase; }
	.sm .preview svg { position: absolute; left: 50%; top: 52%; transform: translate(-50%, -50%); height: 78%; opacity: 0.55; }
	.sm .desc { position: absolute; left: 61vw; top: 56vh; width: 18vw; font-size: 2.3vh; line-height: 1.3; }

	/* The player card (owner, 2026-10-17): emblem top left, "name - TAG" beside it, rank name bottom left,
	   rank picture at the right; the same box in the Start menu and on every Armory page. */
	.pcard { position: absolute; height: 9vh; background: linear-gradient(90deg, rgba(56,62,68,0.94), rgba(36,40,46,0.88));
		border-top: 1px solid rgba(255,255,255,0.22); box-shadow: 0 0.6vh 2vh rgba(0,0,0,0.35); overflow: hidden; }
	.pcard .em { position: absolute; left: 0.5vw; top: 0.6vh; width: 4.6vh; height: 4.6vh; }
	.pcard .nm { position: absolute; left: calc(1vw + 4.6vh); right: 9vh; top: 0.9vh; font-size: 3.3vh; font-weight: 700; line-height: 1.1;
		white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
	.pcard .nm .tg { color: var(--text-dim); font-weight: 600; }
	.pcard .rk { position: absolute; left: 0.6vw; bottom: 0.7vh; font-size: 2.2vh; line-height: 1; color: var(--text-dim); text-transform: uppercase; letter-spacing: 0.04em; }
	.pcard .rp { position: absolute; right: 0.5vw; top: 0.5vh; width: 8vh; height: 8vh; }
	.sm .pcard { left: 24vw; right: 20vw; top: 77vh; }
	.sm .hints2 { position: absolute; left: 21vw; top: 89vh; display: flex; gap: 1.5vw; font-size: 2.4vh; }
	.sm.live { background: linear-gradient(90deg, rgba(14, 22, 32, 0.985), rgba(14, 22, 32, 0.96) 50%, rgba(14, 22, 32, 0.5) 64%, rgba(0, 0, 0, 0) 74%); }
	.sm.live .preview { display: none !important; }
	.sm.live .col2, .sm.live .desc { left: 54vw; width: 14vw; }
	.sm.live .pcard { right: 33vw; }
	.sm .loading { position: absolute; left: 72vw; top: 46vh; font-size: 2.2vh; letter-spacing: 0.08em; text-transform: uppercase; color: rgba(230, 236, 240, 0.7); display: none; }
	.sm.live.loading .loading { display: block; }
	.sm li .swatch { display: inline-block; width: 1.6vh; height: 1.6vh; margin-right: 0.6vw; vertical-align: -0.2vh; border: 1px solid rgba(255,255,255,0.5); }
	.sm .wheel { position: absolute; left: 54vw; top: 15vh; width: 15vw; display: none; }
	.sm .wheel canvas { width: 15vw; height: 15vw; cursor: crosshair; }
	.sm .wheel .bar { height: 1.6vh; margin-top: 1.2vh; border: 1px solid rgba(255,255,255,0.4); position: relative; }
	.sm .wheel .bar i { position: absolute; top: -0.4vh; width: 0.3vw; height: 2.4vh; background: #fff; }
	.sm .wheel .swatch { height: 4vh; margin-top: 1.2vh; border: 1px solid rgba(255,255,255,0.5); }
	.sm.wheeling .col2 { display: none; }
	.sm.wheeling .wheel { display: block; }
	`;

	const root = document.createElement("div");
	root.className = "sm";
	root.innerHTML = `
		<div class="rrbg"><div class="lattice"></div><canvas class="emb" width="128" height="128"></canvas><div class="vig"></div></div>
		<div class="grid"></div>
		<svg class="diamond" viewBox="0 0 40 40" aria-hidden="true"><path d="M20 2 L38 20 L20 38 L2 20 Z" fill="none" stroke="#7fb3e6" stroke-width="2.5"/><path d="M20 11 L29 20 L20 29 L11 20 Z" fill="none" stroke="#cfe3f5" stroke-width="2"/><circle cx="20" cy="20" r="2.4" fill="#e9f3fb"/></svg>
		<h1>Menu</h1>
		<ul class="col0"></ul>
		<ul class="col1"></ul>
		<ul class="col2"></ul>
		<div class="preview"><div class="side">The Armory</div><div class="word">Armory</div></div>
		<div class="desc"></div>
		<div class="loading">Loading your Spartan...</div>
		<div class="wheel"><canvas width="240" height="240"></canvas><div class="bar"><i></i></div><div class="swatch"></div></div>
		<div class="pcard"></div>
		<div class="hints2"><span class="hint"><span class="btn a">A</span>Select</span><span class="hint"><span class="btn b">B</span>Back</span></div>`;
	// Mouse: click the wheel to pick hue and strength.
	root.querySelector(".wheel canvas").addEventListener("click", (e) => {
		if (!wheel) return;
		const box = e.target.getBoundingClientRect(), dx = (e.clientX - box.left) / box.width * 2 - 1, dy = (e.clientY - box.top) / box.height * 2 - 1;
		wheel.h = (Math.atan2(dy, dx) * 180 / Math.PI + 360) % 360;
		wheel.s = Math.min(1, Math.hypot(dx, dy));
		previewWheel();
		render();
	});
	const style = document.createElement("style");
	style.textContent = css;

	function li(text, cls, value) {
		const e = document.createElement("li");
		e.textContent = text;
		if (cls) e.className = cls;
		if (value) {
			const v = document.createElement("span");
			v.className = "v";
			v.textContent = value;
			e.appendChild(v);
		}
		return e;
	}

	function render() {
		if (window.Emblem) Emblem.paint(root.querySelector(".rrbg .emb"));
		const sec = SECTIONS[section];
		const col0 = root.querySelector(".col0"), col1 = root.querySelector(".col1"), col2 = root.querySelector(".col2");
		col0.innerHTML = col1.innerHTML = col2.innerHTML = "";
		if (window.MenuScroll) col2.classList.add(MenuScroll.CLASS); // (64 helmets: a scroll bar, controls.js)
		SECTIONS.forEach((s, i) => col0.appendChild(li(s.name, i === section ? (column === 0 ? "sel" : "sel") : "")).onclick = () => clickAt(0, i));
		sec.items.forEach((name, i) => {
			const isArmory = section === 0;
			const label = isArmory ? name + "..." : name;
			const e = li(label, [i === item && column >= 1 ? "sel" : "", sec.separator === i ? "sep" : "", column === 0 ? "dim" : ""].join(" ").trim(),
				isArmory && column >= 1 && i === item ? null : null);
			e.onclick = () => clickAt(1, i);
			col1.appendChild(e);
		});
		const preview = root.querySelector(".preview"), desc = root.querySelector(".desc");
		root.classList.toggle("wheeling", !!wheel);
		if (wheel) {
			drawWheel();
			desc.style.top = "57vh";
			desc.textContent = `#${hsvToHex(wheel.h, wheel.s, wheel.v).toUpperCase()} (matches: ${nearestPreset(wheel.slot, hsvToHex(wheel.h, wheel.s, wheel.v)).name}). Left/right hue, up/down strength, LB/RB brightness, A equip.`;
		} else if (column === 2 && section === 0) {
			const slot = sec.items[item];
			preview.style.display = "none";
			ARMOR[slot].forEach((c, i) => {
				const e = li(c, i === choice ? "sel" : "", saved[slot] === c ? "equipped" : "");
				// Color slots: a small swatch before each color.
				const hex = isColorSlot(slot) ? EXTRA_COLORS[c] || Object.values((DATA[slot].items.find(it => it.name === c) || {}).colors || {})[0] : null;
				if (hex) {
					const sw = document.createElement("span");
					sw.className = "swatch";
					sw.style.background = "#" + hex;
					e.prepend(sw);
				}
				e.onclick = () => clickAt(2, i);
				col2.appendChild(e);
			});
			const sel = col2.querySelector(".sel");
			if (sel) sel.scrollIntoView({ block: "nearest" }); // long lists (64 helmets)
			desc.style.top = "57vh";
			desc.textContent = `Choose your ${slot.toLowerCase()}. Left/right or up/down to look, A to equip.`;
		} else {
			preview.style.display = "block";
			// Reach's own picture for the section, its name over it.
			const look = PREVIEWS[sec.name] || ["placeholder", sec.name];
			preview.style.backgroundImage = `url(ui/${look[0]}.png), linear-gradient(160deg, rgba(60, 74, 88, 0.9), rgba(20, 26, 34, 0.9))`;
			// (Noble Six is a full-length cut-out: head to waist, like the other pictures' framing)
			preview.style.backgroundSize = look[0] === "new_user" ? "170% auto, cover" : "";
			preview.style.backgroundPosition = look[0] === "new_user" ? "42% 6%, center" : "";
			preview.querySelector(".side").textContent = sec.name;
			preview.querySelector(".word").textContent = look[1];
			desc.style.top = "56vh";
			if (section === 0 && column === 1) {
				const slot = sec.items[item];
				const shown = saved[slot] === CUSTOM && custom[slot] ? "Custom #" + custom[slot].toUpperCase() : saved[slot] || ARMOR[slot][0];
				const note = isColorSlot(slot) && EXTRA_COLORS[saved[slot]] ? ` Other players see ${nearestPreset(slot, EXTRA_COLORS[saved[slot]]).name}.` : "";
				desc.textContent = `${slot}: ${shown}.${note} ${DATA[slot] ? "" : "(Not applied to the game yet.)"}`;
			} else desc.textContent = sec.text;
		}
		fillCard(root.querySelector(".pcard"));
		// The Elite only once its list is open: scrolling past Elite Armor shouldn't reload the backdrop twice.
		// (Not while a full-screen page is up: it picks its own backdrop, renderPage. The game's answer to a
		// PLAYER change re-rendered this menu under the page and switched the Spartan off, so he dropped
		// behind the page; owner, 2026-10-13.)
		if (!pages.length) showSpartan(section === 0 && column >= 1 ? (sec.items[item] === "Elite Armor" && column === 2 ? "armory_elite" : "armory") : null);
		if (!pages.length && window.Figure) {
			if (pageOpaque()) { Figure.keepRightOf(null); Figure.fitTo(null); } else Figure.fitTo(ARMORY_FIT);
		}
	}

	// The live Spartan: see-through on the right while inside The Armory. The backdrop switch restarts
	// the game (one map per backdrop), so it happens once on the way in and once when the menu closes.
	// scene: "armory" for the Spartan, "armory_elite" for the Elite (while Elite Armor is highlighted).
	// The piece pages (cards) show him in their preview box: the texture camera's picture copied in
	// (figure.js clip), as the game's own drawing can't be fitted into a box (it left the box empty;
	// owner, 2026-10-15).
	let spartanBoxed = false;
	// The Armor Effect page is the exception: Reach's texture camera draws no particles (none of its render flags
	// do), so the box never showed the effect (stranger test, 2026-10-17); there the game draws him whole, as on
	// the Spartan Armory's list (JANK_HUNT.md 10).
	const fxPage = (p) => !!p && p.kind === "pieces" && p.slot === "Armor Effect";
	function showSpartan(scene) {
		const on = !!scene;
		root.classList.toggle("live", on);
		// The game draws him itself, with the page's backdrop drawn into its frame around him and the
		// page see-through over it (game-backdrop.js; owner's pick, 2026-10-14: copying his picture into
		// the page looked hazy and unsteady). Under Wine the page draws the texture camera's picture of him
		// instead, as on the player card (pageOpaque; 2026-10-23 player logs, Proton: its frames reach the page
		// there). (Its `{}` ends a hidden capture of the same camera, index.html keepFigure, which would keep him
		// out of sight.)
		if (window.GameBackdrop && (spartanBoxed || pageOpaque()) && window.Figure) {
			GameBackdrop.hide();
			Figure.want(on ? (spartanBoxed ? "live" : "texcam") : null, on && !spartanBoxed ? {} : undefined);
		} else if (window.GameBackdrop) {
			if (window.Figure) Figure.want(null);
			if (on) GameBackdrop.show(); else GameBackdrop.hide();
		} else if (window.Figure) Figure.want(on ? "live" : null);
		if (on && armoryScene !== scene) {
			armoryScene = scene;
			root.classList.add("loading");
			clearTimeout(showSpartan.timer);
			showSpartan.timer = setTimeout(() => root.classList.remove("loading"), window.INSTANT_SCENES ? 1000 : 6000);
			if (typeof api.onScene === "function") api.onScene(scene);
		}
	}

	function drawWheel() {
		const canvas = root.querySelector(".wheel canvas"), g = canvas.getContext("2d"), r = canvas.width / 2;
		if (!drawWheel.image || drawWheel.v !== wheel.v) {
			const img = g.createImageData(canvas.width, canvas.height);
			for (let y = 0; y < canvas.height; y++) for (let x = 0; x < canvas.width; x++) {
				const dx = x - r, dy = y - r, d = Math.hypot(dx, dy) / r;
				if (d > 1) continue;
				const hex = hsvToHex((Math.atan2(dy, dx) * 180 / Math.PI + 360) % 360, d, wheel.v), o = (y * canvas.width + x) * 4;
				img.data[o] = parseInt(hex.slice(0, 2), 16); img.data[o + 1] = parseInt(hex.slice(2, 4), 16); img.data[o + 2] = parseInt(hex.slice(4, 6), 16); img.data[o + 3] = 255;
			}
			drawWheel.image = img; drawWheel.v = wheel.v;
		}
		g.putImageData(drawWheel.image, 0, 0);
		const a = wheel.h * Math.PI / 180, x = r + Math.cos(a) * wheel.s * r, y = r + Math.sin(a) * wheel.s * r;
		g.strokeStyle = wheel.v > 0.5 ? "#000" : "#fff"; g.lineWidth = 3; g.beginPath(); g.arc(x, y, 8, 0, Math.PI * 2); g.stroke();
		root.querySelector(".wheel .bar").style.background = `linear-gradient(90deg, #000, #${hsvToHex(wheel.h, wheel.s, 1)})`;
		root.querySelector(".wheel .bar i").style.left = (wheel.v * 100) + "%";
		root.querySelector(".wheel .swatch").style.background = "#" + hsvToHex(wheel.h, wheel.s, wheel.v);
	}
	// While the wheel is open the Spartan shows the color being picked (not saved until A).
	function previewWheel() {
		const keep = { ...custom }, keepSaved = saved[wheel.slot];
		custom[wheel.slot] = hsvToHex(wheel.h, wheel.s, wheel.v);
		saved[wheel.slot] = CUSTOM;
		sendAppearance();
		custom = keep; saved[wheel.slot] = keepSaved;
	}
	function wheelAction(a) {
		const step = { left: [-6, 0, 0], right: [6, 0, 0], up: [0, 0.05, 0], down: [0, -0.05, 0], tabl: [0, 0, -0.05], tabr: [0, 0, 0.05] }[a];
		if (step) {
			wheel.h = (wheel.h + step[0] + 360) % 360;
			wheel.s = Math.max(0, Math.min(1, wheel.s + step[1]));
			wheel.v = Math.max(0, Math.min(1, wheel.v + step[2]));
			previewWheel();
		} else if (a === "select") {
			const hex = hsvToHex(wheel.h, wheel.s, wheel.v), slot = wheel.slot;
			custom[slot] = hex;
			saved[slot] = CUSTOM;
			try { localStorage.setItem(STORE, JSON.stringify(saved)); localStorage.setItem(CUSTOM_STORE, JSON.stringify(custom)); } catch (e) { }
			const preset = nearestPreset(slot, hex);
			if (typeof api.onArmor === "function") api.onArmor("armor:" + DATA[slot].offset.toString(16) + "=" + preset.id.toString(16));
			wheel = null;
			column = 1;
			sendAppearance();
		} else if (a === "back") {
			wheel = null;
			sendAppearance();
		}
		render();
	}

	// Mouse: a click on a section opens it, on an Armory slot opens its list, on a piece equips it.
	function clickAt(col, i) {
		if (wheel) return;
		if (col === 2) { choice = i; return act("select"); }
		if (col === 0) { section = i; column = 0; return act("select"); }
		// (a piece in the Spartan Armory preview: its page, on that row)
		if (col === 1 && section === 0 && window.ARMORY_DATA) {
			if (typeof Sound !== "undefined") Sound.play("select");
			return openPage({ kind: "armory", sel: i });
		}
		item = i;
		column = col;
		// Opening a section, or an Armory slot's list, is the same as pressing A on it.
		if (col === 0 ? SECTIONS[i].items.length : section === 0) return act("select");
		if (typeof Sound !== "undefined") Sound.play("move");
		render();
	}

	function act(a) {
		const sec = SECTIONS[section];
		if (pages.length) return pageAct(a);
		// The controller's Start button closes the menu (index.html "pause"; Tab only opens it).
		if (a === "pause") { if (typeof Sound !== "undefined") Sound.play("details_out"); wheel = null; close(); return; }
		// The Armory and Player open the 360's full-screen pages (when the game's armor data is here).
		if (column === 0 && a === "select" && sec.update) {
			const go = document.querySelector(".upd .go");
			if (go) go.click(); else if (typeof api.onArmor === "function") api.onArmor("update-now");
			return;
		}
		if (column === 0 && (a === "select" || a === "right") && sec.go && (sec.go.kind !== "list" || ARMOR[sec.go.slot])) {
			if (typeof Sound !== "undefined") Sound.play("select");
			if (typeof api.onArmor === "function") api.onArmor("settings?");
			return openPage({ ...sec.go });
		}
		if (column === 0 && (a === "select" || a === "right") && sec.page) {
			if (typeof Sound !== "undefined") Sound.play("select");
			if (typeof api.onArmor === "function") api.onArmor("settings?");
			return openPage({ kind: sec.page });
		}
		if (column === 0 && (a === "select" || a === "right") && sec.career && window.Career) return Career.show(sec.career);
		// (over the Start menu, which stays open under them: B comes back here, as from Career)
		if (column === 0 && (a === "select" || a === "right") && sec.menuMotd && window.MenuMotd) {
			if (typeof Sound !== "undefined") Sound.play("select");
			return MenuMotd.show({ manual: true, from: "start" });
		}
		if (column === 0 && (a === "select" || a === "right") && sec.changelog && window.Changelog) {
			if (typeof Sound !== "undefined") Sound.play("select");
			return Changelog.show({ from: "start" });
		}
		// (without the Armory data, Player's items open career.js's screens)
		if (column === 1 && a === "select" && sec.name === "Player" && window.Career && item < 2) return Career.show(item ? "commendations" : "record");
		if (column === 0 && (a === "select" || a === "right") && window.ARMORY_DATA && (sec.name === "Spartan Armory" || sec.name === "Player")) {
			if (typeof Sound !== "undefined") Sound.play("select");
			return openPage({ kind: sec.name === "Player" ? "player" : "armory" });
		}
		if (wheel) {
			const play = (n) => { if (typeof Sound !== "undefined") Sound.play(n); };
			play(a === "select" ? "select" : a === "back" ? "back" : "change");
			if (a === "start") return; // (Tab opens the menu but doesn't close it; B does)
			return wheelAction(a);
		}
		const play = (n) => { if (typeof Sound !== "undefined") Sound.play(n); };
		if (a === "up" || a === "down") play("move");
		else if (a === "left" || a === "right") play(column === 2 ? "change" : "move");
		else if (a === "select") play("select");
		else if (a === "back") play(column === 0 ? "details_out" : "back");
		// Tab (Start) brings the player in but not out (owner, 2026-10-17): B leaves the menu.
		if (a === "start") return;
		if (column === 0) {
			if (a === "down") section = (section + 1) % SECTIONS.length;
			else if (a === "up") section = (section + SECTIONS.length - 1) % SECTIONS.length;
			else if ((a === "select" || a === "right") && sec.items.length) { column = 1; item = 0; }
			else if (a === "back") { close(); return; }
		} else if (column === 1) {
			if (a === "down") item = (item + 1) % sec.items.length;
			else if (a === "up") item = (item + sec.items.length - 1) % sec.items.length;
			else if ((a === "select" || a === "right") && section === 0) {
				column = 2;
				const slot = sec.items[item];
				choice = Math.max(0, ARMOR[slot].indexOf(saved[slot] || ARMOR[slot][0]));
			}
			else if (a === "back" || a === "left") column = 0;
		} else {
			const list = ARMOR[sec.items[item]];
			if (a === "down" || a === "right") choice = (choice + 1) % list.length;
			else if (a === "up" || a === "left") choice = (choice + list.length - 1) % list.length;
			else if (a === "select" && list[choice] === CUSTOM) {
				const slot = sec.items[item];
				const start = custom[slot] || Object.values((DATA[slot].items.find(i => i.name === saved[slot]) || DATA[slot].items[0]).colors)[0];
				wheel = { slot, ...hexToHsv(start) };
				previewWheel();
			}
			else if (a === "select") {
				const slot = sec.items[item];
				saved[slot] = list[choice];
				try { localStorage.setItem(STORE, JSON.stringify(saved)); } catch (e) { }
				const data = DATA[slot];
				if (data && typeof api.onArmor === "function") {
					// An extra color: the profile (and other players) get the nearest game color.
					const piece = EXTRA_COLORS[list[choice]] ? nearestPreset(slot, EXTRA_COLORS[list[choice]]) : data.items[choice];
					api.onArmor("armor:" + data.offset.toString(16) + "=" + piece.id.toString(16));
					sendAppearance();
				}
				column = 1;
			}
			else if (a === "back") column = 1;
		}
		render();
	}

	function openMenu(draw = true) {
		if (!root.isConnected) {
			if (!style.isConnected) document.head.appendChild(style);
			document.body.appendChild(root);
		}
		open = true;
		column = 0;
		root.classList.add("open");
		if (draw) render();
	}
	function close() {
		closePages();
		open = false;
		root.classList.remove("open", "live", "loading");
		if (window.Figure) Figure.want(null);
		// (the game's own drawing of the page backdrop too: left on, it tinted the main menu blue after
		// Start on an Armory page; owner, 2026-10-14)
		if (window.GameBackdrop) GameBackdrop.hide();
		if (armoryScene) {
			armoryScene = null;
			if (typeof api.onScene === "function") api.onScene(null);
		}
	}
	// The Armory Spartan's model regions for the current picks: `appearance:region=permutation,...`.
	// (PLAYER's gender and species, setLook below; here so sendAppearance can read them from the start)
	const LOOK = { female: 0x27, elite: 0x38 };
	const look = { female: false, elite: false };
	// The Elite's own primary and secondary color (owner, 2026-10-15): Reach has one pair for both, so
	// armor.rs writes these into the profile when Elite is preferred; the Colors page from Elite Armor
	// edits them. { "Primary Color": name, "Secondary Color": name }; eliteColorPreview: a color being
	// looked at on that page's grid.
	var eliteColorPreview = null;
	// The Elite's "Accent/suit glow" (owner, 2026-10-16: "white elite with the red glowing accents"): one
	// color for all of its lights, visor included, any color of the grid, kept exact (not in the profile).
	// host-probe paints the Elite's lights with it, in the Armory and in matches for every player
	// (look.glow=, glow.rs and looks.rs, --elite-looks). Unset: each armor's own light color.
	const GLOW = "Elite Glow";
	// The helmet page's Visor row: on once the menu map that marks the Ranger visor's light ships.
	const VISOR_ROW = false;
	const glowHex = () => { const n = eliteColors()[GLOW]; return n ? swatchOf("Primary Color", n) : null; };
	// Each piece's own primary and secondary over the Elite's colors (owner, 2026-10-16: "more piece by piece color
	// customization"), any color of the grid, kept exact: look.piece.<piece>=<primary>_<secondary> (host-probe
	// piece.rs, --elite-pieces), "none" where it keeps the Elite's color.
	// The Elite Armor page's Preset row (owner, 2026-10-17: hidden for now).
	const ELITE_PRESETS_SHOWN = false;
	const ELITE_PIECES = [["helmet", "Helmet"], ["left_shoulder", "Left Shoulder"], ["right_shoulder", "Right Shoulder"],
		["chest", "Chest"], ["forearms", "Forearms"], ["legs", "Legs"]];
	const pieceSlot = (key, k) => "Elite Piece " + key + (k ? " Secondary" : " Primary");
	const PIECE_SLOTS = ELITE_PIECES.flatMap(([key]) => [pieceSlot(key, 0), pieceSlot(key, 1)]);
	// The Elite's colors kept exact (rgb), not in the profile.
	const EXACT = new Set([GLOW, ...PIECE_SLOTS]);
	const exactHex = (slot) => { const n = eliteColors()[slot]; return n ? swatchOf("Primary Color", n) : null; };
	function eliteColors() {
		let c = {};
		try { c = JSON.parse(localStorage.getItem("rr.classic.elitecolors") || "{}"); } catch (e) { c = {}; }
		if (eliteColorPreview) c[eliteColorPreview.slot] = eliteColorPreview.name;
		return c;
	}
	// The look last sent (the appearance line): Credits Earned's kept cut-out is for this look only.
	let lookKey = "";
	function sendAppearance() {
		const pairs = [];
		for (const [slot, data] of Object.entries(DATA)) {
			if (isColorSlot(slot) && customHex(slot)) {
				pairs.push("color." + (slot === "Primary Color" ? "primary" : "secondary") + "=" + customHex(slot));
				continue;
			}
			if (slot === "Visor Color" && visorHex()) {
				pairs.push("color.tertiary=" + visorHex()[0], "color.quaternary=" + visorHex()[1]);
				continue;
			}
			const piece = data.items.find(i => i.name === saved[slot]) || data.items[0];
			if (slot === "Elite Armor" && eliteRegions().length) continue;
			// The Elite's pieces go to the Armory Elite (host-probe reads `elite.` lines in that scene).
			const prefix = slot === "Elite Armor" ? "elite." : "";
			for (const [region, permutation] of Object.entries((piece && piece.regions) || {})) pairs.push(prefix + region + "=" + permutation);
			// Armor and visor colors (RGB) for the Armory Spartan's change colors.
			for (const [which, rgb] of Object.entries((piece && piece.colors) || {})) pairs.push("color." + which + "=" + rgb);
		}
		pairs.push(...eliteRegions());
		// The emblem for matches (host-probe draws it where the game asks for a player's emblem).
		if (window.Emblem) pairs.push("emblem=" + Emblem.code());
		// The body by PLAYER's gender, as Reach's player_model_customization does it ("female spartan
		// selections": body and arms female); arms a wrist piece sets win (owner, 2026-10-14).
		pairs.push("body=" + (look.female ? "female" : "default"));
		if (!pairs.some(x => x.startsWith("arms="))) pairs.push("arms=" + (look.female ? "female" : "default"));
		// Matches: the profile holds the nearest game color; host-probe paints our Spartan with the exact
		// color and shares it with the other players (looks.rs):
		// look.colors=<primary|->,<secondary|->,<visor tint|->,<visor reflection|->.
		if (ARMOR[SUIT]) pairs.push("color.undersuit=" + (suitHex() || "default"));
		// The Elite's own colors exact, as the Spartan's (owner, 2026-10-17: the added colors on Elites too): the
		// Armory Elite wears them (elite_color.), and matches get them through host-probe looks.rs (look.elite=
		// <primary>_<secondary>, shared with RR-LOOK3); the profile keeps the nearest game color (eliteColorEquip,
		// EXTRA_GAME_COLOR) for players without it.
		const eliteExact = [];
		for (const [slot, which] of [["Primary Color", "primary"], ["Secondary Color", "secondary"]]) {
			if (!DATA[slot]) continue;
			const own = eliteColors()[slot];
			const preset = (name) => { const it = DATA[slot].items.find(i => i.name === name); return it && Object.values(it.colors || {})[0]; };
			const hex = own ? (EXTRA_COLORS[own] || preset(own)) : customHex(slot) || preset(saved[slot]) || preset(DATA[slot].items[0].name);
			if (hex) pairs.push("elite_color." + which + "=" + hex);
			eliteExact.push(hex || "none");
		}
		if (eliteExact.length === 2) pairs.push("look.elite=" + eliteExact.join("_"));
		if (glowHex()) pairs.push("look.glow=" + glowHex());
		for (const [key] of ELITE_PIECES) {
			const hex = [0, 1].map(k => exactHex(pieceSlot(key, k)));
			if (hex.some(h => h)) pairs.push("look.piece." + key + "=" + hex.map(h => h || "none").join("_"));
		}
		// (Elite preferred: the profile's one color pair holds the Elite's, armor.rs, so the Spartan's own go along
		// exact even when they are game colors; campaign's Noble Six wore the Elite's; JANK_HUNT.md 8)
		const spartanHex = (slot) => customHex(slot) || (look.elite ? swatchOf(slot, saved[slot]) : null);
		const looks = [...["Primary Color", "Secondary Color"].map(slot => spartanHex(slot) || "-"), ...(visorHex() || ["-", "-"])];
		if (looks.some(c => c !== "-")) pairs.push("look.colors=" + looks.join(","));
		if (pairs.length && typeof api.onArmor === "function") api.onArmor("appearance:" + pairs.join(","));
		lookKey = pairs.join(",");
		rowPrimaries = { spartan: customHex("Primary Color") || swatchOf("Primary Color", saved["Primary Color"]),
			elite: /^[0-9a-fA-F]{6}$/.test(eliteExact[0] || "") ? eliteExact[0] : null };
		paintPlayerRow();
	}
	// The party list's player row takes the primary color, as on the 360 (it was always brown; owner, 2026-10-13,
	// with black armor): the Elite's own when playing as an Elite (the card showed a green Elite in a brown row,
	// the Spartan's color; owner, 2026-10-17). Again whenever the species changes.
	var rowPrimaries; // { spartan, elite } (sendAppearance; a var: it may run before this line)
	function paintPlayerRow() {
		if (!rowPrimaries) return;
		const primary = (look.elite && rowPrimaries.elite) || rowPrimaries.spartan;
		if (primary) {
			const [r, g, b] = [0, 2, 4].map(k => parseInt(primary.slice(k, k + 2), 16));
			document.documentElement.style.setProperty("--player-row", `rgba(${r}, ${g}, ${b}, 0.92)`);
			// (light colors get dark text)
			document.documentElement.style.setProperty("--player-row-text", 0.299 * r + 0.587 * g + 0.114 * b > 150 ? "#14181c" : "#fff");
		}
	}
	// PLAYER's gender and species (owner, 2026-10-13): one-byte profile fields the overlay writes
	// (armor.rs: +0x27 female, +0x38 Elite; +0x64 MCC's gender item, which picks the body in games,
	// 0xC0 male / 0xC1 female, and which armor.rs also keeps in step with +0x27).
	// With Elite preferred, a gender change shows the Spartan for 3 seconds, then the Elite again
	// (owner, 2026-10-14).
	let spartanUntil = 0;
	function setLook(which, on) {
		look[which] = on;
		if (which === "female") {
			sendAppearance();
			if (look.elite) {
				spartanUntil = Date.now() + 3000;
				setTimeout(() => { if (pages.length && pages[pages.length - 1].kind === "player") renderPage(); }, 3050);
			}
		}
		if (which === "elite") paintPlayerRow();
		if (typeof api.onArmor !== "function") return;
		api.onArmor("armor:" + LOOK[which].toString(16) + "=" + (on ? 1 : 0) + (which === "female" ? ",64=" + (on ? "c1" : "c0") : ""));
	}
	// The service tag: the saved one (tag-prompt.js), else what host-probe makes from the name.
	const serviceTag = () => settingsState.tag
		|| ((document.getElementById("player") || {}).textContent || "Player").replace(/[^A-Za-z0-9]/g, "").slice(0, 4).toUpperCase();
	// The player card (.pcard): emblem, "name - TAG", rank name and rank picture.
	function fillCard(el) {
		if (!el) return;
		const name = ((document.getElementById("player") || {}).textContent || "Player").trim();
		const rank = window.Ranks ? Ranks.of(Ranks.credits()) : null;
		// The emblem's CSS is 4.6vh square. Size it from the viewport, avoiding
		// clientWidth/clientHeight layout flushes immediately after replacing the card.
		const px = Math.max(32, Math.min(512, Math.round(innerHeight * 0.046 * (devicePixelRatio || 1))));
		el.innerHTML = `<div class="em painted"><canvas class="embc" width="${px}" height="${px}" style="width:100%;height:100%;display:block"></canvas></div><div class="nm"></div><div class="rk"></div><div class="rp"></div>`;
		el.querySelector(".nm").textContent = name;
		const tag = document.createElement("span");
		tag.className = "tg";
		tag.textContent = " - " + serviceTag();
		el.querySelector(".nm").appendChild(tag);
		el.querySelector(".rk").textContent = rank ? rank.name : "Recruit";
		if (rank) el.querySelector(".rp").style.cssText = Ranks.picture(rank);
		if (window.Emblem) Emblem.paint(el.querySelector(".em canvas"));
	}
	// `armor-state:<offset>=<id>,...` from the overlay: what the game's profile holds now.
	function armorState(text) {
		for (const pair of text.split(",")) {
			const [off, id] = pair.split("=").map(v => parseInt(v, 16));
			// (saved Elite pieces from before eliteSet: the profile's Elite armor follows them, once)
			let picked = false;
			try { picked = !!localStorage.getItem(ELITE_STORE); } catch (e) { }
			if (off === 0x8C && ELITE && picked && id !== eliteSet().id && typeof api.onArmor === "function")
				api.onArmor("armor:8c=" + eliteSet().id.toString(16));
			if (off === LOOK.female) look.female = id === 1;
			if (off === LOOK.elite) { look.elite = id === 1; paintPlayerRow(); }
			if (off === VOICE_OFFSET) {
				const v = FF.find(x => VOICE_IDS[x.key] === id);
				if (v) saved[VOICE_SLOT] = v.name;
			}
			for (const [slot, data] of Object.entries(DATA)) {
				if (slot === "Elite Armor" && window.ELITE_DATA) continue; // (shown from the Elite's chest, eliteEquip)
				const piece = data.offset === off && data.items.find(i => i.id === id);
				// A custom color stays picked while the profile holds its nearest game color.
				const keepCustom = (isColorSlot(slot) && customHex(slot) && piece && nearestPreset(slot, customHex(slot)) === piece)
					|| (slot === "Visor Color" && visorHex() && piece && nearestPreset(slot, visorHex()[0]) === piece);
				if (piece && !keepCustom) saved[slot] = piece.name;
			}
		}
		sendAppearance();
		if (open) {
			if (pages.length) renderPage();
			else render();
		}
	}
	// ---- Full-screen pages like the 360's (owner's Xenia screenshots, 2026-10-12) ----
	// THE ARMORY: one list beside the live Spartan; HELMET: a card per helmet family; <family>: a card
	// per variant with its price, EQUIPPED and description; list pages for colors, voices and the
	// Elite; PLAYER: the player's settings with Elite Armor. Icons are the supply depot sprites
	// (scripts/menu/extract_armory.py, icons/ next to this file, git-ignored).
	const pages = [];
	const pageRoot = document.createElement("div");
	pageRoot.className = "ar";
	const pageCss = `
	.ar { position: fixed; inset: 0; display: none; font-family: var(--font); color: var(--text);
		background: linear-gradient(90deg, rgba(16, 28, 40, 0.99) 0%, rgba(18, 32, 46, 0.97) 44%, rgba(18, 32, 46, 0.55) 56%, rgba(10, 20, 30, 0.12) 68%, rgba(10, 20, 30, 0.12) 100%); }
	.ar.open { display: block; }
	body.paging .screen, body.paging .shade, body.paging .tag { visibility: hidden; }
	/* Card pages: opaque everywhere except the preview box, a window onto the live Spartan (the box's
	   shadow paints the rest). */
	.ar.cards { background: transparent; }
	.ar > * { z-index: 2; }
	.ar > .box { z-index: 1; }
	.ar .dots { position: absolute; left: 0; top: 0; width: 40vw; height: 60vh; background-image: radial-gradient(rgba(255,255,255,0.05) 1px, transparent 1.5px);
		background-size: 1.1vh 1.1vh; -webkit-mask-image: linear-gradient(135deg, black, transparent 60%); }
	.ar .head { position: absolute; left: 17vw; top: 9vh; display: flex; align-items: center; gap: 0.8vw; }
	.ar .head svg { width: 5.4vh; height: 5.4vh; }
	.ar .head h1 { margin: 0; font-size: 6vh; font-weight: 700; letter-spacing: 0.01em; text-transform: uppercase; }
	.ar .side { position: absolute; left: 16.6vw; top: 16.5vh; writing-mode: vertical-rl; font-size: 3.6vh; font-weight: 700;
		color: rgba(255,255,255,0.13); text-transform: uppercase; letter-spacing: 0.03em; white-space: nowrap; }
	.ar ul { position: absolute; left: 20.5vw; top: 16.5vh; width: 20vw; margin: 0; padding: 0; list-style: none; }
	.ar ul li { padding: 0.35vh 0.4vw; margin-bottom: 0.3vh; font-size: 2.8vh; font-weight: 600; letter-spacing: 0.03em; text-transform: uppercase;
		color: var(--text-dim); cursor: pointer; display: flex; justify-content: space-between; align-items: center; }
	.ar ul li.sel { color: #fff; background: linear-gradient(90deg, rgba(255,255,255,0.15), rgba(255,255,255,0.05) 85%, transparent); box-shadow: inset 0.2vw 0 0 #f2f4f5; }
	.ar ul li.sep { margin-top: 2.2vh; border-top: 1px solid rgba(255,255,255,0.2); padding-top: 1.8vh; }
	.ar ul li.off { color: rgba(185,194,200,0.42); }
	.ar ul li .v { color: #e8ecef; text-transform: none; font-weight: 500; }
	.ar ul li .swatch { display: inline-block; width: 2vh; height: 2vh; margin-right: 0.6vw; vertical-align: -0.3vh; border: 1px solid rgba(255,255,255,0.55); }
	.ar ul li .eq { font-size: 1.8vh; color: #e8ecef; }
	/* The Elite armor pages: a piece name beside each slot; the presets' search box above their list. */
	.ar ul.el { width: 29vw; }
	.ar ul.el li > span:first-child { white-space: nowrap; }
	.ar ul.el li { display: flex; justify-content: space-between; gap: 1vw; }
	.ar ul.el li .val, .ar ul.el li .eq { text-transform: none; font-weight: 500; color: #e8ecef; }
	.ar ul.el.search { top: 22vh; }
	.ar .esearch { position: absolute; left: 20.5vw; top: 16.5vh; width: 26.2vw; padding: 0.6vh 0.4vw; font-size: 2.6vh;
		background: rgba(10, 18, 26, 0.6); border: 1px solid rgba(255,255,255,0.35); }
	.ar .esearch b { font-weight: 400; animation: esblink 1s steps(1) infinite; }
	.ar .esearch i { color: rgba(185,194,200,0.6); font-style: normal; margin-left: 0.4vw; }
	@keyframes esblink { 50% { opacity: 0; } }
	.ar .about.el { width: 29vw; }
	/* Firefight voices: the depot's portraits on the cards. */
	.ar.portraits .card img { object-fit: cover; object-position: 50% 20%; }
	/* Settings pages (Audio Video, Keyboard, Controller, the in-game menu): a wider list with values,
	   scrolling when long, over a darkened backdrop (the match shows through in game). */
	.ar.settings { background: linear-gradient(90deg, rgba(4,8,12,0.88), rgba(4,8,12,0.6) 60%, rgba(4,8,12,0.35)); }
	.ar.settings ul { width: 38vw; max-height: 56vh; overflow-y: auto; }
	.ar.settings ul li .val { color: #e8ecef; font-weight: 500; text-transform: none; white-space: nowrap; margin-left: 1vw; }
	.ar.settings .about { left: 60vw; top: 16.5vh; width: 22vw; }
	/* The match's menu: what is being played (owner, 2026-10-21: "game mode and map and mod (or no mod)"), at the
	   top of the right column, the highlighted row's text under it. Clear of the chat dock (chat.js, right 2vw,
	   bottom 14vh in the game menu) and of the list on the left. */
	.ar .match { position: absolute; left: 60vw; top: 16.5vh; width: 22vw; padding-bottom: 1.4vh; border-bottom: 1px solid rgba(255,255,255,0.18); }
	.ar .match div { display: flex; justify-content: space-between; gap: 1vw; padding: 0.3vh 0; font-size: 2.3vh; line-height: 1.25; }
	.ar .match span { color: var(--text-dim); text-transform: uppercase; letter-spacing: 0.04em; font-weight: 600; white-space: nowrap; }
	.ar .match b { color: #e8ecef; font-weight: 500; text-align: right; overflow-wrap: anywhere; }
	.ar .match b.none { color: rgba(185,194,200,0.6); }
	.ar.settings .match ~ .about { top: 31vh; border-top: none; }
	/* The settings screen (owner 2026-10-12: "more modern and organized"): one SETTINGS page with tabs
	   (LB/RB, Q/E or a click), the rows in titled groups, values in boxes on the right (key caps for
	   bindings), and a side panel about the highlighted row. */
	.ar.tabbed ul { top: 23vh; width: 44vw; max-height: 51vh; padding-right: 0.6vw; }
	.ar .tabs { position: absolute; left: 20.5vw; top: 16.5vh; display: flex; gap: 0.3vw; border-bottom: 1px solid rgba(255,255,255,0.22); width: 44vw; }
	.ar .tabs .tab { padding: 0.7vh 1.3vw 0.9vh; font-size: 2.3vh; font-weight: 600; letter-spacing: 0.08em; text-transform: uppercase;
		color: rgba(214,222,228,0.62); cursor: pointer; border-bottom: 0.35vh solid transparent; margin-bottom: -1px; }
	.ar .tabs .tab:hover { color: #e8ecef; }
	.ar .tabs .tab.on { color: #fff; border-bottom-color: #f2f4f5; background: linear-gradient(0deg, rgba(255,255,255,0.1), transparent); }
	.ar .tabs .lb, .ar .tabs .rb { align-self: center; font-size: 1.7vh; color: rgba(214,222,228,0.5); border: 1px solid rgba(214,222,228,0.35);
		border-radius: 0.4vh; padding: 0 0.4vw; margin: 0 0.3vw; }
	.ar.tabbed ul li.grp { margin: 1.6vh 0 0.6vh; padding: 0 0 0.4vh; font-size: 1.8vh; font-weight: 600; letter-spacing: 0.16em; color: rgba(160,190,214,0.85);
		border-bottom: 1px solid rgba(160,190,214,0.25); background: none; box-shadow: none; cursor: default; }
	.ar.tabbed ul li.grp:first-child { margin-top: 0.4vh; }
	.ar.tabbed ul li[data-i] { display: flex; align-items: center; justify-content: space-between; font-size: 2.4vh; font-weight: 500;
		text-transform: none; letter-spacing: 0.02em; padding: 0.55vh 0.6vw; min-height: 3.6vh; }
	.ar.tabbed ul li .val { min-width: 13vw; text-align: center; padding: 0.35vh 0.6vw; border: 1px solid rgba(255,255,255,0.22);
		background: rgba(10,18,26,0.55); font-size: 2.1vh; }
	.ar.tabbed ul li.sel .val { border-color: rgba(255,255,255,0.6); background: rgba(30,44,58,0.75); }
	/* A setting is chosen first (A or a click), then its arrows change it (stranger test, 2026-10-17):
	   only the row being changed shows them, lit, and they can be clicked. */
	.ar ul li .val.editing { display: inline-flex; align-items: center; justify-content: space-between; gap: 0.4vw;
		border-color: #f2f4f5 !important; background: rgba(52,84,112,0.9) !important; color: #fff; box-shadow: 0 0 0 1px rgba(242,244,245,0.6), 0 0 1.2vh rgba(150,200,240,0.35); }
	.ar ul li .val .arr { cursor: pointer; font-weight: 700; padding: 0 0.45vw; color: #fff; animation: rrnudge 1.1s ease-in-out infinite; }
	.ar ul li .val .arr.l { animation-name: rrnudgel; }
	.ar ul li .val .arr:hover { color: #9fd0ff; }
	.ar ul li .val .vt { flex: 1; text-align: center; cursor: pointer; }
	@keyframes rrnudge { 50% { transform: translateX(0.25vw); } }
	@keyframes rrnudgel { 50% { transform: translateX(-0.25vw); } }
	.ar.tabbed ul li .val.key { min-width: 9vw; font-family: inherit; letter-spacing: 0.04em; box-shadow: inset 0 -0.3vh 0 rgba(255,255,255,0.12); }
	.ar.tabbed ul li .val.key.none { color: rgba(214,222,228,0.45); }
	.ar.tabbed ul li .val.wait { border-color: #f2f4f5; color: #fff; animation: rrpulse 0.9s ease-in-out infinite alternate; }
	@keyframes rrpulse { from { background: rgba(30,44,58,0.6); } to { background: rgba(90,120,150,0.6); } }
	.ar.tabbed ul li .val.pick, .ar.tabbed ul li .val.key { cursor: pointer; }
	/* Settings being applied (owner, 2026-10-16): a spinner while they go to the game, then which landed
	   and which wait for the next game, under the side panel. */
	.ar .applying { position: absolute; left: 67vw; top: 66vh; width: 19vw; display: none; align-items: flex-start; gap: 0.7vw;
		font-size: 2vh; line-height: 1.25; color: #e8ecef; }
	.ar .applying.on { display: flex; animation: rrfadein 0.15s ease-out; }
	.ar .applying .spin { flex: none; width: 1.7vh; height: 1.7vh; margin-top: 0.15vh; border: 0.28vh solid rgba(255,255,255,0.25);
		border-top-color: #f2f4f5; border-radius: 50%; animation: rrspin 0.8s linear infinite; }
	.ar .applying.done .spin { border: none; animation: none; width: auto; height: auto; margin: 0; }
	.ar .applying.done .spin::before { content: "✓"; color: rgba(150,215,160,0.95); font-size: 2.1vh; }
	.ar .applying .later { display: block; color: rgba(240,205,130,0.95); font-size: 1.8vh; margin-top: 0.3vh; }
	@keyframes rrspin { to { transform: rotate(360deg); } }
	@keyframes rrfadein { from { opacity: 0; } to { opacity: 1; } }
	.ar.tabbed .about { left: 67vw; top: 23vh; width: 18vw; border-top: none; border-left: 1px solid rgba(255,255,255,0.18); padding: 0 0 0 1.2vw; }
	.ar.tabbed .about b { display: block; font-size: 2.6vh; font-weight: 600; text-transform: uppercase; letter-spacing: 0.04em; margin-bottom: 1vh; }
	.ar.tabbed .about i { display: block; font-style: normal; font-size: 2vh; color: rgba(214,222,228,0.6); margin-top: 1.4vh; }
	.ar.tabbed .about i.warn { color: rgba(240,205,130,0.95); }
	.ar.tabbed .tprev { left: 67vw; top: 23vh; width: 18vw; height: 10.125vw; }
	.ar.tabbed .tprev ~ .about { top: calc(23vh + 10.125vw + 2vh); width: 18vw; }
	/* Theme page: the highlighted theme's picture above its description. */
	.ar .tprev { position: absolute; left: 60vw; top: 16.5vh; width: 26vw; height: 14.625vw; background: #0b1118 center / cover no-repeat;
		border: 1px solid rgba(255,255,255,0.4); box-shadow: 0 0.6vh 2.4vh rgba(0,0,0,0.5); }
	.ar .tprev.wait::after, .ar .tprev.nopic::after { content: "Loading preview..."; position: absolute; inset: 0; display: flex; align-items: center; justify-content: center;
		font-size: 2.2vh; color: rgba(255,255,255,0.55); }
	.ar .tprev.nopic::after { content: "No preview under Wine"; }
	.ar.settings .tprev ~ .about { top: calc(16.5vh + 14.625vw + 2vh); width: 26vw; }
	.ar .about { position: absolute; left: 20.5vw; width: 19vw; top: 52vh; border-top: 1px solid rgba(255,255,255,0.18); padding-top: 1.8vh; font-size: 2.6vh; line-height: 1.3; }
	.ar .sub { position: absolute; left: 20.8vw; top: 16.5vh; font-size: 3vh; font-weight: 600; text-transform: uppercase; letter-spacing: 0.03em; }
	.ar .cname { position: absolute; left: 41.5vw; width: 18.5vw; top: 17.5vh; text-align: right; font-size: 3vh; font-weight: 500; }
	.ar ul.cl { top: 22.5vh; width: 20vw; border-top: 1px solid rgba(255,255,255,0.2); padding-top: 1vh; }
	/* (a short note at a row's right: the Undersuit's "Menus only") */
	.ar ul.cl li .aside { font-size: 1.9vh; font-weight: 500; text-transform: none; letter-spacing: 0.02em; white-space: nowrap; color: rgba(214,222,228,0.6); }
	.ar .about.cl { top: 51.5vh; } /* (below the six color slots) */
	.ar .grid3 { position: absolute; left: 41.5vw; top: 22.5vh; width: 18.5vw; display: grid; grid-template-columns: repeat(4, 1fr); gap: 0.4vh 0.35vw;
		border-top: 1px solid rgba(255,255,255,0.2); padding-top: 1vh; }
	.ar .grid3 .cell { height: 3.6vh; cursor: pointer; opacity: 0.92; }
	/* The grid's scroll bar when it has more rows than show (owner, 2026-10-14: "clearly indicating"). */
	.ar .gscroll { position: absolute; left: 60.4vw; width: 0.45vw; background: rgba(255,255,255,0.12); border-radius: 0.3vw; }
	.ar .gscroll i { position: absolute; left: 0; right: 0; background: rgba(235,240,245,0.85); border-radius: 0.3vw; }
	.ar .grid3 .cell.eq { box-shadow: inset 0 0 0 0.25vh rgba(255,255,255,0.55); }
	.ar .grid3 .cell.on { transform: scale(1.12); box-shadow: 0 0 0 0.3vh #f2f4f5, 0 0.6vh 1.4vh rgba(0,0,0,0.6); opacity: 1; position: relative; z-index: 1; }
	.ar .cardlist { position: absolute; left: 20.6vw; top: 16.4vh; width: 27.5vw; }
	.ar .card { position: relative; height: 18.4vh; margin-bottom: 0.6vh; background: linear-gradient(180deg, rgba(60, 76, 92, 0.55), rgba(40, 54, 68, 0.55));
		cursor: pointer; overflow: hidden; }
	.ar .card.sel { background: linear-gradient(180deg, rgba(120, 136, 150, 0.6), rgba(84, 100, 116, 0.6)); box-shadow: inset 0.2vw 0 0 #f2f4f5; }
	.ar .card .n { position: absolute; left: 1vw; top: 0.8vh; font-size: 2.9vh; font-weight: 600; letter-spacing: 0.02em; }
	.ar .card .r { position: absolute; right: 0.6vw; top: 1vh; font-size: 2.5vh; font-weight: 600; }
	.ar .card img { position: absolute; left: 50%; top: 58%; height: 13.5vh; transform: translate(-50%, -50%); }
	.ar .card .vsw { position: absolute; left: 50%; top: 58%; width: 16vh; height: 7vh; transform: translate(-50%, -50%); border-radius: 3.5vh 3.5vh 1.2vh 1.2vh;
		box-shadow: inset 0 0 1.4vh rgba(255,255,255,0.35), 0 0 1vh rgba(0,0,0,0.5); }
	.ar .card .arrow { position: absolute; right: 1.2vw; top: 42%; font-size: 5vh; font-weight: 300; color: rgba(255,255,255,0.35); }
	.ar .card.sel .arrow { color: #fff; }
	.ar .more { position: absolute; left: 48.4vw; font-size: 3vh; color: rgba(255,255,255,0.5); }
	.ar .track { position: absolute; left: 48.65vw; top: 21vh; width: 0.35vw; height: 50vh; background: rgba(255,255,255,0.12); }
	.ar .track i { position: absolute; left: 0; right: 0; background: rgba(240,244,246,0.85); }
	.ar .count { position: absolute; left: 20.6vw; width: 27.5vw; top: 74.2vh; text-align: right; font-size: 2.3vh; font-weight: 600; color: var(--text-dim); letter-spacing: 0.05em; }
	.ar .box { position: absolute; left: 50.3vw; top: 17.5vh; width: 29vw; height: 36.5vh; border: 1px solid rgba(255,255,255,0.4);
		box-shadow: 0 0.6vh 2.4vh rgba(0, 0, 0, 0.5); background: rgba(40, 70, 100, 0.08); }
	.ar .info { position: absolute; left: 50.3vw; top: 54vh; width: 29vw; height: 22vh; background: rgba(30, 44, 58, 0.85); }
	.ar .info .t { position: absolute; left: 1vw; top: 0.6vh; font-size: 4.6vh; font-weight: 700; text-transform: uppercase; }
	.ar .info .f { position: absolute; right: 1vw; top: 1.4vh; font-size: 2.4vh; font-weight: 600; text-transform: uppercase; color: var(--text-dim); }
	.ar .info .d { position: absolute; left: 1vw; right: 1vw; top: 7.4vh; font-size: 2.5vh; line-height: 1.25; color: #dfe5ea; }
	.ar .info .e { position: absolute; right: 1vw; bottom: 1vh; font-size: 2.4vh; font-weight: 600; border-top: 1px solid rgba(255,255,255,0.25); left: 1vw; text-align: right; padding-top: 0.8vh; }
	/* (the bar ends left of the Spartan; owner's marked screenshot, 2026-10-14) */

	/* The player card (owner, 2026-10-17): emblem top left, "name - TAG" beside it, rank name bottom left,
	   rank picture at the right; the same box in the Start menu and on every Armory page. */
	.pcard { position: absolute; height: 9vh; background: linear-gradient(90deg, rgba(56,62,68,0.94), rgba(36,40,46,0.88));
		border-top: 1px solid rgba(255,255,255,0.22); box-shadow: 0 0.6vh 2vh rgba(0,0,0,0.35); overflow: hidden; }
	.pcard .em { position: absolute; left: 0.5vw; top: 0.6vh; width: 4.6vh; height: 4.6vh; }
	.pcard .nm { position: absolute; left: calc(1vw + 4.6vh); right: 9vh; top: 0.9vh; font-size: 3.3vh; font-weight: 700; line-height: 1.1;
		white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
	.pcard .nm .tg { color: var(--text-dim); font-weight: 600; }
	.pcard .rk { position: absolute; left: 0.6vw; bottom: 0.7vh; font-size: 2.2vh; line-height: 1; color: var(--text-dim); text-transform: uppercase; letter-spacing: 0.04em; }
	.pcard .rp { position: absolute; right: 0.5vw; top: 0.5vh; width: 8vh; height: 8vh; }
	/* (bottom right, above and left of Exit, clear of the left column's descriptions; owner, 2026-10-17) */
	.ar .pcard.plate { right: 20vw; width: max(27vw, 52vh); top: 76.5vh; }
	/* The pages showing the Elite (eliteview): the game draws him from x 56vw, with no framing of his own further
	   right as the Spartan's Colors page has, so the plate goes to the left column and the color grid and its name
	   end at 53vw (owner, 2026-10-17: the grid drew over him). */
	.ar.eliteview .pcard.plate { right: auto; left: 20.5vw; }
	.ar.eliteview .grid3, .ar.eliteview .cname { left: 41vw; width: 12vw; }
	.ar.eliteview .gscroll { left: 53.4vw; }
	/* (not on the settings pages and the match's menu: their lists run under it, 2026-10-17 sweep) */
	.ar.settings .pcard.plate { display: none; }
	.ar .keys { position: absolute; left: 17vw; right: 20vw; top: 87vh; display: flex; gap: 1.6vw; font-size: 2.7vh; }
	.ar .keys .exit { margin-left: auto; }
	.ar .keys .hint { cursor: pointer; }
	.ar .btn.rs { background: rgba(255,255,255,0.15); font-size: 1.2vh; }
	`;
	const pageStyle = document.createElement("style");
	pageStyle.textContent = pageCss;
	const DIAMOND = '<svg viewBox="0 0 40 40" aria-hidden="true"><path d="M20 2 L38 20 L20 38 L2 20 Z" fill="none" stroke="#7fb3e6" stroke-width="2.5"/><path d="M20 11 L29 20 L20 29 L11 20 Z" fill="none" stroke="#cfe3f5" stroke-width="2"/><circle cx="20" cy="20" r="2.4" fill="#e9f3fb"/></svg>';
	const ARMORY_LIST = ["Helmet", "Left Shoulder", "Right Shoulder", "Chest", "Wrist", "Utility", "Visor Color", "Knee Guards", "Armor Effect", "Firefight Voice", "Emblem", "Colors"];
	// The MENU's Spartan Armory column previews the page it opens (it listed Elite Armor and the two old
	// color rows, and a click there opened the old in-menu lists; bug sweep, 2026-10-17).
	if (window.ARMORY_DATA) {
		SECTIONS[0].items = ARMORY_LIST.filter(s => s === "Colors" || s === "Emblem" || ARMOR[s]);
		SECTIONS[0].separator = SECTIONS[0].items.indexOf("Emblem");
	}
	const esc = (s) => String(s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
	

	// The entries a page shows: [{ label, value, swatch, off, sep, icon, right, title, text, family, go }].
	// ---- Firefight voices (owner 2026-10-12): the depot's voices with their portraits, a sample of
	// each, and every line the voice speaks in a game (scripts/menu/extract_ff_voices.py, ffvoices-data.js:
	// one audio file per character, lines as [start, length] in seconds). The choice goes into the
	// game's profile (+0x94, armor.rs): the MCC item of each voice, by Reach's own id switch and the
	// order of firefight_globals' `spartan voices` (2026-10-14; it was never sent, so games used the base
	// profile's voice, not the one shown: owner, "my gender is male, but my spartan voice was female").
	// Noble Six speaks with the male or female voice by the Spartan's gender.
	const FF = window.FF_VOICES || [];
	const VOICE_SLOT = "Firefight Voice", VOICE_OFFSET = 0x94;
	const VOICE_IDS = { voices_default: 0xb4, voices_cortana: 0xbe, voices_chief: 0xbf, voices_buck: 0xbc, voices_johnson: 0xbd,
		voices_trooper: 0xbb, voices_carter: 0xba, voices_kat: 0xb8, voices_jun: 0xb6, voices_emile: 0xb7, voices_jorge: 0xb5, voices_dot: 0xb9 };
	function sendVoice(v) {
		if (v && VOICE_IDS[v.key] && typeof api.onArmor === "function") api.onArmor("armor:" + VOICE_OFFSET.toString(16) + "=" + VOICE_IDS[v.key].toString(16));
	}
	let voiceAudio = null, voiceStop = null;
	const voicePrice = new Intl.NumberFormat("en-US");
	const voiceName = (v) => v.name.replace(/\s*\[A\.I\.\]/, "");
	function playClip(character, clip) {
		if (!character || !clip) return;
		if (!voiceAudio) voiceAudio = new Audio();
		const src = character.audio;
		if (!voiceAudio.src.endsWith(src)) voiceAudio.src = src;
		clearTimeout(voiceStop);
		const go = () => {
			voiceAudio.currentTime = clip[0];
			voiceAudio.play().catch(() => { });
			voiceStop = setTimeout(() => voiceAudio.pause(), clip[1] * 1000 + 60);
		};
		if (voiceAudio.readyState >= 1) go(); else voiceAudio.addEventListener("loadedmetadata", go, { once: true });
	}
	function playSample(v) {
		const c = v && v.characters[0];
		if (!c) return;
		const pool = c.samples.length ? c.samples : c.groups.flatMap(g => g.lines.flatMap(l => l.clips));
		playClip(c, pool[Math.floor(Math.random() * pool.length)]);
	}
	function voiceEntries(p) {
		if (p.kind === "voices") {
			const current = saved[VOICE_SLOT];
			return FF.map((v, i) => {
				const equipped = current ? current === v.name || voiceName(v).toUpperCase().startsWith(current.toUpperCase()) : i === 0;
				return { label: voiceName(v), title: voiceName(v), text: v.text, icon: v.icon, voice: v, equipped,
					right: equipped ? "EQUIPPED" : v.cost ? voicePrice.format(v.cost) + " cR" : "" };
			});
		}
		if (p.kind === "voicelines") {
			const list = [];
			p.voice.characters.forEach((c, ci) => c.groups.forEach((g, gi) => g.lines.forEach((l, li) => list.push({
				label: (p.voice.characters.length > 1 ? (c.name.endsWith("fem") ? "Female - " : "Male - ") : "") + g.name + ": " + l.name,
				value: l.clips.length > 1 ? l.clips.length + " takes" : "", sep: li === 0 && (gi > 0 || ci > 0), character: c, line: l,
				text: "A plays this line (again for the next take). " + voiceName(p.voice) + " has " + p.total + " lines." }))));
			return list;
		}
		return null;
	}
	function voicesAct(p, a, list) {
		const e = list[p.sel] || {};
		if (p.kind === "voices") {
			if (a === "star") { playSample(e.voice); return true; }
			if (a === "refresh" && e.voice) {
				playSample(e.voice);
				const total = e.voice.characters.reduce((n, c) => n + c.groups.reduce((m, g) => m + g.lines.length, 0), 0);
				openPage({ kind: "voicelines", voice: e.voice, total });
				return true;
			}
			if (a === "select" && e.voice) {
				saved[VOICE_SLOT] = e.voice.name;
				sendVoice(e.voice);
				try { localStorage.setItem(STORE, JSON.stringify(saved)); } catch (err) { }
				if (typeof Sound !== "undefined") Sound.play("select");
				playSample(e.voice);
				renderPage();
				return true;
			}
		}
		if (p.kind === "voicelines" && a === "select" && e.line) {
			e.take = ((e.line.take ?? -1) + 1) % e.line.clips.length;
			e.line.take = e.take;
			playClip(e.character, e.line.clips[e.take]);
			return true;
		}
		return false;
	}

	// ---- Settings pages (owner 2026-10-12): Audio Video, Keyboard, Controller, and the in-game menu ----
	// Values come from the overlay program (`settings-state:`, its settings.rs); changes go back as
	// `setting:<key>=<value>` and apply the next time a game starts.
	const GFX_KEYS = ["gfx.aa", "gfx.details", "gfx.effects", "gfx.lighting", "gfx.shadows", "gfx.filtering", "gfx.water", "gfx.motionblur"];
	const SETTINGS_KINDS = ["game", "audiovideo", "audio", "gameplay", "keyboard", "controller", "network", "theme", "quick", "quickpick", "presets", "musictrack", "musiclist"];
	// Quick Settings (owner, 2026-10-14): up to 8 settings, picked by the player, on one page of the game
	// menu (setting `quick`, ids: a setting's key or `bind:<action>`); and Settings Presets: slots that
	// keep a copy of the settings (overlay settings.rs). Settings the game can change at once (frame
	// rate, mouse speed, third-person camera) apply during a game (host-probe live.rs).
	const QUICK_DEFAULT = "display;resolution;fps;fov;mouse;camera.distance;bind:camera.toggle;bind:9";
	const QUICK_MAX = 8;
	// The player card Spartan's pose (setting `pose`; scripts/menu/all_scenes.py POSES, same order):
	// Reach's own menu animations (owner, 2026-10-14). Ready, Ready II, Ready III, Posing, Shotgun and Heavy are
	// hidden for now (owner, 2026-10-18: "they seem to be busted"); a saved one shows as Roster, and the overlay
	// program plays Roster for it too (settings.rs HIDDEN_POSES). POSE_EXTRAS_SHOWN brings them back.
	const POSE_EXTRAS_SHOWN = false;
	const POSE_HIDDEN = ["Ready", "Ready II", "Ready III", "Posing", "Shotgun", "Heavy"];
	const POSE = { key: "pose", label: "Player Card Pose", default: "0",
		options: ["Roster", "Ready", "Ready II", "Ready III", "Posing", "Shotgun", "Heavy", "Victory", "Victory II", "Armory"].map((n, i) => [String(i), n])
			.filter(([, n]) => POSE_EXTRAS_SHOWN || !POSE_HIDDEN.includes(n)) };
	// The menu music's settings (music.js; the page plays it, so they apply at once).
	const MENU_MUSIC_KEYS = ["volume.menumusic", "music", "music.track", "music.playlist", "music.shuffle"];
	// What a running game takes at once (host-probe live.rs, 2026-10-16: key bindings and the window too;
	// the picture follows the window's size, host-probe live.rs resize). The field
	// of view and the rest wait for the next game; the controller's look sensitivity too, a map rotation's next
	// game included (host-probe live.rs pad_look; it said "leave and start or join again" before, 2026-10-20
	// player batch, report 11).
	const LIVE = ["fps", "mouse", "camera.distance", "camera.toggle", "camera.shoulder", "pad.camera.toggle", "pad.camera.shoulder", "pad.vibration", "pad.bumpers", "pad.layout", "display", "resolution",
		"chat.team", "chat.general", "chat.toggle", "chat.lines", "chat.size", "chat.width", "chat.fade", "chat.opacity",
		...["a", "b", "x", "y", "lb", "rb", "lt", "rt", "ls", "rs", "up", "down", "left", "right", "back"].map(id => "pad.map." + id),
		"volume.game", "volume.music", "volume.effects", "volume.menu", "subtitles", "vsync", "gfx.preset", ...GFX_KEYS, ...MENU_MUSIC_KEYS,
		"gamma", "ui.gamma", "mouse.accel", "mouse.accel.min", "mouse.accel.max", "mouse.accel.scale", "mouse.accel.power", "mouse.smoothing"];
	const isLive = (key) => LIVE.includes(key) || /^bind\./.test(key);
	const applies = (key) => isLive(typeof key === "number" ? "bind." + key : key) ? "It applies right away, in a game too." : "It applies the next time a game starts.";
	// Applying indicator (owner, 2026-10-16: "some kind of indicator that settings are being changed,
	// especially when a player is changing many settings at once"). Each change is saved by the overlay
	// program (its reply: `settings-state:`); in a game, the ones the game takes at once are confirmed by
	// host-probe (`live=`, what it applied). `changes`: key -> { label, value, state: "saving" |
	// "applying" | "done" | "later" }.
	const changes = new Map();
	let changesShownUntil = 0, changesPoll = null, changesSince = 0;
	// The settings before this visit's changes, for Revert (X): key -> value.
	let original = {};
	const DEFAULTS = { display: "windowed", resolution: "auto", fps: "0", fov: "78", "fov.vehicle": "78", gamma: "5", "ui.gamma": "5",
		crosshair: "centered", jumper: "on", "mouse.accel": "off", "mouse.accel.min": "2", "mouse.accel.max": "80", "mouse.accel.scale": "0", "mouse.accel.power": "1", "mouse.smoothing": "off", mouse: "100", "camera.distance": "100",
		"camera.toggle": "116", "camera.shoulder": "117", "pad.camera.toggle": "34", "pad.camera.shoulder": "40",
		"chat.general": "89", "chat.team": "84", "chat.toggle": "191", "chat.lines": "6", "chat.size": "medium", "chat.width": "normal", "chat.fade": "8", "chat.opacity": "80",
		"volume.game": "100", "volume.music": "100", "volume.effects": "100", "volume.menu": "100", subtitles: "automatic",
		vsync: "off", "gfx.preset": "enhanced", "gfx.aa": "on", "gfx.motionblur": "on",
		...Object.fromEntries(["gfx.details", "gfx.effects", "gfx.lighting", "gfx.shadows", "gfx.filtering", "gfx.water"].map(k => [k, "high"])),
		"volume.menumusic": "100", music: "reach", "music.track": "menu", "music.playlist": "", "music.shuffle": "on",
		...Object.fromEntries(["a", "b", "x", "y", "lb", "rb", "lt", "rt", "ls", "rs", "up", "down", "left", "right", "back"].map(id => ["pad.map." + id, "0"])) };
	const inGame = () => document.body.classList.contains("ingame") || document.body.classList.contains("inmatch");
	const currentValue = (key) => { const b = /^bind\.(\d+)$/.exec(key); return b ? settingsState.binds[+b[1]] : settingsState[key]; };
	// One change from any settings row: saved at once, shown on the indicator, kept for Revert.
	function changeSetting(key, value, label) {
		if (!(key in original)) original[key] = currentValue(key) ?? DEFAULTS[key];
		const b = /^bind\.(\d+)$/.exec(key);
		if (b) settingsState.binds[+b[1]] = String(value); else settingsState[key] = String(value);
		changes.set(key, { label: label || key, value: String(value), state: "saving" });
		changesSince = performance.now();
		if (typeof api.onArmor === "function") api.onArmor("setting:" + key + "=" + value);
		if (window.MenuMusic && MENU_MUSIC_KEYS.includes(key)) MenuMusic.settings(settingsState);
		if (key === "ui.gamma") uiGamma(value);
		showChanges();
	}
	// UI GAMMA over the menus: the same curve host-probe gamma.rs draws over the menus' backdrop game,
	// color ^ 2^((5 - gamma) / 5), as an SVG gamma filter on the page; at 5 no filter at all (a filter
	// on the page is redrawn with everything that moves on it).
	function uiGamma(value) {
		const g = Math.min(10, Math.max(1, +value || 5));
		const root = document.documentElement;
		if (g === 5) { root.style.filter = ""; return; }
		let svg = document.getElementById("ui-gamma-svg");
		if (!svg) {
			svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
			svg.id = "ui-gamma-svg";
			svg.setAttribute("aria-hidden", "true");
			svg.style.cssText = "position:absolute;width:0;height:0";
			svg.innerHTML = `<filter id="ui-gamma" color-interpolation-filters="sRGB"><feComponentTransfer>${["R", "G", "B"].map(c => `<feFunc${c} type="gamma" amplitude="1" offset="0"/>`).join("")}</feComponentTransfer></filter>`;
			document.body.appendChild(svg);
		}
		const exponent = String(Math.pow(2, (5 - g) / 5));
		svg.querySelectorAll("feFuncR, feFuncG, feFuncB").forEach(f => f.setAttribute("exponent", exponent));
		root.style.filter = "url(#ui-gamma)";
	}
	function revertChanges() {
		const keys = Object.keys(original).filter(k => original[k] !== undefined && currentValue(k) !== original[k]);
		const was = original;
		for (const k of keys) changeSetting(k, was[k], (changes.get(k) || {}).label);
		original = {};
		return keys.length;
	}
	const canRevert = () => Object.keys(original).some(k => original[k] !== undefined && currentValue(k) !== original[k]);
	// The overlay's reply (and host-probe's live list): which changes landed.
	let lastLive = {};
	function settleChanges(live) {
		lastLive = live;
		const now = performance.now();
		for (const [key, c] of changes) {
			if (c.state === "done" || c.state === "later") continue;
			if (String(currentValue(key)) !== c.value) { if (now - changesSince > 4000) c.state = "later"; continue; } // (not saved yet)
			if (!inGame() || key === "volume.menu" || key === "ui.gamma" || MENU_MUSIC_KEYS.includes(key)) c.state = "done"; // (the menus' own sounds, music and brightness: this page does them)
			else if (!isLive(key)) c.state = "later";
			else if (live[key] === c.value) c.state = "done";
			// host-probe reads the file four times a second; past 4 s it isn't coming in this game
			else if (now - changesSince > 4000) c.state = "later";
			else c.state = "applying";
		}
		showChanges();
	}
	function showChanges() {
		const el = pageRoot.querySelector(".applying");
		const list = [...changes.values()];
		const busy = list.filter(c => c.state === "saving" || c.state === "applying");
		clearTimeout(changesPoll);
		if (busy.length) {
			changesShownUntil = 0;
			// (ask again until host-probe has applied them; it rewrites its list when it has; with no answer
			// at all, the timeout in settleChanges still ends the wait)
			changesPoll = setTimeout(() => { if (typeof api.onArmor === "function") api.onArmor("settings?"); settleChanges(lastLive); }, 300);
		} else if (list.length && !changesShownUntil) {
			changesShownUntil = performance.now() + 5000;
			changesPoll = setTimeout(() => { changes.clear(); changesShownUntil = 0; showChanges(); }, 5000);
		}
		if (!el) return;
		el.classList.toggle("on", list.length > 0);
		el.classList.toggle("done", list.length > 0 && !busy.length);
		if (!list.length) return;
		const n = (k) => k + (k === 1 ? " change" : " changes");
		const later = list.filter(c => c.state === "later");
		const laterHelp = "Applies when the next game starts: " + later.map(c => c.label).join(", ");
		const done = list.length - busy.length - later.length;
		let text = busy.length ? "Applying " + n(busy.length) + "..." : done ? (inGame() ? n(done) + " applied" : n(done) + " saved") : "";
		if (!busy.length && !done) text = n(later.length) + " saved";
		el.innerHTML = `<span class="spin"></span><span>${esc(text)}${later.length && !busy.length
			? `<span class="later">${esc(laterHelp)}</span>` : ""}</span>`;
	}
	let presetsState = null; // {slot: summary} from the overlay (`presets:`)
	const quickIds = () => (settingsState.quick ?? QUICK_DEFAULT).split(";").filter(Boolean).slice(0, QUICK_MAX);
	// Every setting that can be on the Quick Settings page, with its id.
	function quickCatalog() {
		const rows = [...settingsEntries({ kind: "audiovideo" }), ...settingsEntries({ kind: "audio" }), ...settingsEntries({ kind: "keyboard" }),
			...settingsEntries({ kind: "controller" }).filter(r => r.setting), ...settingsEntries({ kind: "gameplay" })];
		const seen = new Set();
		return rows.map(r => ({ ...r, quick: r.setting ? r.setting.key : "bind:" + r.bind })).filter(r => !seen.has(r.quick) && seen.add(r.quick));
	}
	// The tabs of the settings screen, in order.
	const SETTINGS_TABS = [["audiovideo", "Video"], ["audio", "Audio"], ["gameplay", "Gameplay"], ["keyboard", "Keyboard"], ["controller", "Controller"], ["network", "Network"], ["theme", "Theme"]];
	// Hide My IP (owner, 2026-10-22: a player saw every player's IP in NetLimiter): host-probe announce.rs
	// joins through the server list's relay only, so the host and the other players never get this PC's address.
	const HIDE_IP = { key: "net.hideip", label: "HIDE MY IP", group: "PRIVACY", options: [["off", "Off"], ["on", "On"]], default: "off",
		text: "Join games through the Reach Renaissance server instead of connecting to the host directly, so neither the host nor the other players can see your IP address. The server is in Europe, so this can add noticeable lag (up to about half a second from the Americas), and the Server Browser shows no ping (asking each server directly would show it your IP). Servers on your own local network can still see your local address. When you host with it on, players join you through the same server, so they can't see yours either. With it off, the host sees your IP, and on hosts running an older version other players can too." };
	DEFAULTS[HIDE_IP.key] = HIDE_IP.default;
	// Not offered in 0.1.20 (settings.rs HIDE_IP_OFFERED; owner, 2026-10-23: "Hide it until fixed").
	const HIDE_IP_OFFERED = false;
	// Network tab: Windows Firewall for hosting (host-probe --check-firewall / --fix-firewall through
	// the overlay program). `code`: 0 allowed, 1 blocked or not set up, 2 failed, 3 cancelled.
	let firewall = { code: null, line: "", busy: false };
	function firewallAsk(fix) {
		firewall = { ...firewall, busy: fix ? "fix" : "check" };
		if (typeof api.onArmor === "function") api.onArmor(fix ? "firewall-fix" : "firewall?");
	}
	const tabbed = (p) => SETTINGS_TABS.some(t => t[0] === p.kind);
	// MCC's own Halo: Reach key bindings (owner, 2026-10-16: "our keybinds labels ... should essentially
	// be identical to MCC's"): its sections, order and wording, from this PC's MCC
	// (data/settings/optionsdata.xml, the InputBinding rows enabled for HaloReach, with their text from
	// data/ui/Localization/EN_Global.bin; scripts/menu/extract_mcc_binds.py). Each row: MCC's label, the
	// Reach game action it sets (ACTIONS, MCC's Key<name> matched by name and by MCC's default key), and
	// MCC's description. MCC's Communication rows (text chat, push to talk) aren't game actions.
	const MCC_BINDS = [
		["MOVEMENT", [["MOVE FORWARD", "MoveForward", "Set key to Move Forward."], ["MOVE BACKWARD", "MoveBackward", "Set key to Move Backward."],
			["MOVE LEFT", "StrafeLeft", "Set key to Move Left."], ["MOVE RIGHT", "StrafeRight", "Set key to Move Right."],
			["JUMP", "Jump", "Set key to JUMP."], ["CROUCH", "Crouch", "Set key to CROUCH."]]],
		["ACTIONS", [["FIRE", "Fire", "Set key to FIRE your primary weapon."],
			["ZOOM", "Zoom", "Set key to cycle between magnification levels for weapon scopes. Can be held or toggled."],
			["ZOOM IN", "ZoomIn", "Set key to cycle up to the next magnification level."], ["ZOOM OUT", "ZoomOut", "Set key to cycle down to the previous magnification level."],
			["MELEE", "MeleeAttack", "Set key to MELEE."], ["RELOAD", "Reload", "Set key to RELOAD."], ["THROW GRENADE", "ThrowGrenade", "Set key to THROW GRENADE."],
			["ACTION", "ActionReload", "Set key for primary ACTIONS like interacting, picking up weapons, and entering vehicles."],
			["CHANGE WEAPON", "SwitchWeapon", "Set key to CHANGE WEAPON."], ["SWITCH GRENADES", "SwitchGrenade", "Set key to SWITCH GRENADES."],
			["USE ARMOR ABILITY", "Equipment", "Set key to USE ARMOR ABILITY."], ["TOGGLE NIGHT VISION", "Flashlight", "Set key to TOGGLE NIGHT VISION."]]],
		["VEHICLE CONTROLS", [["VEHICLE FUNCTION 1", "SecondaryFire", "Set key to use vehicle functions like secondary fire, drifting, boosting, and ascending."],
			["VEHICLE FUNCTION 2", "PrimaryVehicleTrick", "Set key to use vehicle functions like braking and hovering."],
			["VEHICLE FUNCTION 3", "SecondaryVehicleTrick", "Set key to use vehicle functions like aerial maneuvers and descending."]]],
		["UI CONTROLS", [["TOGGLE SCOREBOARD", "ShowScores", "Set key to TOGGLE MULTIPLAYER SCOREBOARD."], ["PING NAVPOINTS", "PingNavpoints", "Set key to ping on demand navpoints."],
			["OPEN LOADOUTS MENU", "LoadoutMenu", "Set key to open the LOADOUTS MENU."]]],
		["FORGE", [["ASCEND", "LiftEditor", "Set key to ASCEND while in Editor mode."], ["DESCEND", "DropEditor", "Set key to DESCEND while in Editor mode."],
			["GRAB / RELEASE OBJECT", "GrabObjectEditor", "Set key to GRAB and RELEASE objects while in Editor mode."],
			["BOOST", "BoostEditor", "Set key to BOOST movement speed while in Editor mode."],
			["PRECISION EDIT", "CrouchEditor", "Set key to enter PRECISION EDIT mode while in Editor mode."],
			["DELETE OBJECT", "DeleteObjectEditor", "Set key to DELETE OBJECTS while in Editor mode."],
			["CREATE OBJECT / OBJECT PROPERTIES", "CreateObjectEditor", "Set key to create objects and access their properties while in Editor mode."],
			["TOOLS", "OpenToolMenuEditor", "Set key to access TOOLS menu while in Editor mode."], ["DUPLICATE", "DuplicateObjectEditor", "Set key to DUPLICATE objects while in Editor mode."],
			["RESET", "ResetOrientationEditor", "Set key to RESET object orientation while in Editor mode."],
			["SWITCH PLAYER MODE", "SwitchPlayerModeEditor", "Set key to switch between Player and Editor mode."],
			["ZOOM", "ScopeZoomEditor", "Set key to ZOOM the camera while in Editor mode."],
			["ROTATION MODE", "PlayerLockForManipulationEditor", "Set key to enter Object ROTATION MODE while in Editor mode."],
			["TOGGLE ROTATION AXES", "ToggleRotationAxesEditor", "Set key to switch between global/local rotation axes."]]],
		["THEATER", [["TOGGLE PANEL", "ShowHidePannelTheater", "Set key to toggle visibility of the Theater control panel."],
			["TOGGLE INTERFACE", "ShowHideInterfaceTheater", "Set key to toggle visibility of the player HUD and Theater interface."],
			["TOGGLE FIRST / THIRD PERSON", "ToggleFirstThirdPersonViewTheater", "Set key to toggle between first and third person view."],
			["CAMERA RESET", "CameraFocusTheater", "Set key to reset the camera position while in orbit cam."],
			["JUMP FORWARD", "FastForwardTheater", "Set key to JUMP FORWARD to the next available rewind point."],
			["JUMP BACK", "FastRewindTheater", "Set key to JUMP BACK to the previous rewind point."],
			["PAUSE / RESUME PLAYBACK", "StopContinuePlaybackTheater", "Set key to pause and resume playback."],
			["FAST FORWARD", "PlaybackSpeedUpTheater", "Set key to increase playback speed."],
			["TOGGLE FREECAM", "EnterFreeCameraModeTheater", "Set key to switch the camera between anchored and freecam modes."],
			["BOOST", "MovementSpeedUpTheater", "Set key to BOOST the camera movement speed."], ["THEATER PANNING", "PanningCameraTheater", "Set key to enable panning in Theater mode."],
			["ASCEND", "CameraMoveUpTheater", "Set key to ASCEND the fly cam while in Theater mode."], ["DESCEND", "CameraMoveDownTheater", "Set key to DESCEND the fly cam while in Theater mode."],
			["ZOOM", "ZoomCameraTheater", "Set key to ZOOM the fly camera while in Theater mode."]]],
	];
	// Main menu backdrops (owner 2026-10-12): Reach's title scene by default; the 360 also showed the
	// campaign acts' scenes as the player got further in the campaign.
	const THEMES = [["title", "Reach", "The ring over the mountains, in the rain: the menu Reach starts with."],
		["campaign_act1", "Act I: The Fall", "Fire on the plains, Covenant shields in the valley."],
		["campaign_act2", "Act II: New Alexandria", "The city at night, under attack."],
		["campaign_act3", "Act III: The Pillar of Autumn", "Above the burning planet, a Phantom close by."]];
	const THEME_STORE = "rr.theme";
	// Theme previews (owner, 2026-10-12): a picture of each backdrop, taken from the game the first time
	// that theme is highlighted (the backdrop behind the page switches to it for a moment, figure.js
	// grabs a frame) and kept in localStorage.
	const SHOT_STORE = "rr.themeshot.";
	const shot = (scene) => { try { return localStorage.getItem(SHOT_STORE + scene); } catch (e) { return null; } };
	let previewing = null; // the theme whose backdrop is behind the page for a preview
	function themePreview(scene) {
		const box = pageRoot.querySelector(".tprev");
		if (!box) return;
		const have = shot(scene);
		// (no pictures of the game window under Wine, figure.js: no preview there, and the backdrop isn't
		// switched for one either, which in a match would end it)
		const pictures = !window.Figure || Figure.windowPictures !== false;
		box.classList.toggle("nopic", !have && !pictures);
		box.classList.toggle("wait", !have && pictures);
		box.style.backgroundImage = have ? `url("${have}")` : "";
		if (have || !window.Figure || !pictures || previewing === scene) return;
		previewing = scene;
		if (typeof api.onScene === "function") api.onScene(scene);
		Figure.grab(1500, (url) => {
			if (previewing !== scene) return; // (moved on to another theme meanwhile)
			try { localStorage.setItem(SHOT_STORE + scene, url); } catch (e) { }
			const p = pages[pages.length - 1];
			if (p && p.kind === "theme") themePreview((entries(p)[p.sel] || {}).theme || scene);
		});
	}
	// Leaving the Theme page: the menu's own backdrop again.
	function endPreview() {
		if (!previewing) return;
		previewing = null;
		if (typeof api.onScene === "function") api.onScene(null);
	}
	const theme = () => { try { const t = localStorage.getItem(THEME_STORE); return THEMES.some(x => x[0] === t) ? t : "title"; } catch (e) { return "title"; } };
	let settingsState = { binds: [] };
	let audioDevices = null; // [[endpoint id, name]] from the overlay (`audio-devices:`), asked for once
	// (labels in MCC's own wording: WINDOW MODE, RESOLUTION SETTINGS, FRAMERATE LIMIT, FIELD-OF-VIEW)
	const FOVS = ["70", "78", "85", "90", "95", "100", "110", "120"].map(f => [f, f]);
	const AV = [
		{ key: "display", label: "WINDOW MODE", options: [["windowed", "Windowed"], ["borderless", "Borderless Fullscreen"]] },
		// (21:9 sizes too: the menus' window may be wider than 16:9 since 2026-10-20, player report 22)
		{ key: "resolution", label: "RESOLUTION", options: [["auto", "Automatic"], ...["1280x720", "1600x900", "1920x1080", "2560x1080", "2560x1440", "3440x1440", "3840x2160"].map(r => [r, r.replace("x", " x ")])] },
		{ key: "fov", label: "FIELD-OF-VIEW", options: FOVS, default: "78" },
		{ key: "fps", label: "FRAMERATE LIMIT", options: [["0", "Unlimited"], ...["30", "60", "90", "120", "144", "165", "240"].map(f => [f, f + " FPS"])] },
	];
	// MCC's video rows the menus didn't have (owner, 2026-10-18: "see all of MCC's settings and try to
	// recreate them"), in its wording, ranges and defaults: GAMMA and UI GAMMA (1 to 10, 5; host-probe
	// gamma.rs draws them over the game's picture, the page's own filter over the menus), and THIRD PERSON
	// FIELD-OF-VIEW (70 to 120, 78; the profile's +0x18, beside FIELD-OF-VIEW's +0x14; overlay settings.rs).
	const GAMMA_STEPS = Array.from({ length: 19 }, (_, i) => String(1 + i / 2)).map(v => [v, (+v).toFixed(1)]);
	const GAMMA = { key: "gamma", label: "GAMMA", options: GAMMA_STEPS, default: "5", slider: true, group: "VIDEO SETTINGS",
		text: "Set game brightness." };
	const UI_GAMMA = { key: "ui.gamma", label: "UI GAMMA", options: GAMMA_STEPS, default: "5", slider: true, group: "GENERAL SETTINGS",
		text: "Set menu brightness." };
	const FOV_VEHICLE = { key: "fov.vehicle", label: "THIRD PERSON FIELD-OF-VIEW", options: FOVS, default: "78", group: "VIDEO SETTINGS",
		text: "Set how wide the third-person camera field-of-view appears." };
	// Graphics (owner, 2026-10-17: "graphics presets in the video settings like MCC has with per setting
	// options"): MCC's rows for Reach in its wording, plus MOTION BLUR, which Reach honours though MCC
	// hides it. host-probe graphics.rs hands them to the game, and changes them during a game too.
	// MCC's other video rows can't be done here: texture resolution and blood (Reach never reads them),
	// resolution scale, FSR and sharpening (MCC's own upscaling around the game's picture).
	const LEVEL = [["low", "Low"], ["normal", "Normal"], ["high", "High"]];
	const ONOFF = [["off", "Off"], ["on", "On"]];
	const VSYNC = { key: "vsync", label: "V-SYNC", options: ONOFF, default: "off", group: "VIDEO SETTINGS",
		text: "Set whether to synchronise the frame rate to your display's refresh rate." };
	const GFX = [
		{ key: "gfx.aa", label: "ANTI-ALIASING (AA)", options: ONOFF, default: "on", text: "Toggles anti-aliasing on or off. Turning this off may result in better performance." },
		{ key: "gfx.details", label: "DETAILS QUALITY", options: LEVEL, default: "high", text: "Controls level of detail settings, and how far away objects stay drawn. Lowering this may result in better performance." },
		{ key: "gfx.effects", label: "EFFECTS QUALITY", options: LEVEL, default: "high", text: "Controls detail of particle effects. Lowering this may result in better performance." },
		{ key: "gfx.lighting", label: "LIGHTING QUALITY", options: LEVEL, default: "high", text: "Controls detail of lighting. Lowering this may result in better performance." },
		{ key: "gfx.shadows", label: "SHADOW QUALITY", options: LEVEL, default: "high", text: "Controls shadow details. Lowering this may result in better performance." },
		{ key: "gfx.filtering", label: "ANISOTROPIC FILTERING", options: LEVEL, default: "high", text: "Controls how textures appear at a distance. Lowering this may result in better performance." },
		{ key: "gfx.water", label: "WATER QUALITY", options: LEVEL, default: "high", text: "Controls detail of water. Lowering this may result in better performance." },
		{ key: "gfx.motionblur", label: "MOTION BLUR", options: ONOFF, default: "on", text: "Toggles Motion Blur on or off. Turning this off may result in better performance." },
	];
	// MCC's presets: every row low (anti-aliasing and motion blur off), normal, or high.
	const GFX_PRESETS = {
		performance: { "gfx.aa": "off", "gfx.motionblur": "off", ...Object.fromEntries(GFX.filter(g => g.options === LEVEL).map(g => [g.key, "low"])) },
		original: { "gfx.aa": "on", "gfx.motionblur": "on", ...Object.fromEntries(GFX.filter(g => g.options === LEVEL).map(g => [g.key, "normal"])) },
		enhanced: { "gfx.aa": "on", "gfx.motionblur": "on", ...Object.fromEntries(GFX.filter(g => g.options === LEVEL).map(g => [g.key, "high"])) },
	};
	const GFX_PRESET_TEXT = { performance: "The graphics quality is reduced for best performance.", original: "The graphics quality matches the original experience.",
		enhanced: "The graphics quality is increased for maximum quality.", custom: "The graphics quality is customized." };
	// The preset the rows add up to (`custom` when they match none).
	const gfxPreset = () => Object.keys(GFX_PRESETS).find(n => GFX.every(g => (settingsState[g.key] ?? g.default) === GFX_PRESETS[n][g.key])) || "custom";
	function gfxPresetSetting() {
		const options = [["performance", "Performance"], ["original", "Original"], ["enhanced", "Enhanced"]];
		if (gfxPreset() === "custom") options.push(["custom", "Custom"]);
		return { key: "gfx.preset", label: "GRAPHICS QUALITY", options, default: "enhanced", group: "GRAPHICS SETTINGS" };
	}
	// Audio tab (owner, 2026-10-17): volumes in percent (the profile's f32 volumes, 100% = 1.0; overlay
	// settings.rs, host-probe live.rs) and Reach's subtitle setting.
	const PERCENT = ["0", "10", "20", "30", "40", "50", "60", "70", "80", "90", "100"].map(v => [v, v + "%"]);
	const AUDIO = [
		{ key: "volume.game", label: "GAME VOLUME", group: "AUDIO", options: PERCENT, default: "100", slider: true, text: "Set the volume for all game sounds and music." },
		{ key: "volume.music", label: "GAME MUSIC VOLUME", group: "AUDIO", options: PERCENT, default: "100", slider: true, text: "Set the volume of the game music." },
		{ key: "volume.effects", label: "EFFECTS VOLUME", group: "AUDIO", options: PERCENT, default: "100", slider: true, text: "Set the volume of the sound effects in game." },
		{ key: "volume.menu", label: "MENU SOUNDS VOLUME", group: "AUDIO", options: PERCENT, default: "100", slider: true, text: "Set the volume of the menus' own sounds." },
		{ key: "volume.menumusic", label: "MENU MUSIC VOLUME", group: "AUDIO", options: PERCENT, default: "100", slider: true, text: "Set the volume of the music in the menus." },
		{ key: "music", label: "MENU MUSIC", group: "MENU MUSIC", options: [["reach", "Halo: Reach"], ["track", "One Track"], ["playlist", "My Playlist"], ["off", "Off"]], default: "reach",
			text: "Choose the music in the menus. Halo: Reach plays the Xbox 360's menu music: its opening, then its pieces in a random order. One Track plays the track you choose again and again; My Playlist plays your playlist." },
		{ key: "music.shuffle", label: "SHUFFLE PLAYLIST", group: "MENU MUSIC", options: [["on", "On"], ["off", "Off"]], default: "on",
			text: "Play My Playlist in a random order, or in the order you added the tracks." },
		{ key: "subtitles", label: "SUBTITLES", group: "SUBTITLES", options: [["automatic", "Automatic"], ["on", "On"], ["off", "Off"]], default: "automatic",
			text: "Display subtitles for dialogue when in game. Automatic shows them when the game's text and voices are in different languages." },
	];
	// MCC's controller rows for Reach (owner thread, 2026-10-17), in its order, wording and defaults
	// (optionsdata.xml). The overlay writes them into the game's profile (settings.rs PAD_FIELDS);
	// Vibration is host-probe's (pad.rs). MCC's Impulse Triggers (XInput has no trigger motors) and Aim
	// Control (MCC's own stick handling, which a game we host never gets) have nothing to set here.
	const STEPS = (from, to, step) => { const out = []; for (let v = from; v <= to + 1e-9; v += step) out.push(String(Math.round(v * 10) / 10)); return out; };
	const PAD_SETTINGS = [
		{ key: "pad.crouch", label: "CROUCH BEHAVIOR", group: "GAMEPAD CONTROLS", options: [["hold", "Hold"], ["toggle", "Toggle"]], default: "hold",
			text: "Select your desired crouch behavior." },
		{ key: "pad.layout", label: "BUTTON LAYOUT", group: "GAMEPAD CONTROLS", default: "default",
			options: [["default", "Default"], ["boxer", "Boxer"], ["greenthumbs", "Green Thumbs"], ["bumperjumper", "Bumper Jumper"], ["recon", "Recon"],
				["unidefault", "Universal Default (Recon)"], ["unireclaimer", "Universal Reclaimer"], ["unizoomshoot", "Universal Zoom & Shoot"],
				["unibumperjumper", "Universal Bump & Jump"], ["unigreenthumbs", "Universal Green Thumbs"]],
			text: "Change gamepad layout to a specific controller preset." },
		{ key: "pad.dpad", label: "D-PAD & BUTTONS", group: "GAMEPAD CONTROLS", options: [["default", "Default"], ["swapped", "Swapped"], ["inverted", "Inverted"]], default: "default",
			text: "Select which gamepad layout to use for D-pad & buttons. Inverted swaps them and inverts them too." },
		{ key: "pad.bumpers", label: "BUMPERS & TRIGGERS", group: "GAMEPAD CONTROLS", options: [["default", "Default"], ["swapped", "Swapped"]], default: "default",
			text: "Select which gamepad layout to use for bumpers & triggers." },
		{ key: "pad.thumbs", label: "THUMBSTICK LAYOUT", group: "GAMEPAD CONTROLS", default: "default",
			options: [["default", "Default"], ["southpaw", "Southpaw"], ["legacy", "Legacy"], ["legacysouthpaw", "Legacy Southpaw"]],
			text: "Select which gamepad layout to use for thumbsticks." },
		{ key: "pad.invert", label: "LOOK INVERSION", group: "GAMEPAD CONTROLS", options: [["off", "Not Inverted"], ["on", "Inverted"]], default: "off",
			text: "Select whether to invert look controls." },
		{ key: "pad.flight.invert", label: "FLIGHT INVERSION", group: "GAMEPAD CONTROLS", options: [["off", "Not Inverted"], ["on", "Inverted"]], default: "off",
			text: "Select whether to invert look controls when controlling flying vehicles." },
		{ key: "theater.turn", label: "THEATER TURN SENSITIVITY", group: "GAMEPAD CONTROLS", default: "normal",
			options: [["slow", "Slow"], ["normal", "Normal"], ["fast", "Fast"], ["veryfast", "Very Fast"]], text: "Set the turn sensitivity of the camera in Theater mode." },
		{ key: "theater.panning", label: "THEATER PANNING", group: "GAMEPAD CONTROLS", options: [["hold", "Hold to Pan"], ["toggle", "Toggle"]], default: "hold",
			text: "Set the panning behavior of the camera in Theater mode." },
		{ key: "theater.speed", label: "THEATER SPEED", group: "GAMEPAD CONTROLS", default: "normal",
			options: [["slow", "Slow"], ["normal", "Normal"], ["fast", "Fast"], ["veryfast", "Very Fast"]], text: "Set the speed of the camera in Theater mode." },
		{ key: "theater.thrust", label: "THEATER THRUST", group: "GAMEPAD CONTROLS", options: [["slow", "Slow"], ["normal", "Normal"], ["fast", "Fast"]], default: "normal",
			text: "Set the thrust speed of the camera in Theater mode." },
		{ key: "pad.autocenter", label: "AUTO LOOK CENTERING", group: "GAMEPAD", options: [["off", "Disabled"], ["on", "Enabled"]], default: "off",
			text: "Automatically center the vertical look axis as the player moves." },
		{ key: "pad.vibration", label: "VIBRATION", group: "GAMEPAD", options: [["on", "Enabled"], ["off", "Disabled"]], default: "on",
			text: "Control whether the gamepad vibrates during gameplay and cutscenes." },
		{ key: "pad.look.h", label: "HORIZONTAL LOOK SENSITIVITY", group: "GAMEPAD", options: STEPS(1, 10, 0.5).map(v => [v, v]), default: "2", slider: true,
			text: "Change how sensitive horizontal aiming feels, from 1 to 10 in half steps. This is your own setting when hosting or joining." },
		{ key: "pad.look.v", label: "VERTICAL LOOK SENSITIVITY", group: "GAMEPAD", options: STEPS(1, 10, 0.5).map(v => [v, v]), default: "2", slider: true,
			text: "Change how sensitive vertical aiming feels, from 1 to 10 in half steps. This is your own setting when hosting or joining." },
		{ key: "pad.accel", label: "LOOK ACCELERATION", group: "GAMEPAD", options: STEPS(1, 10, 1).map(v => [v, v]), default: "4", slider: true,
			text: "Change your look acceleration, controlling how quickly the maximum turn speed is reached." },
		{ key: "pad.deadzone.axial", label: "LOOK AXIAL DEAD ZONE", group: "GAMEPAD", options: STEPS(0, 20, 1).map(v => [v, v + "%"]), default: "12", slider: true,
			text: "Change the amount of input required to exit the dead zone. Used to adjust 'drift'." },
		{ key: "pad.deadzone.radial", label: "LOOK RADIAL DEAD ZONE", group: "GAMEPAD", options: STEPS(0, 20, 1).map(v => [v, v + "%"]), default: "12", slider: true,
			text: "Change the amount of input required to exit the dead zone based on radius. Used to adjust 'drift'." },
	];
	for (const s of PAD_SETTINGS) DEFAULTS[s.key] = s.default;
	// Mouse look speed (host-probe --mouse-speed, percent of its tuned speed), on the Keyboard tab.
	const MOUSE = { key: "mouse", label: "MOUSE SENSITIVITY", options: ["50", "60", "70", "80", "90", "100", "110", "125", "150", "175", "200", "250", "300"]
		.map(v => [v, v === "100" ? "100% (Default)" : v + "%"]), default: "100" };
	// MCC's other MOUSE rows for Reach (owner, 2026-10-18), in its wording, ranges and defaults; host-probe
	// mouse.rs changes the mouse's movement with them, during a game too.
	const nums = (list) => list.map(v => [String(v), String(v)]);
	const MOUSE_MORE = [
		{ key: "mouse.accel", label: "MOUSE ACCELERATION", options: ONOFF, default: "off",
			text: "Set whether look axis movement is increased when the mouse is moved over a larger distance." },
		{ key: "mouse.accel.min", label: "ACCELERATION MIN RATE", options: nums([0, 1, 2, 3, 5, 8, 10, 15, 20, 30, 50, 75, 100]), default: "2", slider: true,
			text: "If mouse acceleration is enabled, set the lower threshold at which acceleration starts." },
		{ key: "mouse.accel.max", label: "ACCELERATION MAX RATE", options: nums([1, 10, 20, 40, 60, 80, 100, 150, 200, 300, 400, 600, 800]), default: "80", slider: true,
			text: "If mouse acceleration is enabled, set the upper limit at which acceleration ends." },
		{ key: "mouse.accel.scale", label: "ACCELERATION SCALE", options: nums([0, 1, 2, 3, 5, 10, 15, 20, 30, 40, 50, 75, 100]), default: "0", slider: true,
			text: "If mouse acceleration is enabled, set the acceleration scaling curve." },
		{ key: "mouse.accel.power", label: "ACCELERATION POWER", options: nums([0.25, 0.5, 0.75, 1, 1.25, 1.5, 2, 3, 5, 10, 25, 50, 100]), default: "1", slider: true,
			text: "If mouse acceleration is enabled, set the intensity of the scaling curve." },
		{ key: "mouse.smoothing", label: "MOUSE SMOOTHING", options: ONOFF, default: "off",
			text: "Set whether mouse input is smoothed between frames." },
	];
	const GAMEPLAY = [
		{ key: "crosshair", label: "CROSSHAIR POSITION", group: "GAME SETTINGS", options: [["lowered", "Lowered"], ["centered", "Centered"]], default: "centered",
			text: "Set the vertical position of the crosshair on screen." },
		{ key: "jumper", label: "JUMPER JUMPER", group: "GAME SETTINGS", options: [["off", "Disabled"], ["on", "Enabled"]], default: "on",
			text: "Press jump twice quickly to use a jetpack." },
	];
	// How far the third-person camera (F5) sits, percent of Reach's own distance (host-probe
	// --camera-distance; owner 2026-10-14), shown as a slider.
	// The match text chat (chat.js; owner, 2026-10-21): its keys (host-probe takes letters, digits, F1-F24, the
	// numeric keypad and punctuation: ingame_chat.rs `bindable`; two chat keys swap) and how its lines look.
	const CHAT_KEYS = [["GENERAL CHAT", "chat.general", 89, "Set key to talk to everyone in the game. A party that plays together keeps its General chat from map to map."],
		["TEAM CHAT", "chat.team", 84, "Set key to talk to your team. In a game without teams it does nothing."],
		["SHOW/HIDE CHAT", "chat.toggle", 191, "Set key to show or hide the chat. In a game it hides the chat's lines, with a count of how many came; in the menus, the chat panel."]];
	const chatKey = (vk) => (vk >= 0x30 && vk <= 0x39) || (vk >= 0x41 && vk <= 0x5A) || (vk >= 0x60 && vk <= 0x87) || (vk >= 0xBA && vk <= 0xC0) || (vk >= 0xDB && vk <= 0xDF);
	const CHAT_LOOK = [
		{ key: "chat.lines", label: "CHAT LINES", options: nums([4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]), default: "6", slider: true,
			text: "Set how many chat lines show at once in a game. The game menu's Match tab has the whole chat." },
		{ key: "chat.size", label: "CHAT TEXT SIZE", options: [["small", "Small"], ["medium", "Medium"], ["large", "Large"]], default: "medium",
			text: "Set the size of the chat's text in a game." },
		{ key: "chat.width", label: "CHAT WIDTH", options: [["narrow", "Narrow"], ["normal", "Normal"], ["wide", "Wide"]], default: "normal",
			text: "Set how wide the chat's lines are in a game." },
		{ key: "chat.fade", label: "CHAT FADE", options: [["5", "5 Seconds"], ["8", "8 Seconds"], ["15", "15 Seconds"], ["never", "Never"]], default: "8",
			text: "Set how long a chat line stays before it fades. Never keeps the newest lines up." },
		{ key: "chat.opacity", label: "CHAT BACKGROUND", options: [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100].map(v => [String(v), v ? v + "%" : "Off"]), default: "80", slider: true,
			text: "Set how see-through the dark background behind the chat is in a game (and behind its message box). Off leaves text with a shadow only." },
	];
	const CAM_DISTANCE = { key: "camera.distance", label: "THIRD PERSON DISTANCE", options: ["50", "60", "70", "80", "90", "100", "120", "140", "160", "180", "200", "250", "300"]
		.map(v => [v, v === "100" ? "100% (Default)" : v + "%"]), default: "100", slider: true };
	// Reach's game actions in its own order (the profile's key-binding entries; MCC's
	// GameAbstractButton_* list). Forge and Theater actions are marked as such.
	const ACTIONS = ["Jump", "SwitchGrenade", "ActionReload", "Reload", "SwitchWeapon", "MeleeAttack", "Flashlight", "ThrowGrenade", "Fire",
		"Crouch", "Zoom", "ZoomIn", "ZoomOut", "SwapWeapon", "Sprint", "BansheeBomb", "MoveForward", "MoveBackward", "StrafeLeft", "StrafeRight",
		"ShowScores", "PrimaryVehicleTrick", "SecondaryVehicleTrick", "Equipment", "SecondaryFire", "LiftEditor", "DropEditor", "GrabObjectEditor",
		"BoostEditor", "CrouchEditor", "DeleteObjectEditor", "CreateObjectEditor", "OpenToolMenuEditor", "SwitchPlayerModeEditor", "ScopeZoomEditor",
		"PlayerLockForManipulationEditor", "ShowHidePannelTheater", "ShowHideInterfaceTheater", "ToggleFirstThirdPersonViewTheater", "CameraFocusTheater",
		"FastForwardTheater", "FastRewindTheater", "StopContinuePlaybackTheater", "PlaybackSpeedUpTheater", "EnterFreeCameraModeTheater",
		"MovementSpeedUpTheater", "PanningCameraTheater", "CameraMoveUpTheater", "CameraMoveDownTheater", "DualWield", "ZoomCameraTheater",
		"ToggleRotationAxesEditor", "DuplicateObjectEditor", "LockObjectEditor", "ResetOrientationEditor", "ReloadSecondary", "PreviousGrenade",
		"SpecialAction", "LoadoutMenu", "ActivateWaypoint", "ActivateWaypointAlt", "PingNavpoints", "RaiseHornet", "LowerHornet", "FlashlightAlt", "NextGrenade"];
	const actionName = (n) => {
		const group = n.endsWith("Editor") ? " (Forge)" : n.endsWith("Theater") ? " (Theater)" : "";
		return n.replace(/(Editor|Theater)$/, "").replace("Pannel", "Panel").replace(/([a-z])([A-Z])/g, "$1 $2") + group;
	};
	// Key names as MCC writes them (its defaults in optionsdata.xml: MOUSE 1, LEFT CTRL, SPACE, TAB, ESC, NUM0).
	const KEY_NAMES = { 1: "MOUSE 1", 2: "MOUSE 2", 4: "MOUSE 3", 5: "MOUSE 4", 6: "MOUSE 5", 8: "BACKSPACE", 9: "TAB", 13: "ENTER",
		16: "SHIFT", 17: "CTRL", 18: "ALT", 20: "CAPS LOCK", 27: "ESC", 32: "SPACE", 33: "PAGE UP", 34: "PAGE DOWN", 35: "END", 36: "HOME",
		37: "LEFT", 38: "UP", 39: "RIGHT", 40: "DOWN", 45: "INSERT", 46: "DELETE", 160: "LEFT SHIFT", 161: "RIGHT SHIFT", 162: "LEFT CTRL",
		163: "RIGHT CTRL", 164: "LEFT ALT", 165: "RIGHT ALT", 174: "MOUSE WHEEL DOWN", 175: "MOUSE WHEEL UP", 186: ";", 187: "=", 188: ",",
		189: "-", 190: ".", 191: "/", 192: "`", 219: "[", 220: "\\", 221: "]", 222: "'" };
	// The mouse wheel turned down and up, as Reach's profile loader takes them (to Windows the Volume
	// Down and Up keys; host-probe live.rs wheel_move). 2026-10-20 player batch, report 18.
	const WHEEL_DOWN = 174, WHEEL_UP = 175;
	const keyName = (vk) => !vk ? "NOT BOUND" : KEY_NAMES[vk] || (vk >= 112 && vk <= 135 ? "F" + (vk - 111) : vk >= 96 && vk <= 105 ? "NUM" + (vk - 96) : String.fromCharCode(vk));
	// Controller buttons for the third-person camera (host-probe pad.rs masks: XInput's button bits,
	// 0x10000 left trigger, 0x20000 right), and the browser's standard gamepad buttons in that mask.
	const PAD_BITS = { 0: 0x1000, 1: 0x2000, 2: 0x4000, 3: 0x8000, 4: 0x100, 5: 0x200, 6: 0x10000, 7: 0x20000, 8: 0x20, 9: 0x10, 10: 0x40, 11: 0x80,
		12: 0x1, 13: 0x2, 14: 0x4, 15: 0x8 };
	const PAD_NAMES = [[0x20, "Back"], [0x10, "Start"], [0x100, "LB"], [0x200, "RB"], [0x10000, "LT"], [0x20000, "RT"], [0x1000, "A"], [0x2000, "B"],
		[0x4000, "X"], [0x8000, "Y"], [0x40, "Left Stick"], [0x80, "Right Stick"], [0x1, "D-Pad Up"], [0x2, "D-Pad Down"], [0x4, "D-Pad Left"], [0x8, "D-Pad Right"]];
	const padName = (mask) => PAD_NAMES.filter(([b]) => mask & b).map(([, n]) => n).join(" + ") || "NOT BOUND";
	let padCapturing = null; // the camera setting waiting for controller buttons on the Controller page
	// Nothing pressed within 8 s: the wait ends. With no controller seen by the page at all the row says so,
	// instead of going back to its old button without a word (2026-10-20 player batch, report 6: a remap that
	// "doesn't save" can be one the menus never saw the controller for, reports 3 and 26).
	let padUnseen = null; // the Controller page row whose wait ended with no controller seen
	const NO_PAD = "No controller seen by the menus, so nothing changed. Plug it in, or press one of its buttons with the menus in front, then try again.";
	function padGaveUp(key, seen) {
		padCapturing = null;
		padUnseen = seen ? null : key;
		if (!seen && typeof Sound !== "undefined") Sound.play("error");
		renderPage();
	}
	// Waits for a press on the controller: every button held together, taken when they are let go.
	// Start alone, or Esc, cancels; nothing within 8 s cancels too.
	// The buttons the controller holds now, as PAD_BITS: the controllers the menus read (pad.js choose).
	const padsSeen = () => MenuPad.choose(navigator.getGamepads ? navigator.getGamepads() : []);
	function padNow() {
		let now = 0;
		for (const pad of padsSeen()) for (const [i, bit] of Object.entries(PAD_BITS)) { const b = pad.buttons[i]; if (b && (b.pressed || b.value > 0.5)) now |= bit; }
		return now;
	}
	function padCapture(key, label) {
		padCapturing = key;
		const started = performance.now();
		let held = 0, seen = false;
		// (the A that started this is still down: buttons held at the start count only once let go and
		// pressed again; a player's report, 2026-10-17: RB bound showed as A)
		let stale = padNow();
		const step = () => {
			if (padCapturing !== key) return;
			seen = seen || padsSeen().length > 0;
			const raw = padNow();
			stale &= raw;
			const now = raw & ~stale;
			held |= now;
			if (held && !now) {
				padCapturing = null;
				if (held !== 0x10) changeSetting(key, held, label);
				return renderPage();
			}
			if (!held && performance.now() - started > 8000) return padGaveUp(key, seen);
			requestAnimationFrame(step);
		};
		requestAnimationFrame(step);
	}
	let capturing = null; // the action waiting for a key on the Keyboard page
	let swallowClick = false; // (the click after a captured mouse button isn't a menu click)
	let wheelTakenUntil = 0; // (the rest of a wheel turn just taken as a key doesn't scroll the list)
	let lastBound = null; // the Keyboard page's action that last got a key (its warning, settingsEntries)
	// Reach's Default layout, as MCC has it (HaloReachController.json BaseGamepadMapping; host-probe pad.rs).
	const CONTROLLER = [["Right Trigger", "Fire"], ["Left Trigger", "Throw Grenade"], ["Right Bumper", "Melee"], ["Left Bumper", "Armor Ability"],
		["A", "Jump"], ["B", "Switch Grenade"], ["X", "Reload / Action"], ["Y", "Switch Weapon"], ["Left Stick", "Move (click: Crouch)"], ["Right Stick", "Look (click: Zoom)"],
		["D-Pad", "Flashlight (left)"], ["Back", "Scoreboard"], ["Start", "Menu"]];
	// The player's controller layout (stranger test, 2026-10-17: "controller binds can't be rebound"):
	// for each button of the Button Layout, the controller button that does what the layout puts on it
	// (settings `pad.map.<id>`, a mask as PAD_BITS; 0 or absent: the same button; host-probe pad.rs puts
	// it into each action's button in slot 116's array). The actions named are Reach's default layout's
	// (CONTROLLER above).
	const PAD_LAYOUT = [["a", 0x1000, "A", "Jump"], ["b", 0x2000, "B", "Switch Grenade"], ["x", 0x4000, "X", "Reload / Action"], ["y", 0x8000, "Y", "Switch Weapon"],
		["rt", 0x20000, "Right Trigger", "Fire"], ["lt", 0x10000, "Left Trigger", "Throw Grenade"], ["rb", 0x200, "Right Bumper", "Melee"],
		["lb", 0x100, "Left Bumper", "Armor Ability"], ["ls", 0x40, "Left Stick Click", "Crouch"], ["rs", 0x80, "Right Stick Click", "Zoom"],
		["up", 0x1, "D-Pad Up", ""], ["down", 0x2, "D-Pad Down", ""], ["left", 0x4, "D-Pad Left", "Flashlight"], ["right", 0x8, "D-Pad Right", ""], ["back", 0x20, "Back", "Scoreboard"]];
	const padSource = (id) => { const own = PAD_LAYOUT.find(b => b[0] === id)[1]; return +(settingsState["pad.map." + id] || 0) || own; };
	// One game button onto the controller button `mask`; the game button that had `mask` takes this one's
	// old button (a swap, so no button does two things and none is left out).
	function padMapSet(id, mask) {
		const row = PAD_LAYOUT.find(b => b[0] === id), old = padSource(id);
		if (mask === old) return;
		const other = PAD_LAYOUT.find(b => b[0] !== id && padSource(b[0]) === mask);
		const send = (b, m) => changeSetting("pad.map." + b[0], m === b[1] ? 0 : m, (b[3] || b[2]).toUpperCase() + " (" + b[2] + ")");
		send(row, mask);
		if (other) send(other, old);
	}
	// Waits for one controller button (the first pressed, taken when let go); Start or Esc cancels.
	function padMapCapture(id) {
		padCapturing = "pad.map." + id;
		const key = padCapturing, started = performance.now();
		let first = 0, seen = false;
		// (the A that started this is still down: it counts only once let go and pressed again)
		let stale = padNow();
		const step = () => {
			if (padCapturing !== key) return;
			seen = seen || padsSeen().length > 0;
			const raw = padNow();
			stale &= raw;
			const now = raw & ~stale;
			if (!first && now) first = PAD_NAMES.map(([b]) => b).find(b => now & b) || 0;
			if (first && !(now & first)) {
				padCapturing = null;
				if (first !== 0x10) padMapSet(id, first);
				return renderPage();
			}
			if (!first && performance.now() - started > 8000) return padGaveUp(key, seen);
			requestAnimationFrame(step);
		};
		requestAnimationFrame(step);
	}
	// Our own actions on a controller (owner, 2026-10-16), bindable on the Controller page.
	const PAD_ACTIONS = [["THIRD PERSON CAMERA", "pad.camera.toggle", "Set button to toggle the third-person camera. Hold two buttons together for a combination."],
		["SWAP SHOULDER", "pad.camera.shoulder", "Set button to move the third-person camera to the other shoulder."]];
	function settingsEntries(p) {
		if (p.kind === "game") {
			return [
				{ label: "Resume Game", act: "resume", text: "Back to the game." },
				{ label: "Controller...", go: { kind: "controller" }, text: "See the controller layout." },
				{ label: "Keyboard...", go: { kind: "keyboard" }, text: "See every key and mouse button the game uses, and change them." },
				{ label: "Settings...", go: { kind: "audiovideo" }, text: "Video, audio, keyboard, controller, network and theme settings: the window, resolution, frame rate, field of view and more." },
				{ label: "Audio...", go: { kind: "audio" }, text: "Change the game, music, effects and menu volumes, and subtitles." },
				{ label: "Quick Settings...", go: { kind: "quick" }, text: "Up to 8 settings you pick, all on one page, to switch back and forth during a game." },
				{ label: "Settings Presets...", go: { kind: "presets" }, text: "Save your settings as a preset, and load another one." },
				// (Forge: keep the map; leaving Forge saves it too. host-probe forgesave.rs)
				...(window.lastGame && window.lastGame.kind === "forge" ? [{ label: "Save Map", act: "save-map", text: "Save this Forge map into your files. It shows in Select Map under its map (My Maps); leaving Forge saves it too." },
					// (2026-10-20 player batch, report 13: no Save As, maps couldn't be renamed)
					{ label: "Save Map As...", act: "save-map-as", text: "Save this Forge map into your files under a name you choose. It shows in Select Map under its map (My Maps), by that name." }] : []),
				// (a team game whose Team Changing allows it: the game checks it too, Balancing Only included; host-probe teams.rs)
				...(window.lastGame && window.lastGame.kind === "mp" && window.lastGame.teams && window.lastGame.teams.mask && window.lastGame.teams.changing
					? [{ label: "Change Team", act: "team", text: window.lastGame.teams.changing === 2 ? "Switch to another team. This game type allows it only when it keeps the teams even." : "Switch to another team." }] : []),
				// (the host's own Multiplayer or Firefight game: index.html start() marks it `host`)
				// (End Round: a host's Multiplayer game; player report 2026-10-18, limited-lives game types that never ended the round)
				...(window.lastGame && window.lastGame.host && window.lastGame.kind === "mp" ? [{ label: "End Round", act: "end-round", sep: true, text: "End this round for everyone now, as if a player or team reached the score to win: the best score wins the round, then the next round starts, or the game ends after its last round." }] : []),
				...(window.lastGame && window.lastGame.host && (window.lastGame.kind === "mp" || window.lastGame.kind === "ff") ? [{ label: "End Game", act: "end", sep: !(window.lastGame.kind === "mp"), text: "End this game for everyone now. The game ends as if its time ran out, and everyone gets their results." }] : []),
				{ label: "Leave Game", act: "leave", sep: !(window.lastGame && window.lastGame.host && (window.lastGame.kind === "mp" || window.lastGame.kind === "ff")), text: "Leave this game and go back to the menus." },
				{ label: "Exit Client", act: "quit", text: "Close Reach Renaissance." },
			];
		}
		if (p.kind === "audiovideo") {
			const GROUPS = { display: "GENERAL SETTINGS", resolution: "GENERAL SETTINGS", fps: "VIDEO SETTINGS", fov: "VIDEO SETTINGS" };
			const ABOUT = { display: "Set the window mode in which to run the game: a window, or a borderless window that fills the screen.",
				resolution: "Set the size of the game window. During a game the window and the picture change at once.",
				fps: "Set the most frames drawn per second. Higher is smoother if your PC keeps up.",
				fov: "Set how wide the first-person camera field-of-view appears." };
			const out = AV.map(s => {
				// (a field of view of 0, the old Default, is MCC's 78: overlay settings.rs)
				const cur = s.key === "fov" && settingsState.fov === "0" ? "78" : settingsState[s.key] ?? s.default ?? s.options[0][0];
				const opt = s.options.find(o => o[0] === cur) || s.options[0];
				return { label: s.label, value: opt[1], pick: true, setting: s, group: GROUPS[s.key],
					text: ABOUT[s.key], note: "A or a click to change it, then left and right or its arrows; A keeps it, B puts it back. " + applies(s.key) };
			});
			const pickRow = (s, text) => {
				const opts = s.options, cur = s.key === "gfx.preset" ? gfxPreset() : settingsState[s.key] ?? s.default;
				if (s.key === "gfx.preset") settingsState[s.key] = cur; // (what the rows add up to, for left and right)
				const at = Math.max(0, opts.findIndex(o => o[0] === cur));
				return { label: s.label, value: opts[at][1], pick: true, setting: s, group: s.group, text, fill: s.slider ? at / (opts.length - 1) : undefined,
					note: "A or a click to change it, then left and right or its arrows; A keeps it, B puts it back. " + applies(s.key) };
			};
			// MCC's order: UI GAMMA after the window rows; GAMMA, then the two fields of view, then V-SYNC.
			out.splice(out.findIndex(r => r.setting.key === "resolution") + 1, 0, pickRow(UI_GAMMA, UI_GAMMA.text));
			out.splice(out.findIndex(r => r.setting.key === "fov"), 0, pickRow(GAMMA, GAMMA.text));
			out.splice(out.findIndex(r => r.setting.key === "fov") + 1, 0, pickRow(FOV_VEHICLE, FOV_VEHICLE.text));
			out.splice(out.findIndex(r => r.setting.key === "fps"), 0, pickRow(VSYNC, VSYNC.text));
			const preset = gfxPresetSetting();
			out.push(pickRow(preset, "Set the graphics quality in game to suit your hardware. " + GFX_PRESET_TEXT[gfxPreset()]));
			out.push(...GFX.map(g => pickRow({ ...g, group: "GRAPHICS QUALITY SETTINGS" }, g.text)));
			// The third-person view here too (owner, 2026-10-14; the same settings as the Keyboard tab's).
			out.push(...settingsEntries({ kind: "keyboard" }).filter(r => r.group === "THIRD PERSON VIEW"));
			return out;
		}
		if (p.kind === "audio") {
			// MCC's own rows for Reach (owner, 2026-10-17), in its wording: GAME VOLUME, GAME MUSIC VOLUME,
			// EFFECTS VOLUME and SUBTITLES; MENU SOUNDS VOLUME is our menus' own sounds, MENU MUSIC VOLUME
			// and the MENU MUSIC rows their music (music.js); MCC's voice chat rows and subtitle styling (size, font, colors: MCC's own subtitle
			// overlay, which Reach's subtitles don't use) have nothing to set here.
			// MCC's GAME AUDIO OUTPUT DEVICE first, as in MCC (owner, 2026-10-18): the PC's playback devices
			// from the overlay program (audiodev.rs), the game's audio opens the chosen one when it starts
			// (host-probe host.rs slot 33); Default is Windows' own.
			if (audioDevices === null) { audioDevices = []; if (typeof api.onArmor === "function") api.onArmor("audio-devices?"); }
			const chosen = settingsState["audio.device"] || "";
			const device = { key: "audio.device", label: "GAME AUDIO OUTPUT DEVICE", group: "AUDIO", default: "",
				options: [["", "Default"], ...audioDevices, ...(chosen && !audioDevices.some(d => d[0] === chosen) ? [[chosen, "Not Connected"]] : [])],
				text: "Set the preferred device for game audio output." };
			const out = [device, ...AUDIO].map(s => {
				const opts = s.options, cur = settingsState[s.key] ?? s.default;
				const at = Math.max(0, opts.findIndex(o => o[0] === cur));
				return { label: s.label, value: opts[at][1], pick: true, setting: s, group: s.group, fill: s.slider ? at / (opts.length - 1) : undefined,
					text: s.text, note: "A or a click to change it, then left and right or its arrows; A keeps it, B puts it back. " + applies(s.key) };
			});
			// Menu music (owner, 2026-10-17; music.js): the track and the playlist are picked on their own pages.
			if (window.MenuMusic && MenuMusic.available()) {
				const at = out.findIndex(r => r.setting && r.setting.key === "music") + 1;
				const track = MenuMusic.byId(settingsState["music.track"] || MenuMusic.MENU_ID) || MenuMusic.byId(MenuMusic.MENU_ID);
				const count = (settingsState["music.playlist"] || "").split(";").filter(id => MenuMusic.byId(id)).length;
				out.splice(at, 0,
					{ label: "Choose Track...", value: track.name, go: { kind: "musictrack" }, group: "MENU MUSIC",
						text: "Pick the track One Track plays, from all of Halo: Reach's music: the menu music, cutscenes, missions and Firefight." },
					{ label: "Edit Playlist...", value: count ? count + (count === 1 ? " track" : " tracks") : "Empty", go: { kind: "musiclist" }, group: "MENU MUSIC",
						text: "Make My Playlist from any of Halo: Reach's music." });
			} else {
				for (const r of out) if (r.setting && r.setting.key.startsWith("music")) { r.off = true; r.text = ((window.MenuMusic && MenuMusic.problem()) || "The game's music isn't ready yet.") + " The menus have no music."; }
			}
			return out;
		}
		if (p.kind === "quick") {
			const all = quickCatalog();
			const rows = quickIds().map(id => all.find(r => r.quick === id)).filter(Boolean).map(r => ({ ...r, group: "Quick Settings" }));
			rows.push({ label: "Choose Settings...", go: { kind: "quickpick" }, sep: true, group: "Quick Settings",
				text: "Pick which settings show here, up to " + QUICK_MAX + "." });
			return rows;
		}
		if (p.kind === "quickpick") {
			const ids = quickIds();
			return quickCatalog().map(r => ({ label: r.label, value: ids.includes(r.quick) ? "Shown" : "", pickid: r.quick, group: r.group,
				text: "A shows it on Quick Settings or takes it off (" + ids.length + " of " + QUICK_MAX + ")." }));
		}
		// Menu music: every track of Halo: Reach's music (music.js). The track page picks One Track's; the
		// playlist page adds and removes tracks (A) and plays the highlighted one meanwhile (X).
		if ((p.kind === "musictrack" || p.kind === "musiclist") && window.MenuMusic) {
			const ids = (settingsState["music.playlist"] || "").split(";").filter(Boolean);
			const chosen = settingsState["music.track"] || MenuMusic.MENU_ID;
			const time = (d) => d ? Math.floor(d / 60) + ":" + String(Math.round(d % 60)).padStart(2, "0") : "";
			return MenuMusic.tracks().map(t => {
				const name = t.group === "Cutscenes" || t.group === "Main Menu" ? t.name : t.group + ": " + t.name;
				const about = (t.group === "Main Menu" ? "The Xbox 360's menu music: its opening, then each of its pieces once." : t.group + (t.dur ? ", " + time(t.dur) : "") + ".")
					+ (MenuMusic.previewing() === t.id ? " Playing now." : "");
				if (p.kind === "musictrack") return { label: name, value: t.id === chosen ? "Chosen" : "", musictrack: t.id, text: about };
				const at = ids.indexOf(t.id);
				return { label: name, value: at >= 0 ? "#" + (at + 1) : "", musiclist: t.id, text: about };
			});
		}
		if (p.kind === "presets") {
			if (presetsState === null && typeof api.onArmor === "function") api.onArmor("preset-list");
			const st = presetsState || {};
			const out = [];
			for (let n = 1; n <= 5; n++) {
				out.push({ label: "Preset " + n, value: st[n] !== undefined ? (st[n] || "Saved") : "Empty", preset: { op: "load", slot: n }, group: "Load",
					off: st[n] === undefined, text: st[n] !== undefined ? "A loads these settings." : "Nothing saved here yet." });
			}
			for (let n = 1; n <= 5; n++) {
				out.push({ label: "Save to Preset " + n, value: st[n] !== undefined ? "Replaces it" : "", preset: { op: "save", slot: n }, group: "Save",
					text: "A saves your current settings here (not your name, service tag or quick settings)." });
			}
			return out;
		}
		if (p.kind === "keyboard") {
			// (the game takes a move to or from the wheel in the next game: host-probe live.rs wheel_move; and
			// the overlay gives CHANGE WEAPON the wheel as its second key: settings.rs wheel_changes_weapons)
			const wheelKey = (vk) => vk === WHEEL_DOWN || vk === WHEEL_UP;
			const row = (label, bind, vk, group, text) => ({ label, value: capturing === bind ? "PRESS A KEY..." : keyName(vk), key: true, unbound: !vk,
				wait: capturing === bind, bind, group, vk,
				text: capturing === bind ? "Press a key or mouse button for this action" + (typeof bind === "number" ? ", or turn the mouse wheel" : "") + ". Esc cancels."
					: text || "Press A or click to change it.",
				note: (capturing === bind ? "" : "A or a click changes it. ")
					+ (bind === ACTIONS.indexOf("SwitchWeapon") ? "The mouse wheel changes weapons too, in a direction no other action has. " : "")
					+ (wheelKey(vk) ? "A change to or from the mouse wheel applies the next time a game starts." : applies(bind)) });
			const out = [];
			const speed = MOUSE.options.find(o => o[0] === (settingsState.mouse ?? "100")) || MOUSE.options[5];
			out.push({ label: MOUSE.label, value: speed[1], pick: true, setting: MOUSE, group: "MOUSE",
				text: "Control how fast the view turns when you move the mouse.", note: "A or a click to change it, then left and right or its arrows; A keeps it, B puts it back. " + applies(MOUSE.key) });
			for (const s of MOUSE_MORE) {
				const cur = settingsState[s.key] ?? s.default, at = Math.max(0, s.options.findIndex(o => o[0] === cur));
				out.push({ label: s.label, value: s.options[at][1], pick: true, setting: s, group: "MOUSE", fill: s.slider ? at / (s.options.length - 1) : undefined,
					text: s.text, note: "A or a click to change it, then left and right or its arrows; A keeps it, B puts it back. " + applies(s.key) });
			}
			// MCC's list, line for line.
			for (const [group, rows] of MCC_BINDS) {
				for (const [label, name, text] of rows) {
					const i = ACTIONS.indexOf(name);
					if (i >= 0) out.push(row(label, i, +settingsState.binds[i] || 0, group, text));
				}
			}
			// Reach Renaissance's own third-person camera keys (host-probe camera.rs), after MCC's list.
			out.push(row("THIRD PERSON CAMERA", "camera.toggle", +settingsState["camera.toggle"] || 116, "THIRD PERSON VIEW", "Set key to toggle the third-person camera."));
			out.push(row("SWAP SHOULDER", "camera.shoulder", +settingsState["camera.shoulder"] || 117, "THIRD PERSON VIEW", "Set key to move the third-person camera to the other shoulder."));
			// The match text chat's keys and look (chat.js, host-probe ingame_chat.rs).
			for (const [label, key, vk, text] of CHAT_KEYS) out.push(row(label, key, +settingsState[key] || vk, "TEXT CHAT", text));
			for (const s of CHAT_LOOK) {
				const cur = settingsState[s.key] ?? s.default, at = Math.max(0, s.options.findIndex(o => o[0] === cur));
				out.push({ label: s.label, value: s.options[at][1], pick: true, setting: s, group: "TEXT CHAT", fill: s.slider ? at / (s.options.length - 1) : undefined,
					text: s.text, note: "A or a click to change it, then left and right or its arrows; A keeps it, B puts it back. " + applies(s.key) });
			}
			// The key just chosen, when another action has it where both work at once (on foot, with the UI
			// and camera keys; in a vehicle; in Forge; in Theater: MCC's own keys repeat across those, as F
			// for THROW GRENADE and Forge's DESCEND): it does both (2026-10-20 player batch, report 21).
			const chosen = out.find(r => r.key && r.bind === lastBound && r.vk && !r.wait);
			const scope = (r) => ["VEHICLE CONTROLS", "FORGE", "THEATER"].includes(r.group) ? r.group : "";
			const also = chosen ? out.filter(r => r.key && r !== chosen && r.vk === chosen.vk && scope(r) === scope(chosen)).map(r => r.label) : [];
			if (also.length) chosen.warn = "Also on " + also.join(", ") + ": " + chosen.value + " does both.";
			{
				const opts = CAM_DISTANCE.options, cur = settingsState[CAM_DISTANCE.key] ?? CAM_DISTANCE.default;
				const at = Math.max(0, opts.findIndex(o => o[0] === cur));
				out.push({ label: CAM_DISTANCE.label, value: opts[at][1], pick: true, setting: CAM_DISTANCE, group: "THIRD PERSON VIEW", fill: at / (opts.length - 1),
					text: "Set how far behind you the third-person camera sits. Lower is closer, higher is further away.",
					note: "A or a click to change it, then left and right or its arrows; A keeps it, B puts it back. " + applies(CAM_DISTANCE.key) });
			}
			return out;
		}
		// Gameplay tab (owner, 2026-10-18): MCC's Gameplay and game-settings rows for Reach, in its wording and
		// defaults, written into the game's profile (overlay settings.rs): CROSSHAIR POSITION and JUMPER JUMPER.
		if (p.kind === "gameplay") {
			return GAMEPLAY.map(s => {
				const cur = settingsState[s.key] ?? s.default, at = Math.max(0, s.options.findIndex(o => o[0] === cur));
				return { label: s.label, value: s.options[at][1], pick: true, setting: s, group: s.group, text: s.text,
					note: "A or a click to change it, then left and right or its arrows; A keeps it, B puts it back. " + applies(s.key) };
			});
		}
		if (p.kind === "theme") {
			const now = theme();
			return THEMES.map(([scene, name, text]) => ({ label: name, value: scene === now ? "Current" : "", theme: scene, text, group: "Main Menu Backdrop" }));
		}
		if (p.kind === "network") {
			if (firewall.code === null && !firewall.busy) firewallAsk(false);
			const detail = firewall.line.replace(/^firewall:\s*/, "");
			const state = firewall.busy === "fix" ? "Waiting for Windows..." : firewall.busy ? "Checking..."
				: firewall.code === 0 ? "Allowed" : /not set up/.test(detail) ? "Not Set Up" : /blocked/.test(detail) ? "Blocked"
				: /cancel/.test(detail) ? "Not Changed" : firewall.code === null ? "" : "Unknown";
			const why = firewall.code === 0 ? "Windows lets players on other PCs reach games you host."
				: "Players on other PCs can't reach games you host until Windows Firewall allows Reach Renaissance.";
			const me = (document.getElementById("player") || {}).textContent || "Player";
			const name = { label: "Player Name", value: me, act: "name", group: "Player", text: "The name other players see. A changes it.", note: "It applies the next time a game starts." };
			// Under Wine (Proton on Linux and the Steam Deck, or a Mac's Wine) host-probe answers `firewall: linux:
			// ...`: the system's own firewall applies there, which it can't check or change, so no Windows rules.
			const hideIp = !HIDE_IP_OFFERED ? [] : [(() => {
				const cur = settingsState[HIDE_IP.key] ?? HIDE_IP.default, at = Math.max(0, HIDE_IP.options.findIndex(o => o[0] === cur));
				return { label: HIDE_IP.label, value: HIDE_IP.options[at][1], pick: true, setting: HIDE_IP, group: HIDE_IP.group, text: HIDE_IP.text,
					note: "A or a click to change it, then left and right or its arrows; A keeps it, B puts it back. It applies the next time you join a game." };
			})()];
			if (/^linux:/.test(detail)) return [name, ...hideIp,
				{ label: "Firewall", value: "Linux / macOS", group: "Hosting", text: detail.replace(/^linux:\s*/, "") }];
			return [
				name,
				...hideIp,
				{ label: "Windows Firewall", value: state, group: "Hosting", text: why + (detail ? " (" + detail + ")" : "") },
				{ label: "Allow Reach Renaissance", act: "firewall-fix", group: "Hosting",
					text: "Adds Windows Firewall rules so friends can join games you host. Windows asks for permission first.",
					note: "Moving or reinstalling Reach Renaissance needs this again." },
				{ label: "Check Again", act: "firewall-check", group: "Hosting", text: "Looks at the Windows Firewall rules again." },
			];
		}
		if (p.kind === "controller") {
			const GROUP = (b) => /Trigger|Bumper/.test(b) ? "TRIGGERS AND BUMPERS" : /^[ABXY]$/.test(b) ? "BUTTONS" : /Stick/.test(b) ? "STICKS" : "D-PAD AND MENUS";
			const pads = PAD_ACTIONS.map(([label, key, text]) => {
				const mask = +(settingsState[key] ?? DEFAULTS[key]) || 0;
				return { label, value: padCapturing === key ? "PRESS BUTTONS..." : padName(mask), key: true, wait: padCapturing === key, unbound: !mask,
					padbind: key, group: "THIRD PERSON VIEW",
					text: padCapturing === key ? "Press a button, or hold two together, on the controller. Start or Esc cancels." : padUnseen === key ? NO_PAD : text,
					note: (padCapturing === key ? "" : "A or a click changes it. ") + "Those buttons stop doing their game action while held together. " + applies(key) };
			});
			const settings = PAD_SETTINGS.map(s => {
				const opts = s.options, cur = settingsState[s.key] ?? s.default;
				const at = Math.max(0, opts.findIndex(o => o[0] === cur));
				return { label: s.label, value: opts[at][1], pick: true, setting: s, group: s.group, fill: s.slider ? at / (opts.length - 1) : undefined,
					text: s.text, note: "A or a click to change it, then left and right or its arrows; A keeps it, B puts it back. " + applies(s.key) };
			});
			// (the rows below name Reach's Default layout's actions; another layout moves them)
			const standard = (settingsState["pad.layout"] ?? "default") === "default";
			const layout = PAD_LAYOUT.map(([id, own, name, doing]) => {
				const key = "pad.map." + id, src = padSource(id), what = standard ? doing : "";
				return { label: (what ? what.toUpperCase() + " (" + name + ")" : name.toUpperCase()), value: padCapturing === key ? "PRESS A BUTTON..." : padName(src),
					key: true, wait: padCapturing === key, padmap: id, group: "CONTROLLER LAYOUT",
					text: padCapturing === key ? "Press the controller button you want for this. Start or Esc cancels." : padUnseen === key ? NO_PAD
						: "The game's " + name + " button" + (what ? " (" + what + " in Reach's default layout)" : "") + ". A or a click, then press the button you want for it; the button that had it takes this one's.",
					// (a player's report, 2026-10-17: binding Armor Ability to X also lowered the Forge
					// monitor on X: every action on the button moves. Since the owner's bug list of
					// 2026-10-19 host-probe hands the game each action's button, as MCC does (pad.rs, slot
					// 116), so the game's button prompts follow the layout and these rows.)
					note: (src === own ? "" : "Moved from " + name + ". ") + "This moves the whole button: everything the Button Layout puts on " + name + " (in vehicles and Forge too) moves with it, and the game's button prompts name the new button. A few of the game's own actions, such as its menus' Select and Back, keep their buttons, as in MCC. " + applies(key) };
			});
			layout.push({ label: "RESET CONTROLLER LAYOUT", act: "padreset", group: "CONTROLLER LAYOUT", text: "Every button back to where the Button Layout puts it." });
			return [...settings, ...pads, ...layout];
		}
		return null;
	}
	// A settings row's value: with its arrows while it is being changed (pageAct, p.edit).
	function editValue(p, i, c) {
		if (p.edit !== i) return esc(c.value || "");
		return `<b class="arr l" data-step="-1">&#9664;</b><span class="vt">${esc(c.value || "")}</span><b class="arr" data-step="1">&#9654;</b>`;
	}
	function setSetting(key, value, label) {
		// A graphics preset sets every graphics row; a changed row makes the preset what the rows add up to.
		if (key === "gfx.preset") {
			const vals = GFX_PRESETS[value];
			if (vals) for (const g of GFX) if ((settingsState[g.key] ?? g.default) !== vals[g.key]) changeSetting(g.key, vals[g.key], g.label);
			return changeSetting(key, gfxPreset(), label);
		}
		changeSetting(key, value, label);
		if (GFX_KEYS.includes(key) && (settingsState["gfx.preset"] ?? "enhanced") !== gfxPreset()) changeSetting("gfx.preset", gfxPreset(), "GRAPHICS QUALITY");
	}
	// The game menu's match details: [label, value, none?] rows from window.lastGame (set by whoever started or
	// joined the game: index.html start(), browser.js, social.js). An unknown map or game type has no row; the
	// mod row says "No Mod" only when the game is known to have none (a party member following its leader has
	// no mod list, so no row).
	function matchRows(g) {
		if (!g) return [];
		const known = (v) => typeof v === "string" && v !== "" && v !== "?";
		const mode = known(g.mode) ? g.mode : { camp: "Campaign", ff: "Firefight", forge: "Forge" }[g.kind] || "";
		const rows = [];
		if (mode) rows.push(["Game Type", mode]);
		if (known(g.map)) rows.push([g.kind === "camp" ? "Mission" : "Map", g.map]);
		if (typeof g.modName === "string") rows.push(["Mod", g.modName || "No Mod", !g.modName]);
		else if (g.mod) rows.push(["Mod", "Modded"]);
		return rows;
	}
	// The in-game menu's actions (overlay program: game-menu:resume / game-menu:leave / game-menu:end, quit).
	function gameAction(what) {
		closePages();
		close();
		document.body.classList.remove("ingame");
		if (typeof api.onArmor === "function") api.onArmor(what === "quit" ? "quit" : "game-menu:" + what);
	}
	// Keyboard page: the next key or mouse button press, or wheel turn, becomes the action's binding (Esc cancels).
	function captureKey(ev) {
		if (padCapturing !== null && ev.type === "keydown" && ev.keyCode === 27) {
			ev.preventDefault();
			ev.stopImmediatePropagation();
			padCapturing = null;
			renderPage();
			return true;
		}
		if (capturing === null && ev.type === "wheel" && performance.now() < wheelTakenUntil) {
			ev.preventDefault();
			ev.stopImmediatePropagation();
			return true;
		}
		if (capturing === null || !pages.length) return false;
		ev.preventDefault();
		ev.stopImmediatePropagation();
		if (ev.type === "mousedown") swallowClick = true;
		if (ev.type === "keydown" && ev.keyCode === 27) { capturing = null; renderPage(); return true; }
		// The wheel (2026-10-20 player batch, report 18): turned up (deltaY < 0) or down, for the game's
		// actions only (host-probe reads the camera keys as keys). A keyboard's Volume Down and Up keys
		// send the wheel's codes, so they aren't taken.
		const vk = ev.type === "mousedown" ? ({ 0: 1, 1: 4, 2: 2, 3: 5, 4: 6 }[ev.button] || 0)
			: ev.type === "wheel" ? (typeof capturing !== "number" || !ev.deltaY ? 0 : ev.deltaY < 0 ? WHEEL_UP : WHEEL_DOWN)
			: ev.keyCode === WHEEL_DOWN || ev.keyCode === WHEEL_UP ? 0 : ev.keyCode;
		// (a chat key: only a key host-probe takes; another key, a mouse button, waits for one)
		if (vk && typeof capturing === "string" && capturing.startsWith("chat.") && !chatKey(vk)) return true;
		if (vk) {
			const action = capturing;
			capturing = null;
			// Two chat keys can't share a key: the other one gets this one's old key.
			const other = typeof action === "string" && action.startsWith("chat.") && CHAT_KEYS.find(([, k, d]) => k !== action && (+settingsState[k] || d) === vk);
			if (other) {
				const mine = CHAT_KEYS.find(([, k]) => k === action);
				changeSetting(other[1], +settingsState[action] || mine[2], other[0]);
			}
			lastBound = action;
			if (ev.type === "wheel") wheelTakenUntil = performance.now() + 400;
			const p = pages[pages.length - 1], row = p && (entries(p) || []).find(r => r.bind === action);
			changeSetting(typeof action === "string" ? action : "bind." + action, vk, row ? row.label : undefined);
			renderPage();
		}
		return true;
	}
	window.addEventListener("mousedown", (ev) => { captureKey(ev); }, true);
	window.addEventListener("keydown", (ev) => { captureKey(ev); }, true);
	// (not passive: a turn taken as a key mustn't scroll the list too)
	window.addEventListener("wheel", (ev) => { captureKey(ev); }, { capture: true, passive: false });
	window.addEventListener("click", (ev) => { if (swallowClick) { swallowClick = false; ev.stopImmediatePropagation(); ev.preventDefault(); } }, true);
	window.addEventListener("contextmenu", (ev) => { if (pages.length && SETTINGS_KINDS.includes(pages[pages.length - 1].kind)) ev.preventDefault(); }, true);

	// The Armory Elite of the menu map (modular since 2026-10-14, the Prophets' Hand Elite) wears the picked
	// pieces: `elite.<built region>=<permutation>`. (A function, as sendAppearance runs before the
	// constants below exist; pieces that map lacks are left out.)
	function eliteRegions() {
		const data = window.ELITE_DATA;
		if (!data || !data.slots) return [];
		let picks = {};
		try { picks = JSON.parse(localStorage.getItem("rr.classic.elite") || "{}"); } catch (e) { picks = {}; }
		return Object.entries(data.slots).map(([slot, pieces]) => pieces.find(x => x.id === picks[slot] && eliteOffered(x)) || pieces.find(x => x.id === eliteMinor()[slot]) || pieces[0])
			.filter(x => x && x.built && x.shown).map(x => "elite." + x.built + "=" + x.permutation);
	}
	// The Elite's own armor, a piece per slot (Prophets' Hand plan B, mod-recovery/prophets_hand/PLAN_B.md;
	// elite-data.js from scripts/menu/extract_elite.py). Saved as `elite.<slot>=<index>` (armor.rs), which
	// puts them in the game's slot fields when Elite is preferred. A preset fills all six; typing on the
	// presets page searches them by name.
	const ELITE = window.ELITE_DATA && window.ELITE_DATA.slots ? window.ELITE_DATA : null;
	const ELITE_SLOTS = [["helmet", "Helmet"], ["left_shoulder", "Left Shoulder"], ["right_shoulder", "Right Shoulder"],
		["chest", "Chest"], ["forearms", "Forearms"], ["legs", "Legs"]];
	const ELITE_STORE = "rr.classic.elite";
	let elitePicks = {};
	try { elitePicks = JSON.parse(localStorage.getItem(ELITE_STORE) || "{}"); } catch (e) { elitePicks = {}; }
	const elitePick = (slot) => ELITE.slots[slot].some(x => x.id === elitePicks[slot] && eliteOffered(x)) ? elitePicks[slot]
		: ELITE.slots[slot].some(x => x.id === eliteMinor()[slot]) ? eliteMinor()[slot] : ELITE.slots[slot][0].id;
	// A saved pick that is hidden now goes back to the default piece, in the game's slot fields too (armor.rs).
	if (ELITE) {
		const hidden = Object.fromEntries(ELITE_SLOTS.filter(([s]) => ELITE.slots[s] && elitePicks[s] && elitePicks[s] !== elitePick(s)).map(([s]) => [s, elitePick(s)]));
		if (Object.keys(hidden).length) setTimeout(() => eliteEquip(hidden), 0);
	}
	function eliteEquip(picks) {
		Object.assign(elitePicks, picks);
		try { localStorage.setItem(ELITE_STORE, JSON.stringify(elitePicks)); } catch (e) { }
		const msg = Object.entries(picks).map(([slot, id]) => "elite." + slot + "=" + Math.max(0, ELITE.slots[slot].findIndex(x => x.id === id))).join(",");
		if (typeof api.onArmor === "function") api.onArmor("armor:" + msg + ",8c=" + eliteSet().id.toString(16));
		sendAppearance();
	}
	// Reach's matches put a whole armor set on an Elite (the profile's Elite armor, +0x8C; per-piece armor needs a
	// map of our own), so games get the set closest to the picks: the helmet's, else the one most pieces come from,
	// else Minor. (Before, +0x8C was left empty, and stock maps gave the Elite some other set; JANK_HUNT.md 7.)
	const ELITE_SETS = { minor: 0xA6, default: 0xA6, spec_ops: 0xAB, space: 0xAC, ultra: 0xA8, zealot: 0xA9, general: 0xAA, story_elite: 0xA7 };
	function eliteSet() {
		const setOf = (slot) => ELITE_SETS[elitePick(slot).split(".")[1]];
		let id = setOf("helmet");
		if (!id) {
			const count = {};
			for (const [slot] of ELITE_SLOTS) { const s = setOf(slot); if (s) count[s] = (count[s] || 0) + 1; }
			id = +(Object.entries(count).sort((a, b) => b[1] - a[1])[0] || [0xA6])[0];
		}
		const item = DATA["Elite Armor"] && DATA["Elite Armor"].items.find(i => i.id === id);
		return { id, name: item ? item.name : "MINOR" };
	}
	// The default Elite (owner, 2026-10-17: "make the elite default all minor armour and make them blue"): Reach's
	// Minor on every piece and Blue for both colors. A new player starts with it (newPlayer, the first run) and
	// the Elite page's Default row puts it back; saved looks are left alone. (armor.rs NOBLE_SIX writes the same.)
	// (a function: eliteRegions runs before these constants exist; a slot without a pick shows Minor, as the
	// profile's Elite armor, 8c=a6, has it in matches)
	function eliteMinor() {
		return { helmet: "helmet.minor", left_shoulder: "left_shoulder.minor", right_shoulder: "right_shoulder.minor",
			chest: "chest.minor", forearms: "forearms.default", legs: "legs.minor" };
	}
	// Only Reach's own Elite armor for now (owner, 2026-10-18: "hide any non standard elite armours", "anything reach
	// doesn't normally have"; "we'll likely enable them later"): the stock Elite's armor_pieces permutations
	// (mod-recovery/prophets_hand/regions.md). The added ones (Council, Honor Guard, Ossoona, Classic, Combat, Schism)
	// stay in elite-data.js, since saved picks are indices into its lists; eliteExtrasShown returning true offers them again.
	// (functions: eliteRegions runs before these constants exist)
	function eliteExtrasShown() { return false; }
	function eliteOffered(x) {
		const stock = ["minor", "default", "general", "officer", "space", "spec_ops", "story_elite", "ultra", "zealot"];
		return x.shown && !x.dup_of && (eliteExtrasShown() || stock.includes(x.id.split(".")[1]));
	}
	const ELITE_DEFAULT_COLOR = "Blue";
	function eliteDefault() {
		if (ELITE) eliteEquip(Object.fromEntries(Object.entries(eliteMinor()).filter(([s, id]) => ELITE.slots[s] && ELITE.slots[s].some(x => x.id === id))));
		try { localStorage.setItem("rr.classic.elitecolors", "{}"); } catch (e) { }
		for (const slot of ["Primary Color", "Secondary Color"]) if (DATA[slot]) eliteColorEquip(slot, ELITE_DEFAULT_COLOR);
	}
	const elitePreset = () => (ELITE.presets.find(pr => ELITE_SLOTS.every(([s]) => pr.slots[s] === elitePick(s))) || { name: "Custom" }).name;
	// The presets page's search: letters, digits and spaces type, Backspace deletes (and goes back when empty).
	window.addEventListener("keydown", (ev) => {
		const p = pages[pages.length - 1];
		if (!p || p.kind !== "elitepresets" || ev.ctrlKey || ev.altKey) return;
		const q = p.query || "";
		if (ev.key === "Backspace" && q) p.query = q.slice(0, -1);
		else if (ev.key.length === 1 && /[\w '()-]/.test(ev.key) && (ev.key !== " " || q)) p.query = (q + ev.key).slice(0, 30);
		else return;
		ev.preventDefault();
		ev.stopImmediatePropagation();
		p.sel = 0;
		renderPage();
	}, true);

	function entries(p) {
		// SPARTAN GENDER (Reach's Armory: "Choose the gender of your Spartan. This does not affect gameplay."),
		// also the first run's question after the name (chooseGender below).
		if (p.kind === "gender") return [false, true].map(female => ({ label: female ? "Female" : "Male", female, equipped: look.female === female,
			text: "Choose the gender of your Spartan. This does not affect gameplay." + (p.required ? " You can change it later in The Armory, under Player." : "") }));
		const st = settingsEntries(p);
		if (st) return st;
		const vo = voiceEntries(p);
		if (vo) return vo;
		if (p.kind === "armory") {
			return ARMORY_LIST.filter(s => s === "Colors" || s === "Emblem" || ARMOR[s]).map(s => ({
				label: s + "...", sep: s === "Emblem", off: s === "Emblem" && !window.EmblemEditor, slot: s,
				// (the Firefight voice also gives the sprint and callout sounds: players who never picked one sprinted with
				// Sgt. Johnson's male lines, female Spartans too; 2026-10-20 player batch, report 24, armor.rs)
				text: s === "Emblem" ? "Select an icon and background for your emblem. Its colors are under Colors."
					: s === "Firefight Voice" ? "The voice your Spartan speaks with in Firefight. It also sets your sprint and callout sounds. Noble Six speaks male or female by your Spartan Gender." : null,
				go: s === "Helmet" && DATA.Helmet && DATA.Helmet.families ? { kind: "families", slot: s }
					: s === "Colors" ? { kind: "colors" } : s === "Emblem" ? (window.EmblemEditor ? { kind: "emblem" } : null)
					: s === "Firefight Voice" && window.FF_VOICES ? { kind: "voices" }
					: DATA[s] && DATA[s].icons ? { kind: "pieces", slot: s } : { kind: "list", slot: s },
			}));
		}
		if (p.kind === "colors") {
			const armor = (s, label, text) => ({ label, slot: s, text, off: !ARMOR[s] });
			// The emblem's three colors (360 strings color_emblem1-3_current_choose); any color of the grid.
			const emblem = (label) => ({ label, slot: label, off: !ARMOR["Primary Color"],
				text: EMBLEM_COLORS[label][1] + " Press A to select." });
			if (p.elite && p.piece) {
				const name = (ELITE_PIECES.find(([key]) => key === p.piece) || [])[1] || p.piece;
				return [
					{ label: "Primary", slot: pieceSlot(p.piece, 0), text: "Your Elite's " + name.toLowerCase() + " color, over its armor color. Press A to select." },
					{ label: "Secondary", slot: pieceSlot(p.piece, 1), text: "The " + name.toLowerCase() + "'s trim color. Press A to select." },
					// The visor glows in the Armor Light Glow color (owner, 2026-10-18: the Ranger visor couldn't be
					// changed; the menu map marks its light, glow_colors.tsv), so the helmet page offers that color too.
					// Hidden until that menu map ships (owner, 2026-10-19: 0.1.12 goes out without it; set VISOR_ROW then).
					...(VISOR_ROW && p.piece === "helmet" ? [{ label: "Visor", slot: GLOW, off: !ARMOR["Primary Color"],
						text: "The color your Elite's visor glows. It is your Armor Light Glow, so the Elite's other lights take it too. Press A to select." }] : []),
					{ label: "Default", reset: [pieceSlot(p.piece, 0), pieceSlot(p.piece, 1)], off: ![0, 1].some(k => eliteColors()[pieceSlot(p.piece, k)]),
						text: "The " + name.toLowerCase() + " takes your Elite's own colors again. Press A to go back to them." },
				];
			}
			if (p.elite && p.pieces) return [
				...ELITE_PIECES.map(([key, name]) => ({ label: name, go: { kind: "colors", elite: true, piece: key },
					value: [0, 1].some(k => eliteColors()[pieceSlot(key, k)]) ? "Own colors" : "",
					text: "Your Elite's " + name.toLowerCase() + " colors. Press A to choose them." })),
				{ label: "Default Pieces", reset: PIECE_SLOTS, off: !PIECE_SLOTS.some(s => eliteColors()[s]),
					text: "Every piece takes your Elite's own colors again. Press A to go back to them." },
			];
			if (p.elite) return [
				armor("Primary Color", "Armor Primary", "Your Elite's armor color, in games where you play as an Elite. Press A to select."),
				armor("Secondary Color", "Armor Secondary", "The color of your Elite's trim. Press A to select."),
				// (the owner's name for it, 2026-10-17: "it should be called" armor light glow)
				{ label: "Armor Light Glow", slot: GLOW, off: !ARMOR["Primary Color"],
					text: "The color of your Elite's lights and visor, in the Armory and in games where you play as an Elite. Press A to select." },
				{ label: "Default Armor Light Glow", reset: [GLOW], off: !eliteColors()[GLOW],
					text: "Each armor's own light color. Press A to go back to it." },
				{ label: "Pieces...", go: { kind: "colors", elite: true, pieces: true }, off: !ARMOR["Primary Color"],
					text: "Colors for one piece at a time: helmet, shoulders, chest, forearms and legs, over your Elite's own colors. Press A to choose a piece." },
			];
			return [
				armor("Primary Color", "Armor Primary", "The primary armor color is used when you are in individual combat but overwritten in team scenarios. Press A to select."),
				armor("Secondary Color", "Armor Secondary", "The secondary armor color is used when you are in individual combat but overwritten in team scenarios. Press A to select."),
				// (beside the row too: matches have no undersuit color yet, and a missing one read as a bug; undersuit
				// report, 2026-10-19)
				{ ...armor(SUIT, "Undersuit", "The color of the bodysuit under your armor. Your Spartan wears it in the menus; in matches the undersuit keeps its usual dark grey for now. Press A to select."),
					aside: "Menus only" },
				emblem("Emblem Primary"), emblem("Emblem Secondary"), emblem("Emblem Background"),
			];
		}
		if (p.kind === "player") {
			return [
				{ label: "Ranks...", act: "ranks", text: "Every rank in Reach, the credits each needs, and yours." },
				{ label: "Service Record...", act: "record", text: "Your games, kills, deaths, missions and time played in Campaign, Firefight and multiplayer." },
				{ label: "Commendations...", act: "commendations", text: "Reach's 45 commendations, from Iron to Onyx and Max, and how far along each one you are." },
				{ label: "Service Tag", value: serviceTag(), act: "tag", text: "Four letters, numbers or symbols other players see on the scoreboard. A changes it. It applies the next time a game starts." },
				{ label: "Spartan Gender", value: look.female ? "Female" : "Male", look: "female",
					text: "Male or female Spartan, in every game you play as a Spartan. A, left or right changes it. It applies the next time a game starts."
						+ " Sprint and callout sounds come from your Firefight Voice (The Armory); Noble Six's follows this choice."
						+ (look.elite ? " (You play as an Elite where games let you choose: Preferred Species.)" : "") },
				{ label: POSE.label, value: (POSE.options.find(o => o[0] === (settingsState.pose ?? "0")) || POSE.options[0])[1], pick: true, setting: POSE,
					text: "How your Spartan stands on the player card in the main menu. Left and right change it; it shows right away." },
				{ label: "Preferred Species", value: look.elite ? "Elite" : "Spartan", look: "elite",
					text: "Play as a Spartan or an Elite in games that let players choose. A, left or right changes it. It applies the next time a game starts." },
			];
		}
		if (p.kind === "elite") {
			return [
				// (the presets are hidden for now, owner 2026-10-17; ELITE_PRESETS_SHOWN brings the row back, the data stays)
				...(ELITE_PRESETS_SHOWN ? [{ label: "Preset", value: elitePreset(), go: { kind: "elitepresets", query: "" },
					text: "A whole Elite look by name; it sets all six pieces. Type on the next page to search." }] : []),
				...ELITE_SLOTS.map(([slot, name], i) => {
					const pieces = ELITE.slots[slot], at = Math.max(0, pieces.findIndex(x => x.id === elitePick(slot)));
					// (matches: the armor pack's modular Elite wears each pick, host-probe elitepicks.rs; players whose
					// copy lacks it see the closest whole set, eliteSet)
					return { label: name, value: pieces[at].name, epick: slot, sep: i === 0,
						text: "Left and right change it. Your Elite wears it here, on your card and in multiplayer games where you play as an Elite. Players on an older version see the closest whole set: " + eliteSet().name + "." };
				}),
				// (owner, 2026-10-15: nowhere to change the Elite's colors) The Elite's own pair (eliteColors,
				// armor.rs `elite.primary/secondary`), used when you play as an Elite.
				{ label: "Colors...", go: { kind: "colors", elite: true }, sep: true,
					text: "Your Elite's own primary and secondary colors, separate from your Spartan's. They're used in games where you play as an Elite." },
				{ label: "Default", edefault: true,
					text: "Minor armor on every piece and blue for both colors, the Elite every player starts with. Press A to go back to it." },
			];
		}
		if (p.kind === "elitepresets") {
			const q = (p.query || "").toLowerCase(), now = elitePreset();
			const out = ELITE.presets.filter(pr => !q || pr.name.toLowerCase().includes(q)).map(pr => ({
				label: pr.name, epreset: pr, equipped: pr.name === now, value: pr.approximate ? "Close match" : "",
				text: ELITE_SLOTS.map(([s, n]) => n + ": " + (ELITE.slots[s].find(x => x.id === pr.slots[s]) || {}).name).join(", ") + "." }));
			return out.length ? out : [{ label: "No preset matches", off: true, text: "Backspace changes the search." }];
		}
		if (p.kind === "families") {
			const fams = DATA.Helmet.families;
			return fams.map(f => ({ label: f.name + " Variants...", title: f.name, text: f.text, family: f.name,
				icon: DATA.Helmet.familyIcons + "_" + f.icon + ".png", arrow: true, go: { kind: "pieces", slot: "Helmet", family: f.name },
				equipped: (DATA.Helmet.items.find(i => i.name === (saved.Helmet || ARMOR.Helmet[0])) || {}).family === f.name }));
		}
		const data = DATA[p.slot];
		const names = ARMOR[p.slot] || [];
		const current = saved[p.slot] || names[0];
		return names.map(n => {
			const it = data ? data.items.find(i => i.name === n) : null;
			return { name: n, it };
		}).filter(({ it }) => !p.family || (it && it.family === p.family)).map(({ name, it }) => ({
			label: p.family && it ? (it.variant || name).toUpperCase() : name,
			title: p.family && it ? (it.variant || name) : name, text: it ? it.text : "", family: p.family,
			// (the game's visors have no depot entry; their icons follow the list order)
			icon: data && data.icons && it ? data.icons + "_" + (it.icon ?? data.items.indexOf(it)) + ".png" : null,
			right: name === current ? "EQUIPPED" : it && it.cost ? it.cost + " cR" : "",
			equipped: name === current, swatch: swatchOf(p.slot, name), equip: name,
			visor: p.slot === "Visor Color" ? EXTRA_VISORS[name] : null,
		}));
	}
	// The emblem's colors on Armory > Colors: [index in Emblem's colors, the 360's text]. They take the
	// armor colors' grid and are kept as rgb (emblem.js draws them; the game gets them from host-probe).
	const EMBLEM_COLORS = {
		"Emblem Primary": [0, "This color is applied to the primary icon area of your emblem."],
		"Emblem Secondary": [1, "This color is applied to the secondary icon area of your emblem."],
		"Emblem Background": [2, "The emblem background color defines the color of the field that your icon sits on."],
	};
	// A color slot's grid, and its color now (a name of the grid).
	const gridNames = (slot) => ((EMBLEM_COLORS[slot] || EXACT.has(slot) ? ARMOR["Primary Color"] : ARMOR[slot]) || []).filter(n => n !== CUSTOM);
	function gridStored(slot, p) {
		if (!EMBLEM_COLORS[slot]) return (p && p.elite ? eliteColors() : saved)[slot];
		const hex = (window.Emblem ? Emblem.player().colors[EMBLEM_COLORS[slot][0]] : "").toLowerCase();
		return gridNames(slot).find(n => (swatchOf(slot, n) || "").toLowerCase() === hex);
	}
	// Tries a grid color on the emblem (null: back to the saved one), or keeps it.
	function emblemColor(slot, name, keep) {
		if (!window.Emblem) return;
		const colors = [...Emblem.player().colors];
		if (name) colors[EMBLEM_COLORS[slot][0]] = swatchOf(slot, name);
		if (keep) { Emblem.save({ colors }); Emblem.preview(null); sendAppearance(); }
		else Emblem.preview(name ? Object.assign(Emblem.player(), { colors }) : null);
	}
	function refreshEmblemGrid(p, names) {
		const grid = pageRoot.querySelector(".grid3"), cell = grid && grid.querySelector(`[data-c="${p.grid.idx}"]`);
		// Only reuse a complete, stationary grid. Scrolled/custom palettes keep the full renderer.
		if (!cell || grid.children.length !== names.length) return false;
		grid.querySelectorAll(".on").forEach(el => el.classList.remove("on"));
		cell.classList.add("on");
		pageRoot.querySelector(".cname").textContent = names[p.grid.idx] || "";
		// Preview changed only the colors. Keep the card, Figure fit and handlers; repaint its two emblems.
		if (window.Emblem) pageRoot.querySelectorAll(".rrbg .emb, .pcard .em canvas").forEach(Emblem.paint);
		return true;
	}
	function swatchOf(slot, name) {
		if (EMBLEM_COLORS[slot] || EXACT.has(slot)) return swatchOf("Primary Color", name);
		if (slot === SUIT) return name === SUIT_DEFAULT ? SUIT_DEFAULT_SWATCH : swatchOf("Primary Color", name);
		if (!isColorSlot(slot)) return null;
		// (no armory-data.js, a page copy without the generated files: no swatch rather than an error that stopped
		// sendAppearance; PC 2, 2026-10-17)
		const items = (DATA[slot] && DATA[slot].items) || [];
		return EXTRA_COLORS[name] || Object.values((items.find(it => it.name === name) || {}).colors || {})[0] || null;
	}
	function pageTitle(p) {
		if (p.kind === "armory") return "Spartan Armory";
		if (p.kind === "gender") return "Spartan Gender";
		if (p.kind === "families") return "Helmet";
		if (p.kind === "colors") return "Colors";
		if (p.kind === "emblem") return "Emblem";
		if (p.kind === "player") return "Player";
		if (p.kind === "game") return "Menu";
		if (p.kind === "quick") return "Quick Settings";
		if (p.kind === "quickpick") return "Choose Quick Settings";
		if (p.kind === "presets") return "Settings Presets";
		if (p.kind === "musictrack") return "Choose Track";
		if (p.kind === "musiclist") return "My Playlist";
		if (tabbed(p)) return "Settings";
		if (p.kind === "voices") return "Firefight Voice";
		if (p.kind === "elite") return "Elite Armory";
		if (p.kind === "elitepresets") return "Elite Presets";
		if (p.kind === "voicelines") return voiceName(p.voice);
		return p.family || p.slot;
	}
	function pageScene(p) {
		if (SETTINGS_KINDS.includes(p.kind) || p.kind === "voices" || p.kind === "voicelines") return null; // (no Spartan behind these)
		if ((p.kind === "list" && p.slot === "Elite Armor") || p.kind === "elite" || p.kind === "elitepresets") return "armory_elite";
		// PLAYER shows the species you play as (owner, 2026-10-13).
		// (the Spartan Gender row shows the Spartan the whole time it is highlighted: with Elite preferred,
		// the Elite after 3 s made a gender change look like it hadn't worked; stranger test, 2026-10-17)
		if (p.kind === "player" && look.elite && Date.now() >= spartanUntil && (entries(p)[p.sel] || {}).look !== "female") return "armory_elite";
		// The one-map backdrops (PLAN-017) have the 360's framings: closer for the list pages, head and
		// shoulders for the card pages' preview box.
		if (!window.INSTANT_SCENES) return "armory";
		// A piece page frames the piece (owner 2026-10-12): chest, wrists, the utility on the thigh, ...
		const PIECE_SCENES = { "Chest": "armory_chest", "Wrist": "armory_arm", "Utility": "armory_leg", "Knee Guards": "armory_knee",
			"Left Shoulder": "armory_shoulder", "Right Shoulder": "armory_shoulder" };
		if (p.kind === "pieces" && PIECE_SCENES[p.slot]) return PIECE_SCENES[p.slot];
		if (fxPage(p)) return "armory_full";
		// COLORS: further right, clear of the color grid (owner, 2026-10-14)
		if (p.kind === "colors") return p.elite ? "armory_elite" : "armory_colors";
		return p.kind === "families" || p.kind === "pieces" ? "armory_head" : "armory_full";
	}
	function openPage(p) {
		if (p.kind === "emblem" && window.EmblemEditor) EmblemEditor.start(p);
		if (tabbed(p) && !(pages.length && tabbed(pages[pages.length - 1]))) original = {};
		const list = entries(p);
		p.sel = p.sel ?? Math.max(0, list.findIndex(e => e.equipped));
		p.top = p.top ?? Math.max(0, p.sel - 1);
		pages.push(p);
		renderPage();
	}
	function renderPage() {
		const p = pages[pages.length - 1];
		// Read the old scroll position before any style writes, and only when keeping this page.
		const samePage = renderPage.last === p, oldList = samePage && pageRoot.querySelector(":scope > ul");
		const oldTop = oldList ? oldList.scrollTop : 0;
		if (!pageRoot.isConnected) {
			if (!pageStyle.isConnected) document.head.appendChild(pageStyle);
			document.body.appendChild(pageRoot);
		}
		root.classList.remove("open");
		pageRoot.classList.add("open");
		document.body.classList.add("paging");
		const list = entries(p);
		p.sel = Math.min(p.sel, list.length - 1);
		const cards = p.kind === "families" || p.kind === "pieces" || p.kind === "voices";
		pageRoot.classList.toggle("cards", cards);
		const trail = p.required ? "" : [pageTitle(p), ...pages.slice(0, -1).reverse().map(pageTitle), ...(pages[0].kind === "game" ? [] : ["Menu"])].slice(1).join(" ◆ ");
		const hint = (cls, key, text, a) => `<span class="hint" data-a="${a}"><span class="btn ${cls}">${key}</span>${text}</span>`;
		const e = list[p.sel] || {};
		let body = "";
		if (cards) {
			if (p.sel < p.top) p.top = p.sel;
			if (p.sel > p.top + 2) p.top = p.sel - 2;
			body = `<div class="cardlist">` + list.slice(p.top, p.top + 3).map((c, k) => `
				<div class="card${p.top + k === p.sel ? " sel" : ""}" data-i="${p.top + k}">
					<div class="n">${esc(c.label)}</div>${c.right ? `<div class="r">${esc(c.right)}</div>` : ""}
					${c.icon ? `<img src="${esc(c.icon)}" alt="" onerror="this.remove()">` : ""}${c.visor ? `<div class="vsw" style="background:linear-gradient(135deg, #${esc(c.visor[0])} 35%, #${esc(c.visor[1])})"></div>` : ""}${c.arrow ? `<div class="arrow">&rsaquo;</div>` : ""}
				</div>`).join("") + `</div>`
				+ (p.top > 0 ? `<div class="more" style="top:16.5vh">&#8963;</div>` : "")
				+ (p.top + 3 < list.length ? `<div class="more" style="top:72vh">&#8964;</div>` : "")
				// Scroll bar and position (owner 2026-10-12: a hidden 4th variant needs "1/4").
				+ (list.length > 3 ? `<div class="track"><i style="top:${(p.top / list.length) * 100}%;height:${(3 / list.length) * 100}%"></i></div>` : "")
				+ `<div class="count">${p.sel + 1}/${list.length}</div>`
				+ `<div class="box"${p.kind === "voices" && e.icon ? ` style="background:#0b1118 url('${esc(e.icon)}') center bottom / contain no-repeat"` : ""}></div><div class="info"><div class="t">${esc(e.title || "")}</div>`
				+ (p.kind === "pieces" && p.family ? `<div class="f">${esc(p.family)}</div>` : "")
				+ `<div class="d">${esc(e.text || "")}</div>` + (e.equipped && (p.kind === "pieces" || p.kind === "voices") ? `<div class="e">EQUIPPED</div>` : "") + `</div>`;
		} else if (p.kind === "emblem") {
			body = EmblemEditor.body(p);
		} else if (p.kind === "colors") {
			// COLORS (360): the five color slots, the color grid (COLOR_ROWS), the highlighted color's name
			// above it, and the live Spartan wearing it.
			const slot = p.grid ? p.grid.slot : (list[p.sel] || {}).slot;
			const names = slot ? gridNames(slot) : [];
			const stored = slot && gridStored(slot, p);
			const at = p.grid ? p.grid.idx : Math.max(0, names.indexOf(stored || names[0]));
			// A piece or glow with no color of its own follows the Elite's (owner, 2026-10-17: the first swatch, Jet
			// Black, showed picked and named, so a helmet in the Elite's colors looked stuck on black).
			const unset = !p.grid && slot && EXACT.has(slot) && !stored;
			// (twelve rows show, all of the color grid; more, as the undersuit's, scroll with a bar beside them)
			const SHOWN = 12, rows = Math.ceil(names.length / GRID_COLUMNS), first = Math.max(0, Math.min(Math.floor(at / GRID_COLUMNS) - 5, rows - SHOWN));
			const scroll = rows > SHOWN ? `<div class="gscroll" style="top:23.5vh;height:${(SHOWN * 4).toFixed(1)}vh"><i style="top:${(first / rows * 100).toFixed(1)}%;height:${(SHOWN / rows * 100).toFixed(1)}%"></i></div>` : "";
			const pieceName = p.piece && (ELITE_PIECES.find(([key]) => key === p.piece) || [])[1];
			body = `<div class="sub">${pieceName ? "Elite " + pieceName : p.pieces ? "Elite Pieces" : p.elite ? "Elite Colors" : "Spartan Colors"}</div><div class="cname">${esc(unset ? (slot === GLOW ? "Armor's Own" : "Elite's Colors") : names[at] || "")}</div><ul class="cl">` + list.map((c, i) =>
				`<li class="${[i === p.sel ? "sel" : "", c.off ? "off" : ""].join(" ")}" data-i="${i}"><span>${esc(c.label)}</span>${c.aside ? `<span class="aside">${esc(c.aside)}</span>` : ""}</li>`).join("") + `</ul>`
				+ `<div class="about cl">${esc(e.text || "")}</div><div class="grid3">`
				+ names.map((n, i) => i < first * GRID_COLUMNS || i >= (first + SHOWN) * GRID_COLUMNS ? "" :
					`<div class="cell${i === at && !unset ? " on" : ""}${n === stored ? " eq" : ""}" data-c="${i}" style="background:#${esc(swatchOf(slot, n) || "777")}"></div>`).join("") + `</div>` + scroll;
		} else if (tabbed(p)) {
			body = `<div class="tabs"><span class="lb">LB</span>` + SETTINGS_TABS.map(([k, n]) => `<span class="tab${k === p.kind ? " on" : ""}" data-tab="${k}">${esc(n)}</span>`).join("")
				+ `<span class="rb">RB</span></div><ul>` + list.map((c, i) => (c.group && (i === 0 || list[i - 1].group !== c.group) ? `<li class="grp">${esc(c.group)}</li>` : "")
				+ `<li class="${[i === p.sel ? "sel" : "", c.off ? "off" : ""].join(" ")}" data-i="${i}"><span>${esc(c.label)}</span>`
				+ (c.value || c.key ? `<span class="${["val", c.pick ? "pick" : "", c.key ? "key" : "", c.unbound ? "none" : "", c.wait ? "wait" : "", p.edit === i ? "editing" : ""].join(" ")}"${c.fill !== undefined && p.edit !== i
					? ` style="background:linear-gradient(90deg, rgba(110,160,200,0.55) ${(c.fill * 100).toFixed(1)}%, rgba(10,18,26,0.55) ${(c.fill * 100).toFixed(1)}%)"` : ""}>${editValue(p, i, c)}</span>` : "")
				+ `</li>`).join("") + `</ul>`;
			if (p.kind === "theme") body += `<div class="tprev"></div>`;
			body += `<div class="about"><b>${esc(e.label || "")}</b>${esc(e.text || "")}${e.warn ? `<i class="warn">${esc(e.warn)}</i>` : ""}${e.note ? `<i>${esc(e.note)}</i>` : ""}</div><div class="applying"></div>`;
		} else {
			// (the Elite presets: 8 rows at a time under the search box)
			const el = p.kind === "elite" || p.kind === "elitepresets" || p.kind === "player" || p.kind === "gender", search = p.kind === "elitepresets", ROWS = 8;
			if (search) {
				p.top = Math.min(p.top || 0, p.sel);
				if (p.sel >= p.top + ROWS) p.top = p.sel - ROWS + 1;
			}
			const first = search ? p.top : 0, shown = search ? list.slice(first, first + ROWS) : list;
			body = (search ? `<div class="esearch">${esc(p.query || "")}<b>|</b>${p.query ? "" : "<i>Type to search</i>"}</div>` : "")
				+ `<ul class="${el ? "el" : ""}${search ? " search" : ""}">` + shown.map((c, k) => { const i = first + k; return `<li class="${[i === p.sel ? "sel" : "", c.sep ? "sep" : "", c.off ? "off" : ""].join(" ")}" data-i="${i}">
				<span>${c.swatch ? `<span class="swatch" style="background:#${esc(c.swatch)}"></span>` : ""}${esc(c.label)}</span>${c.equipped ? `<span class="eq">EQUIPPED</span>` : ""}${c.value ? `<span class="val${p.edit === i ? " editing" : ""}">${editValue(p, i, c)}</span>` : ""}</li>`; }).join("") + `</ul>`
				+ (search && list.length > ROWS ? `<div class="more" style="left:47.5vw;top:22vh">${p.top + 1}-${Math.min(list.length, p.top + ROWS)} of ${list.length}</div>` : "");
			if (p.kind === "theme") body += `<div class="tprev"></div>`;
			if (p.kind === "game") {
				const rows = matchRows(window.lastGame);
				if (rows.length) body += `<div class="match">` + rows.map(([k, v, none]) => `<div><span>${esc(k)}</span><b${none ? ` class="none"` : ""}>${esc(v)}</b></div>`).join("") + `</div>`;
			}
			const about = e.text || (p.kind === "list" && e.it ? "" : "");
			if (about) body += `<div class="about${el ? " el" : ""}">${esc(about)}</div>`;
		}
		const select = p.edit != null ? "Done" : (list[p.sel] || {}).setting ? "Change" : p.kind === "musiclist" ? ((settingsState["music.playlist"] || "").split(";").includes((list[p.sel] || {}).musiclist) ? "Remove" : "Add") : p.kind === "musictrack" ? "Choose" : p.kind === "list" || p.kind === "pieces" || p.kind === "voices" || p.kind === "gender" ? "Equip" : p.kind === "keyboard" ? "Change" : p.kind === "voicelines" ? "Play" : p.kind === "emblem" ? "Apply" : "Select";
		pageRoot.classList.toggle("settings", SETTINGS_KINDS.includes(p.kind) || p.kind === "voicelines");
		pageRoot.classList.toggle("tabbed", tabbed(p));
		pageRoot.classList.toggle("portraits", p.kind === "voices");
		renderPage.last = p;
		// Share the editor's central raster-cache entry with its decorative backdrop. Their CSS
		// sizes stay unchanged; one emblem no longer needs two large CPU rasters on each move.
		const backdropPx = p.kind === "emblem" ? Math.max(16, Math.round(innerHeight * 0.166 * (devicePixelRatio || 1))) : 128;
		pageRoot.innerHTML = `<div class="rrbg"><div class="lattice"></div><canvas class="emb" width="${backdropPx}" height="${backdropPx}"></canvas><div class="vig"></div></div><div class="dots"></div><div class="head">${DIAMOND}<h1>${esc(pageTitle(p))}</h1></div><div class="side">${esc(trail)}</div>${body}
			<div class="pcard plate"></div>
			<div class="keys">${hint("a", "A", select, "select")}${p.required ? "" : hint("b", "B", p.kind === "emblem" || p.edit != null ? "Cancel" : "Back", "back")}${p.edit != null ? hint("lr", "&#9664;&#9654;", "Change", "right") : ""}${p.kind === "voices" ? hint("x", "X", "Play Sample", "star") + hint("y", "Y", "Voice Lines", "refresh") : ""}${p.kind === "emblem" ? hint("x", "X", "Toggle Emblem", "star") : ""}${p.kind === "musiclist" ? hint("x", "X", window.MenuMusic && MenuMusic.previewing() === (list[p.sel] || {}).musiclist ? "Stop Listening" : "Listen", "star") : ""}${tabbed(p) && canRevert() ? hint("x", "X", "Revert Changes", "star") : ""}${p.kind === "player" || p.kind === "voicelines" || SETTINGS_KINDS.includes(p.kind) ? "" : hint("rs", "RS", "Turn", "turnr")}${pages[0].kind === "game" ? `<span class="exit">${hint("start", "&#9776;", "Exit", "start")}</span>` : ""}</div>`;
		if (!pageRoot.classList.contains("settings")) fillCard(pageRoot.querySelector(".pcard"));
		// Only whole-figure pages display this decorative emblem.
		if (window.Emblem && !cards && pageScene(p)) pageRoot.querySelectorAll(".rrbg .emb").forEach(Emblem.paint);
		if (p.kind === "emblem") { EmblemEditor.paint(pageRoot, p); EmblemEditor.bind(pageRoot, p, pageAct); }
		{
			const ul = pageRoot.querySelector(":scope > ul"), about = pageRoot.querySelector(":scope > .about"), match = pageRoot.querySelector(":scope > .match");
			// (the game menu's match details: the text goes right under them, beside the list, not below it)
			if (match && about) about.style.top = (match.getBoundingClientRect().bottom / innerHeight * 100 + 1.8).toFixed(1) + "vh";
			else if (ul && about && !tabbed(p)) {
				const below = ul.getBoundingClientRect().bottom / innerHeight * 100 + 2;
				if (below > 52) about.style.top = below.toFixed(1) + "vh";
			}
		}
		pageRoot.querySelectorAll("[data-i]").forEach(el => el.onclick = () => {
			p.grid = null;
			if (p.edit != null && p.edit !== +el.dataset.i) p.edit = null; // (clicking another row ends the change)
			p.sel = +el.dataset.i;
			pageAct("select");
		});
		// The row being changed: its arrows step, its value opens the list of choices (controls.js).
		pageRoot.querySelectorAll(".val.editing .arr").forEach(el => el.onclick = (ev) => { ev.stopPropagation(); pageAct(el.dataset.step === "1" ? "right" : "left"); });
		pageRoot.querySelectorAll(".val.editing .vt").forEach(el => el.onclick = (ev) => {
			ev.stopPropagation();
			const cur = list[p.edit], s = cur && cur.setting;
			if (!s || !window.Dropdown) return;
			Dropdown.open({ title: cur.label, options: s.options, value: settingsState[s.key] ?? s.default ?? s.options[0][0], anchor: el.parentElement,
				onPick(v) { setSetting(s.key, v, cur.label); renderPage(); } });
		});
		pageRoot.querySelectorAll("[data-c]").forEach(el => el.onclick = () => {
			if (!p.grid) { p.grid = { slot: list[p.sel].slot, idx: 0 }; }
			p.grid.idx = +el.dataset.c;
			pageAct("select");
		});
		pageRoot.querySelectorAll(".keys [data-a]").forEach(el => el.onclick = () => pageAct(el.dataset.a));
		pageRoot.querySelectorAll("[data-tab]").forEach(el => el.onclick = () => switchTab(el.dataset.tab));
		// The wheel moves the highlight one row a turn (a hover only moves it once the mouse really moves:
		// MenuScroll.hoverOk, controls.js); the list keeps its place and shows the highlight.
		pageRoot.onwheel = (ev) => { ev.preventDefault(); pageAct(ev.deltaY > 0 ? "down" : "up"); };
		{
			const ul = pageRoot.querySelector(":scope > ul");
			if (ul && window.MenuScroll) {
				ul.classList.add(MenuScroll.CLASS);
				if (samePage) ul.scrollTop = oldTop;
			}
		}
		const selEl = pageRoot.classList.contains("settings") && pageRoot.querySelector("ul li.sel");
		if (selEl) selEl.scrollIntoView({ block: "nearest" });
		spartanBoxed = cards && p.kind !== "voices" && !fxPage(p);
		pageRoot.classList.toggle("fxwhole", fxPage(p));
		pageRoot.classList.toggle("eliteview", pageScene(p) === "armory_elite");
		// (under Wine, between the box's close-up and the whole Spartan: the old picture goes first, or it hung
		// unclipped over the page until the other camera's first frame)
		if (window.Figure && pageOpaque() && pageScene(p) && Figure.mode && Figure.mode !== (spartanBoxed ? "live" : "texcam")) Figure.want(null);
		if (window.Figure) Figure.clip(spartanBoxed ? pageRoot.querySelector(".box") : null);
		showSpartan(pageScene(p));
		// His place beside this page's panels: right of the rightmost one above the plate (the color
		// grid, a second list, ...), with a little room.
		if (window.Figure && pageScene(p) && !cards && !pageOpaque()) {
			const plate = pageRoot.querySelector(".plate");
			const floor = plate ? plate.getBoundingClientRect().top : innerHeight;
			let right = 0;
			for (const el of pageRoot.children) {
				if (el.matches(".rrbg, .plate, .keys, .head, .side, .box")) continue;
				const r = el.getBoundingClientRect();
				if (r.width > 0 && r.top < floor) right = Math.max(right, r.right);
			}
			// Whole-body framings fit between the title and the plate; the close-ups (a piece, the helmet)
			// only keep right of the panels, as they are framed to be cut by the picture's edge.
			const whole = !cards && ["armory_full", "armory", "armory_elite", "armory_colors"].includes(pageScene(p));
			Figure.keepRightOf(cards || whole || !right ? null : right / innerWidth + 0.02);
			Figure.fitTo(whole ? Object.assign({}, ARMORY_FIT, right ? { left: right / innerWidth + 0.02 } : {}) : null);
		}
		if (window.Figure && (cards || !pageScene(p) || pageOpaque())) { Figure.keepRightOf(null); Figure.fitTo(null); }
		if (p.kind === "theme") themePreview((list[p.sel] || {}).theme); else endPreview();
		if (p.kind !== "musiclist" && window.MenuMusic && MenuMusic.previewing()) MenuMusic.preview(null);
		if (tabbed(p)) showChanges();
	}
	// Another tab of the settings screen: it replaces the current page (Back still leaves the screen).
	function switchTab(kind) {
		const p = pages[pages.length - 1];
		if (!p || !tabbed(p) || p.kind === kind) return;
		capturing = null;
		pages[pages.length - 1] = { kind, sel: 0, top: 0, edit: null };
		renderPage();
	}
	function closePages() {
		if (window.Emblem) Emblem.preview(null);
		if (window.MenuMusic && MenuMusic.previewing()) MenuMusic.preview(null);
		spartanBoxed = false;
		endPreview();
		pages.length = 0;
		pageRoot.classList.remove("open");
		document.body.classList.remove("paging");
	}
	function pageAct(a) {
		const p = pages[pages.length - 1];
		const list = entries(p);
		const play = (n) => { if (typeof Sound !== "undefined") Sound.play(n); };
		padUnseen = null; // (the Controller page's "no controller seen" stays until the next button or key)
		// The controller's Start button (index.html "pause"): out of the menu, or back to the match.
		if (a === "pause" && padCapturing === null && capturing === null && !p.required) {
			play("details_out");
			if (p.grid) sendAppearance();
			if (pages[0].kind === "game") return gameAction("resume");
			closePages();
			close();
			return;
		}
		if (a === "pause") return;
		if (p.kind === "gender" && genderAct(p, a, list, play)) return;
		// Tab (Start) doesn't close these pages (owner, 2026-10-17); in a match's menu it still resumes the game.
		if (a === "start") { if (pages[0].kind !== "game") return; play("details_out"); if (p.grid) sendAppearance(); return gameAction("resume"); }
		// Settings: left/right (or A) change an Audio Video value; A on a Keyboard action waits for a key;
		// the in-game menu's own actions; B on the in-game menu goes back to the game.
		if (voicesAct(p, a, list)) return;
		if (p.kind === "emblem") {
			const done = EmblemEditor.act(p, a);
			if (done === "apply" || done === "cancel") {
				play(done === "apply" ? "select" : "back");
				if (done === "apply") sendAppearance();
				pages.pop();
				return renderPage();
			}
			if (done) { play(a === "star" ? "change" : "move"); return renderPage(); }
		}
		if (p.kind === "theme" && a === "select" && list[p.sel]) {
			try { localStorage.setItem(THEME_STORE, list[p.sel].theme); } catch (e) { }
			play("select");
			if (typeof api.onTheme === "function") api.onTheme(list[p.sel].theme);
			return renderPage();
		}
		const cur = list[p.sel] || {};
		// (waiting for controller buttons: the controller's presses are the binding, not menu actions)
		if (padCapturing !== null) return;
		if (tabbed(p) && a === "star") {
			if (!canRevert()) return play("error");
			play("back");
			revertChanges();
			return renderPage();
		}
		// Settings (stranger test, 2026-10-17: "you have to select the setting you want to change with
		// either a click or the A button, and then arrows pop up ... and only then can change that
		// setting"): A or a click starts changing a row; left and right (or its arrows) step its value and
		// a click on the value lists the choices; A or a click on the row keeps it, B or Esc puts the
		// value from before back; up and down keep it and move on. Nothing else changes a setting.
		if (p.edit != null) {
			const er = list[p.edit];
			if (!er || !er.setting) p.edit = null;
			else if (a === "left" || a === "right") {
				const s = er.setting, opts = s.options;
				const at = Math.max(0, opts.findIndex(o => o[0] === (settingsState[s.key] ?? s.default ?? opts[0][0])));
				// (no wrapping: the ends stop, as a slider does)
				const next = Math.max(0, Math.min(opts.length - 1, at + (a === "left" ? -1 : 1)));
				if (next === at) return play("error");
				setSetting(s.key, opts[next][0], er.label);
				play("change");
				return renderPage();
			} else if (a === "select") { p.edit = null; play("select"); return renderPage(); }
			else if (a === "back") {
				const s = er.setting;
				if (p.editGfx) { // (the graphics preset: every row back as it was)
					for (const g of GFX) if ((settingsState[g.key] ?? g.default) !== p.editGfx[g.key]) changeSetting(g.key, p.editGfx[g.key], g.label);
					if (settingsState["gfx.preset"] !== gfxPreset()) changeSetting("gfx.preset", gfxPreset(), er.label);
				} else if ((settingsState[s.key] ?? s.default) !== p.editFrom && p.editFrom !== undefined) setSetting(s.key, p.editFrom, er.label);
				p.edit = null;
				play("back");
				return renderPage();
			}
			else if (a === "up" || a === "down") p.edit = null; // (keeps the value; moves on below)
			else return;
		}
		if (cur.setting && a === "select") {
			p.edit = p.sel;
			p.editFrom = settingsState[cur.setting.key] ?? cur.setting.default ?? cur.setting.options[0][0];
			p.editGfx = cur.setting.key === "gfx.preset" ? Object.fromEntries(GFX.map(g => [g.key, settingsState[g.key] ?? g.default])) : null;
			play("select");
			return renderPage();
		}
		// (left and right on a row not being changed do nothing on the settings pages)
		if (SETTINGS_KINDS.includes(p.kind) && (a === "left" || a === "right") && p.kind !== "game") return;
		if (cur.bind !== undefined && a === "select") { play("select"); capturing = cur.bind; return renderPage(); }
		if (cur.padbind && a === "select") { play("select"); padCapture(cur.padbind, cur.label); return renderPage(); }
		if (cur.padmap && a === "select") { play("select"); padMapCapture(cur.padmap); return renderPage(); }
		if (cur.act === "padreset" && a === "select") {
			for (const [id] of PAD_LAYOUT) if (+(settingsState["pad.map." + id] || 0)) changeSetting("pad.map." + id, 0, "Controller layout");
			play("select");
			return renderPage();
		}
		if (cur.musictrack && a === "select") {
			setSetting("music.track", cur.musictrack, "Menu music track");
			if (settingsState.music !== "track") setSetting("music", "track", "MENU MUSIC");
			play("select");
			return renderPage();
		}
		if (cur.musiclist && (a === "select" || a === "star")) {
			if (a === "star") {
				MenuMusic.preview(MenuMusic.previewing() === cur.musiclist ? null : cur.musiclist);
				play("change");
				return renderPage();
			}
			const ids = (settingsState["music.playlist"] || "").split(";").filter(Boolean);
			const at = ids.indexOf(cur.musiclist);
			if (at >= 0) ids.splice(at, 1); else ids.push(cur.musiclist);
			setSetting("music.playlist", ids.join(";"), "My Playlist");
			if (ids.length && settingsState.music !== "playlist") setSetting("music", "playlist", "MENU MUSIC");
			play("change");
			return renderPage();
		}
		if (cur.pickid && a === "select") {
			const ids = quickIds();
			const at = ids.indexOf(cur.pickid);
			if (at >= 0) ids.splice(at, 1);
			else if (ids.length >= QUICK_MAX) { play("error"); return; }
			else ids.push(cur.pickid);
			setSetting("quick", ids.join(";") || ";");
			play("change");
			return renderPage();
		}
		if (cur.preset && a === "select") {
			if (cur.preset.op === "load" && cur.off) { play("error"); return; }
			play("select");
			if (typeof api.onArmor === "function") api.onArmor("preset-" + cur.preset.op + ":" + cur.preset.slot);
			return;
		}
		if (tabbed(p) && (a === "tabl" || a === "tabr")) {
			const at = SETTINGS_TABS.findIndex(t => t[0] === p.kind);
			play("move");
			return switchTab(SETTINGS_TABS[(at + (a === "tabr" ? 1 : SETTINGS_TABS.length - 1)) % SETTINGS_TABS.length][0]);
		}
		if (cur.act === "ranks" && a === "select") { if (window.Ranks) Ranks.show(); return; }
		if ((cur.act === "record" || cur.act === "commendations") && a === "select") { if (window.Career) Career.show(cur.act); return; }
		if (cur.act === "tag" && a === "select" && window.TagPrompt) {
			play("select");
			return TagPrompt.show(serviceTag(), (tag) => { settingsState.tag = tag; renderPage(); });
		}
		if (cur.epick && (a === "left" || a === "right" || a === "select")) {
			// Step over pieces the build lacks (shown false), duplicates of another piece (dup_of) and hidden added
			// armor (eliteOffered); the list itself keeps every piece, as saved picks are indices into it.
			const pieces = ELITE.slots[cur.epick], at = Math.max(0, pieces.findIndex(x => x.id === elitePick(cur.epick)));
			let next = at;
			for (let n = 0; n < pieces.length; n++) {
				next = (next + (a === "left" ? pieces.length - 1 : 1)) % pieces.length;
				if (eliteOffered(pieces[next])) break;
			}
			eliteEquip({ [cur.epick]: pieces[next].id });
			play("change");
			return renderPage();
		}
		if (cur.edefault && a === "select") {
			eliteDefault();
			play("select");
			return renderPage();
		}
		if (cur.epreset && a === "select") {
			eliteEquip(Object.assign({}, cur.epreset.slots));
			play("select");
			pages.pop();
			return renderPage();
		}
		if (cur.look && (a === "select" || a === "left" || a === "right")) {
			setLook(cur.look, !look[cur.look]);
			play("change");
			return renderPage();
		}
		if (cur.act === "name" && a === "select" && window.NamePrompt) {
			play("select");
			return NamePrompt.show(cur.value, false, () => renderPage());
		}
		if ((cur.act === "firewall-fix" || cur.act === "firewall-check") && a === "select") {
			if (firewall.busy) return play("error");
			play("select");
			firewallAsk(cur.act === "firewall-fix");
			return renderPage();
		}
		// Leave Game, End Game and Exit Client ask first, No highlighted (bug sweep 2026-10-17: Leave Game left at
		// once, and a host leaving ends the game for everyone).
		if ((cur.act === "leave" || cur.act === "quit" || cur.act === "end" || cur.act === "end-round") && a === "select" && window.Dropdown) {
			const what = cur.act;
			const ASK = { leave: ["Leave this game?", "No, keep playing", "Yes, leave the game"], end: ["End this game for everyone?", "No, keep playing", "Yes, end the game"],
				"end-round": ["End this round for everyone?", "No, keep playing", "Yes, end the round"],
				quit: ["Close Reach Renaissance?", "No", "Yes, close it"] }[what];
			Dropdown.open({ title: ASK[0], value: "no",
				anchor: document.querySelector(".ar ul li.sel") || null,
				options: [["no", ASK[1]], ["yes", ASK[2]]],
				onPick: (v) => { if (v === "yes") { play("select"); gameAction(what); } } });
			return;
		}
		// Change Team: pick a team; the game moves you if its Team Changing allows it, and the menu goes back to the game.
		if (cur.act === "team" && a === "select" && window.Dropdown) {
			const t = window.lastGame.teams, names = window.Social ? Social.TEAMS : [];
			Dropdown.open({ title: "Change Team", value: null, anchor: document.querySelector(".ar ul li.sel") || null,
				options: names.map((n, i) => [String(i), n[0] + " Team"]).filter((o, i) => t.mask >> i & 1),
				onPick: (v) => { play("select"); if (typeof api.onArmor === "function") api.onArmor("game-menu:team:" + v); gameAction("resume"); } });
			return;
		}
		// Save Map (Forge): the game saves, and the menu goes back to the game.
		if (cur.act === "save-map" && a === "select") {
			play("select");
			if (typeof api.onArmor === "function") api.onArmor("game-menu:save-map");
			return gameAction("resume");
		}
		// Save Map As: a name first (name-prompt.js), then as Save Map; the name goes in the saved file (host-probe forgesave.rs).
		if (cur.act === "save-map-as" && a === "select" && window.NamePrompt) {
			play("select");
			return NamePrompt.show(window.lastGame.map || "", false, (name) => {
				// (the match ended under the prompt, onGameReturn: no game to save, and game-menu:resume would hide the menus)
				if (!document.body.classList.contains("ingame")) return;
				if (typeof api.onArmor === "function") api.onArmor("game-menu:save-map:" + name);
				gameAction("resume");
			}, { title: "Save Map As", text: "Name this Forge map. It shows in Select Map under its map (My Maps), by this name.", max: 32 });
		}
		if (cur.act && a === "select") { play("select"); return gameAction(cur.act); }
		if (p.kind === "game" && (a === "back" || a === "left")) { play("back"); return gameAction("resume"); }
		if (p.kind === "controller" && a === "select") return;
		// Turn the live Spartan (360: right stick "Move Camera"; also LB/RB, Q/E, a mouse drag).
		if (a === "turnl" || a === "turnr" || a === "tabl" || a === "tabr") {
			holdTurn(a === "turnr" || a === "tabr" ? 1 : -1);
			return;
		}
		// COLORS grid: arrows move (three across), the Spartan shows the color at once; A equips, B puts
		// the old one back.
		if (p.kind === "colors" && p.grid) {
			const names = gridNames(p.grid.slot);
			const step = { left: -1, right: 1, up: -GRID_COLUMNS, down: GRID_COLUMNS }[a];
			if (step) {
				p.grid.idx = Math.max(0, Math.min(names.length - 1, p.grid.idx + step));
				play("move");
				if (EMBLEM_COLORS[p.grid.slot]) {
					emblemColor(p.grid.slot, names[p.grid.idx]);
					if (refreshEmblemGrid(p, names)) return;
				}
				else if (p.elite) {
					eliteColorPreview = { slot: p.grid.slot, name: names[p.grid.idx] };
					sendAppearance();
					eliteColorPreview = null;
				} else {
					const keep = saved[p.grid.slot];
					saved[p.grid.slot] = names[p.grid.idx];
					sendAppearance();
					saved[p.grid.slot] = keep;
				}
			} else if (a === "select") {
				play("select");
				if (EMBLEM_COLORS[p.grid.slot]) emblemColor(p.grid.slot, names[p.grid.idx], true);
				else if (p.elite) eliteColorEquip(p.grid.slot, names[p.grid.idx]); else equip(p.grid.slot, names[p.grid.idx]);
				p.grid = null;
			} else if (a === "back") {
				play("back");
				if (EMBLEM_COLORS[p.grid.slot]) emblemColor(p.grid.slot, null);
				p.grid = null;
				sendAppearance();
			}
			return renderPage();
		}
		if (p.kind === "colors" && a === "select") {
			const e = list[p.sel];
			if (e && !e.off && e.go) {
				play("select");
				return openPage({ ...e.go });
			} else if (e && !e.off && e.reset) {
				play("select");
				for (const slot of e.reset) eliteColorEquip(slot, null);
			} else if (e && !e.off) {
				play("select");
				const names = gridNames(e.slot);
				p.grid = { slot: e.slot, idx: Math.max(0, names.indexOf(gridStored(e.slot, p) || names[0])) };
			} else play("error");
			return renderPage();
		}
		if (a === "down" || a === "up") {
			p.sel = (p.sel + (a === "down" ? 1 : list.length - 1)) % list.length;
			play("move");
		} else if (a === "back" || (a === "left" && p.kind !== "pieces")) {
			play("back");
			pages.pop();
			if (!pages.length) { closePages(); root.classList.add("open"); render(); return; }
		} else if (a === "select" || a === "right") {
			const e = list[p.sel];
			if (!e) return;
			if (e.go) { play("select"); return openPage({ ...e.go }); }
			if (e.equip && a === "select") {
				play("select");
				equip(p.slot, e.equip);
			} else if (a === "select") play("error");
		}
		renderPage();
	}
	// SPARTAN GENDER: the Spartan beside the list wears the highlighted one; A keeps it, B goes back to
	// the one before (not on the first run, p.required: the menus open once it is chosen).
	function genderAct(p, a, list, play) {
		if (a === "up" || a === "down" || a === "left" || a === "right") {
			p.sel = 1 - p.sel;
			setLook("female", list[p.sel].female);
			play("move");
			renderPage();
			return true;
		}
		if (a === "select") {
			if (look.female !== list[p.sel].female) setLook("female", list[p.sel].female);
			play("select");
			pages.pop();
			if (p.required || !pages.length) { closePages(); close(); }
			else renderPage();
			if (p.done) p.done(look.female);
			return true;
		}
		if (a === "back" || a === "start") {
			if (p.required) { play("error"); return true; }
			if (look.female !== p.was) setLook("female", p.was);
			return false;
		}
		return false;
	}
	// 72 facings, 5 degrees apart (host-probe armory.rs `turn`, the menu map's rr_spin, which glides
	// there); 6 faces the camera a little, as on the 360. A press turns 15 degrees, a drag 5 at a time.
	let turn = 6;
	// The game glides a step a tick toward `turn` the short way round, so a facing more than half a turn
	// ahead of where it is made him spin back the other way while Q/E was held (owner, 2026-10-14). So
	// the page keeps an estimate of where the game is (TURN_RATE steps a second, below its real speed)
	// and lets the facing lead it by at most TURN_LEAD steps.
	const TURN_RATE = 20, TURN_LEAD = 18;
	// Holding Q/E, LB/RB or the right stick turns him one way at TURN_HOLD steps a second until it is let
	// go (index.html: turnRelease); a press alone turns 15 degrees at the same pace. Key and controller
	// repeats add no steps of their own: they came in bursts, so he turned in jerks (owner, 2026-10-18).
	const TURN_HOLD = 20;
	let hold = null; // { dir, owed: steps a press still owes, held, next: when the next step is due, timer }
	function holdTurn(dir) {
		if (hold && hold.dir === dir) { hold.held = true; return; } // (a repeat)
		stopTurn();
		hold = { dir, owed: 3, held: true, next: performance.now(), timer: 0 };
		tickTurn();
	}
	function tickTurn() {
		if (!hold) return;
		if (!pages.length) return stopTurn();
		const now = performance.now();
		// (a late timer doesn't make up the steps it missed in a burst)
		if (now - hold.next > 200) hold.next = now;
		while (hold.next <= now && (hold.held || hold.owed > 0)) {
			turnSpartan(hold.dir);
			hold.owed--;
			hold.next += 1000 / TURN_HOLD;
		}
		if (!hold.held && hold.owed <= 0) { hold = null; return; }
		hold.timer = setTimeout(tickTurn, Math.max(0, hold.next - performance.now()));
	}
	function releaseTurn(dir) { if (hold && (dir === undefined || hold.dir === dir)) hold.held = false; }
	function stopTurn() { if (hold) clearTimeout(hold.timer); hold = null; }
	// (a key let go while the menus' window wasn't focused never says so)
	window.addEventListener("blur", () => releaseTurn());
	let turnTarget = 6, turnShown = 6, turnAt = 0;
	function turnSpartan(step) {
		const now = performance.now();
		const gap = turnTarget - turnShown, move = turnAt ? (now - turnAt) / 1000 * TURN_RATE : Infinity;
		turnShown += Math.sign(gap) * Math.min(Math.abs(gap), move);
		turnAt = now;
		if (Math.abs(turnTarget + step - turnShown) > TURN_LEAD) return;
		turnTarget += step;
		turn = ((turnTarget % 72) + 72) % 72;
		if (typeof api.onArmor === "function") api.onArmor("turn:" + turn);
	}
	// Mouse: drag sideways over the page to turn the Spartan (5 degrees per 1% of the width).
	let dragX = null;
	pageRoot.addEventListener("mousedown", (ev) => { if (ev.button === 0 && !ev.target.closest("[data-i],[data-c],[data-a]")) dragX = ev.clientX; });
	window.addEventListener("mouseup", () => { dragX = null; });
	window.addEventListener("mousemove", (ev) => {
		if (dragX === null || !pages.length) return;
		const stepPx = window.innerWidth * 0.01;
		while (Math.abs(ev.clientX - dragX) >= stepPx) {
			const dir = ev.clientX > dragX ? -1 : 1;
			turnSpartan(dir);
			dragX -= dir * stepPx;
		}
	});
	function eliteColorEquip(slot, name) {
		const c = eliteColors();
		if (name) c[slot] = name; else delete c[slot];
		try { localStorage.setItem("rr.classic.elitecolors", JSON.stringify(c)); } catch (e) { }
		if (EXACT.has(slot)) return sendAppearance();
		const piece = EXTRA_COLORS[name] ? nearestPreset(slot, EXTRA_COLORS[name]) : DATA[slot].items.find(i => i.name === name);
		if (piece && typeof api.onArmor === "function") api.onArmor("armor:elite." + (slot === "Primary Color" ? "primary" : "secondary") + "=" + piece.id.toString(16));
		sendAppearance();
	}
	function equip(slot, name) {
		saved[slot] = name;
		try { localStorage.setItem(STORE, JSON.stringify(saved)); } catch (e) { }
		const data = DATA[slot];
		if (slot === SUIT) return sendAppearance(); // (not in the profile: the menus keep it)
		if (!data || typeof api.onArmor !== "function") return;
		// An extra color: the profile (and other players) get the nearest game color.
		const piece = EXTRA_COLORS[name] ? nearestPreset(slot, EXTRA_COLORS[name])
			: slot === "Visor Color" && EXTRA_VISORS[name] ? nearestPreset(slot, EXTRA_VISORS[name][0]) : data.items.find(i => i.name === name);
		if (piece) api.onArmor("armor:" + data.offset.toString(16) + "=" + piece.id.toString(16));
		sendAppearance();
	}

	// onScene(name): set by the page; "armory" to show the Armory Spartan, null for the lobby's own backdrop.
	// onArmor(message): set by the page; sends `armor:<offset>=<id>` to the overlay.
	const api = { open: openMenu, isOpen: () => open, action: act, armorState, onScene: null, onArmor: null, onTheme: null, theme,
		// Settings straight at one tab (the lobby's Y, Select Network: owner, 2026-10-17); B goes back to the Start menu.
		openSettings(kind) {
			openMenu(false);
			pages.length = 0;
			if (typeof api.onArmor === "function") api.onArmor("settings?");
			openPage({ kind: tabbed({ kind }) ? kind : "audiovideo" });
		},
		// Whether one of the settings screen's tabs is up (index.html: F isn't Revert Changes there).
		onSettingsTab: () => open && pages.length > 0 && tabbed(pages[pages.length - 1]),
		// (the page on top: chat.js takes the chat keys only on the game menu itself)
		pageKind: () => open && pages.length > 0 ? pages[pages.length - 1].kind : "",
		// Whether you play as an Elite (PLAYER > Preferred Species): the player card shows your Elite then.
		playsElite: () => !!look.elite,
		lookKey: () => lookKey,
		// Q/E, LB/RB or the right stick let go (index.html): a held one stops turning the Spartan.
		turnRelease: (a) => releaseTurn(a === "turnr" || a === "tabr" ? 1 : -1),
		// Closes the menu and any page, the match's pause menu too, with nothing sent to the game (a match
		// that ended under it: Credits Earned, postgame.js).
		dismiss() { closePages(); if (open) close(); document.body.classList.remove("ingame"); },
		// The Spartan's gender (welcome.js, the first run's WELCOME TO NOBLE TEAM): in the profile and on
		// the Armory Spartan.
		isFemale: () => !!look.female,
		// A new player (the first run, no name yet): the default Elite, unless an Elite look is already saved.
		newPlayer() {
			let has = false;
			try { has = !!(localStorage.getItem(ELITE_STORE) || localStorage.getItem("rr.classic.elitecolors")); } catch (e) { }
			if (!has) eliteDefault();
		},
		setGender(female) { if (look.female !== !!female) setLook("female", !!female); },
		// "Select and Continue to the Armory": the menu open on THE ARMORY page (when its data is here).
		openArmory() {
			openMenu(!window.ARMORY_DATA);
			pages.length = 0;
			if (typeof api.onArmor === "function") api.onArmor("settings?");
			if (window.ARMORY_DATA) openPage({ kind: "armory" });
		},
		// The SPARTAN GENDER page; required: no Back.
		chooseGender(required, done) {
			openMenu(false);
			pages.length = 0;
			openPage({ kind: "gender", required: !!required, done, was: look.female, sel: look.female ? 1 : 0 });
		},
		// `firewall-state:<exit code>|<line>` from the overlay program (host-probe's firewall check or fix).
		// `audio-devices:<id>\t<name>\n...` from the overlay program (audiodev.rs).
		audioDevices(text) {
			audioDevices = text.split("\n").filter(Boolean).map(l => l.split("\t")).filter(d => d.length === 2);
			if (pages.length && pages[pages.length - 1].kind === "audio") renderPage();
		},
		firewallState(text) {
			const at = text.indexOf("|");
			firewall = { code: +text.slice(0, at), line: text.slice(at + 1), busy: false };
			if (pages.length && pages[pages.length - 1].kind === "network") renderPage();
		},
		// `presets:<slot>|<summary>;...` from the overlay program (settings.rs).
		presetsState(text) {
			presetsState = {};
			for (const part of text.split(";")) {
				const at = part.indexOf("|");
				if (at > 0) presetsState[+part.slice(0, at)] = part.slice(at + 1);
			}
			if (pages.length && pages[pages.length - 1].kind === "presets") renderPage();
		},
		// `settings-state:<k>=<v>,...,binds=<vk>;<vk>;...` from the overlay program.
		settingsState(text) {
			const st = { binds: [] };
			for (const part of text.split(",")) {
				const [k, v] = part.split("=");
				if (k === "binds") st.binds = (v || "").split(";");
				else if (k === "live") st.live = Object.fromEntries((v || "").split(";").filter(Boolean).map(x => [x.slice(0, x.indexOf(":")), x.slice(x.indexOf(":") + 1)]));
				else if (k) st[k] = v;
			}
			// entries() derives gfx.preset even when the host omitted it; that is not a new setting.
			const previous = { ...settingsState };
			if (!("gfx.preset" in st)) delete previous["gfx.preset"];
			const changed = JSON.stringify(st) !== JSON.stringify(previous);
			settingsState = st;
			// The menus' own sounds (index.html Sound) follow MENU SOUNDS VOLUME.
			window.MENU_VOLUME = Math.max(0, Math.min(100, +(st["volume.menu"] ?? 100))) / 100;
			// The menus' brightness follows UI GAMMA.
			uiGamma(st["ui.gamma"]);
			// The menu music follows its settings (music.js).
			if (window.MenuMusic) MenuMusic.settings(st);
			// The match chat's look (chat.js).
			if (window.MatchChat && MatchChat.settings) MatchChat.settings(st);
			settleChanges(st.live || {});
			if (changed && pages.length && SETTINGS_KINDS.includes(pages[pages.length - 1].kind)) renderPage();
		},
		// Esc in a match (host-probe asks the overlay): the game menu over the game. `n` numbers the overlay's ask.
		gameMenu(n) {
			document.body.classList.add("ingame");
			openMenu(false);
			pages.length = 0;
			openPage({ kind: "game" });
			if (typeof api.onArmor === "function") api.onArmor("settings?");
			// (drawn: the overlay shows the menus now, not before, so the last main menu doesn't flash)
			requestAnimationFrame(() => requestAnimationFrame(() => api.gameMenuState(n)));
		},
		// Whether the game menu is up, for the overlay's ask n: `game-menu:shown:<n>`, or `game-menu:none:<n>`. A
		// held Esc could close it again before it was drawn, and "shown" then made the overlay show the menus with
		// nothing in them, holding the focus over a paused game (2026-10-20 player batch, report 33).
		gameMenuState(n) {
			const up = document.body.classList.contains("ingame") && pages.length > 0 && pages[0].kind === "game";
			if (typeof api.onArmor === "function") api.onArmor(`game-menu:${up ? "shown" : "none"}:${n}`);
		},
	};
	// Parse page styles during boot, before the first interactive transition.
	document.head.appendChild(style);
	document.head.appendChild(pageStyle);
	// First-use system-font fallback (especially the scroll arrows) stalled cold pages.
	// Warm their glyphs and the current emblem while the boot screen is up.
	const warm = () => {
		const c = document.createElement("canvas"), g = c.getContext("2d");
		const font = getComputedStyle(document.body).fontFamily;
		const text = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789⌃⌄◆◇◀▶◄►‹›←→•✓×—–°%/+";
		const probe = document.createElement("div");
		probe.setAttribute("aria-hidden", "true");
		probe.className = window.MenuScroll ? MenuScroll.CLASS : "";
		probe.style.cssText = "position:fixed;visibility:hidden;pointer-events:none;contain:strict;width:64px;height:24px;overflow:scroll";
		for (const weight of [300, 400, 500, 600, 700]) {
			g.font = weight + " 24px " + font;
			g.measureText(text);
			const span = document.createElement("span");
			span.style.font = g.font; span.style.display = "block"; span.textContent = text; probe.appendChild(span);
		}
		document.body.appendChild(probe);
		void probe.lastChild.offsetWidth; // Resolve text and native scrollbars before the first scrollIntoView.
		probe.remove();
		if (window.Emblem) {
			const e = Emblem.player(), preview = Object.assign({}, e, { toggle: !!e.toggle });
			const plate = Math.max(32, Math.min(512, Math.round(innerHeight * 0.046 * (devicePixelRatio || 1))));
			// The editor normalizes toggle to false; that is a different existing raster-cache key.
			// Warm only the current emblem, one raster per idle task. Keep ImageData/context recovery
			// in Emblem.paint; no retained GPU canvases or preview/settings mutation here.
			const jobs = [[128, e], [plate, e], [128, preview], [plate, preview],
				[Math.max(16, Math.round(innerHeight * 0.166 * (devicePixelRatio || 1))), preview]];
			const next = () => { const job = jobs.shift(); if (!job) return; c.width = c.height = job[0]; Emblem.paint(c, job[1]); if (jobs.length) idle(next); };
			idle(next);
		}
	};
	const idle = fn => window.requestIdleCallback ? requestIdleCallback(fn, { timeout: 1500 }) : setTimeout(fn, 0);
	idle(warm);
	return api;
})();
