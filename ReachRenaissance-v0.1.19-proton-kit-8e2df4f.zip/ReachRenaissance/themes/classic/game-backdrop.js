// The Armory's backdrop painted into a picture for the game (owner's pick, 2026-10-14: "let the game
// draw him"). The game draws it into its own frame wherever nothing of the Spartan is (host-probe
// texcam/backdrop.rs, by the main view's depth), and the page goes see-through over it
// (body.gamedraw), so the Spartan, his armor effects and his lighting are the game's own pixels.
//
// GameBackdrop.show(): paint (when the emblem or the window size changed) and send; .hide(): off.
// The painting follows start-menu.js's .rrbg layers: the teal radial base, Reach's clouds, the
// diamond lattice fading in from the top left, the player's emblem large and faint, the vignette.
(function () {
	let sentKey = null, on = false, clouds = null;

	function post(text) { if (window.chrome && window.chrome.webview) window.chrome.webview.postMessage(text); }

	function loadClouds() {
		if (clouds) return clouds;
		clouds = new Promise(resolve => {
			const img = new Image();
			img.onload = () => resolve(img);
			img.onerror = () => resolve(null);
			img.src = "ui/background_clouds.png";
		});
		return clouds;
	}

	// An elliptical radial gradient (CSS `radial-gradient(ellipse rx ry at cx cy, ...)`) filling the canvas.
	function ellipse(g, W, H, cx, cy, rx, ry, stops) {
		g.save();
		g.translate(cx * W, cy * H);
		g.scale(rx * W, ry * H);
		const grad = g.createRadialGradient(0, 0, 0, 0, 0, 1);
		for (const [at, color] of stops) grad.addColorStop(at, color);
		g.fillStyle = grad;
		g.fillRect(-cx / rx - 1, -cy / ry - 1, 1 / rx + 2, 1 / ry + 2);
		g.restore();
	}

	async function paint(W, H, withClouds) {
		const c = document.createElement("canvas");
		c.width = W; c.height = H;
		const g = c.getContext("2d");
		const vh = H / 100;
		// (CSS: an ellipse's radii are the percentages of the width and height)
		ellipse(g, W, H, 0.42, 0.40, 0.80, 0.75, [[0, "#20404f"], [0.38, "#163140"], [0.68, "#0d2230"], [1, "#07131d"]]);
		const img = withClouds ? await loadClouds() : null;
		if (img) {
			g.save();
			g.globalAlpha = 0.10;
			g.globalCompositeOperation = "screen";
			const tw = W * 1.2 * 0.7, th = tw * img.height / img.width;
			const x0 = -W * 0.1 + ((W * 1.2 - tw) / 2) % tw - tw, y0 = -H * 0.1 + ((H * 1.2 - th) / 2) % th - th;
			for (let y = y0; y < H; y += th) for (let x = x0; x < W; x += tw) g.drawImage(img, x, y, tw, th);
			g.restore();
		}
		// The lattice: dots every 1.6vh, and thin diagonal lines both ways every 1.13vh, faded by a mask.
		const lat = document.createElement("canvas");
		lat.width = W; lat.height = H;
		const l = lat.getContext("2d");
		l.fillStyle = "rgba(170, 215, 245, 0.26)";
		const step = 1.6 * vh, r = 0.18 * vh;
		for (let y = step / 2; y < H; y += step) for (let x = step / 2; x < W; x += step) { l.beginPath(); l.arc(x, y, r, 0, Math.PI * 2); l.fill(); }
		l.strokeStyle = "rgba(150, 200, 235, 0.11)";
		l.lineWidth = Math.max(1, 0.09 * vh);
		const gap = 1.13 * vh * Math.SQRT2;
		l.beginPath();
		for (let k = -H; k < W + H; k += gap) { l.moveTo(k, 0); l.lineTo(k + H, H); l.moveTo(k, H); l.lineTo(k + H, 0); }
		l.stroke();
		l.globalCompositeOperation = "destination-in";
		ellipse(l, W, H, 0.08, 0.08, 0.55, 0.60, [[0, "rgba(0,0,0,1)"], [0.45, "rgba(0,0,0,0.55)"], [0.85, "rgba(0,0,0,0)"], [1, "rgba(0,0,0,0)"]]);
		g.drawImage(lat, 0, 0);
		// The emblem, large and faint behind him (.rrbg .emb: 60vh at 61vw, 41vh).
		if (window.Emblem) {
			const e = document.createElement("canvas");
			e.width = e.height = 256;
			Emblem.paint(e, Emblem.player()); // (the saved one: the key below; not a page's try-out)
			const s = 60 * vh;
			g.save();
			g.globalAlpha = 0.2;
			g.globalCompositeOperation = "soft-light";
			g.filter = "grayscale(1) brightness(1.5)";
			g.drawImage(e, 0.61 * W - s / 2, 41 * vh - s / 2, s, s);
			g.restore();
		}
		ellipse(g, W, H, 0.5, 0.45, 0.85, 0.85, [[0, "rgba(0,0,0,0)"], [0.62, "rgba(0,0,0,0)"], [1, "rgba(0,0,0,0.42)"]]);
		return g.getImageData(0, 0, W, H).data;
	}

	function base64(bytes) {
		let s = "";
		for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
		return btoa(s);
	}

	async function show() {
		on = true;
		document.body.classList.add("gamedraw");
		const dpr = window.devicePixelRatio || 1;
		const W = Math.round(innerWidth * dpr), H = Math.round(innerHeight * dpr);
		const key = `${W}x${H}:${JSON.stringify(window.Emblem ? Emblem.player() : null)}`;
		if (key === sentKey) { post("backdrop:on"); return; }
		sentKey = key;
		let px;
		try { px = await paint(W, H, true); }
		catch (e) {
			// (a file: picture can't be read back without the overlay's --allow-file-access-from-files)
			post("page-note: backdrop without clouds: " + e.message);
			px = await paint(W, H, false);
		}
		if (!on || sentKey !== key) return;
		post(`backdrop:${W}x${H}:${base64(px)}`);
	}

	function hide() {
		if (!on) return;
		on = false;
		document.body.classList.remove("gamedraw");
		post("backdrop:off");
	}

	window.GameBackdrop = { show, hide, get on() { return on; } };
})();
