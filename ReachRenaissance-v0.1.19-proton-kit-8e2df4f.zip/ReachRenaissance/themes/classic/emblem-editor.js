// Armory > Emblem, laid out as the 360's (ui\cui\start_menu\player\supply_depot\supply_depot_emblem in
// the Mod Tools): the foregrounds in a row that runs left and right, the backgrounds in a column that
// runs up and down, the two crossing at the emblem they make; items shrink away from the middle (the
// screen's list items are 150, 60, 30 and 15 wide). The foreground and background's name and "n of N"
// on the left, X toggles the foreground's secondary layer ("Foreground (Toggled)"), A applies, B
// cancels. Names and the lists' order come from the 360's strings (emblems-data.js `names`, `order`).
// The emblem colors are on Armory > Colors (Emblem Primary, Secondary, Background), as on the 360.
//
// start-menu.js runs it as an Armory page (kind "emblem"): EmblemEditor.start(page), .body(page),
// .paint(root, page) after the page is drawn, and .act(page, action) for input, which returns "apply",
// "cancel", true (handled) or false (the Armory's own: turning the Spartan, Start).
window.EmblemEditor = (() => {
	const css = document.createElement("style");
	css.textContent = `
	.ar .emdesc { position: absolute; left: 20.5vw; top: 16.5vh; width: 12vw; font-size: 2.4vh; line-height: 1.3; color: #b9c2c8; }
	.ar .eminfo { position: absolute; left: 20.5vw; width: 12.5vw; border-top: 1px solid rgba(255,255,255,0.2); padding-top: 1vh; }
	.ar .eminfo .t { font-size: 2.2vh; font-weight: 600; letter-spacing: 0.03em; text-transform: uppercase; color: #b9c2c8; }
	.ar .eminfo .n { margin-top: 0.4vh; font-size: 3.2vh; font-weight: 600; color: #fff; line-height: 1.15; }
	.ar .eminfo .c { margin-top: 0.6vh; font-size: 2.2vh; color: #b9c2c8; }
	.ar .eminfo .q { margin-left: 0.6vw; font-size: 1.7vh; color: #e8ecef; letter-spacing: 0.04em; }
	.ar .emx { position: absolute; left: 0; top: 0; width: 0; height: 0; }
	.ar .emx canvas { position: absolute; cursor: pointer; transform: translate(-50%, -50%); }
	.ar .emx canvas.mid { cursor: default; box-shadow: 0 0 0 0.25vh #f2f4f5, 0 0.8vh 2.4vh rgba(0,0,0,0.6); animation: rrPulse 1.5s ease-in-out infinite; }
	.ar .emx .bar { position: absolute; transform: translate(-50%, -50%); background: rgba(10, 18, 26, 0.45); pointer-events: none; }
	.ar .emx .arr { position: absolute; transform: translate(-50%, -50%); font-size: 3vh; color: rgba(255,255,255,0.75); cursor: pointer; }`;
	document.head.appendChild(css);

	// Rows from the middle: offsets (vh) along the list and sizes (vh). The 360's at 720 lines tall,
	// scaled by 0.8 to fit between the title and the player plate.
	const STEPS = [-3, -2, -1, 0, 1, 2, 3];
	const ROW_AT = [-28, -24.6, -15.5, 0, 15.5, 24.5, 28], COL_AT = [-24.6, -20.6, -14, 0, 14, 20.6, 24.6];
	const SIZE = [1.7, 3.3, 6.7, 16.6, 6.7, 3.3, 1.7];
	const CX = "50vw", CY = 46;

	const data = () => window.EMBLEM_DATA;
	const order = (list) => (data().order && data().order[list]) || data()[list].map((_, i) => i);
	const nameOf = (list, i) => (data().names && data().names[list][i]) || data()[list][i].name.replace(/_/g, " ");
	const rowOf = (list, name) => Math.max(0, order(list).indexOf(data()[list].findIndex(e => e.name === name)));
	const wrap = (n, len) => ((n % len) + len) % len;
	const at = (list, row) => data()[list][order(list)[wrap(row, order(list).length)]];
	const esc = (s) => String(s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);

	function start(p) {
		const e = Emblem.player();
		p.em = { front: rowOf("front", e.front), back: rowOf("back", e.back), toggle: !!e.toggle };
		show(p);
	}
	function pending(p) {
		return Object.assign(Emblem.player(), { front: at("front", p.em.front).name, back: at("back", p.em.back).name, toggle: p.em.toggle });
	}
	// The plate and the backdrop's emblem show the one being made.
	function show(p) { Emblem.preview(pending(p)); }

	function info(list, p, top) {
		const row = p.em[list], len = order(list).length, now = Emblem.player();
		const equipped = at(list, row).name === now[list] && (list === "back" || !!now.toggle === p.em.toggle);
		const title = list === "front" ? (p.em.toggle ? "Foreground (Toggled)" : "Foreground") : "Background";
		return `<div class="eminfo" style="top:${top}vh"><div class="t">${title}</div>`
			+ `<div class="n">${esc(nameOf(list, order(list)[wrap(row, len)]))}</div>`
			+ `<div class="c">${wrap(row, len) + 1} of ${len}${equipped ? `<span class="q">EQUIPPED</span>` : ""}</div></div>`;
	}

	function body(p) {
		if (!data()) return `<div class="emdesc">The emblem library isn't on this PC (Mod Tools).</div>`;
		const pos = (dx, dy, s) => `left:calc(${CX} + ${dx}vh);top:${CY + dy}vh;width:${s}vh;height:${s}vh`;
		let x = `<div class="emx">`
			+ `<div class="bar" style="left:${CX};top:${CY}vh;width:60vh;height:9vh"></div>`
			+ `<div class="bar" style="left:${CX};top:${CY}vh;width:9vh;height:52vh"></div>`;
		STEPS.forEach((k, i) => {
			if (k) x += `<canvas data-ef="${k}" style="${pos(ROW_AT[i], 0, SIZE[i])}"></canvas><canvas data-eb="${k}" style="${pos(0, COL_AT[i], SIZE[i])}"></canvas>`;
		});
		x += `<canvas class="mid" data-em="1" style="${pos(0, 0, SIZE[3])}"></canvas>`
			+ `<div class="arr" data-ea="left" style="left:calc(${CX} - 31vh);top:${CY}vh">&lsaquo;</div>`
			+ `<div class="arr" data-ea="right" style="left:calc(${CX} + 31vh);top:${CY}vh">&rsaquo;</div>`
			+ `<div class="arr" data-ea="up" style="left:${CX};top:${CY - 27.5}vh">&#8963;</div>`
			+ `<div class="arr" data-ea="down" style="left:${CX};top:${CY + 27.5}vh">&#8964;</div></div>`;
		return `<div class="emdesc">Select an icon and background for your emblem.</div>` + info("front", p, 30) + info("back", p, 50) + x;
	}

	function paint(root, p) {
		if (!data()) return;
		const e = pending(p), px = (vh) => Math.max(16, Math.round(vh / 100 * innerHeight * (window.devicePixelRatio || 1)));
		const put = (c, emblem, vh) => { c.width = c.height = px(vh); Emblem.paint(c, emblem); };
		STEPS.forEach((k, i) => {
			if (!k) return;
			const f = root.querySelector(`[data-ef="${k}"]`), b = root.querySelector(`[data-eb="${k}"]`);
			if (f) put(f, Object.assign({}, e, { front: at("front", p.em.front + k).name }), SIZE[i]);
			// (a background alone, in the background color)
			if (b) put(b, Object.assign({}, e, { front: "", back: at("back", p.em.back + k).name }), SIZE[i]);
		});
		const mid = root.querySelector("[data-em]");
		if (mid) put(mid, e, SIZE[3]);
	}

	// Mouse: a list item jumps there, the middle applies, the arrows step.
	function bind(root, p, act) {
		root.querySelectorAll("[data-ef]").forEach(c => c.onclick = () => { p.em.front += +c.dataset.ef; act("emblem-moved"); });
		root.querySelectorAll("[data-eb]").forEach(c => c.onclick = () => { p.em.back += +c.dataset.eb; act("emblem-moved"); });
		root.querySelectorAll("[data-ea]").forEach(c => c.onclick = () => act(c.dataset.ea));
		const mid = root.querySelector("[data-em]");
		if (mid) mid.onclick = () => act("select");
	}

	function act(p, a) {
		if (!data()) return a === "back" || a === "select" ? "cancel" : false;
		if (a === "emblem-moved") { p.em.front = wrap(p.em.front, order("front").length); p.em.back = wrap(p.em.back, order("back").length); show(p); return true; }
		if (a === "left" || a === "right") { p.em.front = wrap(p.em.front + (a === "right" ? 1 : -1), order("front").length); show(p); return true; }
		if (a === "up" || a === "down") { p.em.back = wrap(p.em.back + (a === "down" ? 1 : -1), order("back").length); show(p); return true; }
		if (a === "star") { p.em.toggle = !p.em.toggle; show(p); return true; }
		if (a === "select") {
			const e = pending(p);
			Emblem.save({ front: e.front, back: e.back, toggle: e.toggle });
			Emblem.preview(null);
			return "apply";
		}
		if (a === "back") { Emblem.preview(null); return "cancel"; }
		return false;
	}

	return { start, body, paint, bind, act };
})();
