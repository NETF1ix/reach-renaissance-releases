// Game setup for hosts (owner, 2026-10-16: "server creators have no way of creating map rotations or
// gametype rotations or seamlessly naming their servers or matches", "we don't have a proper game
// type settings menu at all"). Three rows in Custom Games open it:
//
// - SERVER NAME: what the server list, the lobby and server.ini call the game.
// - ROTATION: a saved playlist of maps and game types that a hosted game or a dedicated server plays
//   in turn (the overlay's gamesetup.rs keeps them in %LOCALAPPDATA%\<data folder>\playlists, where
//   server.ini's `playlist = <name>` finds them too).
// - GAME OPTIONS: the selected game type's settings as Reach's own custom game options have them (the
//   value lists are the Mod Tools' game_variant_settings), saved as a game type of your own
//   (gametypes\<name>.rrgt; host-probe gametype.rs writes it into the game variant it starts from).
//
// Each game type's current settings come from gametype-settings-data.js
// (scripts/menu/extract_gametype_settings.py: decoded with the game's own reader).
"use strict";

window.GameSetup = (() => {
	const post = (m) => { try { window.chrome.webview.postMessage(m); } catch (e) { } };
	const play = (n) => { if (typeof Sound !== "undefined") Sound.play(n); };
	const esc = (s) => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
	const SETTINGS = window.GAMETYPE_SETTINGS || {};
	const STORE = "rr.gamesetup";
	let store = {};
	try { store = JSON.parse(localStorage.getItem(STORE) || "{}"); } catch (e) { store = {}; }
	const save = () => { try { localStorage.setItem(STORE, JSON.stringify(store)); } catch (e) { } };

	// ---- value lists (Reach's own, from the Mod Tools' game_variant_settings) ----
	const n = (v, unit, one) => [v, v === 1 && one ? one : v + " " + unit];
	const mins = (v) => n(v, "Minutes", "1 Minute"), secs = (v) => n(v, "Seconds", "1 Second");
	const WEAPONS = ["DMR", "Assault Rifle", "Plasma Pistol", "Spiker", "Energy Sword", "Magnum", "Needler", "Plasma Rifle",
		"Rocket Launcher", "Shotgun", "Sniper Rifle", "Spartan Laser", "Gravity Hammer", "Plasma Repeater", "Needle Rifle",
		"Focus Rifle", "Plasma Launcher", "Concussion Rifle", "Grenade Launcher", "Golf Club", "Fuel Rod Gun"].map((w, i) => [i, w])
		.sort((a, b) => a[1].localeCompare(b[1]));
	const LISTS = {
		teams: [[0, "Disabled"], [1, "Enabled"]],
		score_to_win: [[0, "Unlimited"], ...[1, 3, 5, 10, 15, 20, 25, 50, 75, 100, 150, 200, 250, 300, 400, 500].map(v => [v, String(v)])],
		time_limit: [[0, "No Limit"], ...[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 15, 20, 30, 45, 60].map(mins)],
		round_limit: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(v => [v, v === 1 ? "1 Round" : v + " Rounds"]),
		sudden_death: [[-1, "No Limit"], [0, "Disabled"], secs(15), secs(30), secs(45), [60, "1 Minute"], [120, "2 Minutes"]],
		lives: [[0, "Unlimited"], ...[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(v => [v, String(v)])],
		respawn_time: [3, 4, 5, 10, 15, 20, 25, 30, 45, 60, 90].map(secs).concat([[120, "2 Minutes"], [180, "3 Minutes"]]),
		suicide_penalty: [[0, "None"], ...[3, 5, 10, 15, 20, 30, 60].map(secs), [120, "2 Minutes"], [180, "3 Minutes"]],
		respawn_growth: [[0, "Disabled"], ...[2, 3, 5, 10, 15].map(secs)],
		primary_weapon: [[-3, "Unchanged"], ...WEAPONS],
		secondary_weapon: [[-3, "Unchanged"], [-1, "None"], ...WEAPONS],
		armor_ability: [[-3, "Unchanged"], [-1, "None"], [0, "Sprint"], [8, "Evade"], [1, "Jet Pack"], [2, "Armor Lock"],
			[4, "Active Camo"], [9, "Drop Shield"], [7, "Hologram"]],
		grenades: [[0, "Unchanged"], [1, "Map Default"], [2, "None"], [3, "1 Frag"], [4, "2 Frags"], [5, "3 Frags"], [6, "4 Frags"],
			[7, "1 Plasma"], [8, "2 Plasma"], [9, "3 Plasma"], [10, "4 Plasma"], [11, "1 Frag, 1 Plasma"], [12, "2 Frags, 2 Plasma"],
			[13, "3 Frags, 3 Plasma"], [14, "4 Frags, 4 Plasma"]],
		shields: [[0, "Unchanged"], [1, "No Shields"], [2, "Normal Shields"], [3, "1.5x Overshields"], [4, "2x Overshields"],
			[5, "3x Overshields"], [6, "4x Overshields"]],
		shield_recharge: [[0, "Unchanged"], [4, "0%"], [5, "10%"], [6, "25%"], [7, "50%"], [8, "75%"], [9, "90%"], [10, "100%"],
			[11, "110%"], [12, "125%"], [13, "150%"], [14, "200%"]],
		weapon_set: [[-2, "Map Default"], [0, "Human"], [1, "Covenant"], [2, "No Snipers"], [3, "Rockets Only"], [4, "No Power Weapons"],
			[5, "Juggernaut"], [6, "Slayer Pro"], [7, "Rifles Only"], [8, "Mid-Range Only"], [9, "Long-Range Only"],
			[10, "Human Snipers Only"], [11, "Melee"], [12, "Swords Only"], [13, "Hammers Only"], [14, "Mass Destruction"], [15, "No Weapons"]],
		vehicle_set: [[-2, "Map Default"], [0, "Mongoose Only"], [1, "Warthog Only"], [2, "No Aircraft"], [3, "Aircraft Only"],
			[4, "No Tanks"], [5, "Tanks Only"], [6, "No Light Ground"], [7, "Light Ground Only"], [8, "No Covenant Vehicles"],
			[9, "All Covenant Vehicles"], [10, "No Human Vehicles"], [11, "All Human Vehicles"], [12, "No Vehicles"], [13, "All Vehicles"]],
		grenades_on_map: [[0, "None"], [1, "Map Default"]],
		indestructible_vehicles: [[0, "Disabled"], [1, "Enabled"]],
	};
	LISTS.betrayal_penalty = LISTS.suicide_penalty;
	// Our own match rules (host-probe matchrules.rs; owner, 2026-10-17), enforced on every player's copy.
	LISTS.player_colors = [[0, "Disabled"], [1, "Enabled"]];
	LISTS.third_person = [[0, "Default"], [1, "Forced First Person"], [2, "Forced Third Person"], [3, "Block Third-Person Button"]];
	LISTS.elites = [[0, "Disabled"], [1, "Enabled"]];
	const RULES = { player_colors: 0, third_person: 0, elites: 1 };
	// Every player trait (host-probe gametype.rs TRAITS; the values are the Mod Tools' player_traits_template).
	const PCT = (vals) => vals.map(([v, p]) => [v, p + "%"]);
	const MOD = [[0, "Unchanged"], ...PCT([[1, 0], [2, 25], [3, 50], [4, 75], [5, 90], [6, 100], [7, 110], [8, 125], [9, 150], [10, 200], [11, 300]])];
	const ONOFF3 = [[0, "Unchanged"], [1, "Disabled"], [2, "Enabled"]];
	const SEEN = [[0, "Unchanged"], [1, "None"], [2, "Allies Only"], [3, "Everyone"]];
	Object.assign(LISTS, {
		damage_resistance: [[0, "Unchanged"], ...PCT([[1, 10], [2, 50], [3, 90], [4, 100], [5, 110], [6, 150], [7, 200], [8, 300], [9, 500], [10, 1000], [11, 2000]]), [12, "Invulnerable"]],
		health_recharge: [[0, "Unchanged"], ...PCT([[4, 0], [5, 50], [6, 90], [7, 100], [8, 110], [9, 200]])],
		shield_multiplier: LISTS.shields, headshot_immunity: ONOFF3, assassination_immunity: ONOFF3,
		damage: MOD, melee_damage: MOD, weapon_pickup: ONOFF3,
		infinite_ammo: [[0, "Unchanged"], [1, "Disabled"], [2, "Enabled"], [3, "Bottomless Clip"]],
		ability_usage: [[0, "Unchanged"], [1, "Disabled"], [2, "Normal"], [3, "Enabled"]],
		speed: [[0, "Unchanged"], ...PCT([[1, 0], [2, 25], [3, 50], [4, 75], [5, 90], [6, 100], [7, 110], [8, 120], [11, 150], [16, 200], [17, 300]])],
		gravity: [[0, "Unchanged"], ...PCT([[1, 50], [2, 75], [3, 100], [4, 150], [5, 200]])],
		vehicle_use: [[0, "Unchanged"], [1, "None"], [2, "Passenger Only"], [3, "Driver Only"], [4, "Gunner Only"], [5, "No Passenger"], [6, "No Driver"], [7, "No Gunner"], [8, "Full Use"]],
		jump_height: [[-1, "Unchanged"], ...PCT([[0, 0], [25, 25], [50, 50], [75, 75], [90, 90], [100, 100], [110, 110], [125, 125], [150, 150], [200, 200], [300, 300]])],
		active_camo: [[0, "Unchanged"], [1, "Off"], [3, "Poor"], [4, "Good"]],
		waypoint: SEEN, name_visibility: SEEN,
		forced_color: [[0, "Unchanged"], [1, "Off"], ...["Red", "Blue", "Green", "Orange", "Purple", "Gold", "Brown", "Pink", "White", "Black", "Zombie"].map((c, i) => [i + 2, c])],
		motion_tracker: [[0, "Unchanged"], [1, "Off"], [2, "Allies Only"], [3, "Normal Mode"], [4, "Enhanced Mode"]],
		tracker_range: [[0, "Unchanged"], [1, "10 m"], [3, "25 m"], [5, "75 m"], [7, "150 m"]],
		team_lives: [[0, "Unlimited"], ...[1, 2, 3, 5, 10, 15, 20, 25, 50].map(v => [v, String(v)])],
		respawn_traits_duration: [[0, "None"], ...[1, 2, 3, 4, 5, 10, 15, 30, 60].map(secs)],
		team_changing: [[0, "Not Allowed"], [1, "Allowed"], [2, "Balancing Only"]],
		friendly_fire: [[0, "Disabled"], [1, "Enabled"]], betrayal_booting: [[0, "Disabled"], [1, "Enabled"]],
		shortcuts_on_map: [[0, "Disabled"], [1, "Map Default"]], abilities_on_map: [[0, "None"], [1, "Map Default"]],
		powerups_on_map: [[0, "None"], [1, "Map Default"]], turrets_on_map: [[0, "None"], [1, "Map Default"]],
	});
	LISTS.red_powerup_duration = LISTS.blue_powerup_duration = LISTS.yellow_powerup_duration = [[0, "None"], ...[3, 4, 5, 6, 10, 15, 20, 30, 45, 60, 90].map(secs)];
	LISTS.respawn_sync = [[0, "Disabled"], [1, "Enabled"]];
	LISTS.loadout_camera_time = [[0, "None"], ...[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 15].map(secs)];
	// Loadouts (host-probe gametype.rs LOADOUTS): 6 palettes, Spartan and Elite for each of 3 tiers, of 5 loadouts.
	// Names: the Mod Tools' megalo loadouts list in order, English from ui/cui/strings/loadout_strings.
	const LOADOUT_NAMES = ["Noble 1", "Noble 2", "Noble 3", "Noble 4", "Noble 5", "Noble 6", "Carter", "Kat", "Jorge", "Emile", "Jun", "Thom",
		"Rosenda", "Danny", "John", "Kelly", "Linda", "Sam", "Kurt", "Jerry", "Jimmy", "Bobby", "Marlo", "Omar", "Juggernaut", "Berserker", "Maverick",
		"Zombie", "Demon", "Angel", "Redshirt", "Ling Ling", "Pookie", "FNG", "Noob", "Camper", "Specter", "Bunker", "Claymore", "Firebase", "Intel",
		"Ninja", "Power", "Cobra", "Eagle", "Hog", "Bear", "Warrior", "Deceiver", "Ranger", "Zealot", "Royal Zealot", "Assassin", "Dark Assassin",
		"Champion", "Gladiator", "Sentry", "Warden", "Saboteur", "Spec Ops", "Scout", "Guard", "Air Assault", "Marksman", "Recon", "Sharpshooter",
		"Operator", "Grenadier", "Medic", "Corpsman", "Stalker", "Demolitions", "Infiltrator", "Security", "Sprint", "Evade", "Armor Lock",
		"Active Camo", "Hologram", "Drop Shield", "Jet Pack"];
	const LOADOUT_LISTS = {
		shown: [[1, "Not Hidden"], [0, "Hidden"]],
		name: [[-1, "None"], ...LOADOUT_NAMES.map((n, i) => [i, n]).sort((a, b) => a[1].localeCompare(b[1]))],
		primary: [[-3, "Unchanged"], ...WEAPONS],
		secondary: [[-3, "Unchanged"], [-1, "None"], ...WEAPONS],
		ability: LISTS.armor_ability,
		grenades: LISTS.grenades.filter(o => o[0] !== 1),
	};
	const LOADOUT_ROWS = [["shown", "Hide Loadout", "Hidden loadouts aren't offered when players spawn."], ["name", "Name", "The loadout's name on the spawn screen."],
		["primary", "Primary Weapon", "The weapon players spawn holding."], ["secondary", "Secondary Weapon", "The weapon players spawn carrying."],
		["ability", "Equipment", "The armor ability players spawn with."], ["grenades", "Grenades", "The grenades players spawn with."]];
	const loadoutKey = (p, l, f) => `loadout.${p}.${l}.${f}`;
	// Firefight's lists: the Mod Tools' firefight game_variant_settings, English from game_options_strings.
	const LIVES = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 15, 20, 25, 50].map(v => [v, v ? String(v) : "None"]);
	const ONOFF = [[0, "Disabled"], [1, "Enabled"]];
	const FF_LISTS = {
		set_count: [[1, "One Wave"], [5, "One Round"], [10, "Two Rounds"], [16, "One Set"], [32, "Two Sets"], [48, "Three Sets"], [64, "Four Sets"],
			[80, "Five Sets"], [160, "Ten Sets"], [0, "No Limit"]],
		time_limit: [[0, "No Limit"], ...[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 15, 20, 30, 45, 60].map(mins)],
		turns: [[1, "No Turns"], [2, "One Each"], [4, "Two Each"], [6, "Three Each"]],
		hazards: ONOFF, weapon_drops: ONOFF, ammo_crates: ONOFF,
		generator_count: [[0, "Disabled"], [1, "1"], [2, "2"], [3, "3"]],
		generator_defend_all: [[1, "Lose One"], [0, "Lose All"]],
		generator_random: [[0, "Ordered"], [1, "Random"]],
		spartan_lives: [[-1, "Unlimited"], ...LIVES], elite_lives: [[-1, "Unlimited"], ...LIVES], max_lives: LIVES,
		elite_kill_bonus: [[0, "No Bonus"], [1, "One Life"], [2, "Two Lives"], [3, "Three Lives"], [4, "Four Lives"], [5, "Five Lives"]],
		respawn: [...[3, 4, 5, 10, 15, 20, 25, 30, 45, 60, 90].map(secs), [120, "2 Minutes"], [180, "3 Minutes"], [255, "On Wave"]],
		bonus_duration: [...[15, 30, 45, 60, 90].map(secs), [120, "2 Minutes"]],
		// (firefight_globals' wave templates, in their order)
		squad: [[-1, "None"], ...["Brutes", "Brute Kill Team", "Brute Patrol", "Brute Infantry", "Brute Tactical", "Brute Chieftains", "Elites", "Elite Patrol",
			"Elite Infantry", "Elite Airborne", "Elite Tactical", "Elite Spec Ops", "Engineers", "Elite Generals", "Grunts", "Hunter Kill Team", "Hunter Patrol",
			"Hunter Strike Team", "Jackal Patrol", "Elite Strike Team", "Skirmisher Patrol", "Hunters", "Jackal Snipers", "Jackals", "Hunter Infantry", "Mules",
			"Skirmishers", "Hunter Tactical", "Skirmisher Infantry", "Heretics", "Heretic Snipers", "Heretic Heavy"].map((n, i) => [i, n])],
		vision: [[0, "Unchanged"], [1, "Normal"], [2, "Blind"], [3, "Near Sighted"], [4, "Eagle Eye"]],
		hearing: [[0, "Unchanged"], [1, "Normal"], [2, "Deaf"], [3, "Sharp"]],
		luck: [[0, "Unchanged"], [1, "Normal"], [2, "Unlucky"], [3, "Lucky"], [4, "Leprechaun"]],
		weapon: [[0, "Unchanged"], [1, "Normal"], [2, "Marksman"], [3, "Trigger Happy"]],
		grenades: [[0, "Unchanged"], [1, "Normal"], [2, "None"], [3, "Catch"]],
		equipment_drop: [[0, "Unchanged"], [1, "Enabled"], [2, "Disabled"]],
		assassination_immunity: ONOFF3, headshot_immunity: ONOFF3,
		damage_resistance: LISTS.damage_resistance, damage: MOD,
	};
	FF_LISTS.dropship = ONOFF;
	FF_LISTS.elite_respawn_time = FF_LISTS.respawn;
	FF_LISTS.order = [[0, "Random"], [1, "Ordered"]];
	const FF_SKULLS = [[1, "Black Eye"], [2, "Tough Luck"], [3, "Catch"], [4, "Cloud"], [5, "Famine"], [7, "Tilt"], [8, "Mythic"], [11, "Cowbell"],
		[12, "Grunt Birthday"], [13, "IWHBYD"], [14, "Red"], [15, "Yellow"], [16, "Blue"]];
	const FF_AI = [["vision", "Vision"], ["hearing", "Hearing"], ["luck", "Luck"], ["weapon", "Shootiness"], ["grenades", "Grenades"],
		["equipment_drop", "Equipment Drop"], ["damage_resistance", "Damage Resistance"], ["damage", "Damage Modifier"],
		["headshot_immunity", "Headshot Immunity"], ["assassination_immunity", "Assassination Immunity"]];
	const T = (key, name) => ({ key, name });
	const TRAIT_GROUPS = [
		["Shields and Health", [T("damage_resistance", "Damage Resistance"), T("shield_multiplier", "Shield Multiplier"), T("shield_recharge", "Shield Recharge Rate"),
			T("health_recharge", "Health Recharge Rate"), T("headshot_immunity", "Headshot Immunity"), T("assassination_immunity", "Assassination Immunity")]],
		["Weapons and Damage", [T("damage", "Damage Modifier"), T("melee_damage", "Melee Damage Modifier"), T("primary_weapon", "Primary Weapon"),
			T("secondary_weapon", "Secondary Weapon"), T("armor_ability", "Armor Ability"), T("grenades", "Grenade Count"), T("infinite_ammo", "Infinite Ammo"),
			T("weapon_pickup", "Weapon Pickup"), T("ability_usage", "Armor Ability Usage")]],
		["Movement", [T("speed", "Player Speed"), T("jump_height", "Jump Height"), T("gravity", "Player Gravity"), T("vehicle_use", "Vehicle Use")]],
		["Appearance", [T("active_camo", "Active Camo"), T("waypoint", "Waypoint"), T("name_visibility", "Visible Name"), T("forced_color", "Forced Color")]],
		["Sensors", [T("motion_tracker", "Motion Tracker Mode"), T("tracker_range", "Motion Tracker Range")]],
	];
	// The base traits' fields that the quick Player Traits rows already edit (their older keys).
	const BASE_KEYS = { primary_weapon: "primary_weapon", secondary_weapon: "secondary_weapon", armor_ability: "armor_ability", grenades: "grenades",
		shield_multiplier: "shields", shield_recharge: "shield_recharge" };
	const SET_NAMES = { base: "Base Player Traits", respawn: "Respawn Traits", red: "Red Power-up Traits", blue: "Blue Power-up Traits", yellow: "Yellow Power-up Traits" };
	const traitKey = (set, field) => set === "base" && BASE_KEYS[field] ? BASE_KEYS[field] : `trait.${set}.${field}`;
	const S = (key, name, text) => ({ key, name, text });
	const GROUPS = [
		{ name: "General Settings", text: "Score, time and rounds.", settings: [
			S("score_to_win", "Score to Win", "The score that wins the round."),
			S("time_limit", "Time Limit", "How long each round lasts."),
			S("round_limit", "Number of Rounds", "How many rounds the game has."),
			S("sudden_death", "Sudden Death", "How long a round may run past its time while the objective is contested."),
			S("teams", "Teams", "Players play on teams, or every player for themselves.")] },
		{ name: "Respawn Settings", text: "Lives and how long players wait to come back.", settings: [
			S("lives", "Lives per Round", "How many times a player may spawn in each round."),
			S("respawn_time", "Respawn Time", "How long a player waits to respawn."),
			S("suicide_penalty", "Suicide Penalty", "Extra wait after killing yourself."),
			S("betrayal_penalty", "Betrayal Penalty", "Extra wait after killing a teammate."),
			S("respawn_growth", "Respawn Time Growth", "How much longer the wait gets with each death."),
			S("team_lives", "Lives per Team", "How many times a team's players may spawn in each round, all together."),
			S("respawn_traits_duration", "Respawn Traits Duration", "How long the respawn traits last after a player spawns."),
			S("respawn_sync", "Synchronize with Team", "Enabled: players' respawn timers synchronize so that dead teammates respawn together."),
			S("loadout_camera_time", "Loadout Camera Time", "How long players look over the map while picking a loadout before they spawn.")] },
		{ name: "Player Traits", text: "What every player spawns with.", settings: [
			S("primary_weapon", "Primary Weapon", "The weapon players spawn holding."),
			S("secondary_weapon", "Secondary Weapon", "The weapon players spawn carrying."),
			S("armor_ability", "Armor Ability", "The armor ability players spawn with."),
			S("grenades", "Grenades", "The grenades players spawn with."),
			S("shields", "Shield Multiplier", "How strong players' shields are."),
			S("shield_recharge", "Shield Recharge Rate", "How fast shields come back.")] },
		{ name: "Map Overrides", text: "Weapons, vehicles and grenades placed on the map.", settings: [
			S("weapon_set", "Weapons on Map", "Which weapons the map places."),
			S("vehicle_set", "Vehicle Set", "Which vehicles the map places."),
			S("grenades_on_map", "Grenades on Map", "Whether the map places grenades."),
			S("indestructible_vehicles", "Indestructible Vehicles", "Vehicles can't be destroyed."),
			S("abilities_on_map", "Armor Abilities on Map", "Whether the map places armor abilities."),
			S("turrets_on_map", "Turrets on Map", "Whether the map places turrets."),
			S("shortcuts_on_map", "Shortcuts", "Whether the map's shortcuts are open."),
			S("powerups_on_map", "Power-ups on Map", "Whether the map places power-ups."),
			S("red_powerup_duration", "Red Power-up Duration", "How long the red power-up lasts."),
			S("blue_powerup_duration", "Blue Power-up Duration", "How long the blue power-up lasts."),
			S("yellow_powerup_duration", "Yellow Power-up Duration", "How long the yellow power-up lasts.")] },
		{ name: "Social", text: "Teams and friendly fire.", settings: [
			S("team_changing", "Team Changing", "Whether players may switch teams during the game."),
			S("friendly_fire", "Friendly Fire", "Whether teammates can hurt each other."),
			S("betrayal_booting", "Betrayal Booting", "Whether a player betrayed by a teammate may boot them.")] },
		{ name: "Match Settings", text: "Our own rules for this match, enforced for every player.", settings: [
			S("player_colors", "Halo Infinite Style Colors", "Enabled: in team games (Team Slayer, Invasion and the like) every player wears their own armor colors, as in free-for-all; teams are told apart by the scoreboard, friendly names and arrows, the red reticle on enemies and the motion tracker. Disabled: team games use team colors (red against blue), as in Reach. Forced colors (Infection's zombies and the like) always apply."),
			S("third_person", "Third-Person Camera", "Default: each player's choice. Forced First Person: no third person on foot, not even for assassinations. Forced Third Person: everyone in third person. Block Third-Person Button: the third-person button does nothing; Reach's own third-person moments stay."),
			S("elites", "Allow Elites", "Enabled: players who chose Elite as their species in the Armory play as Elites, in team games such as Team Slayer too. Disabled: everyone plays as a Spartan. Invasion, Firefight and Covenant Slayer keep their own Spartans and Elites.")] },
	];
	// Allow Elites acts only where the game type doesn't set its own Elites (host-probe gametype.rs species_rule,
	// owner report 2026-10-19): not in Covenant Slayer (species mode 2), Invasion (4, by side) or a game type with a
	// team of Elites (3). Data from before species_mode shows the row.
	function elitesRuleActs(base) {
		const m = base && base.species_mode;
		return typeof m !== "number" || !(m === 2 || m === 4 || (m === 3 && base.elite_teams));
	}
	const LABEL = Object.fromEntries(GROUPS.flatMap(g => g.settings.map(s => [s.key, s.name])));

	// ---- the lobby this works for (index.html attach) ----
	let ctx = null; // { lobby, render, modes, maps, mapIds }: the lobby Game Options is open for
	const ctxs = []; // every lobby with these rows (Custom Games, Firefight)
	let gametypes = []; // saved game types: { name, base, settings: {key: value}, text }
	let playlists = []; // { name, games: [[map, mode], ...] }

	function parseFile(text) {
		const out = { settings: {} };
		for (const line of String(text).split(/\r?\n/)) {
			const m = /^\s*([^#=][^=]*?)\s*=\s*(.*?)\s*$/.exec(line);
			if (!m) continue;
			if (m[1] === "name" || m[1] === "base") out[m[1]] = m[2];
			else if (m[1] === "game") (out.games = out.games || []).push(m[2]);
			else if (/^-?\d+$/.test(m[2])) out.settings[m[1]] = +m[2];
		}
		return out;
	}
	// A game type's key in gametype-settings-data.js (extract_gametype_settings.py key_of).
	function keyOf(path) {
		const p = String(path).replace(/\\/g, "/").toLowerCase();
		for (const cut of ["/haloreach/", "/976730/"]) if (p.includes(cut)) return p.split(cut)[1];
		return p;
	}
	// The base game type file (MCC's name or a path) for the lobby's Game Type row.
	function current() {
		const item = ctx.lobby.items.find(i => i.name === "Game Type");
		if (item.variant && item.variant.saved) {
			const gt = gametypes.find(g => g.name === item.variant.saved);
			if (gt) return { base: gt.base, own: gt, title: gt.name };
		}
		// A saved game type from the File Share (another player's .rrgt; gamesetup.rs myfiles sends its text):
		// its settings on top of its base, as for one of ours, but with no name, so Save asks for one instead of
		// quietly replacing a saved game type of the player's own with the same name (2026-10-21).
		if (item.variant && item.variant.rrgt) {
			const gt = parseFile(item.variant.rrgt);
			if (gt.base) return { base: gt.base, own: { ...gt, name: "" }, title: item.variant.name };
		}
		if (item.variant) return { base: item.variant.path, title: item.variant.name };
		// (Forge's Game Type row has no list: its one game type)
		const mode = item.options ? ctx.modes.find(m => m[0] === item.options[item.pick]) : ctx.modes[0];
		return { base: mode[1], title: mode[0] };
	}
	// Settings read on this PC by the game program (`gametype-describe:`; the player's own game types,
	// or any the package's list doesn't have), by the file they came from.
	const described = {};
	const dataOf = (base) => described[base] || SETTINGS[/[\\/]/.test(base) ? keyOf(base) : "game_variants/" + base.toLowerCase() + ".bin"];
	let describing = null; // the game type being read for Game Options
	// The File Share game type a file there stands for (gamesetup.rs myfiles): its own entry, or for a shared
	// .rrgt's base (fileshare\base\<sha256>.bin, not listed and named only by its hash) the .rrgt it came
	// with. A game type saved from a shared .rrgt is on top of that base: without this it was "on top of"
	// 64 hex digits and always went to Custom Games, a Firefight one too (2026-10-21).
	const sharedOf = (file) => {
		const low = String(file).toLowerCase();
		if (!/[\\/]fileshare[\\/]/.test(low)) return null;
		return ((window.VARIANT_DATA || {}).games || []).find(g => g.group === "File Share" && (String(g.path).toLowerCase() === low
			|| (g.rrgt && g.rrgt.toLowerCase().includes(low) && String(parseFile(g.rrgt).base || "").toLowerCase() === low))) || null;
	};
	const modeName = (mode) => {
		if (mode.startsWith("rr:")) return mode.slice(3);
		const m = ctx.modes.find(x => x[1] === mode);
		if (m) return m[0];
		const v = ((window.VARIANT_DATA || {}).games || []).find(g => g.path === mode) || sharedOf(mode);
		return v ? v.name : mode.split(/[\\/]/).pop().replace(/\.bin$/i, "");
	};
	const mapName = (map) => ctx.maps.find(m => m.replace(/ /g, "") === map) || map;

	// ---- the pages (styled like Select Map: index.html's .picker) ----
	const root = document.createElement("div");
	root.className = "picker gs";
	const css = document.createElement("style");
	css.textContent = `
	.gs { z-index: 40; }
	.gs ul { width: 30vw !important; left: 31vw; max-height: 66vh; }
	.gs li .r { font-size: 2.3vh !important; color: #e8ecef !important; }
	.gs li.grp { color: rgba(160,190,214,0.9); font-size: 2vh; letter-spacing: 0.12em; pointer-events: none; margin-top: 1.4vh; }
	.gs li.changed .r::before { content: "\\2022 "; color: #e2c35a; }
	.gs .info { left: 64vw; width: 24vw; top: 17.5vh; }
	.gs .note { position: absolute; left: 31vw; top: 84vh; font-size: 2.2vh; color: #e2c35a; }
	.gsp { position: fixed; inset: 0; z-index: 1003; display: none; align-items: center; justify-content: center;
		background: radial-gradient(ellipse at 50% 45%, rgba(20, 40, 54, 0.92), rgba(4, 8, 12, 0.96)); font-family: var(--font); color: var(--text); }
	.gsp.open { display: flex; }
	.gsp .box { width: 44vw; padding: 4vh 3vw; background: linear-gradient(180deg, rgba(40, 56, 70, 0.92), rgba(22, 32, 42, 0.92));
		box-shadow: inset 0.25vw 0 0 #f2f4f5, 0 1vh 4vh rgba(0, 0, 0, 0.6); }
	.gsp h1 { margin: 0 0 1vh; font-size: 5vh; font-weight: 700; text-transform: uppercase; }
	.gsp p { margin: 0 0 3vh; font-size: 2.4vh; color: #b9c2c8; }
	.gsp input { width: 100%; box-sizing: border-box; font: 600 4vh var(--font); padding: 1vh 1vw; color: #fff;
		background: rgba(0, 0, 0, 0.35); border: 1px solid rgba(255, 255, 255, 0.35); outline: none; }
	.gsp .err { min-height: 2.6vh; margin-top: 1vh; font-size: 2.2vh; color: #e8a33a; }
	.gsp .keys { margin-top: 2vh; display: flex; gap: 1.6vw; font-size: 2.6vh; }
	.gsp .keys .hint { cursor: pointer; }`;
	let page = null; // { title, side, rows: [{label, value, text, act(a, el), changed, head}], sel, top, back, note }

	function show(p) {
		if (!root.isConnected) { document.head.appendChild(css); document.body.appendChild(root); }
		p.parent = p.parent === undefined ? page : p.parent;
		p.sel = p.sel ?? p.rows.findIndex(r => !r.head);
		page = p;
		draw();
	}
	function rebuild() {
		if (!page) return;
		const keep = { sel: page.sel, top: page.top, parent: page.parent, note: page.note };
		const fresh = page.build();
		Object.assign(page, fresh, keep);
		page.sel = Math.min(page.sel, page.rows.length - 1);
		draw();
	}
	function draw() {
		const p = page, SHOWN = 15;
		let top = p.top ?? 0;
		if (p.sel < top) top = p.sel;
		if (p.sel >= top + SHOWN) top = p.sel - SHOWN + 1;
		p.top = top = Math.max(0, Math.min(top, Math.max(0, p.rows.length - SHOWN)));
		const r = p.rows[p.sel] || {};
		root.innerHTML = `<div class="dots"></div>
			<div class="head"><svg viewBox="0 0 40 40" aria-hidden="true"><path d="M20 2 L38 20 L20 38 L2 20 Z" fill="none" stroke="#7fb3e6" stroke-width="2.5"/><path d="M20 11 L29 20 L20 29 L11 20 Z" fill="none" stroke="#cfe3f5" stroke-width="2"/><circle cx="20" cy="20" r="2.4" fill="#e9f3fb"/></svg>
			<h1 class="${p.title.length > 22 ? "long" : ""}">${esc(p.title)}</h1></div><div class="side">${esc(p.side || "Custom Games")}</div>
			<ul>${p.rows.map((row, i) => i < top || i >= top + SHOWN ? "" : `<li data-i="${i}" class="${row.head ? "grp" : ""} ${i === p.sel ? "sel" : ""} ${row.changed ? "changed" : ""}"><span>${esc(row.label)}</span>${row.value !== undefined ? `<span class="r">${esc(row.value)}</span>` : ""}</li>`).join("")}</ul>
			<div class="info"><div class="nm">${esc(r.label || "")}</div>${r.value !== undefined ? `<div class="pl">${esc(r.value)}</div>` : ""}${r.text ? `<div class="ab">${esc(r.text)}</div>` : ""}</div>
			${p.note || p.hint ? `<div class="note">${esc(p.note || p.hint)}</div>` : ""}
			<div class="keys"><span class="hint" data-a="select"><span class="btn a">A</span>Select</span><span class="hint" data-a="back"><span class="btn b">B</span>Back</span>${p.xHint ? `<span class="hint" data-a="star"><span class="btn x">X</span>${esc(p.xHint)}</span>` : ""}</div>`;
		root.classList.add("open");
		root.querySelectorAll("[data-i]").forEach(el => {
			const i = +el.dataset.i;
			el.onmouseenter = () => { if (page && page.sel !== i && !p.rows[i].head && (!window.MenuScroll || MenuScroll.hoverOk())) { page.sel = i; play("move"); draw(); } };
			el.onclick = () => { if (!p.rows[i].head) { page.sel = i; act("select"); } };
		});
		root.querySelectorAll("[data-a]").forEach(el => el.onclick = () => act(el.dataset.a));
		root.onwheel = (ev) => act(ev.deltaY > 0 ? "down" : "up");
		// A scroll bar beside lists longer than the screen (controls.js MenuScroll; clicks on its track page).
		if (window.MenuScroll && p.rows.length > SHOWN) {
			root.querySelector("ul").insertAdjacentHTML("afterend", MenuScroll.bar(top, SHOWN, p.rows.length, "left:61.6vw;top:16.5vh;height:52vh"));
			MenuScroll.wire(root, (dir) => { if (!dir) return; p.top = Math.max(0, Math.min(p.rows.length - SHOWN, top + (dir === "down" ? SHOWN : -SHOWN))); p.sel = Math.max(p.top, Math.min(p.sel, p.top + SHOWN - 1)); while (p.rows[p.sel] && p.rows[p.sel].head && p.sel < p.rows.length - 1) p.sel++; draw(); });
		}
	}
	function close() {
		page = null;
		root.classList.remove("open");
		if (ctx) ctx.render();
	}
	function act(a) {
		if (prompt.open) return prompt.action(a);
		if (window.Dropdown && Dropdown.action(a)) return;
		if (a === "start") return close();
		const p = page, n = p.rows.length;
		if (a === "up" || a === "down") {
			let i = p.sel;
			do i = (i + (a === "down" ? 1 : n - 1)) % n; while (p.rows[i].head && i !== p.sel);
			p.sel = i; play("move"); return draw();
		}
		if (a === "back") {
			play("back");
			if (p.onBack && p.onBack() === false) return;
			page = p.parent;
			if (page) { if (page.build) rebuild(); else draw(); } else close();
			return;
		}
		const row = p.rows[p.sel];
		if (row && row.act) row.act(a, root.querySelector(`[data-i="${p.sel}"] .r`) || root.querySelector(`[data-i="${p.sel}"]`));
	}
	// A setting's row: A opens its list (controls.js), left and right step through it.
	function choiceRow(label, list, value, set, text, changed) {
		const known = list.some(o => o[0] === value) ? list : [...list, [value, "Custom (" + value + ")"]];
		const shown = (known.find(o => o[0] === value) || [0, String(value)])[1];
		return { label, value: shown, text, changed, act(a, anchor) {
			const at = known.findIndex(o => o[0] === value);
			if (a === "left" || a === "right") { play("change"); set(known[(at + (a === "right" ? 1 : known.length - 1)) % known.length][0]); rebuild(); }
			else if (a === "select" && window.Dropdown) Dropdown.open({ title: label, options: known, value, anchor, onPick: (v) => { set(v); rebuild(); } });
			else if (a === "select") { play("change"); set(known[(at + 1) % known.length][0]); rebuild(); }
		} };
	}

	// ---- text prompt (names) ----
	const prompt = (() => {
		const el = document.createElement("div");
		el.className = "gsp";
		el.innerHTML = `<div class="box"><h1></h1><p></p><input maxlength="32" spellcheck="false" autocomplete="off"><div class="err"></div>
			<div class="keys"><span class="hint" data-a="ok"><span class="btn a">A</span>Accept</span><span class="hint" data-a="cancel"><span class="btn b">B</span>Cancel</span></div></div>`;
		const input = el.querySelector("input"), err = el.querySelector(".err");
		let done = null, max = 32;
		const state = { open: false };
		const valid = (v) => new RegExp(`^[A-Za-z0-9 _-]{1,${max}}$`).test(v) && v.trim() === v;
		function open(title, text, value, limit, after) {
			if (!el.isConnected) { document.head.appendChild(css); document.body.appendChild(el); }
			max = limit; done = after; state.open = true;
			el.querySelector("h1").textContent = title;
			el.querySelector("p").textContent = text;
			input.maxLength = limit;
			input.value = value || "";
			err.textContent = "";
			el.classList.add("open");
			setTimeout(() => { input.focus(); input.select(); }, 0);
		}
		function finish(ok) {
			const v = input.value.trim();
			if (ok && !valid(v)) { err.textContent = `1 to ${max} letters, numbers, spaces, - or _.`; play("error"); return; }
			state.open = false;
			el.classList.remove("open");
			input.blur();
			play(ok ? "select" : "back");
			if (ok && done) done(v);
		}
		input.addEventListener("keydown", (e) => {
			e.stopPropagation();
			if (e.key === "Enter") { e.preventDefault(); finish(true); }
			else if (e.key === "Escape") { e.preventDefault(); finish(false); }
		});
		el.querySelectorAll("[data-a]").forEach(b => b.onclick = () => finish(b.dataset.a === "ok"));
		state.show = open;
		state.action = (a) => { if (a === "select") finish(true); else if (a === "back") finish(false); };
		return state;
	})();

	// ---- SERVER NAME ----
	const player = () => ((document.getElementById("player") || {}).textContent || "Player").replace(/[^A-Za-z0-9 _-]/g, "").trim() || "Player";
	function serverName() { return store.serverName || player() + " Game"; }
	function editServerName() {
		prompt.show("Server Name", "Players see it in the server list and the lobby. Dedicated servers use it too.", serverName(), 32, (v) => {
			store.serverName = v; save(); refreshRows();
		});
	}

	// ---- GAME OPTIONS ----
	let editing = null; // { base, title, name, values: {key: value}, start: {key: value}, options: [...], data }
	function openOptions() {
		const cur = current();
		const data = dataOf(cur.base);
		// (traits come from the game program's reading: MCC's own game types in the package's list lack them)
		if (!data || ((!data.traits || !data.loadouts) && window.chrome && window.chrome.webview)) {
			// Not in the package's list (the player's own game types): the game program reads it.
			const d = document.getElementById("description");
			if (describing === cur.base) return;
			describing = cur.base;
			if (d) d.textContent = "Reading " + cur.title + "...";
			post("gametype-describe:" + cur.base);
			clearTimeout(openOptions.timer);
			openOptions.timer = setTimeout(() => {
				if (describing !== cur.base) return;
				describing = null;
				play("error");
				if (d) d.textContent = "Couldn't read " + cur.title + "'s settings on this PC. Pick another game type, or one of MCC's.";
			}, 8000);
			return;
		}
		const traitValues = {};
		for (const set of data.traits || []) for (const [f, v] of Object.entries(set.values)) traitValues[traitKey(set.key, f)] = v;
		(data.loadouts || []).forEach((pal, p) => pal.forEach((lo, l) => { for (const [f, v] of Object.entries(lo)) traitValues[loadoutKey(p, l, f)] = v; }));
		Object.assign(traitValues, data.firefight || {}, data.forge || {});
		const values = { ...traitValues, ...data.base, ...RULES };
		for (const o of data.options) values["option." + o.index] = o.value;
		if (cur.own) Object.assign(values, cur.own.settings);
		editing = { base: cur.base, title: cur.title, name: cur.own ? cur.own.name : "", values, start: { ...values }, from: { ...traitValues, ...data.base, ...RULES, ...Object.fromEntries(data.options.map(o => ["option." + o.index, o.value])) }, data };
		show({ parent: null, build: optionsPage, ...optionsPage(), onBack: () => {
			const dirty = Object.keys(editing.values).some(k => editing.values[k] !== editing.start[k]);
			if (!dirty || page.confirmLeave) return true;
			page.confirmLeave = true;
			page.note = "Unsaved changes. Press B again to leave without saving, or choose Save.";
			draw();
			return false;
		} });
	}
	function optionsPage() {
		const e = editing, d = e.data;
		const changed = (k) => e.values[k] !== e.from[k];
		const rows = [
			{ label: "Name", value: e.name || "(not saved yet)", text: "The game type's name: in the lobby, the server list and Saved Game Types.", act: (a) => {
				if (a === "select") prompt.show("Game Type Name", "Name this game type.", e.name || e.title, 32, (v) => { e.name = v; rebuild(); });
			} },
		];
		if (d.firefight) rows.push(...firefightRows());
		else if (d.forge) rows.push(...forgeRows());
		else for (const g of GROUPS) {
			rows.push({ head: true, label: g.name });
			for (const s of g.settings) {
				if (s.key === "elites" && !elitesRuleActs(d.base)) continue;
				rows.push(choiceRow(s.name, LISTS[s.key], e.values[s.key], (v) => { e.values[s.key] = v; }, s.text, changed(s.key)));
			}
		}
		// Every trait set, each on its own page: Reach's five and the game type's own (Leader Traits, ...).
		// (Firefight's are on its Spartan, Elite and skull pages.)
		if (d.traits && !d.firefight && !d.forge) {
			rows.push({ head: true, label: "All Player Traits" });
			for (const set of d.traits) {
				const name = SET_NAMES[set.key] || set.name || "Traits " + set.key;
				const n = TRAIT_GROUPS.flatMap(([, ts]) => ts).filter(t => e.values[traitKey(set.key, t.key)] !== e.from[traitKey(set.key, t.key)]).length;
				rows.push({ label: name + "...", value: n ? n + " changed" : "", changed: n > 0, text: "Every trait for " + name.toLowerCase() + ": shields, weapons, movement, appearance and sensors.",
					act: (a) => { if (a === "select") { play("select"); show({ build: () => traitsPage(set.key, name), ...traitsPage(set.key, name) }); } } });
			}
		}
		// Loadouts: Spartan and Elite, each 3 tiers of 5, on their own pages.
		if (d.loadouts && !d.firefight && !d.forge) {
			rows.push({ head: true, label: "Loadouts" });
			for (const [species, first] of [["Spartan", 0], ["Elite", 1]]) {
				const keys = [0, 2, 4].flatMap(p => [0, 1, 2, 3, 4].flatMap(l => LOADOUT_ROWS.map(([f]) => loadoutKey(p + first, l, f))));
				const n = keys.filter(changed).length;
				rows.push({ label: species + " Loadouts...", value: n ? n + " changed" : "", changed: n > 0,
					text: `The loadouts ${species}s pick from when they spawn: 3 tiers of 5, each with a name, weapons, equipment and grenades.`,
					act: (a) => { if (a === "select") { play("select"); show({ build: () => loadoutsPage(species, first), ...loadoutsPage(species, first) }); } } });
			}
		}
		if (d.options.length) {
			rows.push({ head: true, label: (d.name || e.title) + " Options" });
			for (const o of d.options) {
				const k = "option." + o.index;
				const list = o.values ? o.values.map((label, i) => [i, label.replace(/^./, c => c.toUpperCase())])
					: Array.from(new Set([o.min, ...[0, 1, 2, 3, 5, 10, 15, 20, 25, 30, 50, 75, 100, 150, 200, 250, 300, 500].filter(v => v > o.min && v < o.max), o.max])).map(v => [v, String(v)]);
				rows.push(choiceRow(o.name, list, e.values[k], (v) => { e.values[k] = v; }, o.text, changed(k)));
			}
		}
		rows.push({ head: true, label: "" });
		rows.push({ label: "Save", text: "Save this game type and pick it for this lobby. Saving under a name you already used replaces that one.", act: (a) => { if (a === "select") saveOptions(); } });
		rows.push({ label: "Reset to " + e.title, text: "Back to the settings " + e.title + " starts with.", act: (a) => {
			if (a !== "select") return;
			play("select");
			Object.assign(e.values, e.from);
			rebuild();
		} });
		return { title: "Game Options", side: e.title, rows };
	}
	// ---- Firefight (host-probe gametype.rs FF_*; Reach's own Firefight menus and labels) ----
	// A row that opens a page; its value counts the changed settings whose keys `mine` picks.
	function pageRow(label, text, mine, build) {
		const e = editing;
		const n = Object.keys(e.values).filter(k => mine(k) && e.values[k] !== e.from[k]).length;
		return { label: label + "...", value: n ? n + " changed" : "", changed: n > 0, text,
			act: (a) => { if (a === "select") { play("select"); show({ build, ...build() }); } } };
	}
	const traitRow = (set, name, text) => pageRow(name, text, (k) => k.startsWith(`trait.${set}.`) || (set === "base" && Object.values(BASE_KEYS).includes(k)), () => traitsPage(set, name));
	function ffRow(key, name, text) {
		const e = editing;
		return choiceRow(name, FF_LISTS[key.split(".").pop()], e.values[key], (v) => { e.values[key] = v; }, text, e.values[key] !== e.from[key]);
	}
	function firefightRows() {
		const rows = [];
		rows.push({ head: true, label: "General Settings" });
		rows.push(ffRow("ff.set_count", "Wave Limit", "How many waves, rounds or sets the game lasts."));
		rows.push(choiceRow("Time Limit", FF_LISTS.time_limit, editing.values.time_limit, (v) => { editing.values.time_limit = v; }, "How long each turn lasts.", editing.values.time_limit !== editing.from.time_limit));
		rows.push(choiceRow("Turn Count", FF_LISTS.turns, editing.values.round_limit, (v) => { editing.values.round_limit = v; }, "Versus: how many turns each team plays as the Spartans.", editing.values.round_limit !== editing.from.round_limit));
		rows.push({ head: true, label: "Scenario Settings" });
		rows.push(ffRow("ff.hazards", "Hazards", "The map's own hazards."));
		rows.push(ffRow("ff.weapon_drops", "Weapon Drops", "Weapons dropped in for the Spartans between waves."));
		rows.push(ffRow("ff.ammo_crates", "Ammo Crates", "Ammo crates on the map."));
		rows.push({ head: true, label: "Generator Properties" });
		rows.push(ffRow("ff.generator_count", "Generator Count", "Generator Defense: how many generators the Spartans defend."));
		rows.push(ffRow("ff.generator_defend_all", "Loss Condition", "Lose One: the game is lost when one generator falls. Lose All: when every generator has."));
		rows.push(ffRow("ff.generator_random", "Spawn Order", "Which generators the Covenant go for first."));
		rows.push({ head: true, label: "Spartans and Elites" });
		rows.push(pageRow("Spartan Settings", "Lives, respawn, traits and loadouts for the Spartans.", (k) => /^ff\.(spartan_lives|max_lives|elite_kill_bonus)$|^trait\.(ff_spartan|respawn)\.|^respawn_time$|^loadout\.[024]\./.test(k), spartanPage));
		rows.push(pageRow("Elite Settings", "Lives, respawn, traits and loadouts for Elite players (Versus).", (k) => /^ff\.elite_(lives|respawn_time)$|^trait\.ff_elite|^loadout\.[135]\./.test(k), elitePage));
		rows.push({ head: true, label: "Waves" });
		for (let r = 0; r < 3; r++) rows.push(pageRow(`Round ${r + 1} Wave Properties`, `Skulls and the Covenant squads of round ${r + 1}'s initial, main and boss waves.`, (k) => k.startsWith(`ff.round.${r}.`), () => roundPage(r)));
		rows.push(pageRow("Bonus Wave Properties", "The bonus wave's length, skulls and squads.", (k) => k.startsWith("ff.bonus"), bonusPage));
		rows.push(pageRow("Wave Traits", "How every Covenant wave fights: vision, hearing, luck, aim, grenades and toughness.", (k) => k.startsWith("ff.ai.wave."), () => aiPage("wave", "Wave Traits")));
		rows.push(pageRow("Custom Skull Settings", "What the Red, Yellow and Blue skulls do to Spartans, Elites and the Covenant.", (k) => /^ff\.ai\.(red|yellow|blue)\.|^trait\.(red|yellow|blue)_/.test(k), skullsPage));
		return rows;
	}
	// ---- Forge (host-probe gametype.rs FORGE_*) ----
	function forgeRows() {
		const e = editing;
		return [{ head: true, label: "Forge Settings" },
			choiceRow("Edit Mode", [[0, "All Players"], [1, "Only Leader"]], e.values["forge.edit_mode"], (v) => { e.values["forge.edit_mode"] = v; },
				"All Players: everyone can switch into the editor. Only Leader: only the party leader can.", e.values["forge.edit_mode"] !== e.from["forge.edit_mode"]),
			choiceRow("Respawn Time", [[0, "Instant"], ...[1, 2, 3, 4, 5, 10, 15, 20, 30, 45, 60].map(secs)], e.values["forge.respawn_time"], (v) => { e.values["forge.respawn_time"] = v; },
				"How long a player waits to respawn in Forge.", e.values["forge.respawn_time"] !== e.from["forge.respawn_time"]),
			{ head: true, label: "Player Traits" },
			traitRow("editor", "Editor Traits", "Traits players have while editing: shields, camo, waypoints and the motion tracker, among the rest."),
			traitRow("base", "Base Player Traits", "Traits players have while playing, out of the editor.")];
	}
	function spartanPage() {
		const rows = [
			ffRow("ff.spartan_lives", "Starting Lives", "The lives the Spartans share at the start."),
			ffRow("ff.max_lives", "Maximum Extra Lives", "The most extra lives the Spartans can bank."),
			choiceRow("Respawn Time", FF_LISTS.respawn, editing.values.respawn_time, (v) => { editing.values.respawn_time = v; }, "How long a Spartan waits to respawn. On Wave: at the next wave.", editing.values.respawn_time !== editing.from.respawn_time),
			ffRow("ff.elite_kill_bonus", "Elite Kill Bonus", "Lives the Spartans earn for each Elite player they kill (Versus)."),
			traitRow("ff_spartan", "Base Traits", "Every trait the Spartans play with."),
			traitRow("respawn", "Respawn Traits", "Traits Spartans have for a while after they respawn."),
			pageRow("Loadouts", "The loadouts Spartans pick from.", (k) => /^loadout\.[024]\./.test(k), () => loadoutsPage("Spartan", 0)),
		];
		return { title: "Spartan Settings", side: editing.title, rows };
	}
	function elitePage() {
		const rows = [
			ffRow("ff.elite_lives", "Starting Lives", "Each Elite player's lives (Versus)."),
			ffRow("ff.elite_respawn_time", "Respawn Time", "How long an Elite player waits to respawn. On Wave: at the next wave."),
			traitRow("ff_elite", "Base Traits", "Every trait Elite players play with."),
			traitRow("ff_elite_respawn", "Respawn Traits", "Traits Elite players have for a while after they respawn."),
			pageRow("Loadouts", "The loadouts Elite players pick from.", (k) => /^loadout\.[135]\./.test(k), () => loadoutsPage("Elite", 1)),
		];
		return { title: "Elite Settings", side: editing.title, rows };
	}
	// A wave's rows: dropship, order and its squads (Reach shows 3 for initial, boss and bonus waves, 5 for main).
	function waveRows(prefix, name, squads) {
		const rows = [{ head: true, label: name }];
		rows.push(ffRow(prefix + ".dropship", "Uses Dropship", "The squads arrive by dropship."));
		rows.push(ffRow(prefix + ".order", "Squad Selection Order", "Random: any of the squads below. Ordered: one after another."));
		for (let k = 0; k < squads; k++) {
			const key = `${prefix}.squad.${k}`;
			rows.push(choiceRow(`Squad ${k + 1}`, FF_LISTS.squad, editing.values[key], (v) => {
				// (the wave sends its first `count` squads: one set to None ends the list)
				editing.values[key] = v;
				let n = 0;
				while (n < squads && editing.values[`${prefix}.squad.${n}`] >= 0) n++;
				editing.values[prefix + ".count"] = n;
			}, "", editing.values[key] !== editing.from[key]));
		}
		return rows;
	}
	function skullRows(key) {
		const e = editing;
		return FF_SKULLS.map(([bit, name]) => choiceRow(name, [[0, "Off"], [1, "On"]], (e.values[key] >> bit) & 1, (v) => {
			e.values[key] = v ? e.values[key] | (1 << bit) : e.values[key] & ~(1 << bit);
		}, "", ((e.values[key] ^ e.from[key]) >> bit) & 1));
	}
	function roundPage(r) {
		const p = `ff.round.${r}`;
		const rows = [{ head: true, label: "Skulls" }, ...skullRows(p + ".skulls"), ...waveRows(p + ".initial", "Initial Wave", 3),
			...waveRows(p + ".main", "Main Waves", 5), ...waveRows(p + ".boss", "Boss Wave", 3)];
		return { title: `Round ${r + 1} Wave Properties`, side: editing.title, rows };
	}
	function bonusPage() {
		const rows = [ffRow("ff.bonus_duration", "Bonus Wave Duration", "How long the bonus wave lasts."), { head: true, label: "Bonus Wave Skulls" }, ...skullRows("ff.bonus.skulls"),
			...waveRows("ff.bonus", "Squads", 3)];
		return { title: "Bonus Wave Properties", side: editing.title, rows };
	}
	function aiPage(set, name) {
		const rows = FF_AI.map(([f, label]) => ffRow(`ff.ai.${set}.${f}`, label, ""));
		return { title: name, side: editing.title, rows };
	}
	function skullsPage() {
		const rows = [];
		for (const [c, name] of [["red", "Red"], ["yellow", "Yellow"], ["blue", "Blue"]]) {
			rows.push({ head: true, label: name + " Skull Settings" });
			rows.push(traitRow(c + "_spartan", name + " Skull Spartan Traits", "Traits Spartans get while the " + name + " skull is on."));
			rows.push(traitRow(c + "_elite", name + " Skull Elite Traits", "Traits Elite players get while the " + name + " skull is on."));
			rows.push(pageRow(name + " Skull Wave Traits", "How the Covenant fight while the " + name + " skull is on.", (k) => k.startsWith(`ff.ai.${c}.`), () => aiPage(c, name + " Skull Wave Traits")));
		}
		return { title: "Custom Skull Settings", side: editing.title, rows };
	}
	function traitsPage(set, name) {
		const e = editing;
		const rows = [];
		for (const [group, ts] of TRAIT_GROUPS) {
			rows.push({ head: true, label: group });
			for (const t of ts) {
				const k = traitKey(set, t.key);
				if (e.values[k] === undefined) continue;
				rows.push(choiceRow(t.name, LISTS[t.key], e.values[k], (v) => { e.values[k] = v; }, "", e.values[k] !== e.from[k]));
			}
		}
		return { title: name, side: e.title, rows };
	}
	// One species' loadouts: palettes first, first + 2 and first + 4 are its tiers 1 to 3.
	function loadoutsPage(species, first) {
		const e = editing;
		const rows = [];
		for (const tier of [0, 1, 2]) {
			const p = first + 2 * tier;
			rows.push({ head: true, label: `Tier ${tier + 1} Loadouts` });
			for (let l = 0; l < 5; l++) {
				const v = (f) => e.values[loadoutKey(p, l, f)];
				const n = LOADOUT_ROWS.filter(([f]) => v(f) !== e.from[loadoutKey(p, l, f)]).length;
				const label = `Loadout ${l + 1}`, title = `${species} Tier ${tier + 1} ${label}`;
				const name = v("name") >= 0 ? LOADOUT_NAMES[v("name")] || "Custom" : "None";
				rows.push({ label, value: name + (v("shown") ? "" : " (Hidden)"), changed: n > 0, text: n ? n + " changed." : "",
					act: (a) => { if (a === "select") { play("select"); show({ build: () => loadoutPage(p, l, title), ...loadoutPage(p, l, title) }); } } });
			}
		}
		return { title: species + " Loadouts", side: e.title, rows };
	}
	function loadoutPage(p, l, title) {
		const e = editing;
		const rows = LOADOUT_ROWS.map(([f, label, text]) => {
			const k = loadoutKey(p, l, f);
			return choiceRow(label, LOADOUT_LISTS[f], e.values[k], (v) => { e.values[k] = v; }, text, e.values[k] !== e.from[k]);
		});
		return { title, side: e.title, rows };
	}
	function saveOptions() {
		const e = editing;
		const go = (name) => {
			e.name = name;
			// (MCC's own game types by name, so the game type works on a PC with MCC in another folder)
			const stock = /[\\/]haloreach[\\/]game_variants[\\/]([^\\/]+)\.bin$/i.exec(e.base);
			const lines = ["# Game type from the menus' Game Options. Settings are on top of the base game type.", "name = " + name, "base = " + (stock ? stock[1] : e.base)];
			for (const [k, v] of Object.entries(e.values)) if (v !== e.from[k]) lines.push(`${k} = ${v}`);
			pendingPick = name;
			post("gametype-save:" + name + "\n" + lines.join("\n") + "\n");
			e.start = { ...e.values };
			page.note = "Saved as " + name + ".";
			page.confirmLeave = false;
			rebuild();
		};
		if (e.name) go(e.name);
		else prompt.show("Save Game Type", "Name this game type.", e.title.slice(0, 26) + " Custom", 32, go);
	}
	let pendingPick = null;
	// The lobby's Game Type row on a saved game type (after saving, or picked from Saved Game Types).
	function pickSaved(name) {
		const gt = gametypes.find(g => g.name === name);
		const item = ctx && ctx.lobby.items.find(i => i.name === "Game Type");
		if (!gt || !item) return;
		item.variant = { name: gt.name, path: "rr:" + gt.name, saved: gt.name, group: "Saved Game Types", kind: kindOf(gt),
			text: "Your game type, on top of " + modeName(gt.base) + "." };
		refreshRows();
	}
	// Saved game types as Select Game Type entries (index.html openGameTypes).
	// (a saved game type on one of MCC's Firefight game types belongs to the Firefight lobby; on a File Share
	// file, to its lobby, which the menus read from the file: its name says nothing)
	const kindOf = (g) => (sharedOf(g.base) || {}).kind
		|| (/(^|[\\/])hr_ff_|firefight|survival/i.test(g.base) ? "firefight" : /basic_editing/i.test(g.base) ? "forge" : "mp");
	function savedVariants(kind = "mp") {
		return gametypes.filter(g => kindOf(g) === kind).map(g => ({ name: g.name, path: "rr:" + g.name, saved: g.name, group: "Saved Game Types", kind,
			text: "Your game type, on top of " + modeName(g.base) + "." }));
	}

	// ---- ROTATION ----
	const rotationName = () => store.rotation && playlists.some(p => p.name === store.rotation) ? store.rotation : "";
	function openRotation() {
		show({ parent: null, build: rotationPage, ...rotationPage() });
	}
	function rotationPage() {
		const rows = [{ label: "Off", value: rotationName() ? "" : "In use", text: "Play only the map and game type picked in this lobby.", act: (a) => {
			if (a !== "select") return;
			play("select"); store.rotation = ""; save(); refreshRows(); close();
		} }];
		for (const p of playlists) rows.push({ label: p.name, value: (p.name === rotationName() ? "In use · " : "") + p.games.length + (p.games.length === 1 ? " game" : " games"),
			text: p.games.map(([m, g], i) => `${i + 1}. ${mapName(m)}, ${modeName(g)}`).join("\n"),
			act: (a) => { if (a === "select") { play("select"); editPlaylist(p.name); } } });
		rows.push({ label: "New Playlist", text: "Make a list of maps and game types to play in turn.", act: (a) => {
			if (a === "select") prompt.show("New Playlist", "Name the playlist.", "Rotation " + (playlists.length + 1), 32, (name) => {
				draft = { name, games: [], isNew: true }; editPlaylist(name);
			});
		} });
		return { title: "Rotation", side: "Custom Games", rows,
			hint: "A hosted game or a dedicated server plays the playlist's games in turn. Dedicated servers: playlist = <name> in server.ini." };
	}
	let draft = null; // the playlist being edited: { name, games, isNew }
	function editPlaylist(name) {
		const p = playlists.find(x => x.name === name);
		if (!draft || draft.name !== name) draft = { name, games: p ? p.games.map(g => g.slice()) : [] };
		show({ build: playlistPage, ...playlistPage(), onBack: () => { draft = null; return true; } });
	}
	function playlistPage() {
		const d = draft;
		const rows = d.games.map(([m, g], i) => ({ label: `${i + 1}. ${mapName(m)}`, value: modeName(g), text: "A: move, change or remove this game.", act: (a, anchor) => {
			if (a !== "select" || !window.Dropdown) return;
			Dropdown.open({ title: `Game ${i + 1}`, anchor, options: [["map", "Change Map"], ["mode", "Change Game Type"], ["up", "Move Up"], ["down", "Move Down"], ["remove", "Remove"]], onPick: (v) => {
				if (v === "map") chooseMap(d.games[i][0], (m2) => { d.games[i][0] = m2; rebuild(); });
				else if (v === "mode") chooseMode(d.games[i][1], (g2) => { d.games[i][1] = g2; rebuild(); });
				else if (v === "up" && i > 0) { d.games.splice(i - 1, 0, d.games.splice(i, 1)[0]); page.sel = i - 1; rebuild(); }
				else if (v === "down" && i < d.games.length - 1) { d.games.splice(i + 1, 0, d.games.splice(i, 1)[0]); page.sel = i + 1; rebuild(); }
				else if (v === "remove") { d.games.splice(i, 1); rebuild(); }
			} });
		} }));
		rows.push({ label: "Add Game", text: "Pick a map, then a game type.", act: (a) => {
			if (a !== "select") return;
			const last = d.games[d.games.length - 1] || [];
			chooseMap(last[0], (m) => chooseMode(last[1], (g) => { d.games.push([m, g]); page.sel = d.games.length - 1; rebuild(); }));
		} });
		rows.push({ head: true, label: "" });
		rows.push({ label: "Save and Use", text: "Save this playlist and play it when you host or start a dedicated server from Custom Games.", act: (a) => {
			if (a !== "select") return;
			if (!d.games.length) { play("error"); page.note = "Add a game first."; return draw(); }
			post("playlist-save:" + d.name + "\n# Playlist from the menus' rotation builder.\nname = " + d.name + "\n" + d.games.map(([m, g]) => `game = ${m}:${g}`).join("\n") + "\n");
			store.rotation = d.name; save();
			play("select");
			draft = null;
			page = null; root.classList.remove("open"); refreshRows();
		} });
		if (!d.isNew) rows.push({ label: "Delete Playlist", text: "Delete this playlist.", act: (a) => {
			if (a !== "select") return;
			if (!page.confirmDelete) { page.confirmDelete = true; page.note = "Press A again to delete " + d.name + "."; play("error"); return draw(); }
			post("playlist-delete:" + d.name);
			if (store.rotation === d.name) { store.rotation = ""; save(); }
			draft = null; page = page.parent; if (page) rebuild(); else close();
		} });
		return { title: d.name, side: "Rotation", rows };
	}
	function chooseMap(value, done) {
		const options = ctx.maps.map(m => [m.replace(/ /g, ""), m]);
		Dropdown.open({ title: "Map", options, value: value || options[0][0], onPick: done });
	}
	// Game types for a rotation: MCC's built-in ones, then the saved ones.
	function chooseMode(value, done) {
		const options = [...ctx.modes.map(m => [m[1], m[0]]), ...gametypes.map(g => ["rr:" + g.name, g.name + " (saved)"])];
		Dropdown.open({ title: "Game Type", options, value: value || options[0][0], onPick: done });
	}

	// ---- the lobby rows' values ----
	function refreshRows() {
		for (const c of ctxs) for (const item of c.lobby.items) {
			// (read when the lobby draws: the player's name arrives after the menus start)
			if (item.setup === "name" && !Object.getOwnPropertyDescriptor(item, "value").get) Object.defineProperty(item, "value", { get: serverName, configurable: true });
			if (item.setup === "rotation") item.value = rotationName() || "Off";
			if (item.setup === "options") item.value = editing && editing.name && c === ctx ? editing.name : "Edit";
		}
		if (ctx) ctx.render();
	}

	// Overlay replies (gamesetup.rs).
	if (window.chrome && window.chrome.webview) window.chrome.webview.addEventListener("message", (ev) => {
		const text = String(ev.data);
		try {
			if (text.startsWith("gametype-info:")) {
				const at = text.indexOf("|"), json = text.slice(at + 1);
				const want = describing;
				describing = null;
				clearTimeout(openOptions.timer);
				if (!want) return;
				if (!json) {
					play("error");
					const d = document.getElementById("description");
					if (d) d.textContent = "Couldn't read this game type's settings on this PC. Pick another game type, or one of MCC's.";
					return;
				}
				described[want] = JSON.parse(json);
				if (!page && ctx) openOptions();
			} else if (text.startsWith("myfiles:")) {
				// The player's own game types and Forge maps on this PC (gamesetup.rs), next to the package's list.
				// (File Share entries are kept whole: Select Game Type and Select Map show their `from` and `mod`,
				// and current() reads a shared .rrgt's `rrgt` text)
				const mine = JSON.parse(text.slice(8)), data = window.VARIANT_DATA = window.VARIANT_DATA || { games: [], maps: [], mods: [] };
				for (const key of ["games", "maps"]) {
					data[key] = data[key] || [];
					const seen = new Set(data[key].map(v => String(v.path).toLowerCase()));
					for (const v of mine[key] || []) if (!seen.has(String(v.path).toLowerCase())) data[key].push(v);
				}
				if (ctx) ctx.render();
			} else if (text.startsWith("gametypes:")) {
				gametypes = JSON.parse(text.slice(10)).map(f => ({ ...parseFile(f.text), name: f.name, text: f.text })).filter(g => g.base);
				if (pendingPick) { pickSaved(pendingPick); pendingPick = null; }
				refreshRows();
			} else if (text.startsWith("playlists:")) {
				playlists = JSON.parse(text.slice(10)).map(f => ({ name: f.name, games: (parseFile(f.text).games || []).map(g => { const at = g.indexOf(":"); return [g.slice(0, at), g.slice(at + 1)]; }) }));
				refreshRows();
				if (page && page.build && !draft) rebuild();
			} else if (text.startsWith("gamesetup-error:")) {
				const msg = text.slice(16).split("|")[1] || "";
				if (page) { page.note = msg; draw(); }
				play("error");
			}
		} catch (e) { }
	});

	return {
		attach(spec) {
			ctxs.push(spec);
			if (!ctx) { ctx = spec; post("gametypes?"); post("playlists?"); post("myfiles?"); }
			refreshRows();
		},
		open(which, lobby) {
			play("select");
			ctx = ctxs.find(c => c.lobby === lobby) || ctx;
			if (which === "name") editServerName();
			else if (which === "rotation") openRotation();
			else if (which === "options") openOptions();
		},
		isOpen: () => !!page || prompt.open,
		action: act,
		serverName,
		savedVariants,
		// The player's files again (index.html: a Forge or Custom Games lobby opens, a match ends): a map saved in
		// Forge or downloaded meanwhile showed only after a restart (2026-10-20 player batch, report 13). New
		// files are added by path (`myfiles:` above).
		refreshFiles() { post("myfiles?"); },
		// The lobby's game type's teams for the party (social.js teamRules): {mask, changing}, mask 0 when
		// it isn't a team game. Infection picks its own teams (zombies and survivors), so it has none here.
		teamRules(lobby) {
			const was = ctx;
			ctx = ctxs.find(c => c.lobby === lobby) || ctx;
			try {
				const cur = current();
				const d = dataOf(cur.base);
				const base = (d && d.base) || {};
				const own = (cur.own && cur.own.settings) || {};
				const teams = "teams" in own ? own.teams : base.teams;
				if (!teams || /infection/i.test(String(cur.base)) || /infection/i.test(String(cur.title))) return { mask: 0, changing: 0 };
				// (an older data file without these: Red and Blue, Team Changing allowed)
				const changing = "team_changing" in own ? own.team_changing : "team_changing" in base ? base.team_changing : 1;
				return { mask: typeof base.team_mask === "number" && base.team_mask ? base.team_mask : 3, changing };
			} catch (e) { return { mask: 0, changing: 0 }; } finally { ctx = was; }
		},
		// Before Start Game: the rotation for a hosted game or dedicated server (gamesetup.rs). Only a lobby with a
		// Rotation row plays one: a Forge session hosted online played Custom Games' playlist instead of the Forge map.
		beforeStart(network, lobby) {
			const p = playlists.find(x => x.name === rotationName());
			const on = p && (!lobby || lobby.items.some(i => i.setup === "rotation")) && (network === "Host Online" || network === "Host Public" || network === "Dedicated Server");
			post("rotation:" + (on ? p.games.map(([m, g]) => m + ":" + g).join(",") : ""));
			return on ? p : null;
		},
	};
})();
