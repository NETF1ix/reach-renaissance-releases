// Commendations, daily and weekly Challenges and the Service Record (owner's ask, 2026-10-14: Reach's
// own systems, tracked in our menus, plus new challenges of our own).
//
// On the 360 these lived on Bungie's servers. Here they are kept in the overlay's local storage
// (rr.career) and fed by every finished game's results (host-probe results.rs, `results:` from the
// overlay program, through postgame.js). What each game gives (research/experiments/EXP-050):
//   stat 0.8 kills, 0.9 assists, 0.10 deaths, 1.13 most kills in a row (bot fights, n4mem/n8base runs)
//   2.<n>  medal n of globals\medals.game_medal_globals (85 headshot, 11-18 sprees, 2-10 multikills...)
//   5.<e*256+t> event e (0 kill, 1 death, 4 headshot kill) with damage reporting type t (4 magnum,
//          5 assault rifle, 6 DMR... the weapons' own `damage effect reporting type`)
// Campaign and Firefight (EXP-051): Reach's writers record nothing there, so host-probe counts the
// player's kills itself (who hit each dead enemy last, with which weapon) into the same 0.8 and 5.<t>,
// adds sprees and multikills as the same medals, and `enemies` by kind (grunt, elite, jackal...) from
// the map file's tag names. Not in them yet: headshots there, enemy vehicles destroyed, rounds survived.
//
// Names, counts and credits of the 45 commendations are Reach's (Halopedia's list); challenge names are
// Reach's own (Mod Tools: ui\cui\strings\start_menu_challenges_strings), their counts and credits ours
// (the 360 got them from the servers). Challenges marked NEW are this project's. Pictures come from the
// Mod Tools (scripts/menu/extract_career.py, career/*.png); without them plain shapes stand in.
"use strict";

const Career = (() => {
	const STORE = "rr.career";
	const CREDITS = "rr.credits";

	// ---------- what a finished game gave ----------

	// Damage reporting types (the weapons' `damage effect reporting type`, HREK).
	const W = { magnum: 4, ar: 5, dmr: 6, shotgun: 7, sniper: 8, rocket: 9, laser: 10, frag: 11, gl: 12, pp: 13, needler: 14,
		plasmaRifle: 15, repeater: 16, needleRifle: 17, spiker: 18, plasmaLauncher: 19, hammer: 20, sword: 21, plasmaNade: 22,
		concussion: 23, melee: 43, airstrike: 53, focus: 63, fuelRod: 64 };
	const GROUPS = {
		precision: [W.dmr, W.sniper, W.needleRifle, W.focus],
		automatic: [W.ar, W.needler, W.plasmaRifle, W.repeater, W.spiker],
		pistol: [W.magnum, W.pp],
		heavy: [W.rocket, W.laser, W.gl, W.plasmaLauncher, W.concussion, W.fuelRod, W.airstrike],
		grenade: [W.frag, W.plasmaNade],
		cqc: [W.shotgun, W.hammer, W.sword, W.melee],
		// vehicles: drivers, gunners and turrets (24-40), mounted turrets (54-58)
		vehicle: [...Array(17).keys()].map(i => 24 + i).concat([54, 55, 56, 57, 58]),
	};
	// Medal indices (globals\medals.game_medal_globals, in its order).
	const M = { extermination: 0, perfection: 1, double: 2, triple: 3, spree: 11, frenzy: 12, riot: 13, hijack: 64, skyjack: 65,
		fromGrave: 66, killjoy: 67, stick: 69, assassin: 71, wheelman: 74, headshot: 85, supercombine: 86, emp: 87, assist: 89,
		revenge: 91, firstStrike: 92, pull: 96, showstopper: 97, yoink: 99, avenger: 101, firebird: 103, assassination: 104, bulltrue: 62 };
	const JACK = [M.hijack, M.skyjack, M.revenge, M.avenger, M.yoink, M.emp, M.assist, M.firstStrike, M.extermination, M.killjoy,
		M.fromGrave, M.firebird, M.pull, M.showstopper, M.bulltrue];

	// Reach's enemy classes by kind (Halopedia's commendation notes: infantry the Grunts, leaders the
	// Elites, specialists Jackals, Skirmishers, Brutes, Hunters and the rest).
	const foes = (p, kinds) => kinds.reduce((a, k) => a + (+((p.enemies || {})[k]) || 0), 0);
	// One finished game for the local player: p is their results row, ctx what the menus started.
	function matchOf(p, ctx) {
		const s = p.stats || {};
		const n = (k) => +s[k] || 0;
		const medal = (i) => n("2." + i);
		const kills = (t) => n("5." + t);
		const group = (g) => GROUPS[g].reduce((a, t) => a + kills(t), 0);
		const range = (a, b) => { let t = 0; for (let i = a; i <= b; i++) t += medal(i); return t; };
		const weapons = Object.keys(s).filter(k => k.startsWith("5.") && +k.slice(2) < 256 && n(k) > 0).map(k => +k.slice(2));
		return {
			kind: ctx.kind, map: ctx.map || "", mode: ctx.mode || "", difficulty: ctx.difficulty ?? -1, minutes: ctx.minutes || 0,
			players: ctx.players || 1, won: !!ctx.won, place: ctx.place || 0, teamGame: !!ctx.teamGame, hosted: !!ctx.hosted, mod: !!ctx.mod,
			kills: Math.round(p.kills || n("0.8")), deaths: Math.round(p.deaths || n("0.10")), assists: n("0.9"), score: p.score || 0,
			bestStreak: n("1.13"), headshots: medal(M.headshot), sprees: range(11, 18), multikills: range(2, 10),
			doubles: medal(M.double), triples: medal(M.triple), killingSprees: medal(M.spree), frenzies: medal(M.frenzy), riots: medal(M.riot),
			assassinations: medal(M.assassination) + medal(M.assassin), sticks: medal(M.stick), revenge: medal(M.revenge),
			avenger: medal(M.avenger), firstStrike: medal(M.firstStrike), firebird: medal(M.firebird), supercombine: medal(M.supercombine),
			wheelman: medal(M.wheelman), jack: JACK.reduce((a, i) => a + medal(i), 0),
			precision: group("precision"), automatic: group("automatic"), pistol: group("pistol"), heavy: group("heavy"),
			grenade: group("grenade"), cqc: group("cqc"), vehicle: group("vehicle"), weapons,
			w: (t) => kills(t), hsw: (t) => n("5." + (1024 + t)),
			// Campaign and Firefight: kills by enemy kind (results.rs enemy_kind), and allies killed
			enemy: (k) => +((p.enemies || {})[k]) || 0, betrayals: +p.betrayals || 0,
			infantry: foes(p, ["grunt"]), leaders: foes(p, ["elite"]), specialists: foes(p, ["jackal", "skirmisher", "brute", "hunter", "bugger", "engineer"]),
		};
	}

	// ---------- commendations ----------

	const MODE_NAMES = { camp: "Campaign", ff: "Firefight", mp: "Multiplayer" };
	const LEVELS = ["Not Yet Awarded", "Iron", "Bronze", "Silver", "Gold", "Onyx", "Max"];
	const METALS = ["clear", "steel", "bronze", "silver", "gold", "onyx", "onyx"];
	// [mode, name, description, icon (1-20 of Reach's sheet), counter, [Iron, Bronze, Silver, Gold, Onyx, Max], [cR per level]]
	// counter: a key of the game record, a function, or null (not in the results yet).
	const notEasy = (m) => m.difficulty !== 0;
	const C = (mode, name, text, icon, count, at, cr) => ({ id: mode + ":" + name, mode, name, text, icon, count, at, cr });
	const COMMENDATIONS = [
		C("camp", "Cannon Fodder", "Kill an infantry-class enemy in Campaign.", 18, "infantry", [250, 750, 3000, 7000, 12000, 20000], [200, 600, 1200, 2400, 2400]),
		C("camp", "Demon", "Complete a Campaign mission (not Noble Actual or Lone Wolf).", 15, (m) => /Noble Actual|Lone Wolf/.test(m.map) ? 0 : 1, [9, 18, 81, 135, 270, 540], [400, 400, 400, 400, 400]),
		C("camp", "Flawless Cowboy", "Complete a Campaign mission on Heroic or Legendary without dying.", 16, (m) => m.difficulty >= 2 && m.deaths === 0 && !/Noble Actual|Lone Wolf/.test(m.map) ? 1 : 0, [5, 10, 25, 50, 150, 300], [450, 450, 900, 1500, 2000]),
		C("camp", "Leadership Element", "Kill a leader-class enemy in Campaign.", 17, "leaders", [100, 375, 750, 3000, 6000, 10000], [400, 750, 1250, 2500, 2500]),
		C("camp", "Nice Arm", "Kill an enemy with a Frag or Plasma Grenade in Campaign.", 11, "grenade", [50, 250, 500, 4000, 8000, 13000], [200, 750, 1000, 2000, 2000]),
		C("camp", "Pinpoint", "Kill an enemy with a headshot in Campaign.", 1, "headshots", [50, 250, 500, 4000, 8000, 20000], [100, 750, 1000, 2000, 2000]),
		C("camp", "Precisely", "Kill an enemy with a precision weapon in Campaign (DMR, Needle Rifle, Focus Rifle, Sniper Rifle).", 12, "precision", [250, 750, 4000, 10000, 20000, 32000], [500, 750, 1000, 3000, 3000]),
		C("camp", "Right of Way", "Destroy an enemy vehicle in Campaign.", 20, null, [50, 200, 1000, 2400, 4800, 7200], [250, 400, 800, 1600, 1600]),
		C("camp", "Small Arms", "Kill an enemy with a pistol in Campaign (Magnum, Plasma Pistol).", 7, "pistol", [250, 750, 3000, 6000, 10000, 16000], [250, 375, 750, 1250, 1250]),
		C("camp", "SpecOps", "Kill a specialist-class enemy in Campaign.", 19, "specialists", [175, 525, 2100, 6000, 10000, 14000], [200, 600, 1200, 2400, 2400]),
		C("camp", "Splash Damage", "Kill an enemy with a heavy weapon in Campaign.", 9, "heavy", [100, 375, 750, 1500, 3000, 6000], [200, 750, 1500, 2000, 2000]),
		C("camp", "Standard Issue", "Kill an enemy with an automatic weapon in Campaign.", 6, "automatic", [250, 750, 3000, 6000, 10000, 15000], [500, 750, 1000, 3000, 3000]),
		C("camp", "Super Soldier", "Earn a spree of any type in Campaign.", 3, "sprees", [25, 175, 500, 2000, 5000, 9000], [200, 700, 1500, 2000, 2000]),
		C("camp", "Support Role", "Earn an assist in Campaign.", 4, "assists", [100, 375, 750, 1500, 3000, 6000], [200, 500, 1000, 1500, 1500]),
		C("camp", "Walking Tank", "Earn a multikill in Campaign.", 2, "multikills", [25, 175, 500, 2000, 5000, 9000], [200, 700, 1500, 2000, 2000]),
		C("camp", "War Machine", "Kill an enemy with a vehicle in Campaign.", 10, "vehicle", [200, 500, 800, 3200, 6400, 14000], [250, 700, 1400, 2000, 2000]),
		C("ff", "Backup", "Earn an assist in Firefight.", 4, "assists", [50, 250, 750, 1500, 3000, 8000], [300, 750, 1500, 2400, 2400]),
		C("ff", "Dome Inspector", "Kill an enemy with a headshot in Firefight.", 1, "headshots", [50, 250, 500, 4000, 8000, 20000], [150, 425, 1000, 2400, 2400]),
		C("ff", "Get Loud", "Kill an enemy with a heavy weapon in Firefight.", 9, "heavy", [100, 375, 750, 2000, 4000, 8000], [200, 750, 1500, 2000, 2000]),
		C("ff", "Grounded", "Destroy an enemy vehicle in Firefight.", 20, null, [50, 200, 400, 2500, 6000, 12000], [250, 400, 800, 1600, 1600]),
		C("ff", "In Command", "Kill a leader-class enemy in Firefight.", 17, "leaders", [75, 375, 750, 3000, 6000, 10000], [250, 400, 800, 1600, 1600]),
		C("ff", "Longshot", "Kill an enemy with a precision weapon in Firefight.", 12, "precision", [250, 750, 4000, 10000, 20000, 32000], [500, 750, 1000, 3000, 3000]),
		C("ff", "Methodical", "Earn a spree of any type in Firefight.", 3, "sprees", [25, 175, 500, 2500, 5000, 10000], [200, 700, 1500, 2000, 2000]),
		C("ff", "Numbers Game", "Earn a multikill in Firefight.", 2, "multikills", [25, 175, 500, 2500, 5000, 15000], [200, 700, 1500, 2000, 2000]),
		C("ff", "Perfectionist", "Complete a Firefight round without dying.", 16, null, [50, 250, 500, 2000, 5000, 8000], [250, 1250, 2000, 2000, 2000]),
		C("ff", "Pull the Pin", "Kill an enemy with a grenade in Firefight.", 11, "grenade", [50, 250, 500, 3000, 5000, 9000], [200, 750, 1000, 2000, 2000]),
		C("ff", "Riflin' Through", "Kill an enemy with an automatic weapon in Firefight.", 6, "automatic", [250, 750, 3000, 10000, 20000, 32000], [500, 750, 1000, 2000, 2000]),
		C("ff", "Specialized", "Kill a specialist-class enemy in Firefight.", 19, "specialists", [175, 525, 2000, 6000, 10000, 14000], [200, 600, 1200, 2400, 2400]),
		C("ff", "Target Practice", "Kill an infantry-class enemy in Firefight.", 18, "infantry", [250, 750, 3000, 7000, 12000, 20000], [200, 600, 2000, 2400, 2400]),
		C("ff", "Trigger Happy", "Kill an enemy with a pistol in Firefight.", 7, "pistol", [250, 750, 3000, 6000, 10000, 16000], [500, 750, 1500, 2000, 2000]),
		C("ff", "Vehicular", "Kill an enemy with a vehicle or turret in Firefight.", 10, "vehicle", [200, 500, 800, 3200, 6400, 14000], [250, 700, 1400, 2000, 2000]),
		C("mp", "Any Spree", "Earn a spree of any type in multiplayer.", 3, "sprees", [5, 50, 250, 1000, 4000, 10000], [250, 425, 1200, 2400, 2400]),
		C("mp", "Assistant", "Earn an assist in multiplayer.", 4, "assists", [50, 250, 1000, 4000, 8000, 20000], [150, 425, 1200, 2400, 2400]),
		C("mp", "Close Quarters", "Kill an enemy at close quarters in multiplayer (Gravity Hammer, Energy Sword, Shotgun, melee).", 8, "cqc", [50, 125, 400, 1600, 4000, 8000], [150, 375, 1200, 2400, 2400]),
		C("mp", "Crack Shot", "Kill an enemy with a precision weapon in multiplayer.", 12, "precision", [100, 500, 4000, 10000, 20000, 32000], [300, 1000, 2000, 3000, 3000]),
		C("mp", "Downshift", "Drive while your gunner kills an enemy in multiplayer.", 5, "wheelman", [5, 50, 750, 4000, 8000, 20000], [100, 250, 875, 1200, 1200]),
		C("mp", "Grenadier", "Kill an enemy with a Frag or Plasma Grenade in multiplayer.", 11, "grenade", [25, 125, 500, 4000, 8000, 14000], [100, 200, 500, 750, 750]),
		// (Halopedia has no credits for Heavy Weapon; these are Grenadier's.)
		C("mp", "Heavy Weapon", "Kill an enemy with a heavy weapon in multiplayer.", 9, "heavy", [25, 150, 750, 3000, 7000, 14000], [100, 200, 500, 750, 750]),
		C("mp", "Jack of All Trades", "Perform an incredible feat in multiplayer (Hijack, Revenge, Avenger, Assist, Killjoy, Firebird and others).", 14, "jack", [50, 125, 400, 1600, 4800, 9600], [150, 375, 1000, 1600, 1600]),
		C("mp", "Mobile Asset", "Kill an enemy with a vehicle in multiplayer.", 10, "vehicle", [25, 125, 500, 4000, 8000, 14000], [100, 200, 500, 750, 750]),
		C("mp", "Multikill", "Earn a multikill in multiplayer.", 2, "multikills", [10, 125, 500, 2500, 5000, 15000], [250, 450, 875, 1400, 1400]),
		C("mp", "One Shot", "Kill an enemy with a headshot in multiplayer.", 1, "headshots", [50, 250, 1000, 4000, 8000, 20000], [150, 425, 1200, 2400, 2400]),
		C("mp", "Rear Admiral", "Kill an enemy with an assassination in multiplayer.", 13, "assassinations", [5, 25, 100, 1000, 4000, 8000], [300, 500, 750, 1000, 1000]),
		C("mp", "Sidearm", "Kill an enemy with a pistol in multiplayer (Magnum, Plasma Pistol).", 7, "pistol", [50, 250, 1000, 4000, 8000, 10000], [100, 200, 500, 750, 750]),
		C("mp", "Trigger Man", "Kill an enemy with an automatic weapon in multiplayer.", 6, "automatic", [100, 500, 4000, 10000, 20000, 32000], [300, 1000, 2000, 3000, 3000]),
	];
	const levelOf = (c, n) => c.at.filter(a => n >= a).length; // 0 not awarded ... 6 max
	const tracked = (c) => c.count !== null;
	// How much a game moves a commendation (Easy never counts in Campaign and Firefight, as in Reach).
	function stepOf(c, m) {
		if (c.mode !== m.kind || !tracked(c) || (c.mode !== "mp" && !notEasy(m))) return 0;
		return Math.max(0, Math.round(typeof c.count === "function" ? c.count(m) : m[c.count] || 0));
	}

	// ---------- challenges ----------

	// [id, name, mode, scope, goal, cR, test, text, extra]
	//   mode: camp | ff | mp | any (which games count); scope: game (in one game) or day / week (added up)
	//   test(m) -> this game's amount; text: the description with # for the goal
	const FF_MAP_KILLS = [["overlook", "Overlook", "Overlook's Overwatch", "Heroic Overwatch", "Legendary Overwatch"],
		["courtyard", "Courtyard", "Fortified Court", "Heroic Court", "Legendary Court"],
		["corvette", "Corvette", "Unto the Breach", "A Heroic Breach", "Breach of Legends"],
		["holdout", "Holdout", "Just Holdout", "Heroic Holdout", "Legendary Holdout"],
		["icecave", "Glacier", "Grunt Spelunking", "Heroic Spelunking", "Legendary Spelunking"],
		["park", "Beachhead", "A Walk in the...", "...And Recreation", "Hard Parking"],
		["ruins", "Outpost", "More Like In Post", "Going Outpost-al", "For the Ruiner"],
		["waterfront", "Waterfront", "Take a Dip", "Watersports", "What? No Boat?"]];
	const MISSION_DEATHLESS = [["m10", "Winter Contingency", "It was the Winter..."], ["m20", "ONI: Sword Base", "Office of Not Dying"],
		["m30", "Nightfall", "Mostly at Night"], ["m35", "Tip of the Spear", "Deathless Spear"], ["m45", "Long Night of Solace", "Lost Tyree, Lost Hutch"],
		["m50", "Exodus", "Deathless Exodus"], ["m52", "New Alexandria", "Deathless Alexandria"], ["m60", "The Package", "Deathless Package"],
		["m70", "The Pillar of Autumn", "Deathless Pillar"]];
	const D = (id, name, mode, scope, goal, cr, test, text, extra = {}) => ({ id, name, mode, scope, goal, cr, test, text, ...extra });
	const DAILY = [
		// Anywhere
		D("any_25_kill", "Light Fare", "any", "day", 25, 500, m => m.kills, "Kill # enemies in any game today."),
		D("any_50_kill", "Blastin' and Relaxin'", "any", "day", 50, 900, m => m.kills, "Kill # enemies in any game today."),
		D("any_100_kill", "Shootin' and Lootin'", "any", "day", 100, 1500, m => m.kills, "Kill # enemies in any game today."),
		// Multiplayer, added up over the day
		D("mp_25_kill", "More than a Handful", "mp", "day", 25, 500, m => m.kills, "Kill # enemies in multiplayer today."),
		D("mp_50_kill", "Fire When Ready", "mp", "day", 50, 1000, m => m.kills, "Kill # enemies in multiplayer today."),
		D("mp_100_kill", "Gunslinger", "mp", "day", 100, 2000, m => m.kills, "Kill # enemies in multiplayer today."),
		D("mp_10_assists", "Helping Hand", "mp", "day", 10, 500, m => m.assists, "Earn # assists in multiplayer today."),
		D("mp_20_assists", "Pass the Rock", "mp", "day", 20, 900, m => m.assists, "Earn # assists in multiplayer today."),
		D("mp_30_assists", "A Great Friend", "mp", "day", 30, 1200, m => m.assists, "Earn # assists in multiplayer today."),
		D("mp_50_assists", "Secondary Fire", "mp", "day", 50, 2000, m => m.assists, "Earn # assists in multiplayer today."),
		D("play_3_mm_games", "Participation Counts", "mp", "day", 3, 500, () => 1, "Complete # multiplayer games today."),
		D("play_5_mm_games", "Credits for Completion", "mp", "day", 5, 800, () => 1, "Complete # multiplayer games today."),
		D("play_7_mm_games", "The Magic Number", "mp", "day", 7, 1100, () => 1, "Complete # multiplayer games today."),
		D("play_10_mm_games", "Put Your Quarter Up", "mp", "day", 10, 1500, () => 1, "Complete # multiplayer games today."),
		D("win_3_mm_games", "Un, Deux, Trois", "mp", "day", 3, 900, m => m.won ? 1 : 0, "Win # multiplayer games today."),
		D("win_5_mm_games", "Five-time Champ", "mp", "day", 5, 1400, m => m.won ? 1 : 0, "Win # multiplayer games today."),
		D("win_7_mm_games", "Home Field Advantage", "mp", "day", 7, 2000, m => m.won ? 1 : 0, "Win # multiplayer games today."),
		D("mp_multi_spree", "Streaky Shooter", "mp", "day", 10, 1200, m => m.sprees, "Earn # sprees in multiplayer today."),
		D("mp_multi_multikill", "Oops! All Kills", "mp", "day", 10, 1200, m => m.multikills, "Earn # multikills in multiplayer today."),
		D("mp_multi_precision", "This is My Rifle...", "mp", "day", 50, 1200, m => m.precision, "Earn # kills with precision weapons in multiplayer today."),
		D("mp_multi_auto", "Now I have a Machine Gun", "mp", "day", 50, 1200, m => m.automatic, "Earn # kills with automatic weapons in multiplayer today."),
		D("mp_multi_small_arms", "Single Wield", "mp", "day", 30, 1000, m => m.pistol, "Earn # kills with pistols in multiplayer today."),
		D("mp_multi_cqc", "Close Talking", "mp", "day", 25, 1000, m => m.cqc, "Earn # close quarters kills in multiplayer today."),
		D("mp_firebird_chall", "Cook 'em, Clean 'em!", "mp", "day", 5, 900, m => m.firebird, "Kill # enemies in multiplayer while jet-packing."),
		D("mp_avenger_chall", "Chaddlesby's Justice", "mp", "day", 5, 900, m => m.avenger, "Avenge your teammates' deaths # times in multiplayer."),
		// Multiplayer, in one game
		D("double_double_chall", "Double Double", "mp", "game", 2, 700, m => m.doubles, "Earn # Double Kills in one multiplayer game."),
		D("triple_double_chall", "... Got a Triple Double", "mp", "game", 3, 1000, m => m.doubles, "Earn # Double Kills in one multiplayer game."),
		D("quadruple_double_chall", "The Dream Shake", "mp", "game", 4, 1400, m => m.doubles, "Earn # Double Kills in one multiplayer game."),
		D("triple_kill_chall", "Three Dog Fight", "mp", "game", 1, 900, m => m.triples, "Earn a Triple Kill in a multiplayer game."),
		D("double_triple_chall", "Twin Trips", "mp", "game", 2, 1800, m => m.triples, "Earn # Triple Kills in one multiplayer game."),
		D("mp_kill_spree_chall", "Killing Spree", "mp", "game", 1, 600, m => m.killingSprees, "Earn a Killing Spree in a multiplayer game."),
		D("mp_kill_spree_2x_chall", "Double Nickels", "mp", "game", 2, 1200, m => m.killingSprees, "Earn # Killing Sprees in one multiplayer game."),
		D("mp_any_spree_3x_chall", "Triple Thrill", "mp", "game", 3, 1500, m => m.sprees, "Earn # sprees of any kind in one multiplayer game."),
		D("mp_frenzy_chall", "Killing Frenzy", "mp", "game", 1, 1500, m => m.frenzies, "Earn a Killing Frenzy in a multiplayer game."),
		D("mp_riot_chall", "Make a Wish...", "mp", "game", 1, 2500, m => m.riots, "Earn a Running Riot in a multiplayer game."),
		D("mp_3_multikill_chall", "Multiplier", "mp", "game", 3, 1000, m => m.multikills, "Earn # multikills in one multiplayer game."),
		D("mp_4_multikill_chall", "Fourth Horseman", "mp", "game", 4, 1400, m => m.multikills, "Earn # multikills in one multiplayer game."),
		D("mp_headshot_3_chall", "Above the Neckline", "mp", "game", 3, 600, m => m.headshots, "Kill # enemies with headshots in one multiplayer game."),
		D("mp_headshot_5_chall", "Headshot Honcho", "mp", "game", 5, 900, m => m.headshots, "Kill # enemies with headshots in one multiplayer game."),
		D("mp_headshot_10_chall", "Neuroscience", "mp", "game", 10, 1600, m => m.headshots, "Kill # enemies with headshots in one multiplayer game."),
		D("mp_finish_move_chall", "Sweep the Leg", "mp", "game", 1, 700, m => m.assassinations, "Perform an Assassination in a multiplayer game."),
		D("mp_finish_move_2_chall", "Came From Behind", "mp", "game", 2, 1100, m => m.assassinations, "Perform # Assassinations in one multiplayer game."),
		D("mp_assist_5_chall", "Showtime", "mp", "game", 5, 700, m => m.assists, "Earn # assists in one multiplayer game."),
		D("mp_assist_10_chall", "No 'I' in Team", "mp", "game", 10, 1300, m => m.assists, "Earn # assists in one multiplayer game."),
		D("mp_cqc_5_chall", "Up Close and Personal", "mp", "game", 5, 800, m => m.cqc, "Kill # enemies at close quarters in one multiplayer game."),
		D("mp_cqc_7_chall", "T-Hug It Out", "mp", "game", 7, 1100, m => m.cqc, "Kill # enemies at close quarters in one multiplayer game."),
		D("mp_sticky_2_chall", "I'm Rubber, You're Glue", "mp", "game", 2, 800, m => m.sticks, "Earn # sticky grenade kills in one multiplayer game."),
		D("mp_sticky_4_chall", "Sticky Icky Icky", "mp", "game", 4, 1400, m => m.sticks, "Earn # sticky grenade kills in one multiplayer game."),
		D("mp_grenade_4_chall", "Light Fuse, Run Away", "mp", "game", 4, 900, m => m.grenade, "Kill # enemies with grenades in one multiplayer game."),
		D("mp_grenade_8_chall", "Throwing Fireballs", "mp", "game", 8, 1600, m => m.grenade, "Kill # enemies with grenades in one multiplayer game."),
		D("mp_precision_5_chall", "Not as Clumsy or Random...", "mp", "game", 5, 600, m => m.precision, "Earn # kills with precision weapons in one multiplayer game."),
		D("mp_precision_10_chall", "You Want This, Don't You?", "mp", "game", 10, 1100, m => m.precision, "Earn # kills with precision weapons in one multiplayer game."),
		D("mp_ordnance_5_chall", "Explosive Ordnance Distribution", "mp", "game", 5, 1000, m => m.heavy, "Earn # kills with heavy weapons in one multiplayer game."),
		D("mp_kill_9_chall", "Better, Closer, Warmer", "mp", "game", 9, 500, m => m.kills, "Earn at least # kills in one multiplayer game."),
		D("mp_kill_15_chall", "A Solid Outing", "mp", "game", 15, 900, m => m.kills, "Earn at least # kills in one multiplayer game."),
		D("mp_kill_17_chall", "Aggressive Negotiations", "mp", "game", 17, 1100, m => m.kills, "Earn at least # kills in one multiplayer game."),
		D("mp_kill_20_chall", "Freelancing", "mp", "game", 20, 1400, m => m.kills, "Earn at least # kills in one multiplayer game."),
		D("mp_first_strike_chall", "Go Right Ahead Folks", "mp", "game", 1, 500, m => m.firstStrike, "Earn a First Strike in a multiplayer game."),
		D("mp_revenge_chall", "Vengeance Found", "mp", "game", 1, 500, m => m.revenge, "Earn your Revenge in a multiplayer game."),
		// Firefight
		D("ff_50_kill", "Where There's Smoke...", "ff", "day", 50, 700, m => m.kills, "Kill # enemies in Firefight today."),
		D("ff_75_kill", "Covenant-cide", "ff", "day", 75, 1000, m => m.kills, "Kill # enemies in Firefight today."),
		D("ff_100_kill", "One Spartan Army", "ff", "day", 100, 1400, m => m.kills, "Kill # enemies in Firefight today."),
		D("ff_20_assists", "Supporting Role", "ff", "day", 20, 700, m => m.assists, "Earn # assists in Firefight today."),
		D("ff_30_assists", "Support Structure", "ff", "day", 30, 1000, m => m.assists, "Earn # assists in Firefight today."),
		D("ff_50_assists", "A Friend in Need", "ff", "day", 50, 1500, m => m.assists, "Earn # assists in Firefight today."),
		D("ff_kill_spree_5_chall", "Survivor", "ff", "game", 5, 1000, m => m.sprees, "Earn # sprees in one Firefight game."),
		D("ff_h_kill_spree_10_chall", "Weapon Swap", "ff", "game", 10, 2000, m => m.difficulty >= 2 ? m.sprees : 0, "Earn # sprees in one Firefight game on Heroic or harder."),
		D("ff_multikill_7_chall", "Killagruntjaro!", "ff", "game", 7, 1200, m => m.multikills, "Earn # multikills in one Firefight game."),
		D("ff_h_multikill_7_chall", "Heroic Killagruntjaro!", "ff", "game", 7, 1800, m => m.difficulty >= 2 ? m.multikills : 0, "Earn # multikills in one Firefight game on Heroic or harder."),
		D("ff_grunt_kill_chall", "A Satisfied Thirst", "ff", "day", 100, 900, m => m.enemy("grunt"), "Kill # Grunts in Firefight today."),
		D("ff_elite_kill_chall", "Demon", "ff", "day", 30, 1000, m => m.enemy("elite"), "Kill # Elites in Firefight today."),
		D("ff_h_elite_kill_chall", "Heroic Demon", "ff", "day", 30, 1500, m => m.difficulty >= 2 ? m.enemy("elite") : 0, "Kill # Elites in Firefight today on Heroic or harder."),
		D("ff_headshot_kill_chall", "Hyper Lethal Vector", "ff", "day", 40, 1000, m => m.headshots, "Kill # enemies with headshots in Firefight today.", { off: true }),
		D("ff_launcher_kill_chall", "J.H. Death Machine", "ff", "day", 25, 1000, m => m.w(W.gl), "Kill # enemies with the Grenade Launcher in Firefight today."),
		D("ff_shotgun_kill_chall", "The T.G. Opposition", "ff", "day", 25, 1000, m => m.w(W.shotgun), "Kill # enemies with the Shotgun in Firefight today."),
		D("ff_precision_kill_chall", "Scoped", "ff", "day", 50, 1000, m => m.precision, "Kill # enemies with precision weapons in Firefight today."),
		D("ff_grenade_kill_chall", "Blast Radius", "ff", "day", 20, 900, m => m.grenade, "Kill # enemies with grenades in Firefight today."),
		D("ff_pistol_chall", "Be Their Huckleberry", "ff", "day", 30, 900, m => m.w(W.magnum), "Kill # enemies with the Magnum in Firefight today."),
		D("ff_supercombine_kill_chall", "That Pink Mist", "ff", "day", 15, 1000, m => m.supercombine, "Kill # enemies with a Needler or Needle Rifle supercombine in Firefight today."),
		D("ff_sword_kill_chall", "Katanarama", "ff", "day", 15, 1000, m => m.w(W.sword), "Kill # enemies with the Energy Sword in Firefight today."),
		D("ff_kill_spree_chall", "A Simple Spree", "ff", "game", 1, 500, m => m.sprees, "Earn any spree in Firefight."),
		D("ff_deathless_game_chall", "One Game, One Spawn", "ff", "game", 1, 1800, m => m.deaths === 0 ? 1 : 0, "Complete a Firefight game without dying."),
		D("ff_5_deaths_chall", "On the Sixth Respawn...", "ff", "game", 1, 900, m => m.deaths < 5 ? 1 : 0, "Complete a Firefight game with fewer than 5 deaths."),
		D("kill_attack_chall", "Kill (to Reach the End)", "ff", "game", 100, 1200, m => m.kills, "Kill # enemies in one Firefight game."),
		D("kill_h_attack_chall", "The House of Blue Leaves", "ff", "game", 100, 1800, m => m.difficulty >= 2 ? m.kills : 0, "Kill # enemies in one Firefight game on Heroic or harder."),
		D("ff_airstrike_chall", "Orbital Assets", "ff", "day", 10, 1000, m => m.w(W.airstrike), "Kill # enemies with the Target Locator in Firefight today."),
		...FF_MAP_KILLS.flatMap(([id, map, n0, n1, n2]) => [
			D(`ff_${id}_kill_chall`, n0, "ff", "day", 100, 800, m => m.map === map ? m.kills : 0, `Kill # enemies on ${map} in Firefight today.`),
			D(`ff_h_${id}_kill_chall`, n1, "ff", "day", 100, 1200, m => m.map === map && m.difficulty >= 2 ? m.kills : 0, `Kill # enemies on ${map} on Heroic or harder in Firefight today.`),
			D(`ff_l_${id}_kill_chall`, n2, "ff", "day", 100, 1800, m => m.map === map && m.difficulty >= 3 ? m.kills : 0, `Kill # enemies on ${map} on Legendary in Firefight today.`),
		]),
		// Campaign
		D("any_speed_chall", "...While She's Away", "camp", "game", 1, 1200, m => m.difficulty >= 1 && m.minutes <= 20 ? 1 : 0, "Complete any Campaign mission on Normal or harder in 20 minutes or less."),
		D("elite_kill_chall", "Return of the Mack", "camp", "day", 25, 1000, m => m.difficulty >= 1 ? m.enemy("elite") : 0, "Kill # Elites in Campaign today on Normal or harder."),
		D("grunt_kill_chall", "The Little Guys", "camp", "day", 50, 800, m => m.difficulty >= 1 ? m.enemy("grunt") : 0, "Kill # Grunts in Campaign today on Normal or harder."),
		D("camp_leader_chall", "Leadership Element", "camp", "day", 20, 1000, m => m.leaders, "Kill # enemy leaders in Campaign today."),
		D("camp_infantry_chall", "Cannon Fodder", "camp", "day", 75, 900, m => m.infantry, "Kill # infantry-class foes in Campaign today."),
		D("fauna_kill_chall", "Nature vs. Nurture", "camp", "day", 10, 700, m => m.map === "Winter Contingency" && m.difficulty >= 1 ? m.enemy("moa") : 0, "Kill # Moa in Winter Contingency on Normal or harder."),
		D("camp_precision_chall", "There Are Many Like It...", "camp", "day", 50, 900, m => m.difficulty >= 1 ? m.precision : 0, "Kill # enemies with precision weapons in Campaign today on Normal or harder."),
		D("camp_auto_chall", "Short, Controlled Bursts", "camp", "day", 75, 900, m => m.difficulty >= 1 ? m.automatic : 0, "Kill # enemies with automatic weapons in Campaign today on Normal or harder."),
		D("m30_sniper_med_chall", "A Side of Huevos", "camp", "day", 15, 1100, m => m.map === "Nightfall" && m.difficulty >= 1 ? m.hsw(W.sniper) : 0, "Kill # enemies with Sniper Rifle headshots in Nightfall on Normal or harder."),
		D("m20_airstrike_chall", "Eyes in the Sky", "camp", "day", 10, 1200, m => m.map === "ONI: Sword Base" && m.difficulty >= 2 ? m.w(W.airstrike) : 0, "Kill # enemies with the Target Locator in ONI: Sword Base on Heroic or harder."),
		D("m50_firebird_chall", "Roast 'em, Toast 'em", "camp", "day", 10, 1100, m => m.map === "Exodus" && m.difficulty >= 1 ? m.firebird : 0, "Kill # enemies while jet-packing in Exodus on Normal or harder."),
		...MISSION_DEATHLESS.map(([id, map, name]) => D(`${id}_l_deathless`, name, "camp", "game", 1, 3000,
			m => m.map === map && m.difficulty >= 3 && m.deaths === 0 ? 1 : 0, `Complete ${map} on Legendary without dying.`)),
		// NEW: this project's own (bigger lobbies, hosting, mods, more weapons)
		D("rr_full_house", "Full House", "any", "game", 1, 800, m => m.players >= 16 ? 1 : 0, "Finish a game with 16 or more players.", { fresh: true }),
		D("rr_past_sixteen", "Beyond Sixteen", "any", "game", 1, 1500, m => m.players > 16 ? 1 : 0, "Finish a game with more than 16 players, past the old limit.", { fresh: true }),
		D("rr_top_board", "Top of the Board", "mp", "game", 1, 1000, m => !m.teamGame && m.place === 1 ? 1 : 0, "Finish first in a free-for-all multiplayer game.", { fresh: true }),
		D("rr_clean_sweep", "Clean Sweep", "mp", "game", 1, 1600, m => m.won && m.deaths === 0 && m.kills > 0 ? 1 : 0, "Win a multiplayer game without dying.", { fresh: true }),
		D("rr_positive", "Positive Thinking", "mp", "day", 3, 1000, m => m.kills > m.deaths ? 1 : 0, "Finish # multiplayer games today with more kills than deaths.", { fresh: true }),
		D("rr_host", "Hometown Hero", "mp", "game", 1, 800, m => m.hosted ? 1 : 0, "Host a game online from Custom Games and play it to the end.", { fresh: true }),
		D("rr_workshop", "Workshop Tour", "any", "game", 1, 800, m => m.mod ? 1 : 0, "Finish a game on a mod's map.", { fresh: true }),
		D("rr_pistol_whip", "Pistol Whip", "mp", "game", 10, 1200, m => m.w(W.magnum), "Kill # enemies with the Magnum in one multiplayer game.", { fresh: true }),
		D("rr_sword_saint", "Sword Saint", "any", "day", 10, 1000, m => m.w(W.sword), "Kill # enemies with the Energy Sword today.", { fresh: true }),
		D("rr_hammer_time", "Hammer Time", "any", "day", 10, 1000, m => m.w(W.hammer), "Kill # enemies with the Gravity Hammer today.", { fresh: true }),
		D("rr_rocket_science", "Rocket Science", "any", "day", 10, 1000, m => m.w(W.rocket), "Kill # enemies with the Rocket Launcher today.", { fresh: true }),
		D("rr_laser_show", "Laser Show", "any", "day", 5, 1000, m => m.w(W.laser), "Kill # enemies with the Spartan Laser or Target Locator today.", { fresh: true }),
		D("rr_road_rage", "Road Rage", "any", "day", 10, 1000, m => m.vehicle, "Kill # enemies with vehicles today.", { fresh: true }),
		D("rr_clean_hands", "Friendly Fire Free", "camp", "game", 1, 900, m => m.kills >= 20 && m.betrayals === 0 ? 1 : 0, "Complete a Campaign mission with 20 or more kills without killing an ally.", { fresh: true }),
		D("rr_variety", "Variety Pack", "mp", "day", 3, 900, null, "Finish multiplayer games of # different game types today.", { fresh: true, set: m => m.mode }),
	];
	const WEEKLY = [
		D("mp_spree_4x_chall_week", "Factors of Five", "mp", "game", 4, 8000, m => m.sprees, "Earn # spree medals in one multiplayer game."),
		D("30k_chall", "Like Mike", "mp", "game", 30, 9000, m => m.kills, "Finish a multiplayer game with at least # kills."),
		D("1500k_week_chall", "All in a Week's Work", "mp", "week", 500, 12000, m => m.kills, "Kill # enemies in multiplayer this week."),
		D("win_50_mm_games", "Clear Eyes, Full Hearts...", "mp", "week", 25, 12000, m => m.won ? 1 : 0, "Win # multiplayer games this week."),
		D("win_77_mm_games", "Play to Win", "mp", "week", 40, 16000, m => m.won ? 1 : 0, "Win # multiplayer games this week."),
		D("weekly_multikill_chall", "Multiplicative", "mp", "week", 50, 10000, m => m.multikills, "Earn # multikills in multiplayer this week."),
		D("weekly_revenge_chall", "Best Served Cold", "mp", "week", 25, 9000, m => m.revenge, "Take your Revenge on # enemies in multiplayer this week."),
		D("weekly_precision_chall", "Camp Froman, Indeed", "mp", "week", 250, 10000, m => m.precision, "Earn # kills with precision weapons in multiplayer this week."),
		D("play_x_mm_games", "That's Dedication, Holmes", "mp", "week", 40, 12000, () => 1, "Complete # multiplayer games this week."),
		D("complete_all_daily_chall", "Your Daily Dose", "any", "week", 1, 8000, null, "Complete all of the Daily Challenges for one day.", { dailies: "all" }),
		D("complete_x_daily_chall", "Dedication/Time", "any", "week", 15, 12000, null, "Complete # Daily Challenges this week.", { dailies: "count" }),
		D("m30_sniper_weekly", "Crackshot", "camp", "week", 40, 9000, m => m.map === "Nightfall" && m.difficulty >= 2 ? m.hsw(W.sniper) : 0, "Kill # enemies with Sniper Rifle headshots in Nightfall on Heroic or harder."),
		D("heroic_mission_weekly", "This is How We Do It", "camp", "week", 5, 10000, m => m.difficulty >= 2 ? 1 : 0, "Complete # Campaign missions on Heroic or harder this week."),
		D("firebird_weekly_chall", "A Whole New World", "camp", "week", 40, 9000, m => m.map === "Exodus" && m.difficulty >= 2 ? m.firebird : 0, "While jet-packing, kill # enemies in Exodus on Heroic or harder."),
		D("legend_speed_solo", "Fleet Feet", "camp", "game", 1, 12000, m => m.difficulty >= 3 && m.minutes <= 25 ? 1 : 0, "Complete any Campaign mission on Legendary in 25 minutes or less."),
		// NEW
		D("rr_world_tour", "World Tour", "any", "week", 8, 10000, null, "Finish games on # different maps this week.", { fresh: true, set: m => m.map }),
		D("rr_marathon", "Marathon", "any", "week", 180, 10000, m => m.minutes, "Spend # minutes in finished games this week.", { fresh: true }),
		D("rr_noble_team", "Noble Team", "camp", "week", 3, 9000, m => m.difficulty >= 2 ? 1 : 0, "Complete # Campaign missions on Heroic or harder this week.", { fresh: true }),
		D("rr_last_stand", "Last Stand", "ff", "game", 1, 12000, m => m.difficulty >= 3 ? 1 : 0, "Finish a Firefight game on Legendary.", { fresh: true }),
		D("rr_arsenal", "Spartan Arsenal", "any", "week", 10, 10000, null, "Kill enemies with # different weapons or vehicles this week.", { fresh: true, set: m => m.weapons }),
		D("rr_crowd_control", "Crowd Control", "any", "week", 5, 12000, m => m.players >= 24 ? 1 : 0, "Finish # games with 24 or more players this week.", { fresh: true }),
	];
	const ALL = [...DAILY.map(c => ({ ...c, weekly: false })), ...WEEKLY.map(c => ({ ...c, weekly: true }))];
	const byId = Object.fromEntries(ALL.map(c => [c.id, c]));
	const textOf = (c) => c.text.replace("#", c.goal.toLocaleString("en-US"));

	// Today's four (one Campaign, one Firefight, one multiplayer, one anywhere/NEW, as Reach mixed them)
	// and this week's one, the same for everyone on the same day: picked from the date.
	const pad = (n) => String(n).padStart(2, "0");
	const dayKey = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
	function weekStart(d) { const s = new Date(d.getFullYear(), d.getMonth(), d.getDate()); s.setDate(s.getDate() - (s.getDay() + 6) % 7); return s; }
	const weekKey = (d) => "w" + dayKey(weekStart(d));
	function rng(seed) {
		let h = 1779033703 ^ seed.length;
		for (let i = 0; i < seed.length; i++) { h = Math.imul(h ^ seed.charCodeAt(i), 3432918353); h = (h << 13) | (h >>> 19); }
		return () => { h = Math.imul(h ^ (h >>> 16), 2246822507); h = Math.imul(h ^ (h >>> 13), 3266489909); h ^= h >>> 16; return (h >>> 0) / 4294967296; };
	}
	function dailiesFor(key) {
		const r = rng("daily" + key);
		const pick = (list) => list[Math.floor(r() * list.length)];
		const fromMode = (mode) => pick(DAILY.filter(c => c.mode === mode && !c.fresh && !c.off));
		// the fourth: a NEW one every other day, else one that counts anywhere
		const fourth = r() < 0.5 ? pick(DAILY.filter(c => c.fresh)) : pick(DAILY.filter(c => c.mode === "any" && !c.fresh));
		const list = [fromMode("camp"), fromMode("ff"), fromMode("mp"), fourth];
		// (a second multiplayer one if two picks match)
		return [...new Set(list.map(c => c.id))].concat(DAILY.filter(c => c.mode === "mp" && !c.fresh).map(c => c.id)).filter((v, i, a) => a.indexOf(v) === i).slice(0, 4);
	}
	function weeklyFor(key) {
		const r = rng("weekly" + key);
		return WEEKLY[Math.floor(r() * WEEKLY.length)].id;
	}
	function msUntil(next) { return Math.max(0, next - Date.now()); }
	function resetsIn(weekly) {
		const now = new Date();
		const next = weekly ? (() => { const s = weekStart(now); s.setDate(s.getDate() + 7); return s; })() : new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
		const ms = msUntil(next), h = Math.floor(ms / 3600000), mins = Math.floor(ms / 60000) % 60;
		return h >= 24 ? `${Math.floor(h / 24)}d ${h % 24}h` : `${h}h ${mins}m`;
	}

	// ---------- the record ----------

	const blankMode = () => ({ games: 0, wins: 0, kills: 0, deaths: 0, assists: 0, minutes: 0, headshots: 0, bestStreak: 0, mostKills: 0, sprees: 0, multikills: 0 });
	function load() {
		let st = null;
		try { st = JSON.parse(localStorage.getItem(STORE) || "null"); } catch (e) { st = null; }
		if (!st || st.v !== 1) st = { v: 1, counts: {}, daily: null, weekly: null, done: { daily: 0, weekly: 0 }, modes: {}, missions: {}, since: Date.now() };
		for (const k of ["camp", "ff", "mp"]) st.modes[k] = { ...blankMode(), ...(st.modes[k] || {}) };
		return st;
	}
	function save(st) { try { localStorage.setItem(STORE, JSON.stringify(st)); } catch (e) { } }
	// The day's and week's challenges, new ones when the date has moved on.
	function rotate(st, now = new Date()) {
		const dk = dayKey(now), wk = weekKey(now);
		if (!st.daily || st.daily.key !== dk) st.daily = { key: dk, ids: dailiesFor(dk), progress: {}, sets: {}, done: {} };
		if (!st.weekly || st.weekly.key !== wk) st.weekly = { key: wk, ids: [weeklyFor(wk)], progress: {}, sets: {}, done: {}, dailies: 0, allDays: 0 };
		return st;
	}
	function advance(period, c, m) {
		if (period.done[c.id]) return null;
		if (c.dailies) return null; // counted from the dailies, below
		if (c.mode !== "any" && c.mode !== m.kind) return null;
		let value;
		if (c.set) {
			const seen = new Set(period.sets[c.id] || []);
			for (const v of [].concat(c.set(m))) if (v !== "" && v !== undefined && v !== null) seen.add(v);
			period.sets[c.id] = [...seen];
			value = seen.size;
		} else {
			const got = Math.max(0, c.test(m) || 0);
			value = c.scope === "game" ? Math.max(period.progress[c.id] || 0, got) : (period.progress[c.id] || 0) + got;
		}
		period.progress[c.id] = value;
		if (value >= c.goal) { period.done[c.id] = Date.now(); return c; }
		return null;
	}

	// A finished game: updates everything and returns the Credits Earned rows it adds (postgame.js).
	//   p: the player's results row, ctx: { kind, map, mode, difficulty, minutes, players, won, place, teamGame, hosted, mod }
	function record(p, ctx) {
		const st = rotate(load());
		const m = matchOf(p, ctx);
		const rows = [];
		if (!["camp", "ff", "mp"].includes(m.kind)) { save(st); return rows; }
		// Service record
		const rec = st.modes[m.kind];
		rec.games++; if (m.won) rec.wins++;
		rec.kills += m.kills; rec.deaths += m.deaths; rec.assists += m.assists; rec.minutes += m.minutes; rec.headshots += m.headshots;
		rec.sprees += m.sprees; rec.multikills += m.multikills;
		rec.bestStreak = Math.max(rec.bestStreak, m.bestStreak); rec.mostKills = Math.max(rec.mostKills, m.kills);
		if (m.kind === "camp" && m.map) {
			const ms = st.missions[m.map] || { best: -1, deathless: -1, fastest: 0 };
			ms.best = Math.max(ms.best, m.difficulty);
			if (m.deaths === 0) ms.deathless = Math.max(ms.deathless, m.difficulty);
			if (m.minutes > 0 && (!ms.fastest || m.minutes < ms.fastest)) ms.fastest = m.minutes;
			st.missions[m.map] = ms;
		}
		// Commendations: each level reached gives its credits (Max gives none, as in Reach).
		const ups = [];
		for (const c of COMMENDATIONS) {
			const step = stepOf(c, m);
			if (!step) continue;
			const before = st.counts[c.id] || 0, after = Math.min(before + step, c.at[5]);
			st.counts[c.id] = after;
			for (let lv = levelOf(c, before) + 1; lv <= levelOf(c, after); lv++) ups.push({ c, lv, cr: c.cr[lv - 1] || 0 });
		}
		if (ups.length) rows.push({ name: "Commendations", note: ups.map(u => u.c.name + ": " + LEVELS[u.lv]).join(", "),
			value: ups.reduce((a, u) => a + u.cr, 0), g: "graphic_commendation_wings", ups: ups.map(u => ({ id: u.c.id, level: u.lv })) });
		// Challenges
		const daily = [], weekly = [];
		for (const id of st.daily.ids) { const c = byId[id]; if (c) { const won = advance(st.daily, c, m); if (won) daily.push(won); } }
		st.done.daily += daily.length;
		st.weekly.dailies += daily.length;
		if (daily.length && st.daily.ids.every(id => st.daily.done[id])) st.weekly.allDays++;
		for (const id of st.weekly.ids) {
			const c = byId[id];
			if (!c || st.weekly.done[id]) continue;
			if (c.dailies) {
				const value = c.dailies === "all" ? st.weekly.allDays : st.weekly.dailies;
				st.weekly.progress[id] = value;
				if (value >= c.goal) { st.weekly.done[id] = Date.now(); weekly.push(c); }
			} else { const won = advance(st.weekly, c, m); if (won) weekly.push(won); }
		}
		st.done.weekly += weekly.length;
		if (daily.length) rows.push({ name: "Daily Challenges", note: daily.map(c => c.name).join(", "), value: daily.reduce((a, c) => a + c.cr, 0), g: "graphic_daily_challenges" });
		if (weekly.length) rows.push({ name: "Weekly Challenge", note: weekly.map(c => c.name).join(", "), value: weekly.reduce((a, c) => a + c.cr, 0), g: "graphic_daily_challenges" });
		save(st);
		return rows;
	}

	// For the player card: challenges done and the share of commendation levels reached.
	function summary() {
		const st = load();
		const levels = COMMENDATIONS.reduce((a, c) => a + levelOf(c, st.counts[c.id] || 0), 0);
		return { daily: st.done.daily, weekly: st.done.weekly, commendations: Math.floor(levels / (COMMENDATIONS.length * 6) * 100) };
	}

	// ---------- the screens ----------

	const esc = (s) => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
	const fmt = (n) => Math.round(n).toLocaleString("en-US");
	const play = (n) => { if (typeof Sound !== "undefined") Sound.play(n); };
	// Challenge category pictures (challenges_icon frames; which frame is which mode is our reading).
	const CAT = { mp: 0, any: 1, camp: 2, ff: 3, week: 4 };
	const css = `
	.cc { position: fixed; inset: 0; z-index: 1002; display: none; color: #f2f4f5; font-family: var(--font, sans-serif);
		background: linear-gradient(180deg, rgb(8,16,26), rgb(12,22,34)); } /* (opaque: the Start menu showed through; bug sweep) */
	.cc.open { display: block; }
	.cc .head { position: absolute; left: 6vw; top: 5vh; right: 6vw; display: flex; align-items: baseline; gap: 2vw; }
	.cc .head h1 { margin: 0; font-size: 5.4vh; font-weight: 700; text-transform: uppercase; letter-spacing: 0.02em; }
	.cc .head .sub { font-size: 2.3vh; color: #b9c2c8; text-transform: uppercase; }
	.cc .tabs { position: absolute; left: 6vw; top: 13vh; display: flex; gap: 0.4vw; font-size: 2.3vh; text-transform: uppercase; }
	.cc .tabs span { padding: 0.6vh 1.2vw; background: rgba(255,255,255,0.06); cursor: pointer; }
	.cc .tabs span.on { background: rgba(255,255,255,0.2); box-shadow: inset 0 -0.3vh 0 #8fc6f0; }
	.cc .tabs .lb, .cc .tabs .rb { background: none; color: #8a96a0; padding: 0.6vh 0.4vw; cursor: default; }
	.cc .list { position: absolute; left: 6vw; top: 19vh; width: 52vw; bottom: 11vh; overflow: hidden; }
	.cc .row { display: grid; grid-template-columns: 7vh 1fr auto; gap: 1vw; align-items: center; padding: 1vh 1vw; margin-bottom: 0.7vh;
		background: linear-gradient(90deg, rgba(255,255,255,0.08), rgba(255,255,255,0.02)); cursor: pointer; }
	.cc .row.sel { background: linear-gradient(90deg, rgba(143,198,240,0.32), rgba(143,198,240,0.08)); box-shadow: inset 0.3vw 0 0 #e9f5ff; }
	.cc .row .ic { width: 7vh; height: 7vh; background: center / contain no-repeat; opacity: 0.9; }
	.cc .row.done .ic { opacity: 0.45; }
	.cc .row .t { font-size: 2.6vh; font-weight: 700; text-transform: uppercase; }
	.cc .row .t i { font-style: normal; font-size: 1.6vh; color: #0b1520; background: #ffd36b; padding: 0.1vh 0.4vw; margin-left: 0.6vw; vertical-align: 0.3vh; }
	.cc .row .d { font-size: 1.9vh; color: #c5cdd2; margin-top: 0.2vh; }
	.cc .row .p { text-align: right; font-size: 2.2vh; font-variant-numeric: tabular-nums; }
	.cc .row .p b { display: block; color: #ffd36b; font-size: 2.4vh; }
	.cc .row.done .p { color: #9fd59f; }
	.cc .track { height: 0.8vh; margin-top: 0.6vh; background: rgba(255,255,255,0.12); }
	.cc .track i { display: block; height: 100%; background: linear-gradient(90deg, #8fc6f0, #e9f5ff); }
	.cc .row.done .track i { background: #9fd59f; }
	.cc .side { position: absolute; left: 62vw; right: 6vw; top: 19vh; }
	.cc .side h2 { margin: 1.5vh 0 0.6vh; font-size: 3.4vh; text-transform: uppercase; }
	.cc .side p { font-size: 2.2vh; line-height: 1.35; color: #d5dce0; margin: 0.6vh 0; }
	.cc .side .k { color: #8a96a0; text-transform: uppercase; font-size: 1.8vh; letter-spacing: 0.04em; }
	.cc .side .big { width: 100%; aspect-ratio: 352 / 112; position: relative; }
	.cc .side .note { color: #e2c35a; font-size: 1.9vh; }
	.cc .grid { position: absolute; left: 6vw; top: 19vh; width: 54vw; bottom: 11vh; display: grid; grid-template-columns: repeat(4, 1fr); grid-auto-rows: min-content; gap: 1.6vh 0.8vw; overflow: hidden; }
	.cc .cm { cursor: pointer; padding: 0.4vh; }
	.cc .cm.sel { background: rgba(255,255,255,0.16); box-shadow: inset 0 0 0 0.2vh #f2f4f5; }
	.cc .cm .n { font-size: 1.6vh; font-weight: 600; text-transform: uppercase; margin-top: 0.4vh; display: flex; justify-content: space-between; }
	.cc .cm .n span { color: #b9c2c8; font-weight: 500; }
	.cc .cm.off .n { color: #8a96a0; }
	.cc .plate { position: relative; width: 100%; aspect-ratio: 352 / 112; background: #2a3038 center / 100% 100% no-repeat; }
	.cc .plate .icon { position: absolute; left: 7%; top: 12%; height: 76%; aspect-ratio: 1; background: center / contain no-repeat; }
	.cc .plate .lv { position: absolute; right: 4%; bottom: 8%; font-size: 1.5vh; font-weight: 700; text-transform: uppercase; color: rgba(255,255,255,0.85); text-shadow: 0 0 0.4vh #000; }
	.cc .plate.bare { background: linear-gradient(90deg, var(--mc) 0 50%, #22272e 50%); }
	.cc .plate.bare .icon { border-radius: 50%; background: radial-gradient(circle, var(--metal) 0 55%, transparent 58%); }
	.cc .stats { position: absolute; left: 6vw; top: 19vh; right: 6vw; display: grid; grid-template-columns: repeat(3, 1fr); gap: 1.2vh 3vw; }
	.cc .stats div { display: flex; justify-content: space-between; border-bottom: 1px solid rgba(255,255,255,0.1); padding: 0.8vh 0; font-size: 2.3vh; }
	.cc .stats b { font-weight: 500; color: #b9c2c8; text-transform: uppercase; font-size: 2vh; }
	.cc .stats h3 { grid-column: 1 / -1; margin: 1.5vh 0 0; font-size: 2.6vh; text-transform: uppercase; color: #8fc6f0; }
	.cc .keys { position: absolute; left: 6vw; top: 91vh; display: flex; gap: 1.6vw; font-size: 2.7vh; }
	.cc .keys .hint { cursor: pointer; }
	`;
	let root = null, view = "challenges", tab = 0, sel = 0;
	const TABS = { challenges: ["Daily", "Weekly", "All Challenges"], commendations: ["Campaign", "Firefight", "Multiplayer"], record: ["Career", "Campaign", "Firefight", "Multiplayer"] };
	const MODE_OF_TAB = ["camp", "ff", "mp"];
	const MODE_COLOR = { camp: "#5f6b4a", ff: "#7a3232", mp: "#3d6a97" };
	const METAL_COLOR = ["#555b62", "#8d949b", "#b07a48", "#d6dade", "#e2b84a", "#222"];

	function plateHtml(c, n) {
		const lv = levelOf(c, n), metal = METALS[lv], modeArt = { camp: "campaign", ff: "firefight", mp: "multiplayer" }[c.mode];
		const frame = Math.min(lv, 5);
		// (the plate shows the level itself; only Max, which looks like Onyx, is written on it)
		const label = lv === 6 ? "Max" : art || !lv ? "" : LEVELS[lv];
		// The pictures if extract_career.py has run; plain shapes if they're missing (the img probe below).
		return art ? `<div class="plate" style="background-image:url(career/plate_${modeArt}_${frame}.png)"><div class="icon" style="background-image:url(career/icon_${metal}_${c.icon}.png)"></div><div class="lv">${label}</div></div>`
			: `<div class="plate bare" style="--mc:${MODE_COLOR[c.mode]};--metal:${METAL_COLOR[frame]}"><div class="icon"></div><div class="lv">${label}</div></div>`;
	}
	let art = false;
	// (kept loaded: each render rebuilds the rows, and pictures still loading would blink)
	const keep = [];
	{ const probe = new Image(); probe.onload = () => {
		art = true;
		for (let i = 0; i < 5; i++) { const im = new Image(); im.src = `career/challenge_${i}.png`; keep.push(im); }
		if (isOpen()) render();
	}; probe.src = "career/plate_multiplayer_0.png"; }
	const catIcon = (c) => art ? `background-image:url(career/challenge_${c.weekly ? CAT.week : CAT[c.mode]}.png)` : "";

	function challengeRows(st) {
		if (tab === 2) return ALL.map(c => ({ c, prog: null, done: false }));
		const period = tab === 0 ? st.daily : st.weekly;
		return period.ids.map(id => byId[id]).filter(Boolean).map(c => ({ c, prog: period.progress[c.id] || 0, done: !!period.done[c.id] }));
	}
	function render() {
		const st = rotate(load());
		save(st);
		const tabs = TABS[view];
		const sum = summary();
		const title = { challenges: "Challenges", commendations: "Commendations", record: "Service Record" }[view];
		const sub = view === "challenges" ? (tab === 2 ? `${ALL.length} challenges, ${ALL.filter(c => c.fresh).length} of them new` : `New challenges in ${resetsIn(tab === 1)}`)
			: view === "commendations" ? `Overall progress ${sum.commendations}%` : esc((document.getElementById("player") || {}).textContent || "Player");
		let body = "", side = "";
		if (view === "challenges") {
			const rows = challengeRows(st);
			sel = Math.min(sel, rows.length - 1);
			const first = Math.max(0, Math.min(sel - 3, rows.length - 7));
			body = `<div class="list">${rows.slice(tab === 2 ? first : 0, tab === 2 ? first + 7 : undefined).map((r, k) => {
				const i = (tab === 2 ? first : 0) + k, c = r.c;
				const pct = r.prog === null ? 0 : Math.min(100, r.prog / c.goal * 100);
				return `<div class="row${i === sel ? " sel" : ""}${r.done ? " done" : ""}" data-i="${i}"><div class="ic" style="${catIcon(c)}"></div>
					<div><div class="t">${esc(c.name)}${c.fresh ? "<i>New</i>" : ""}</div><div class="d">${esc(textOf(c))}</div>
					${r.prog === null ? "" : `<div class="track"><i style="width:${pct}%"></i></div>`}</div>
					<div class="p"><b>${fmt(c.cr)} cR</b>${r.prog === null ? (c.weekly ? "Weekly" : "Daily") : r.done ? "Complete" : `${fmt(Math.min(r.prog, c.goal))}/${fmt(c.goal)}`}</div></div>`;
			}).join("") || `<p>No challenges.</p>`}</div>`;
			const r = rows[sel];
			if (r) {
				const c = r.c;
				const where = { camp: "Campaign", ff: "Firefight", mp: "Multiplayer (Custom Games and Matchmaking)", any: "Any game" }[c.mode];
				side = `<div class="side"><div class="k">${c.weekly ? "Weekly Challenge" : "Daily Challenge"}${c.fresh ? " &middot; New in Reach Renaissance" : ""}</div>
					<h2>${esc(c.name)}</h2><p>${esc(textOf(c))}</p>
					<p><span class="k">Counts in</span><br>${where}${c.scope === "game" ? ", in a single game" : ""}</p>
					<p><span class="k">Reward</span><br>${fmt(c.cr)} cR</p>
					${r.prog === null ? `<p class="note">${(tab === 0 ? st.daily : st.weekly).ids.includes(c.id) ? "Active now." : "Comes up in the rotation."}</p>`
						: `<p><span class="k">Progress</span><br>${r.done ? "Complete" : `${fmt(r.prog)} of ${fmt(c.goal)}`}</p>`}
					${tab === 2 ? "" : `<p class="note">${st.done.daily} daily and ${st.done.weekly} weekly challenges completed in all.</p>`}</div>`;
			}
		} else if (view === "commendations") {
			const list = COMMENDATIONS.filter(c => c.mode === MODE_OF_TAB[tab]);
			sel = Math.min(sel, list.length - 1);
			body = `<div class="grid">${list.map((c, i) => {
				const n = st.counts[c.id] || 0;
				return `<div class="cm${i === sel ? " sel" : ""}${tracked(c) ? "" : " off"}" data-i="${i}">${plateHtml(c, n)}<div class="n">${esc(c.name)}<span>${tracked(c) ? fmt(n) : "-"}</span></div></div>`;
			}).join("")}</div>`;
			const c = list[sel];
			if (c) {
				const n = st.counts[c.id] || 0, lv = levelOf(c, n);
				const next = lv < 6 ? c.at[lv] : null, prev = lv ? c.at[lv - 1] : 0;
				const pct = next ? Math.max(0, Math.min(100, (n - prev) / (next - prev) * 100)) : 100;
				side = `<div class="side"><div class="big">${plateHtml(c, n)}</div><h2>${esc(c.name)}</h2><p>${esc(c.text)}</p>
					<p><span class="k">Level</span><br>${LEVELS[lv]}${lv === 6 ? "" : ` &middot; ${fmt(n)} / ${fmt(next)}`}</p>
					<div class="track"><i style="width:${pct}%"></i></div>
					${next ? `<p><span class="k">Next: ${LEVELS[lv + 1]}</span><br>${lv + 1 === 6 ? "No credits for Max" : "+" + fmt(c.cr[lv]) + " cR"}</p>` : ""}
					<p class="k">${c.at.map((a, i) => LEVELS[i + 1] + " " + fmt(a)).join(" &middot; ")}</p>
					${tracked(c) ? (c.mode === "mp" ? "" : `<p class="note">Easy doesn't count.${c.count === "headshots" ? " Headshots aren't counted in " + MODE_NAMES[c.mode] + " yet." : ""}</p>`)
						: `<p class="note">Not tracked yet: the game doesn't say which vehicles you destroyed or which rounds you survived.</p>`}</div>`;
			}
		} else {
			const row = (k, v) => `<div><b>${k}</b><span>${v}</span></div>`;
			const kd = (r) => r.deaths ? (r.kills / r.deaths).toFixed(2) : r.kills ? fmt(r.kills) + ".00" : "0.00";
			const hrs = (mins) => mins >= 60 ? `${Math.floor(mins / 60)}h ${mins % 60}m` : `${mins}m`;
			const modeRows = (r, games = "Games Completed") => row(games, fmt(r.games)) + row("Kills", fmt(r.kills)) + row("Deaths", fmt(r.deaths)) + row("Assists", fmt(r.assists))
				+ row("K/D Ratio", kd(r)) + row("Headshots", fmt(r.headshots)) + row("Sprees", fmt(r.sprees)) + row("Multikills", fmt(r.multikills))
				+ row("Most Kills in a Row", fmt(r.bestStreak)) + row("Most Kills in a Game", fmt(r.mostKills)) + row("Time Played", hrs(r.minutes));
			const DIFF = ["Easy", "Normal", "Heroic", "Legendary"];
			if (tab === 0) {
				const all = ["camp", "ff", "mp"].reduce((a, k) => { for (const f of Object.keys(a)) a[f] += f === "bestStreak" || f === "mostKills" ? 0 : st.modes[k][f]; a.bestStreak = Math.max(a.bestStreak, st.modes[k].bestStreak); a.mostKills = Math.max(a.mostKills, st.modes[k].mostKills); return a; }, blankMode());
				const rank = window.Ranks ? Ranks.of(Ranks.credits()) : null;
				body = `<div class="stats">${row("Rank", rank ? esc(rank.name) : "Recruit")}${row("Credits", fmt(window.Ranks ? Ranks.credits() : 0) + " cR")}
					${row("Player Since", new Date(st.since).toLocaleDateString())}${row("Daily Challenges", fmt(st.done.daily))}${row("Weekly Challenges", fmt(st.done.weekly))}
					${row("Commendations", sum.commendations + "%")}<h3>All games</h3>${modeRows(all)}${row("Multiplayer Wins", fmt(st.modes.mp.wins))}</div>`;
			} else if (tab === 1) {
				const missions = Object.entries(st.missions);
				body = `<div class="stats">${modeRows(st.modes.camp, "Missions Completed")}
					<h3>Missions</h3>${missions.length ? missions.map(([n, ms]) => row(esc(n), `${DIFF[ms.best] || "-"}${ms.deathless >= 0 ? " &middot; deathless " + DIFF[ms.deathless] : ""}${ms.fastest ? " &middot; " + ms.fastest + "m" : ""}`)).join("") : row("None completed yet", "")}</div>`;
			} else body = `<div class="stats">${modeRows(tab === 2 ? st.modes.ff : st.modes.mp)}${tab === 3 ? row("Games Won", fmt(st.modes.mp.wins)) : ""}</div>`;
		}
		root.innerHTML = `<div class="head"><h1>${title}</h1><div class="sub">${sub}</div></div>
			<div class="tabs"><span class="lb">LB</span>${tabs.map((t, i) => `<span data-t="${i}" class="${i === tab ? "on" : ""}">${t}</span>`).join("")}<span class="rb">RB</span></div>
			${body}${side}
			<div class="keys"><span class="hint" data-a="back"><span class="btn b">B</span>Back</span></div>`;
		root.querySelectorAll("[data-i]").forEach(el => {
			el.onclick = () => { sel = +el.dataset.i; play("move"); render(); };
		});
		root.querySelectorAll("[data-t]").forEach(el => el.onclick = () => { tab = +el.dataset.t; sel = 0; play("change"); render(); });
		root.querySelectorAll("[data-a]").forEach(el => el.onclick = () => action(el.dataset.a));
	}
	// view: "challenges", "commendations" or "record"
	function show(which = "challenges") {
		if (!root) {
			const style = document.createElement("style");
			style.textContent = css;
			document.head.appendChild(style);
			root = document.createElement("div");
			root.className = "cc";
			document.body.appendChild(root);
		}
		view = which; tab = 0; sel = 0;
		render();
		root.classList.add("open");
		play("select");
	}
	function close() {
		if (root) root.classList.remove("open");
		play("back");
	}
	function isOpen() { return !!root && root.classList.contains("open"); }
	// Up/down (and left/right on the commendation grid, 4 across), LB/RB the tabs, B / Start close.
	function action(a) {
		if (!isOpen()) return false;
		const count = view === "challenges" ? challengeRows(load()).length : view === "commendations" ? COMMENDATIONS.filter(c => c.mode === MODE_OF_TAB[tab]).length : 0;
		const across = view === "commendations" ? 4 : 1;
		const step = { up: -across, down: across, left: across > 1 ? -1 : 0, right: across > 1 ? 1 : 0 }[a];
		if (a === "tabl" || a === "tabr" || (across === 1 && (a === "left" || a === "right"))) {
			const n = TABS[view].length;
			tab = (tab + (a === "tabl" || a === "left" ? n - 1 : 1)) % n;
			sel = 0;
			play("change");
			render();
		} else if (step) {
			if (count) { sel = Math.max(0, Math.min(count - 1, sel + step)); play("move"); render(); }
		} else if (a === "back" || a === "start") close();
		return true;
	}
	setInterval(() => { if (isOpen() && view === "challenges") render(); }, 60000);

	return { COMMENDATIONS, CHALLENGES: ALL, matchOf, record, summary, dailiesFor, weeklyFor, rotate, load, show, action, isOpen };
})();
// (a top-level const isn't a window property; the Start menu and the party list look for window.Career)
window.Career = Career;
