// The waiting room (2026-10-20 owner request: "a waiting room for campaign and firefight would be amazing (not
// just a black screen or a loading screen, hopefully text chat and voice chat still visible)"). While a
// Campaign or Firefight game hosted online loads, its loading screen (boot.js) says who is coming, and the
// chat dock (chat.js) stays up over it and takes typing, on Party in a party:
// - the host: host-probe holds the start in Reach's member wait until everyone expected is in, 10 s after the
//   last one, or alone 1 s before the wait's 45 s end (its memberwait.rs), and says how it stands
//   (`member-wait`, the overlay's check_retiring: window.bootWaiting): "2 of 4 in" and when it starts anyway.
//   That comes before the load's stage: the host asks for the map file at once and its load-progress says
//   "map" through the whole wait (GAMESETUP cp4 host log: m10.map at 1.0 s, the start at 46 s);
// - a player joining it: the same room without the count (the wait is the host's): "Waiting for the host to
//   start" when following the party leader in, or in Campaign (listed only while it waits); a stranger's
//   Firefight join is most likely into a running game: "Joining Game";
// - the party, from the social picture (social.js): In once their presence names this game (the masters'
//   `in_game`), Joining while it names another one (the masters haven't caught up), or In the menus; players
//   from outside the party whose presence names this game are In too.
// The room is part of the loading screen and goes with it once the game is up. Nothing in it moves by itself
// (menus CPU budget): it changes when the overlay or the social picture says something new.
// Voice chat (not in the menus yet: drafts #70, #75) has its place here: each player's row carries their
// friend code (`data-code`) and an empty `.vc` slot for a talking mark (WaitingRoom.row(code)); a new
// picture redraws the rows, so a mark is set again from the voice's own state.
"use strict";

window.WaitingRoom = (() => {
	const esc = (s) => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
	const css = document.createElement("style");
	// Top left, and clear of the lattice in the middle (owner, 2026-10-21, with a marked-up screenshot): the
	// lattice reaches about 31vh either side of the centre (boot.js frame: 3.6 node spacings of 8.5vh on a
	// screen wider than tall), so the room ends 36vh short of it (with its glow), and at 26vw on a wide screen.
	css.textContent = `
		#boot .room { position: absolute; left: 5vw; top: 6vh; width: min(26vw, calc(45vw - 36vh)); display: none; text-align: left;
			font-family: var(--font, "Bahnschrift SemiCondensed", "Bahnschrift", sans-serif); color: #e8ecef; }
		#boot .room.on { display: block; }
		#boot .room h2 { margin: 0; white-space: nowrap; font-size: 4.6vh; font-weight: 700; letter-spacing: 0.03em; text-transform: uppercase; color: #fff; }
		#boot .room .sub { margin-top: 0.4vh; font-size: 2.3vh; letter-spacing: 0.04em; color: rgba(220, 232, 240, 0.8); }
		#boot .room .sub b { color: #8fd0ff; font-weight: 600; }
		#boot .room .list { margin-top: 2.2vh; }
		/* (the rows in the Friends toast's colors, social.js .sotoast, as the banner above) */
		#boot .room .r { display: flex; align-items: center; gap: 0.7vw; margin-bottom: 0.3vh; padding: 0.5vh 0.7vw; font-size: 2.2vh;
			background: linear-gradient(180deg, rgba(40, 56, 70, 0.9), rgba(22, 32, 42, 0.9)); }
		#boot .room .r.me { box-shadow: inset 0.25vw 0 0 #f2f4f5; }
		#boot .room .pemblem { width: 3.6vh; height: 3.6vh; flex: none; }
		#boot .room .nm { flex: 1; min-width: 0; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
		#boot .room .vc:empty { display: none; }
		#boot .room .st { display: flex; align-items: center; gap: 0.4vw; flex: none; font-size: 1.7vh; font-weight: 600;
			letter-spacing: 0.06em; text-transform: uppercase; color: rgba(185, 194, 200, 0.7); }
		#boot .room .st i { width: 1.1vh; height: 1.1vh; border-radius: 50%; background: rgba(185, 194, 200, 0.35); }
		#boot .room .in .st { color: #7ad08a; } #boot .room .in .st i { background: #7ad08a; }
		#boot .room .join .st { color: #35c9c0; } #boot .room .join .st i { background: #35c9c0; }
		#boot .room .hint { margin-top: 1.4vh; font-size: 1.9vh; color: rgba(220, 232, 240, 0.6); }`;
	document.head.appendChild(css);
	const el = document.createElement("div");
	el.className = "room";
	el.innerHTML = '<h2></h2><div class="sub"></div><div class="list"></div><div class="hint"></div>';
	(document.getElementById("boot") || document.body).appendChild(el);
	const list = el.querySelector(".list");

	let kind = null; // the loading screen's: "Loading" (a game this PC runs) or "Joining"; null while it is down
	let stage = ""; // the load's (bootProgress): server, join, map, start
	let percent = 0; // how much of the map this PC has loaded (bootProgress: the number by the bar)
	let wait = null; // the host's member wait: {members, expected, left}
	let on = false;
	let drop = 0;

	// A game hosted online that waits for its players: the host's, once host-probe says it waits (a public
	// Campaign alone too), or from the start for a party leader; a join of one, always. Campaign and Firefight
	// only, wait or not (a `member-wait` the overlay couldn't delete before a Custom Game is no waiting room).
	function wanted() {
		const g = window.lastGame;
		if (!kind || !g || (g.kind !== "camp" && g.kind !== "ff")) return false;
		return !!wait || kind === "Joining" || !!(window.Social && Social.leadsParty());
	}
	function update() {
		const now = wanted();
		if (now !== on) {
			on = now;
			document.body.classList.toggle("waitroom", on);
			if (window.Chat && Chat.room) Chat.room(on);
			// (the room fades with the loading screen, then goes)
			clearTimeout(drop);
			if (!on) drop = setTimeout(() => { if (!on) el.classList.remove("on"); }, 1000);
		}
		if (on) { el.classList.add("on"); render(); }
	}

	function render() {
		const s = window.Social && Social.picture ? Social.picture() : null;
		const g = window.lastGame || {};
		const hosting = kind === "Loading";
		const loading = stage === "map" || stage === "start";
		// (the wait, while it runs, before the stage: the host's says "map" all through it)
		const waiting = !!wait && wait.left > 0;
		// (a party follows its leader in before the start; a Campaign mission is listed only while it waits)
		const forHost = hosting || (window.Social && Social.following()) || g.kind === "camp";
		el.querySelector("h2").textContent = !waiting && (stage === "start" || (wait && wait.left === 0)) ? "Starting"
			: forHost ? "Waiting for Players" : "Joining Game";
		const parts = [];
		if (hosting && wait) parts.push(`${wait.members} of ${wait.expected} in`);
		if (waiting) parts.push(`Starts in <b>${wait.left} s</b>`);
		else if (stage === "start") parts.push("Starting the game");
		else if (stage === "map") parts.push("Loading the map");
		else if (wait) parts.push(wait.members >= wait.expected ? "Everyone's in" : "Starting");
		else if (hosting) parts.push("Setting up the game");
		else if (stage === "join") parts.push(forHost ? "Waiting for the host to start" : "Joining the host's game");
		else parts.push("Reaching the host's game");
		el.querySelector(".sub").innerHTML = parts.join(" &middot; ");

		// Who is coming: the host first, then you, then the party, then anyone else in the game.
		const party = (s && s.party) || [];
		const here = new Set(((s && s.in_game) || []).map(p => p.code));
		const host = s ? (hosting ? s.code : s.leader) : null;
		const me = party.find(m => m.me) || { code: s ? s.code : "", name: (s && s.name) || ((document.getElementById("player") || {}).textContent || "").trim(), me: true };
		const people = [me, ...party.filter(m => !m.me)].sort((a, b) => (b.code === host) - (a.code === host));
		const others = ((s && s.in_game) || []).filter(p => !party.some(m => m.code === p.code));
		// (the host's own row Hosting without a social picture too: offline, or before the first one)
		const status = (p) => (p.me && hosting) || (p.code && p.code === host) ? ["Hosting", "in"]
			: p.me ? [loading ? `Loading ${percent}%` : "Joining", "join"]
			: here.has(p.code) ? ["In", "in"]
			: p.state && p.state !== "menus" ? ["Joining", "join"] : ["In the menus", ""];
		const row = (p, [st, cls]) => `<div class="r${cls ? " " + cls : ""}${p.me ? " me" : ""}" data-code="${esc(p.code || "")}"><span class="pemblem"></span>`
			+ `<span class="nm">${esc(p.name || p.code || "Player")}${p.me ? " (you)" : ""}</span><span class="vc"></span><span class="st"><i></i>${st}</span></div>`;
		const rows = people.concat(others).slice(0, 12).map(p => [p, status(p)]);
		// The host's count also has players the masters don't name (no presence, or a second player on one PC):
		// the rest, unnamed. (A Joining player may be in already: they count as named.)
		const named = rows.filter(([p, [st]]) => p.code !== host && (st === "In" || st === "Joining")).length;
		const more = hosting && wait ? wait.members - 1 - named : 0;
		const html = rows.map(([p, st]) => row(p, st)).join("") + (more > 0 ? row({ name: `${more} more player${more === 1 ? "" : "s"}` }, ["In", "in"]) : "");
		if (list.dataset.html !== html) {
			list.dataset.html = html;
			list.innerHTML = html;
			if (window.Emblem) list.querySelectorAll(".r").forEach((r, i) => {
				const p = rows[i] && rows[i][0];
				if (!p) return;
				const e = p.me ? null : window.Social && Social.emblemOf(p);
				if (p.me || e) Emblem.paint(r.querySelector(".pemblem"), e);
			});
		}
		el.querySelector(".hint").textContent = window.Chat && Chat.mode() === "off" ? "Press T for chat." : "";
	}

	// A new picture (social.js has it first: its listener came first): who is in, and whether this player now
	// leads a party.
	if (window.chrome && window.chrome.webview) {
		window.chrome.webview.addEventListener("message", (e) => { if (kind && String(e.data).startsWith("social:")) update(); });
	}
	// The overlay program, from host-probe's `member-wait` (whole numbers, checked there).
	window.bootWaiting = (members, expected, left) => {
		if (!kind) return;
		wait = { members, expected, left };
		update();
	};
	return {
		// The loading screen came up for a game ("Loading", "Joining": a new load) or went (null; boot.js).
		boot(k) { kind = k; stage = ""; percent = 0; wait = null; update(); },
		// The load's stage and how much of the map is loaded (boot.js bootProgress): your own row says it too,
		// LOADING 47%. (Only this PC's: the other players' loads aren't known here.) (It asks again whether this
		// load gets the room: a follow's game, social.js setLastGame, may reach the page after its loading screen.)
		stage(st, n = 0) { if (st === stage && n === percent) return; stage = st; percent = n; update(); },
		// The chat dock was turned on or off (chat.js setMode): the "Press T" hint goes or comes now, not at the
		// next count or picture (up to 10 s on a joining player's screen).
		redraw() { if (on) render(); },
		isOpen: () => on,
		// A player's row (voice chat's talking mark goes in its `.vc`), or null.
		row: (code) => (on && code && [...list.querySelectorAll(".r")].find(r => r.dataset.code === code)) || null,
	};
})();
