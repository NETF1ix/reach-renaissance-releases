// Menu music (owner, 2026-10-17: "by default it should be a reach playlist how xbox 360 reach handles
// it, and then we should have the option to change it to any music or create a playlist from the music
// in the game's code"). The music is the player's own: the overlay program unpacks it from their MCC
// install the first time each track plays (src/music.rs; owner, 2026-10-17: the download carries none of
// the game's audio). The page asks `music?` (the list: `music-data:`) and `music:<id>` (the track's file:
// `music-file:<id>|<url>`, or `music-error:`). Without MCC's sound files the menus are silent.
//
// Settings > Audio (start-menu.js; saved by the overlay program, settings.rs):
//   music=reach|track|playlist|off   reach: the 360's menu music: its intro (02_menu_in), then one piece of
//                                     its loop.sound after another, picked at random (12 pieces, all with
//                                     the same weight in the Mod Tools' sound\music\reach_menu\track1\loop.sound)
//   music.track=<id>                  the one track played, over and over
//   music.playlist=<id>;<id>;...      the player's playlist, in order or shuffled (music.shuffle=on|off)
//   volume.menumusic=<percent>        MENU MUSIC VOLUME
// The id `menu` is the 360's menu music itself (its intro and each loop piece once, in a playlist).
//
// The 360's pieces are joined with Web Audio, sample for sample, as the game joins them; the other
// tracks are whole files, played by an audio element. Nothing plays during the boot intro video or a
// match (body.inmatch); after a match the music starts again from its beginning, as on the 360.
"use strict";

window.MenuMusic = (() => {
	let DATA = null; // from the overlay program: { menu: { intro, loops }, tracks } or { error }
	const MENU_ID = "menu";
	const BASE = 0.7; // (the menus' sounds play at 0.8; the music sits under them)
	const FADE = 1.2; // seconds, when the music stops or changes
	const FADE_IN = 0.4; // seconds, when the 360's menu music starts
	let st = { mode: "reach", track: MENU_ID, list: [], shuffle: true, volume: 1 };
	let applied = null; // the settings the music now playing is for
	let ctx = null, out = null;
	let session = null; // what is playing now: { stop() }
	let preview = null; // a track played from the music pages for a moment (its id)

	const post = (m) => { try { window.chrome.webview.postMessage(m); } catch (e) { } };
	const ready = () => !!(DATA && !DATA.error);
	const byId = (id) => !ready() ? null : id === MENU_ID ? { id: MENU_ID, name: "Main Menu (Halo: Reach)", group: "Main Menu" } : DATA.tracks.find(t => t.id === id);
	function tracks() {
		if (!ready()) return [];
		const ORDER = ["Cutscenes", "Poignant", "Heroic", "Action", "Tension", "Firefight", "Invasion", "Percussion", "Ambient", "Other"];
		const rank = (g) => { const i = ORDER.indexOf(g); return i < 0 ? ORDER.length : i; };
		return [byId(MENU_ID), ...DATA.tracks.slice().sort((a, b) => rank(a.group) - rank(b.group))];
	}
	const volume = () => BASE * st.volume;

	// A track's file from the overlay program (made the first time; a second or so).
	const files = new Map(), waiting = new Map();
	function fileOf(id) {
		if (files.has(id)) return Promise.resolve(files.get(id));
		return new Promise((resolve, reject) => {
			if (!waiting.has(id)) { waiting.set(id, []); post("music:" + id); }
			waiting.get(id).push({ resolve, reject });
		});
	}

	function audio() {
		if (!ctx) {
			try {
				ctx = new AudioContext({ sampleRate: 48000 });
				out = ctx.createGain();
				out.connect(ctx.destination);
			} catch (e) { ctx = null; }
		}
		if (ctx && ctx.state === "suspended") ctx.resume().catch(() => {});
		return ctx;
	}
	// (XHR, not fetch: the page and the music are file: URLs, which fetch can't read)
	async function load(id) {
		const url = await fileOf(id);
		const bytes = await new Promise((resolve, reject) => {
			const x = new XMLHttpRequest();
			x.open("GET", url);
			x.responseType = "arraybuffer";
			x.onload = () => x.response && x.response.byteLength ? resolve(x.response) : reject(new Error(url + ": empty"));
			x.onerror = () => reject(new Error(url + ": not read"));
			x.send();
		});
		return await ctx.decodeAudioData(bytes);
	}
	// A piece's name without its _01/_02 (the same music, another cut: not played twice in a row).
	const family = (piece) => piece.id.replace(/_0\d$/, "");

	// The 360's menu music: the intro, then loop pieces at random (`endless`), or each one once.
	function playMenu(endless, done) {
		if (!ready() || !DATA.menu.intro || !audio()) { if (done) setTimeout(done, 1000); return { stop() { } }; }
		const m = DATA.menu;
		let stopped = false, last = null, timer = 0;
		const sources = [];
		const queue = endless ? [] : shuffle(m.loops.slice());
		function nextPiece() {
			if (!endless) return queue.shift() || null;
			const pool = m.loops.filter(p => !last || family(p) !== family(last));
			return pool[Math.floor(Math.random() * pool.length)];
		}
		const gain = ctx.createGain();
		gain.gain.value = 0; // (up when the first piece starts: chain)
		gain.connect(out);
		out.gain.value = volume();
		// Each piece starts the moment the one before ends; the next is unpacked and loaded while one plays.
		async function chain(piece, at) {
			if (stopped || !piece) { if (!stopped && done) timer = setTimeout(done, Math.max(0, (at - ctx.currentTime) * 1000)); return; }
			let buf;
			try { buf = await load(piece.id); } catch (e) { if (!stopped && done) done(); return; }
			if (stopped) return;
			const src = ctx.createBufferSource();
			src.buffer = buf;
			src.connect(gain);
			const when = Math.max(at, ctx.currentTime + 0.05);
			// The first piece fades in a little, as a file track does (playFile); it had started at full
			// volume, right as the intro's sound stopped (owner report, 2026-10-19).
			if (!last) {
				gain.gain.setValueAtTime(0, when);
				gain.gain.linearRampToValueAtTime(1, when + FADE_IN);
			}
			src.start(when);
			sources.push(src);
			src.onended = () => { const i = sources.indexOf(src); if (i >= 0) sources.splice(i, 1); };
			last = piece;
			const end = when + buf.duration;
			// (the next one is asked for at once, loaded a little before this one ends)
			const next = nextPiece();
			if (next) fileOf(next.id).catch(() => {});
			timer = setTimeout(() => chain(next, end), Math.max(0, (end - ctx.currentTime - 8) * 1000));
		}
		chain(m.intro, ctx.currentTime + 0.05);
		return {
			stop() {
				stopped = true;
				clearTimeout(timer);
				const t = ctx.currentTime, v = gain.gain.value;
				gain.gain.cancelScheduledValues(t); // (a fade-in still to come or running)
				gain.gain.setValueAtTime(v, t);
				gain.gain.linearRampToValueAtTime(0, t + FADE);
				for (const s of sources) try { s.stop(t + FADE + 0.05); } catch (e) { }
				setTimeout(() => gain.disconnect(), (FADE + 0.2) * 1000);
			},
			volume() { out.gain.value = volume(); },
			now: () => ({ piece: last && last.id, state: ctx.state, time: +ctx.currentTime.toFixed(1) }),
		};
	}

	// One whole track from its file; `loop` plays it again and again.
	function playFile(track, loop, done) {
		const el = new Audio();
		el.loop = !!loop;
		el.volume = 0;
		let stopped = false, fade = 0;
		const ramp = (to, then) => {
			clearInterval(fade);
			const from = el.volume, t0 = performance.now();
			fade = setInterval(() => {
				const k = Math.min(1, (performance.now() - t0) / (FADE * 1000));
				el.volume = Math.max(0, Math.min(1, from + (to - from) * k));
				if (k >= 1) { clearInterval(fade); if (then) then(); }
			}, 50);
		};
		const failed = () => { if (!stopped && done) setTimeout(done, 1000); };
		el.addEventListener("ended", () => { if (!stopped && done) done(); });
		el.addEventListener("error", failed);
		fileOf(track.id).then((url) => {
			if (stopped) return;
			el.src = url;
			el.play().then(() => { if (!stopped) ramp(volume()); }).catch(failed);
		}, failed);
		return {
			stop() { stopped = true; ramp(0, () => { el.pause(); el.removeAttribute("src"); el.load(); }); },
			volume() { if (!stopped) { clearInterval(fade); el.volume = volume(); } },
			now: () => ({ id: track.id, time: +el.currentTime.toFixed(1), paused: el.paused, volume: +el.volume.toFixed(2) }),
		};
	}

	function shuffle(a) {
		for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
		return a;
	}
	const playOne = (id, loop, done) => id === MENU_ID ? playMenu(loop, done) : byId(id) ? playFile(byId(id), loop, done) : (done && setTimeout(done, 0), { stop() { } });

	// The playlist: each track once, then again (reshuffled when shuffled). Tracks added or removed
	// meanwhile count from the next track on; the one playing plays on.
	function playList() {
		let order = [], cur = null, stopped = false;
		const next = () => {
			if (stopped) return;
			order = order.filter(id => st.list.includes(id));
			if (!order.length) order = st.shuffle ? shuffle(st.list.filter(byId)) : st.list.filter(byId);
			if (!order.length) order = [MENU_ID];
			cur = playOne(order.shift(), false, next);
		};
		next();
		return { stop() { stopped = true; if (cur) cur.stop(); }, volume() { if (cur && cur.volume) cur.volume(); }, now: () => cur && cur.now ? cur.now() : null };
	}

	// Whether music may play now: not during the boot intro video, nor in a match. The video itself must be
	// paused, ended or emptied too, not only the boot screen's "intro" class gone (owner report, 2026-10-19:
	// the intro's music went on under the menu music).
	function allowed() {
		if (document.body.classList.contains("inmatch")) return false;
		const boot = document.getElementById("boot");
		if (boot && boot.classList.contains("intro")) return false;
		const video = document.getElementById("intro");
		return !video || video.paused || video.ended || video.networkState === HTMLMediaElement.NETWORK_EMPTY;
	}
	const key = () => preview ? "preview:" + preview : st.mode === "off" ? "off" : st.mode === "track" ? "track:" + st.track
		: st.mode === "playlist" && st.list.some(byId) ? "playlist" : "reach";
	function update() {
		const want = ready() && st.volume > 0 && allowed() ? key() : "off";
		if (want === applied) return;
		if (session) session.stop();
		session = null;
		applied = want;
		if (want === "off") return;
		if (want.startsWith("preview:")) session = playOne(preview, true);
		else if (want.startsWith("track:")) session = playOne(st.track, true);
		else if (want === "playlist") session = playList();
		else session = playMenu(true);
	}

	// Watch for a match starting or ending and the intro video (class changes on body and #boot, and the
	// video stopping).
	const watch = new MutationObserver(() => update());
	function attach() {
		watch.observe(document.body, { attributes: true, attributeFilter: ["class"] });
		const boot = document.getElementById("boot");
		if (boot) watch.observe(boot, { attributes: true, attributeFilter: ["class"] });
		const video = document.getElementById("intro");
		if (video) for (const ev of ["pause", "ended", "emptied"]) video.addEventListener(ev, () => update());
		// The overlay program's answers, heard here (index.html's listener comes later: the answer to the
		// first `music?` went unheard on PC 1, 2026-10-17); asked again until the list comes.
		try { window.chrome.webview.addEventListener("message", (e) => { const t = String(e.data); if (t.startsWith("music-")) api.message(t); }); } catch (e) { }
		const ask = (n) => { if (!DATA && n > 0) { post("music?"); setTimeout(() => ask(n - 1), 3000); } };
		ask(5);
	}
	const api = {
		MENU_ID,
		tracks,
		byId,
		available: ready,
		// Why there is no music (MCC's sound files or the decoder missing), for Settings > Audio.
		problem: () => DATA && DATA.error || null,
		// The overlay program's answers (`music-data:`, `music-file:`, `music-error:`).
		message(text) {
			if (text.startsWith("music-data:")) {
				if (ready()) return; // (an answer to an earlier ask)
				try { DATA = JSON.parse(text.slice(11)); } catch (e) { DATA = { error: "The music list couldn't be read." }; }
				applied = null;
				update();
				return;
			}
			const m = /^music-(file|error):([^|]*)\|(.*)$/.exec(text);
			if (!m) return;
			const [, kind, id, rest] = m;
			if (kind === "file") files.set(id, rest);
			for (const w of waiting.get(id) || []) kind === "file" ? w.resolve(rest) : w.reject(new Error(rest));
			waiting.delete(id);
		},
		// The saved settings (start-menu.js passes every settings-state and every change).
		settings(s) {
			const v = Math.max(0, Math.min(100, +(s["volume.menumusic"] ?? 100))) / 100;
			const volChanged = v !== st.volume;
			st = {
				mode: ["reach", "track", "playlist", "off"].includes(s.music) ? s.music : "reach",
				track: s["music.track"] || MENU_ID,
				list: (s["music.playlist"] || "").split(";").filter(Boolean),
				shuffle: s["music.shuffle"] !== "off",
				volume: v,
			};
			if (volChanged && session && session.volume && st.volume > 0) session.volume();
			update();
		},
		// A track played from the music pages while one is highlighted (null: back to the setting's music).
		preview(id) { preview = id && byId(id) ? id : null; update(); },
		previewing: () => preview,
		// What plays now ("reach", "track:<id>", "playlist", "preview:<id>" or "off"), and the 360 menu
		// piece or track playing (for checks).
		playing: () => ({ what: applied, now: session && session.now ? session.now() : null }),
	};
	if (document.body) attach(); else document.addEventListener("DOMContentLoaded", attach);
	return api;
})();
