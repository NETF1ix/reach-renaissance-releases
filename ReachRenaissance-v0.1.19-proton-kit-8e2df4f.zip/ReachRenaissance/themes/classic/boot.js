// Startup like the 360's: the boot intro video from the owner's own disc (scripts/menu/extract_intro.py,
// video/intro.mp4, git-ignored) on the first start, then a glowing diamond lattice on dark navy (owner's
// Xenia screenshot, 2026-10-12; the 360 draws it in engine code, so it is redrawn here on a canvas) until
// the game's menu backdrop is up. The overlay program reports that (window.backdropReady, from host-probe's
// `<scene file>.ready`). A bar in the corner shows the game loading, then READY: from then on A / B /
// Start / Enter / Esc / a click skips the rest of the intro; otherwise the full intro plays (owner
// 2026-10-12). Without the ready signal the lattice fades after 30 s anyway. window.bootScreen(true) brings
// the lattice back (the menu game restarting after a match). The same screen covers every load into a game
// (owner, 2026-10-18: "that is what all loading screens need to look like"): the overlay program brings it up
// with window.bootScreen(true, true, "Joining" | "Loading"), the mode at the top right and the map or mission
// by the bar (no banner box over the lattice since 2026-10-21, owner), and
// keeps it up until the game is past its loading (host-probe's `first-frame`), so Reach's black loading
// frames never show. An online Campaign or Firefight's load shows its waiting room on it (waiting-room.js).
"use strict";

(() => {
	const root = document.createElement("div");
	root.id = "boot";
	root.innerHTML = '<canvas></canvas><div class="mode"></div><video id="intro" playsinline preload="auto"></video>'
		+ '<div class="state"><div class="bar"><span class="done"></span><i></i></div><span class="pct"></span><span class="txt">Loading</span><span class="skip"><b>A</b>Skip</span></div>';
	const style = document.createElement("style");
	style.textContent = `
		#boot { position: fixed; inset: 0; z-index: 1000; background: #03060a; transition: opacity 0.9s ease; }
		#boot.off { opacity: 0; pointer-events: none; }
		#boot canvas { width: 100%; height: 100%; display: block; }
		#boot video { position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; background: #000; display: none; transition: opacity 0.6s ease; }
		#boot video.on { display: block; }
		#boot video.out { opacity: 0; }
		#boot .state { position: absolute; right: 4vw; bottom: 5vh; display: flex; align-items: center; gap: 1vw;
			font-family: "Bahnschrift SemiCondensed", "Bahnschrift", sans-serif; font-size: 2.3vh; letter-spacing: 0.12em;
			text-transform: uppercase; color: rgba(220, 232, 240, 0.8); }
		/* (the bar just left of what is loading: a short name puts it further right; owner, 2026-10-21) */
		#boot .bar { width: 18vw; height: 0.5vh; background: rgba(255, 255, 255, 0.15); overflow: hidden; position: relative; }
		#boot .bar i { position: absolute; top: 0; bottom: 0; width: 35%; background: linear-gradient(90deg, transparent, #8fd0ff, transparent);
			animation: bootbar 1.4s linear infinite; }
		#boot.ready .bar i { animation: none; left: 0; width: 100%; background: #8fd0ff; }
		/* A known percentage fills the track, and the moving glow keeps running over it (owner, 2026-10-21: "i
		   liked the old pulsating loading bar"; a solid fill had replaced it). */
		#boot .bar .done { position: absolute; top: 0; bottom: 0; left: 0; width: 0; background: rgba(143, 208, 255, 0.45); transition: width 0.3s ease; }
		#boot.ready .bar .done { width: 0; }
		@keyframes bootbar { from { left: -35%; } to { left: 100%; } }
		#boot .skip { display: none; align-items: center; gap: 0.5vw; letter-spacing: 0.04em; color: #fff; }
		#boot .skip b { display: inline-grid; place-items: center; width: 2.7vh; height: 2.7vh; border-radius: 50%; background: #3a9b3a;
			font-size: 1.6vh; box-shadow: inset 0 0 0 0.25vh rgba(255, 255, 255, 0.55); }
		#boot.ready.intro .skip { display: inline-flex; cursor: pointer; }
		#boot video.out ~ .state .skip { display: none; } /* (skipped: the hint goes while the sound fades) */
		/* The mode at the top right: Campaign, Firefight, Forge, or a multiplayer game's game type (owner, 2026-10-21) */
		#boot .mode { position: absolute; right: 4vw; top: 5vh; display: none; max-width: 40vw; white-space: nowrap; overflow: hidden;
			text-overflow: ellipsis; font-family: var(--font, "Bahnschrift SemiCondensed", "Bahnschrift", sans-serif); font-size: 3.4vh;
			font-weight: 700; letter-spacing: 0.08em; text-transform: uppercase; color: rgba(240, 244, 246, 0.92); }
		#boot .mode.on { display: block; }
		#boot .txt { white-space: nowrap; }
		/* How much of the map is loaded, just right of the bar (owner, 2026-10-21: "a percentage next to the
		   loading bar to show how loaded in the player is"); a fixed width, so the name doesn't shift as it counts */
		#boot .pct { display: none; min-width: 2.6em; font-weight: 700; letter-spacing: 0.04em; font-variant-numeric: tabular-nums; color: #fff; }
		#boot.loadpct .pct { display: inline-block; }`;
	document.head.appendChild(style);
	document.body.appendChild(root);
	const canvas = root.querySelector("canvas");
	const g = canvas.getContext("2d");
	const video = root.querySelector("video");
	const modeLine = root.querySelector(".mode");
	const fill = root.querySelector(".bar .done");
	const pct = root.querySelector(".pct");
	let shown = 0, running = false, fallback = 0, ready = false, intro = false, label = "Loading", forGame = false, loaded = 0;
	// What a game's load says (window.lastGame, set by whoever started or joined it): the map or mission by the
	// bar, "Loading Noble Actual", and the mode at the top right (owner, 2026-10-21: no banner box over the
	// lattice; "if it is a multiplayer mode, it should show the gametype's name").
	const place = () => (forGame && window.lastGame && window.lastGame.map) || "";
	const modeOf = (g) => !g ? "" : g.kind === "camp" ? "Campaign" : g.kind === "ff" ? "Firefight" : g.kind === "forge" ? "Forge" : g.mode || "";
	const saying = (verb) => place() ? `${verb} ${place()}` : verb;
	const whenStopped = []; // (window.afterIntro: run once the intro has stopped)
	const post = (m) => { try { window.chrome.webview.postMessage(m); } catch (e) { } };

	// (an inline width would beat .ready's 100%: cleared whenever the bar goes back to its own look)
	function unknownProgress() {
		root.classList.remove("known", "loadpct");
		fill.style.width = "";
	}
	function setReady(on) {
		ready = on;
		root.classList.toggle("ready", on);
		unknownProgress();
		root.querySelector(".txt").textContent = on ? "Ready" : saying(label);
	}
	// Stops the intro video and its sound for good (owner report, 2026-10-19: the intro's music went on
	// under the menu music; it was paused only 650 ms after a skip, and never when the screen was dropped
	// mid-intro). A skip fades the sound out with the picture, anything else pauses it at once (the page
	// may be hidden, where timers slow down); then the video is emptied, so nothing can start it again.
	// The "intro" class, which holds the menu music back (music.js), goes only once it is paused. Hides
	// nothing and sets no timer: a game's loading screen stays up until the overlay program drops it.
	// `intro:<reason>` goes to the overlay's log (skip-key, skip-pad, skip-click, ended, error, hidden, game).
	function stopIntro(reason) {
		if (!intro) return;
		intro = false;
		post("intro:" + reason);
		video.classList.add("out");
		const ms = reason.startsWith("skip") && !video.paused ? 300 : 0;
		const from = video.volume, t0 = performance.now();
		const step = () => {
			const k = ms ? Math.min(1, (performance.now() - t0) / ms) : 1;
			video.volume = from * (1 - k);
			if (k < 1) return void setTimeout(step, 30);
			video.pause();
			root.classList.remove("intro");
			// (a paused video keeps its frame for the picture's 0.6 s fade)
			setTimeout(() => { video.removeAttribute("src"); video.load(); video.classList.remove("on", "out"); }, 650 - ms);
			for (const fn of whenStopped.splice(0)) fn();
		};
		step();
	}
	// The intro is over (skipped, or played to its end): the lattice until the menu game is up. (Its hide
	// is the fallback timer, so a game's loading screen shown meanwhile cancels it: show.)
	function endIntro(reason) {
		if (!intro) return;
		stopIntro(reason);
		clearTimeout(fallback);
		fallback = setTimeout(hide, ready ? 1200 : 30000);
	}
	video.addEventListener("ended", () => endIntro("ended"));
	video.addEventListener("error", () => endIntro("error"));
	root.addEventListener("click", () => { if (ready) endIntro("skip-click"); });

	// Lattice segments: short diagonal bars around each node of a diamond-shaped grid, like the 360's
	// lattice of "X"s. Each bar has its own phase so light ripples across it.
	const N = 3;
	const bars = [];
	for (let i = -N; i <= N; i++) {
		for (let j = -N; j <= N; j++) {
			if (Math.abs(i) + Math.abs(j) > N + 1 || (i + j) % 2 !== 0) continue;
			for (const dir of [1, -1]) {
				for (const side of [-1, 1]) bars.push({ x: i, y: j, dir, side, seed: Math.sin(i * 12.9898 + j * 78.233 + dir * 3 + side) * 43758.5453 % 1 });
			}
		}
	}

	function frame(now) {
		if (!running) return;
		requestAnimationFrame(frame);
		if (intro) return; // (the video covers it)
		const w = canvas.width = canvas.clientWidth * devicePixelRatio;
		const h = canvas.height = canvas.clientHeight * devicePixelRatio;
		const t = (now - shown) / 1000;
		g.fillStyle = "#03060a";
		g.fillRect(0, 0, w, h);
		const cx = w / 2, cy = h * 0.52, s = Math.min(w, h) * 0.085;
		// Two soft beams crossing behind the lattice.
		g.save();
		g.translate(cx, cy);
		for (const [angle, alpha] of [[-0.62, 0.10], [0.62, 0.05]]) {
			g.rotate(angle);
			const beam = g.createLinearGradient(0, -h * 0.18, 0, h * 0.18);
			beam.addColorStop(0, "rgba(40, 80, 120, 0)");
			beam.addColorStop(0.5, `rgba(60, 110, 160, ${alpha * Math.min(1, t)})`);
			beam.addColorStop(1, "rgba(40, 80, 120, 0)");
			g.fillStyle = beam;
			g.fillRect(-w, -h * 0.18, w * 2, h * 0.36);
			g.rotate(-angle);
		}
		// The lattice: additive glow, a light sweep moving left to right and a slow breathing.
		g.globalCompositeOperation = "lighter";
		g.lineCap = "round";
		g.lineWidth = s * 0.15;
		const sweep = ((t * 0.45) % 2.4) - 1.2; // -1.2 .. 1.2 across the lattice
		for (const b of bars) {
			const x = b.x * s, y = b.y * s;
			const dist = Math.abs(b.x) + Math.abs(b.y);
			const edge = Math.max(0, 1 - dist / (N + 1.5));
			const wave = Math.exp(-Math.pow((b.x / N - sweep) * 2.2, 2));
			const twinkle = 0.55 + 0.45 * Math.sin(t * 1.7 + b.seed * 6.283);
			const a = Math.min(1, t * 0.8) * (0.08 + 0.55 * edge * twinkle + 0.5 * wave * edge);
			if (a < 0.02) continue;
			const len = s * 0.42, off = s * 0.36 * b.side;
			const ox = x + off, oy = y + off * b.dir;
			// Blue on the left, teal toward the right, as in the 360's.
			const k = (b.x + N) / (2 * N);
			g.strokeStyle = `rgba(${Math.round(90 + 60 * k + 60 * wave)}, ${Math.round(130 + 70 * k + 40 * wave)}, ${Math.round(235 - 25 * k)}, ${a})`;
			g.shadowColor = "rgba(90, 160, 255, 0.9)";
			g.shadowBlur = s * 0.5;
			g.beginPath();
			g.moveTo(ox - len / 2, oy + (len / 2) * b.dir);
			g.lineTo(ox + len / 2, oy - (len / 2) * b.dir);
			g.stroke();
		}
		g.restore();
	}

	// `hold`: no 30 s fallback (a game loading: the overlay program drops the screen when the game is up or
	// the join fails). `kind`: "Joining" or "Loading" a game, for the corner and the mode line; none for the
	// menus' own game (startup, back from a match), which has neither.
	function show(hold, kind) {
		// (a game loading over the intro, e.g. a party following its leader: the intro stops, the loading
		// screen stays; owner report, 2026-10-19)
		if (kind) stopIntro("game");
		label = kind || "Loading";
		forGame = !!kind;
		window.joinBanner = "";
		modeLine.textContent = forGame ? modeOf(window.lastGame) : "";
		modeLine.classList.toggle("on", !!modeLine.textContent);
		setReady(false);
		// (a game's load starts at 0% of its map: the number is there from the first frame)
		loaded = 0;
		if (forGame) showLoaded(0);
		root.classList.remove("off");
		shown = performance.now();
		clearTimeout(fallback);
		if (!hold) fallback = setTimeout(() => { if (!intro) hide(); }, 30000);
		if (!running) { running = true; requestAnimationFrame(frame); }
		// (a Campaign or Firefight load becomes the waiting room: waiting-room.js)
		if (window.WaitingRoom) WaitingRoom.boot(kind || null);
	}
	function hide() {
		clearTimeout(fallback);
		// (dropped mid-intro, e.g. a joined game up: the video played on unseen, and nothing could stop it)
		stopIntro("hidden");
		if (root.classList.contains("off")) return;
		root.classList.add("off");
		if (window.WaitingRoom) WaitingRoom.boot(null);
		window.dispatchEvent(new Event("resize")); // (lay the menus out again at the real window size)
		// (the filled bar stays through the fade, then goes)
		setTimeout(() => { if (root.classList.contains("off")) { running = false; unknownProgress(); } }, 1000);
		window.bootsDone = (window.bootsDone || 0) + 1;
		if (window.chrome && window.chrome.webview) window.chrome.webview.postMessage("boot-done");
	}
	window.bootScreen = (on, hold, kind) => on ? show(hold, kind) : hide();
	// How far a game's load has got (the overlay program, from host-probe's `load-progress`; owner report,
	// 2026-10-19): the corner says the stage and the map or mission's name (CONTACTING / JOINING / LOADING /
	// STARTING NOBLE ACTUAL), and the bar and the number just right of it how much of the map is loaded
	// (owner, 2026-10-21). That number is the engine's own load fraction (host slot 23 phase 5; host-probe
	// writes it as `map 10..94`, 10 + 85 x the fraction, loadprogress.rs), not a timer: 0% while the session
	// is set up and while the map is asked for and nothing of it has loaded (a guest waiting for its host to
	// start, a host waiting for its players), 100% once it is loaded and the game starts. It never goes down.
	// The menus' own startup lattice keeps its moving bar and no number. (no animation: a width change now and then)
	const STAGES = { server: "Contacting server", map: "Loading map", start: "Starting" };
	const VERBS = { server: "Contacting", map: "Loading", start: "Starting" };
	const mapPercent = (percent, stage) => stage === "start" ? 100
		: stage === "map" && typeof percent === "number" && isFinite(percent) ? Math.max(0, Math.min(99, Math.round((percent - 10) / 85 * 100)))
		: 0;
	function showLoaded(n) {
		const was = root.classList.contains("known");
		root.classList.add("known", "loadpct");
		fill.style.width = `${n}%`;
		// (the first number shows at once, not as a slide from the moving bar's 35%)
		if (!was) { fill.style.transition = "none"; void fill.offsetWidth; fill.style.transition = ""; }
		pct.textContent = `${n}%`;
	}
	window.bootProgress = (percent, stage) => {
		if (!forGame || ready || root.classList.contains("off")) return;
		loaded = Math.max(loaded, mapPercent(percent, stage));
		if (window.WaitingRoom) WaitingRoom.stage(stage, loaded);
		// (a follow's game, social.js setLastGame, may reach the page after its loading screen)
		if (!modeLine.textContent) { modeLine.textContent = modeOf(window.lastGame); modeLine.classList.toggle("on", !!modeLine.textContent); }
		// ("join": Joining, or Loading for a hosted game or own match)
		// (a join whose host hasn't checked in yet: it is still loading its map, or between games)
		root.querySelector(".txt").textContent = stage === "host" ? `Waiting for the host to load ${place() || "its map"}`
			: place() ? saying(VERBS[stage] || label) : STAGES[stage] || label;
		showLoaded(loaded);
	};
	// The backdrop is up: READY in the corner; without the intro, hold the lattice a moment longer (the
	// camera settles), then fade.
	window.backdropReady = () => {
		if (ready) return;
		setReady(true);
		if (!intro) setTimeout(hide, 700);
	};
	// Menu input while the startup screen is up: once ready, A / B / Start skip the intro; otherwise it
	// goes nowhere.
	window.bootSkip = (a) => {
		if (root.classList.contains("off")) return false;
		if (intro && ready && ["select", "back", "start"].includes(a)) endIntro(document.body.classList.contains("kbm") ? "skip-key" : "skip-pad");
		return true;
	};
	// Whether the intro video plays (index.html: its skip takes the buttons before Friends meanwhile).
	window.introPlaying = () => intro;
	// Runs `fn` once the intro has stopped, or now when none plays (the first run's Welcome waits for it).
	window.afterIntro = (fn) => { if (intro) whenStopped.push(fn); else fn(); };
	show();
	if (window.chrome && window.chrome.webview) {
		video.src = "video/intro.mp4";
		intro = true;
		root.classList.add("intro");
		video.classList.add("on");
		video.play().catch(() => endIntro("error"));
	} else setTimeout(hide, 4000); // (the page opened in a browser, without the overlay program)
})();
