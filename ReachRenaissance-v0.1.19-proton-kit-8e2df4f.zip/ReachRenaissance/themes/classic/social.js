// Friends and parties (owner's list, 2026-10-16: "a lobby system where players can join each other's
// lobbies and party up, a friends list and social features").
//
// The data comes from the local server browser (client/directory social_client.rs) through the overlay
// program: `social:<json>` every few seconds (friends with their presence, invites, the party, `follow`),
// `social-reply:<route>|<json>` and `social-error:<route>|<text>` after a change, `social-follow:<id>`
// when this player follows their party leader into a game, then `social-follow-retry:<seconds>|<why>`,
// `social-follow-failed:<why>` or `social-follow-stopped:<declined|left|removed>` when that join failed or
// ended (Join Their Game sends `follow-retry`; `social-follow-not:<busy|gone>` when it can't). Changes go
// out as `social-api:<route>|<json>` (me, friend, invite, accept, join, dismiss, leave).
//
// Every player has a friend code made from their own key. Friends are added by code and kept on this
// PC. A party follows its leader: when the leader joins or hosts an online game, the members' menus
// join it too. Nothing here ever shows or sends an IP address.
//
// The lobby (owner, 2026-10-17, with Reach's lobby screenshots): the party box lists every player in
// the party under your own card (crown on the leader, "X is the party leader." at the bottom left), then
// "<you>'s Friends:" with the friends who aren't in it, grouped by what they're doing. It scrolls when
// it fills the screen. Picking a card shows that player's card and character (index.html renderParty):
// their appearance line goes on the menus' Spartan while you look, and yours goes back before anything
// else reaches the game. Inviting someone who is in another party asks its leader to bring the whole
// party; you approve their request (merge_offer, merge_request, merge_accept in social_client.rs).
//
// Teams (owner, 2026-10-18): in a team game type the leader keeps everyone's team (social_client
// teams.rs, from the lobby's game type: `teams` with its teams and Team Changing, index.html). The cards
// take their team's color; A on a card is Change Team: the leader moves anyone, a member asks for their
// own team when Team Changing allows it. Each player's own team goes to their game (`team:<n>`, the
// overlay's `--team`, host-probe teams.rs).
"use strict";

window.Social = (() => {
	const TABS = ["Friends", "Party", "Invites"];
	const STATE_TEXT = { menus: "In the menus", in_game: "In a game", hosting: "Hosting a game" };
	// Party privacy (social.rs PRIVACY): who may join without an invite.
	const PRIVACY = [["open", "Open"], ["fof", "Friends of Friends"], ["friends", "Friends Only"], ["invite", "Invite Only"]];
	const privacyName = (p) => (PRIVACY.find(x => x[0] === (p || "friends")) || PRIVACY[2])[1];
	let privacy = "friends";
	try { privacy = localStorage.getItem("rr.party.privacy") || "friends"; } catch (e) { }
	let snap = null;
	let error = "";
	let tab = 0;
	let row = 0;
	let actions = null; // [{label, run}] for the selected row, while its list is open
	let actionRow = 0;
	let prompt = false;
	let note = "";
	let noteUntil = 0;
	// Following the party leader into their game stopped (menu-overlay online.rs: its join failed twice, or
	// you cancelled or left it): Join Their Game tries once more (`follow-retry`; party join loop, 2026-10-19).
	let followStopped = false;
	let followBlockedSaid = "";
	const seenInvites = new Set();
	let firstState = true;
	const post = (m) => { if (window.chrome && window.chrome.webview) window.chrome.webview.postMessage(m); };
	const api = (route, body) => post("social-api:" + route + "|" + JSON.stringify(body || {}));
	const play = (s) => { if (typeof Sound !== "undefined") Sound.play(s); };
	const esc = (s) => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

	// Reach's team colors (as scoreboard.js has them): red, blue, green, orange, purple, gold, brown, pink.
	const TEAMS = [["Red", "#c8352e"], ["Blue", "#2f6fd0"], ["Green", "#3c9a3c"], ["Orange", "#e07a1e"], ["Purple", "#7b46b8"], ["Gold", "#d6a623"], ["Brown", "#7a5233"], ["Pink", "#e06aa8"]];

	const css = document.createElement("style");
	css.textContent = `
	.so { position: fixed; inset: 0; z-index: 1002; display: none; font-family: var(--font); color: var(--text);
		background: radial-gradient(ellipse at 50% 45%, rgba(20, 40, 54, 0.97), rgba(4, 8, 12, 0.99)); }
	.so.open { display: block; }
	.so .box { position: absolute; left: 13vw; top: 9vh; width: 74vw; height: 78vh; }
	.so h1 { margin: 0; font-size: 5vh; font-weight: 700; letter-spacing: 0.02em; text-transform: uppercase; }
	.so .code { margin-top: 0.6vh; font-size: 2.2vh; color: var(--text-dim); }
	.so .code b { color: #fff; letter-spacing: 0.08em; font-size: 2.6vh; cursor: pointer; }
	.so .tabs { margin-top: 2.4vh; display: flex; align-items: center; gap: 1vw; font-size: 2vh; text-transform: uppercase; font-weight: 600; letter-spacing: 0.04em; }
	.so .tabs .t { color: rgba(185, 194, 200, 0.55); cursor: pointer; white-space: nowrap; }
	.so .tabs .t.on { color: #fff; border-bottom: 0.35vh solid #f2f4f5; padding-bottom: 0.2vh; }
	.so .bump { font-size: 1.5vh; padding: 0.1vh 0.45vw; border-radius: 0.4vh; background: rgba(255,255,255,0.14); color: #fff; }
	.so .list { position: absolute; top: 17vh; left: 0; width: 44vw; }
	.so .row { display: grid; grid-template-columns: 1.2vh 1fr auto; column-gap: 0.8vw; align-items: center; padding: 0.7vh 0.7vw; margin-bottom: 0.3vh;
		background: var(--panel-row); font-size: 2.3vh; font-weight: 600; cursor: pointer; }
	.so .row .sub { grid-column: 2 / 4; font-size: 1.8vh; font-weight: 400; color: var(--text-dim); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
	.so .row .tag { font-size: 1.6vh; color: var(--text-dim); text-transform: uppercase; }
	.so .row.sel { color: #fff; background: linear-gradient(90deg, rgba(255,255,255,0.18), rgba(255,255,255,0.07) 80%, rgba(255,255,255,0.03)); box-shadow: inset 0.25vw 0 0 #f2f4f5; }
	.so .dot { width: 1.2vh; height: 1.2vh; border-radius: 50%; background: rgba(185, 194, 200, 0.35); }
	.so .dot.on { background: #7ad08a; } .so .dot.game { background: #35c9c0; }
	.so .empty { font-size: 2.2vh; color: var(--text-dim); padding: 1vh 0.7vw; line-height: 1.45; }
	.so .side { position: absolute; top: 17vh; left: 47vw; width: 27vw; }
	.so .side .h { background: var(--panel); padding: 0.6vh 0.7vw; font-size: 2.3vh; font-weight: 700; text-transform: uppercase; }
	.so .side .r { margin-left: 1.6vw; background: var(--panel-row); padding: 0.4vh 0.7vw; font-size: 1.95vh; margin-top: 0.25vh; }
	.so .acts { margin: 1.2vh 0 0 1.6vw; }
	.so .acts div { padding: 0.6vh 0.7vw; font-size: 2.2vh; font-weight: 600; text-transform: uppercase; color: var(--text-dim); cursor: pointer; }
	.so .acts div.sel { color: #fff; background: rgba(255,255,255,0.14); box-shadow: inset 0.25vw 0 0 #f2f4f5; }
	.so .status { position: absolute; left: 0; bottom: 6vh; font-size: 1.9vh; color: var(--text-dim); }
	.so .status.warn { color: #e8c35a; }
	.so .keys { position: absolute; left: 0; bottom: 0; display: flex; gap: 1.6vw; font-size: 2.4vh; }
	.so .keys .hint { cursor: pointer; }
	.so .add { position: absolute; inset: 0; display: none; align-items: center; justify-content: center; background: rgba(4, 8, 12, 0.7); }
	.so .add.open { display: flex; }
	.so .add .pbox { width: 44vw; padding: 4vh 3vw; background: linear-gradient(180deg, rgba(40, 56, 70, 0.96), rgba(22, 32, 42, 0.96)); box-shadow: inset 0.25vw 0 0 #f2f4f5; }
	.so .add p { margin: 0 0 2vh; font-size: 2.2vh; color: #b9c2c8; }
	.so .add input { width: 100%; box-sizing: border-box; font: 600 3.6vh var(--font); letter-spacing: 0.08em; text-transform: uppercase; padding: 1vh 1vw; color: #fff;
		background: rgba(0, 0, 0, 0.35); border: 1px solid rgba(255, 255, 255, 0.35); outline: none; }
	.so .add .err { min-height: 2.6vh; margin-top: 1vh; font-size: 2vh; color: #e8a33a; }
	.sotoast { position: fixed; z-index: 1004; left: 50%; top: 3vh; transform: translateX(-50%); display: none; padding: 1.2vh 1.6vw; font-family: var(--font);
		font-size: 2.3vh; color: #fff; background: linear-gradient(180deg, rgba(40, 56, 70, 0.96), rgba(22, 32, 42, 0.96)); box-shadow: inset 0.25vw 0 0 #f2f4f5, 0 1vh 3vh rgba(0,0,0,0.5); }
	.sotoast.on { display: block; }`;
	document.head.appendChild(css);
	const root = document.createElement("div");
	root.className = "so";
	root.innerHTML = `<div class="box"><h1>Friends</h1><div class="code"></div><div class="tabs"></div><div class="list"></div><div class="side"></div>
		<div class="status"></div>
		<div class="keys"><span class="hint" data-a="select"><span class="btn a">A</span>Select</span><span class="hint" data-a="back"><span class="btn b">B</span>Back</span>
		<span class="hint" data-a="star"><span class="btn x">X</span>Add Friend</span><span class="hint" data-a="refresh"><span class="btn y">Y</span>Copy My Code</span></div></div>
		<div class="add"><div class="pbox"><h1>Add a Friend</h1><p>Type their friend code. They find it on their own Friends screen.</p>
		<input maxlength="19" spellcheck="false" autocomplete="off" placeholder="XXXX-XXXX-XXXX-XXXX"><div class="err"></div>
		<div class="keys" style="position:static;margin-top:2vh"><span class="hint" data-p="ok"><span class="btn a">A</span>Add</span><span class="hint" data-p="cancel"><span class="btn b">B</span>Cancel</span></div></div></div>`;
	document.body.appendChild(root);
	const toastEl = document.createElement("div");
	toastEl.className = "sotoast";
	document.body.appendChild(toastEl);
	const input = root.querySelector(".add input"), addErr = root.querySelector(".add .err");
	let toastTimer = 0;

	function toast(text, ms) {
		toastEl.textContent = text;
		toastEl.classList.add("on");
		clearTimeout(toastTimer);
		toastTimer = setTimeout(() => toastEl.classList.remove("on"), ms || 6000);
	}
	function say(text) { note = text; noteUntil = Date.now() + 8000; render(); }

	const friends = () => (snap && snap.friends || []).slice().sort((a, b) => (b.online - a.online) || String(a.name).localeCompare(String(b.name)));
	const party = () => (snap && snap.party) || [];
	const invites = () => (snap && snap.invites || []);
	const nameOf = (code) => { const f = (snap && snap.friends || []).find(x => x.code === code); return f ? f.name : code; };
	function friendLine(f) {
		if (!f.online) return "Offline";
		const where = f.game ? (f.state === "hosting" ? "Hosting " : "Playing ") + (f.game.title || "an online game") : STATE_TEXT[f.state] || "Online";
		const inParty = f.party && snap && (f.party === snap.code || f.party === snap.leader) ? " · In your party" : "";
		return where + inParty;
	}
	function inviteLine(i) {
		if (i.kind === "friend") return `${i.from_name} wants to be friends`;
		if (i.kind === "party") return `${i.from_name} invites you to their party`;
		if (i.kind === "merge_offer") return `${i.from_name} invites your party to join theirs`;
		if (i.kind === "merge_request") return `${i.from_name} asks to bring their party of ${i.size || 2} into yours`;
		return `${i.from_name} invites you to ${i.game && i.game.title ? i.game.title : "their game"}`;
	}
	function rows() {
		if (tab === 0) return friends().map(f => ({ dot: f.game ? "game" : f.online ? "on" : "", name: f.name || f.code, sub: friendLine(f), tag: "", item: f }));
		if (tab === 1) return party().map(m => ({ dot: "on", name: m.name + (m.me ? " (you)" : ""), sub: STATE_TEXT[m.state] || "", tag: m.leader ? "Leader" : "", item: m }));
		return invites().map(i => ({ dot: "on", name: inviteLine(i), sub: `${i.seconds_ago < 60 ? "Just now" : Math.round(i.seconds_ago / 60) + " min ago"}`, tag: { friend: "Friend", game: "Game" }[i.kind] || "Party", item: i }));
	}
	function actionsFor(r) {
		if (!r) return tab === 1 ? partyActions() : [];
		if (tab === 0) {
			const f = r.item, a = [];
			// (your party leader's game: the overlay's own follow, which counts the try; joinFollow)
			if (f.online && f.joinable) a.push({ label: "Join Their Game", run: () => { if (snap && snap.leader === f.code) joinFollow(); else { setLastGame(f.game); api("join", { code: f.code }); joining(f.name); } } });
			const theirParty = f.online && (f.party || f.members > 0) && !f.in_party && f.party !== (snap && snap.code);
			if (theirParty && f.party_privacy !== "invite" && !f.kicked_me) a.push({ label: "Join Their Party", run: () => { api("joinparty", { code: f.code }); say(`Joining ${f.name}'s party...`); } });
			if (f.online) a.push({ label: "Invite to My Party", run: () => { api("invite", { code: f.code, kind: "party" }); say(`Party invite sent to ${f.name}.`); } });
			if (f.online && snap && snap.game) a.push({ label: "Invite to My Game", run: () => { api("invite", { code: f.code, kind: "game" }); say(`Game invite sent to ${f.name}.`); } });
			a.push({ label: "Remove Friend", run: () => { api("friend", { code: f.code, add: false }); say(`${f.name || f.code} removed.`); } });
			return a;
		}
		if (tab === 1) {
			const m = r.item, a = [];
			if (snap && !snap.leader && !m.me && !m.leader) a.push({ label: "Remove from Party", run: () => { api("kick", { code: m.code }); say(`${m.name} was removed from your party.`); } });
			return a.concat(partyActions());
		}
		const i = r.item;
		return [
			{ label: { friend: "Add Friend", party: "Join Party", merge_offer: "Bring My Party", merge_request: "Approve" }[i.kind] || "Join Game",
				run: () => { api("accept", { id: i.id }); if (i.kind === "game") { setLastGame(i.game); joining(i.from_name); } } },
			{ label: i.kind === "merge_request" ? "Decline" : "Dismiss", run: () => { api("dismiss", { id: i.id }); snap.invites = invites().filter(x => x.id !== i.id); } },
		];
	}
	function partyActions() {
		const a = [];
		if (followStopped && snap && snap.leader && snap.follow) a.push({ label: "Join Their Game", run: () => joinFollow() });
		if (snap && snap.leader) a.push({ label: "Leave Party", run: () => { api("leave"); say("You left the party."); } });
		// The leader picks who may join without an invite (cycles through the four).
		if (snap && !snap.leader) a.push({ label: "Privacy: " + privacyName(privacy), run: () => choosePrivacy() });
		a.push({ label: "Invite a Friend", run: () => { tab = 0; row = 0; } });
		return a;
	}
	// What Credits Earned and the challenges count a game joined from here as (as the Server Browser
	// does, browser.js): from its listing's title, "Name · Map · Game type" (social_client.rs title_of).
	function setLastGame(game) {
		if (!game) return;
		const [name, map, mode] = String(game.title || "").split(" · ");
		const ff = typeof FF_MODES !== "undefined" && FF_MODES.some(m => m[0] === mode);
		window.lastGame = { title: map && mode ? mode + " on " + map : game.title || "Online Game", text: name || "Online Game", map: map || "", mode: mode || "",
			difficulty: -1, hosted: false, mod: false, kind: /^Campaign/.test(mode || "") ? "camp" : ff ? "ff" : "mp",
			// (the party leader's teams, when following them: Change Team in the game menu)
			teams: snap && snap.leader && game === snap.follow ? teamsNow() : null };
	}
	// (the same words as the loading screen's banner that comes up under the toast, boot.js joinBanner)
	function joiningText(who) {
		const game = window.lastGame && window.lastGame.title;
		return who ? `Joining ${who}'s game...` : game ? `Joining ${game}...` : "Joining game...";
	}
	function joining(who) {
		document.getElementById("curtain").classList.add("on");
		close();
		toast(window.joinBanner = joiningText(who), 8000);
	}
	// One more try of the party leader's game after following them stopped. Not `join:`, which a party member
	// may not send: the overlay answers `social-follow:` (the curtain and toast, below) or `social-follow-not:`.
	function joinFollow() {
		if (snap && snap.follow_blocked) { play("error"); toast(snap.follow_blocked, 8000); return; }
		post("follow-retry");
	}
	const leaderName = () => (snap && snap.leader ? nameOf(snap.leader) : "your party leader");
	// The page's sentence for a reason from menu-overlay ("the server runs ...", host-probe's words).
	const sentence = (s) => { s = String(s || "").trim(); return s ? s[0].toUpperCase() + s.slice(1) + (/[.!?]$/.test(s) ? "" : ".") : ""; };

	function render() {
		if (!isOpen()) return;
		root.querySelector(".code").innerHTML = snap ? `Your friend code: <b title="Click to copy">${esc(snap.code)}</b>` : "Connecting to the server lists...";
		const b = root.querySelector(".code b");
		if (b) b.onclick = copyCode;
		const counts = [friends().filter(f => f.online).length + "/" + friends().length, party().length || 1, invites().length];
		root.querySelector(".tabs").innerHTML = `<span class="bump">LB</span>` + TABS.map((t, i) => `<span class="t${i === tab ? " on" : ""}" data-t="${i}">${t} (${counts[i]})</span>`).join("") + `<span class="bump">RB</span>`;
		root.querySelectorAll(".tabs .t").forEach(t => t.onclick = () => { tab = +t.dataset.t; row = 0; actions = null; play("bumper"); render(); });
		const list = rows();
		row = Math.min(row, Math.max(0, list.length - 1));
		const el = root.querySelector(".list");
		el.innerHTML = "";
		if (!list.length) {
			const e = document.createElement("div");
			e.className = "empty";
			e.textContent = tab === 0 ? "No friends yet. Press X (or F) to add one by their friend code, and give them yours: it's at the top of this screen."
				: tab === 1 ? "You aren't in a party. Invite a friend from the Friends tab: when you join or host an online game, your party comes with you."
				: "No invites right now.";
			el.appendChild(e);
		}
		const first = Math.max(0, Math.min(row - 4, list.length - 9));
		list.slice(first, first + 9).forEach((r, k) => {
			const i = first + k;
			const d = document.createElement("div");
			d.className = "row" + (i === row ? " sel" : "");
			d.innerHTML = `<span class="dot ${r.dot}"></span><span>${esc(r.name)}</span><span class="tag">${esc(r.tag)}</span><span class="sub">${esc(r.sub)}</span>`;
			d.onmouseenter = () => { if (row !== i && !actions && (!window.MenuScroll || MenuScroll.hoverOk())) { row = i; render(); } };
			d.onclick = () => { row = i; openActions(); };
			el.appendChild(d);
		});
		// More rows than show: a scroll bar beside them (controls.js MenuScroll; a click pages).
		if (window.MenuScroll && list.length > 9) {
			el.insertAdjacentHTML("beforeend", MenuScroll.bar(first, 9, list.length, "right:-1.2vw;top:0;bottom:0"));
			MenuScroll.wire(el, (dir) => { if (dir) { row = Math.max(0, Math.min(list.length - 1, row + (dir === "down" ? 9 : -9))); render(); } });
		}
		const side = root.querySelector(".side");
		const r = list[row];
		side.innerHTML = "";
		if (tab === 1 && snap) {
			side.innerHTML = `<div class="h">My Party</div><div class="r">${party().length ? party().length + " players" : "Just you"}</div>` +
				(snap.leader ? `<div class="r">Following ${esc(nameOf(snap.leader))}</div>` : party().length ? `<div class="r">You lead it</div>` : "") +
				// (why you don't follow them into their game: another version; social_client.rs follow_blocked)
				(snap.leader && snap.follow_blocked ? `<div class="r">${esc(snap.follow_blocked)}</div>` : "") +
				(snap.leader ? "" : `<div class="r">Privacy: ${esc(privacyName(privacy))}</div>`);
		} else if (r && tab === 0) {
			side.innerHTML = `<div class="h">${esc(r.item.name || r.item.code)}</div><div class="r">${esc(r.sub)}</div><div class="r">Code ${esc(r.item.code)}</div>`;
		} else if (r) side.innerHTML = `<div class="h">Invite</div><div class="r">${esc(r.name)}</div>`;
		if (actions) {
			const acts = document.createElement("div");
			acts.className = "acts";
			actions.forEach((a, i) => {
				const d = document.createElement("div");
				d.textContent = a.label;
				if (i === actionRow) d.className = "sel";
				d.onclick = () => { actionRow = i; runAction(); };
				acts.appendChild(d);
			});
			side.appendChild(acts);
		}
		const status = root.querySelector(".status");
		const live = note && Date.now() < noteUntil;
		status.className = "status" + ((error || (snap && snap.error)) && !live ? " warn" : "");
		const banned = snap && snap.moderation && snap.moderation.banned;
		status.textContent = live ? note : error ? error : !snap ? "" : banned ? banned : snap.error ? "Can't reach the server lists: " + snap.error
			: `Online on ${snap.masters_answered} of ${snap.masters} server list${snap.masters === 1 ? "" : "s"}` + (snap.game ? " · " + (snap.state === "hosting" ? "Hosting " : "In ") + (snap.game.title || "an online game") : "");
	}

	function openActions() {
		const list = rows();
		const a = actionsFor(list[row]);
		if (!a.length) { play("error"); return; }
		actions = a;
		actionRow = 0;
		play("select");
		render();
	}
	function runAction() {
		const a = actions && actions[actionRow];
		actions = null;
		if (a) { play("select"); a.run(); }
		render();
	}
	function copyCode() {
		if (!snap) return;
		try { navigator.clipboard.writeText(snap.code); say("Your friend code is copied: paste it to a friend."); } catch (e) { say("Your friend code: " + snap.code); }
		play("y");
	}

	function showPrompt(on) {
		prompt = on;
		root.querySelector(".add").classList.toggle("open", on);
		addErr.textContent = "";
		if (on) { input.value = ""; input.focus(); setTimeout(() => input.focus(), 0); } else input.blur();
	}
	function addFriend() {
		const code = input.value.trim();
		if (!/^[0-9A-Za-z -]{16,22}$/.test(code)) { addErr.textContent = "A friend code has 16 letters and digits, like ABCD-EFGH-JKMN-PQRS."; play("error"); return; }
		api("friend", { code, add: true });
		showPrompt(false);
		say("Adding your friend...");
	}
	input.addEventListener("keydown", (e) => {
		e.stopPropagation();
		if (e.key === "Enter") { e.preventDefault(); addFriend(); }
		else if (e.key === "Escape") { e.preventDefault(); showPrompt(false); }
	});
	root.querySelectorAll("[data-p]").forEach(el => el.onclick = () => el.dataset.p === "ok" ? addFriend() : showPrompt(false));
	root.querySelectorAll(".keys [data-a]").forEach(el => el.onclick = () => action(el.dataset.a));

	function isOpen() { return root.classList.contains("open"); }
	function open() {
		post("social?");
		root.classList.add("open");
		actions = null;
		// Back from the leader's game, the invites are what's new: start there when there are any.
		if (invites().length) tab = 2;
		play("details_in");
		render();
	}
	function close() { root.classList.remove("open"); showPrompt(false); actions = null; }
	function action(a) {
		if (prompt) {
			if (a === "select") addFriend();
			else if (a === "back") showPrompt(false);
			return true;
		}
		if (actions) {
			if (a === "down" || a === "up") { actionRow = (actionRow + (a === "down" ? 1 : actions.length - 1)) % actions.length; play("move"); }
			else if (a === "select") return runAction(), true;
			else if (a === "back" || a === "left") { actions = null; play("back"); }
			render();
			return true;
		}
		const n = rows().length;
		if (a === "down" && n) { row = (row + 1) % n; play("move"); }
		else if (a === "up" && n) { row = (row + n - 1) % n; play("move"); }
		else if (a === "tabl" || a === "left") { tab = (tab + TABS.length - 1) % TABS.length; row = 0; play("bumper"); }
		else if (a === "tabr" || a === "right") { tab = (tab + 1) % TABS.length; row = 0; play("bumper"); }
		else if (a === "select") { openActions(); return true; }
		else if (a === "star") { showPrompt(true); play("select"); return true; }
		else if (a === "refresh") { copyCode(); return true; }
		else if (a === "back" || a === "start" || a === "social") { close(); play("back"); return true; }
		else return true;
		render();
		return true;
	}

	// ---------- the lobby: your party's cards, then your friends ----------

	const lobbyCss = document.createElement("style");
	lobbyCss.textContent = `
	.party { max-height: 84vh; overflow-y: auto; overflow-x: hidden; scrollbar-width: thin; scrollbar-color: rgba(255,255,255,0.3) transparent; }
	.party .row.card { margin-top: 0.3vh; align-items: center; background: rgba(30, 33, 36, 0.9); }
	/* (your own row in your armor color too, like everyone else's: it was only colored while selected) */
	.party .row.player { background: var(--player-row, rgba(30, 33, 36, 0.9)); color: var(--player-row-text, #fff); }
	.party .row.card.sel { background: rgba(53, 201, 192, 0.45); box-shadow: inset 0.25vw 0 0 #f2f4f5; }
	.party .row.card .pright { display: flex; align-items: center; gap: 0.5vw; }
	.party .crown { width: 2.4vh; height: 2.4vh; display: block; }
	.party .row.card.out { background: rgba(30, 33, 36, 0.6); color: rgba(233, 237, 240, 0.7); }
	.party .row.card.out .pemblem { opacity: 0.7; }
	.party .fhead { margin: 1.6vh 0 0 4vw; padding: 0.4vh 0.6vw; font-size: 2vh; font-weight: 700; text-transform: uppercase; letter-spacing: 0.03em; background: var(--panel); color: var(--text); }
	body.partyview.cardrow .party .row.player { background: rgba(30, 33, 36, 0.9) !important; box-shadow: none !important; color: var(--text) !important; }
	.party .fsub { margin: 0.6vh 0 0 4vw; padding: 0.3vh 0.6vw; font-size: 1.8vh; color: var(--text-dim); background: rgba(20, 22, 24, 0.55); }
	.party .fmore { margin: 0.3vh 0 0 4vw; font-size: 1.7vh; color: var(--text-dim); padding: 0.3vh 0.6vw; background: rgba(20, 22, 24, 0.55); }
	.partylead { position: fixed; right: 13vw; bottom: 9vh; display: none; align-items: center; gap: 0.6vw; font-family: var(--font); font-size: 2vh; color: var(--text); text-shadow: 0 0.2vh 0.4vh rgba(0,0,0,0.6); }
	.partylead.on { display: flex; }
	.partylead svg { width: 2.6vh; height: 2.6vh; }
	.party .pteam { font-size: 1.6vh; font-weight: 700; text-transform: uppercase; letter-spacing: 0.04em; opacity: 0.85; }`;
	document.head.appendChild(lobbyCss);
	const CROWN = `<svg class="crown" viewBox="0 0 24 24" aria-hidden="true"><path d="M3 18 L5 7 L10 12 L12 5 L14 12 L19 7 L21 18 Z" fill="#e8c35a"/><rect x="3" y="19" width="18" height="2.4" fill="#e8c35a"/></svg>`;
	const leadLine = document.createElement("div");
	leadLine.className = "partylead";
	document.body.appendChild(leadLine);

	// A player's emblem from their appearance line (`emblem=<front>.<back>.<toggle>.<colors...>`, Emblem.code).
	function emblemOf(card) {
		const m = /(?:^|,)emblem=([0-9a-fA-F.]+)/.exec((card && card.look) || "");
		const d = window.EMBLEM_DATA;
		if (!m || !d) return null;
		const [front, back, toggle, ...colors] = m[1].split(".");
		const pick = (list, i) => (d[list][+i] || d[list][0] || {}).name;
		return { front: pick("front", front), back: pick("back", back), toggle: toggle === "1", colors: colors.length ? colors : undefined };
	}
	const rankOf = (n) => (window.Ranks && Ranks.LIST[Math.min(n || 0, Ranks.LIST.length - 1)]) || null;
	// What a card's status line says (Reach's "In Matchmaking", "In Session...").
	function statusOf(p) {
		if (p.online === false) return "Offline";
		if (p.state === "in_game" || p.state === "hosting") return "In Session" + (p.game && p.game.title ? ": " + p.game.title : "...");
		return p.activity || STATE_TEXT[p.state] || "Online";
	}
	// Every card after your own, in the order the party box shows them: the party (leader first), then
	// friends online and not in it. index.html selects them by this index.
	function cards() {
		const members = party().filter(m => !m.me).map(m => Object.assign({}, m, { member: true, online: true }));
		const out = friends().filter(f => f.online && !f.in_party && !party().some(m => m.code === f.code)).map(f => Object.assign({}, f, { member: false }));
		return members.concat(out).map(c => Object.assign(c, { status: statusOf(c) }));
	}
	let selected = -1;
	const subtitle = document.getElementById("subtitle");
	const localText = subtitle ? subtitle.textContent : "";
	// A player's primary armor color from their look (`color.primary=rrggbb`; an Elite player's own,
	// `elite_color.primary=`), as a row background.
	function rowColor(c) {
		const team = c && c.member !== false ? teamOf(c.code) : -1;
		if (team >= 0) return `background: ${TEAMS[team][1]}e6; color: #fff;`;
		const m = (c && c.elite && /(?:^|,)elite_color\.primary=([0-9a-fA-F]{6})/.exec(c.look || "")) || /(?:^|,)color\.primary=([0-9a-fA-F]{6})/.exec((c && c.look) || "");
		if (!m) return "";
		const n = parseInt(m[1], 16), r = n >> 16, g = (n >> 8) & 255, b = n & 255;
		return `background: rgba(${r}, ${g}, ${b}, ${c.member ? 0.92 : 0.6}); color: ${0.299 * r + 0.587 * g + 0.114 * b > 150 ? "#14181c" : "#fff"};`;
	}
	function cardRow(c, k) {
		const r = rankOf(c.rank);
		return `<div class="row card${c.member ? "" : " out"}${k === selected ? " sel" : ""}" data-k="${k}" style="${k === selected ? "" : rowColor(c)}"><span class="pwho"><span class="pemblem"></span>` +
			`<span class="pnames"><span>${esc(c.name)}</span><span class="ptag">${esc(c.tag || "")}</span></span></span>` +
			`<span class="pright">${c.member && teamOf(c.code) >= 0 ? `<span class="pteam">${TEAMS[teamOf(c.code)][0]}</span>` : ""}${c.leader ? CROWN : ""}<span class="rankicon" style="${r && window.Ranks ? Ranks.picture(r) : ""}" title="${esc(r ? r.name : "")}"></span></span></div>`;
	}
	function lobbyParty() {
		const count = document.getElementById("party-count");
		const n = party().length || 1;
		if (count) count.textContent = n + "/" + (window.MAX_PARTY_PLAYERS || 32);
		if (subtitle) subtitle.textContent = !snap || !party().length ? localText
			: snap.leader && snap.follow_blocked ? snap.follow_blocked
			: snap.leader ? `In ${nameOf(snap.leader)}'s party: you join their online games with them.`
			: `You lead a party of ${n}: they join the online games you host or join.`;
		const box = document.querySelector(".party");
		if (!box) return;
		let list = box.querySelector(".lobbycards");
		if (!list) {
			list = document.createElement("div");
			list.className = "lobbycards";
			box.appendChild(list);
			list.addEventListener("click", (ev) => {
				const row = ev.target.closest("[data-k]");
				if (row && typeof window.partyPick === "function") { ev.stopPropagation(); window.partyPick(+row.dataset.k); }
			});
		}
		const all = cards();
		const members = all.filter(c => c.member), out = all.filter(c => !c.member);
		const me = ((document.getElementById("player") || {}).textContent || "Player").trim();
		let html = members.map(c => cardRow(c, all.indexOf(c))).join("");
		if (snap && (snap.friends || []).length) {
			html += `<div class="fhead">${esc(me)}'s Friends:</div>`;
			const groups = new Map();
			for (const c of out) { if (!groups.has(c.status)) groups.set(c.status, []); groups.get(c.status).push(c); }
			for (const [status, list] of groups) html += `<div class="fsub">${esc(status)}</div>` + list.map(c => cardRow(c, all.indexOf(c))).join("");
			const offline = (snap.friends || []).filter(f => !f.online).length;
			if (offline) html += `<div class="fmore">${offline} offline</div>`;
			if (!out.length && !offline) html += `<div class="fmore">All your friends are in your party.</div>`;
		}
		if (list.dataset.html !== html) {
			list.dataset.html = html;
			list.innerHTML = html;
			if (window.Emblem) list.querySelectorAll("[data-k]").forEach(row => {
				const e = emblemOf(all[+row.dataset.k]);
				if (e) Emblem.paint(row.querySelector(".pemblem"), e);
			});
		}
		if (wearing) {
			const open = all.find(c => c.code === wearing);
			if (open && open.look && open.look !== woreLook) wear(open);
		}
		const leader = party().find(m => m.leader);
		const playerRow = box.querySelector(".row.player");
		let myCrown = playerRow && playerRow.querySelector(".mycrown");
		if (playerRow && !myCrown) {
			myCrown = document.createElement("span");
			myCrown.className = "mycrown";
			myCrown.style.cssText = "display:inline-flex;margin-left:auto;margin-right:0.5vw";
			myCrown.innerHTML = CROWN;
			playerRow.insertBefore(myCrown, playerRow.querySelector(".rankicon"));
		}
		if (myCrown) myCrown.style.display = leader && leader.me ? "inline-flex" : "none";
		// Your own row in your team's color in a team game (your armor color otherwise, index.html).
		if (playerRow) {
			const t = myTeam();
			playerRow.style.background = t >= 0 ? TEAMS[t][1] + "e6" : "";
			playerRow.style.color = t >= 0 ? "#fff" : "";
		}
		sendTeam();
		leadLine.innerHTML = leader ? `${CROWN}<span>${esc(leader.me ? "You are" : leader.name + " is")} the party leader.</span>` : "";
		leadLine.classList.toggle("on", !!leader && !document.body.classList.contains("ingame"));
	}
	// ---------- teams ----------

	const NO_TEAMS = { mask: 0, changing: 0, of: {} };
	// The teams this player's own lobby has (teamRules, from index.html; null until it says).
	let rulesWant = null;
	// Leading (or alone) in a lobby without teams: no teams, whatever the browser's picture still says
	// (0.1.18 report: the Matchmaking card stayed Team Red when Custom Games' rules never reached it).
	const teamsNow = () => (snap && !snap.leader && rulesWant && !rulesWant.mask ? NO_TEAMS : (snap && snap.teams) || NO_TEAMS);
	const teamGame = () => !!teamsNow().mask;
	// A player's team in the lobby (-1: none, or not a team game).
	function teamOf(code) {
		const t = teamsNow();
		if (!t.mask || !snap) return -1;
		const v = (t.of || {})[code || snap.code];
		return typeof v === "number" && v >= 0 && v < 8 ? v : -1;
	}
	const myTeam = () => (snap ? teamOf(snap.code) : -1);
	// The leader's lobby (index.html, Custom Games): its game type's teams (bits) and Team Changing (0-2).
	// Sent again until the browser's picture has them (a call that failed, or a browser that kept an
	// older lobby's teams), at most every 3 s.
	let rulesSentAt = 0;
	function teamRules(mask, changing) {
		const want = { mask: mask & 255, changing: Math.max(0, Math.min(2, changing | 0)) };
		if (!rulesWant || rulesWant.mask !== want.mask || rulesWant.changing !== want.changing) { rulesWant = want; rulesSentAt = 0; }
		syncRules();
	}
	function syncRules() {
		if (!rulesWant || !snap || snap.leader) return;
		const t = snap.teams || NO_TEAMS;
		if ((t.mask | 0) === rulesWant.mask && (t.changing | 0) === rulesWant.changing) return;
		if (rulesSentAt && Date.now() - rulesSentAt < 3000) return;
		rulesSentAt = Date.now();
		api("teams", { team_mask: rulesWant.mask, team_changing: rulesWant.changing });
	}
	// This player's team to their game (the overlay keeps it for the next game and sends it to a running one).
	let teamSent = null;
	function sendTeam() {
		const t = myTeam();
		if (t === teamSent) return;
		teamSent = t;
		post("team:" + t);
	}
	// Whether this player may change `code`'s team (null: their own): the leader anyone's; a member their
	// own when Team Changing allows it (the leader checks Balancing Only).
	function canChangeTeam(code) {
		if (!teamGame() || !snap) return false;
		const leading = !snap.leader;
		const own = !code || code === snap.code;
		if (leading) return own || party().some(m => m.code === code);
		return own && teamsNow().changing > 0;
	}
	// Change Team for `card` (null: yourself): a list of the game type's teams.
	function chooseTeam(card) {
		const code = card ? card.code : snap && snap.code;
		if (!canChangeTeam(code)) {
			play("error");
			toast(!teamGame() ? "This game type has no teams." : snap && snap.leader && code !== snap.code ? "Only the party leader moves other players."
				: "This game type's Team Changing is Not Allowed: ask the party leader to move you.", 5000);
			return;
		}
		const mask = teamsNow().mask;
		const options = TEAMS.map((t, i) => [String(i), t[0] + " Team"]).filter((o, i) => mask >> i & 1);
		const name = card ? card.name : "your";
		const go = (v) => {
			const team = +v;
			if (!(mask >> team & 1)) return;
			api("team", snap && !snap.leader ? { code: code === snap.code ? "" : code, team } : { team });
			play("select");
			if (snap && snap.leader) toast(teamsNow().changing === 2 ? `Asked for ${TEAMS[team][0]} Team: you move when it keeps the teams even.` : `Asked for ${TEAMS[team][0]} Team.`, 4000);
		};
		if (window.Dropdown) Dropdown.open({ title: card ? `${card.name}'s Team` : "Your Team", value: String(teamOf(code)), options, onPick: go });
		else go(String(TEAMS.findIndex((t, i) => i > teamOf(code) && mask >> i & 1)));
	}

	function select(k) {
		selected = k;
		const box = document.querySelector(".party");
		if (!box) return;
		const all = cards();
		box.querySelectorAll(".row.card").forEach(r => { r.classList.toggle("sel", +r.dataset.k === k); r.style.cssText = +r.dataset.k === k ? "" : rowColor(all[+r.dataset.k]); });
		const row = box.querySelector(`.row.card[data-k="${k}"]`);
		if (row) row.scrollIntoView({ block: "nearest" });
		else if (k < 0) box.scrollTop = 0;
	}

	// ---------- your card, and looking at other players' characters ----------

	// Your appearance line, as the Armory last sent it (`appearance:...`, start-menu.js sendAppearance), and
	// whose look is on the menus' Spartan while you look at another player's card.
	let ownLook = null;
	let wearing = null;
	let woreLook = "";
	// What puts your own look back first while another player's look is on: a game starting, armor for a match,
	// leaving. Everything else passes. (It was the other way round, a list of what may pass, and every message
	// missing from it put your armor back: the chat's poll every 2 s, so a friend's card showed your armor in
	// their colors after 2 seconds; an Elite friend's `card-elite:1` at once. Player report, 2026-10-18.)
	const RESTORE = ["play:", "host", "join:", "follow-retry", "campaign:", "firefight:", "dedicated", "armor:", "mod:", "modmap:", "variants:", "rotation:", "quit", "update-now"];
	let send = (m) => { if (window.chrome && window.chrome.webview) window.chrome.webview.postMessage(m); };
	if (window.chrome && window.chrome.webview) {
		try {
			const wv = window.chrome.webview, orig = wv.postMessage.bind(wv);
			send = orig;
			wv.postMessage = (m) => {
				const t = String(m);
				if (t.startsWith("appearance:")) {
					ownLook = t.slice(11);
					// (another player's look is on: yours goes back when their card closes, not now)
					if (wearing) return;
				}
				else if (wearing && RESTORE.some(p => t.startsWith(p))) wear(null);
				return orig(m);
			};
		} catch (e) { }
	}
	// Puts `card`'s look on the menus' Spartan (null: yours back).
	function wear(card) {
		if (!card || !card.look || ownLook === null) {
			if (wearing && ownLook !== null) send("appearance:" + ownLook);
			wearing = null;
			woreLook = "";
			return false;
		}
		// (again when they change their look while their card is open)
		// (`appearance-view:`, not `appearance:`: the menus program keeps your own look for every game start)
		if (wearing !== card.code || woreLook !== card.look) { wearing = card.code; woreLook = card.look; send("appearance-view:" + card.look); }
		return true;
	}
	window.addEventListener("beforeunload", () => wear(null));
	let lastCard = "";
	let privacySent = false;
	const seenNotes = new Set();
	function syncCard() {
		const text = (id) => ((document.getElementById(id) || {}).textContent || "").trim();
		const name = text("player");
		if (!name || name === "Player") return;
		const r = window.Ranks ? Ranks.of(Ranks.credits()) : null;
		const card = { name, card: true, tag: text("player-tag"), rank: r ? r.index : 0, activity: text("party-state"), look: ownLook || "",
			elite: typeof StartMenu !== "undefined" && StartMenu.playsElite ? StartMenu.playsElite() : false };
		const key = JSON.stringify(card);
		if (key !== lastCard) { lastCard = key; api("me", card); }
	}

	// A rank a moderator set (PROTOCOL.md "Moderation"; the masters enforce what others see): adopted
	// once per `rev` (its credits, or the rank's own), and put back while it is locked.
	function moderated(m) {
		if (!m || !m.rank || !window.Ranks) return;
		const r = m.rank, rank = Ranks.LIST[r.rank] || Ranks.LIST[0];
		const want = r.credits != null ? r.credits : rank.at;
		let rev = 0;
		try { rev = +localStorage.getItem("rr.modRankRev") || 0; } catch (e) { }
		const fresh = rev !== r.rev;
		if (!fresh && !(r.locked && Ranks.of(Ranks.credits()).index !== rank.index)) return;
		try { localStorage.setItem("rr.credits", String(want)); localStorage.setItem("rr.modRankRev", String(r.rev)); } catch (e) { }
		window.dispatchEvent(new Event("rr-credits"));
		lastCard = "";
		if (fresh) { toast(`A moderator set your rank to ${rank.name}.`); play("details_in"); }
	}

	function state(json) {
		let s;
		try { s = JSON.parse(json); } catch (e) { return; }
		snap = s;
		error = "";
		// The browser keeps the player's name and card as the menus show them.
		if (s.name !== ((document.getElementById("player") || {}).textContent || "").trim()) lastCard = "";
		moderated(s.moderation);
		syncCard();
		if (!privacySent) { privacySent = true; if (privacy !== "friends") api("privacy", { privacy }); }
		// Each note once, by id; on the first picture, only the last half minute's (a page reload).
		for (const n of s.notes || []) {
			if (typeof n !== "object" || seenNotes.has(n.id)) continue;
			seenNotes.add(n.id);
			if (!firstState || n.age_seconds < 30) { toast(n.text); play("details_in"); }
		}
		// The leader is in a game of another version, which you don't follow them into: said once each time.
		if ((s.follow_blocked || "") !== followBlockedSaid) {
			followBlockedSaid = s.follow_blocked || "";
			if (followBlockedSaid) { toast(followBlockedSaid, 10000); play("details_in"); }
		}
		for (const i of s.invites || []) {
			if (seenInvites.has(i.id)) continue;
			seenInvites.add(i.id);
			if (!firstState && !isOpen()) { toast(inviteLine(i) + ". Open Friends from the main menu (or press P) to answer."); play("details_in"); }
		}
		firstState = false;
		syncRules();
		lobbyParty();
		render();
	}

	if (window.chrome && window.chrome.webview) {
		window.chrome.webview.addEventListener("message", (e) => {
			const text = String(e.data);
			if (text.startsWith("social:")) state(text.slice(7));
			else if (text.startsWith("social-reply:")) {
				const [route, json] = text.slice(13).split(/\|(.*)/s);
				let r = {};
				try { r = JSON.parse(json || "{}"); } catch (err) { }
				if (route === "friend" && r.note) say("Added. They'll see your request when they're online: " + r.note);
				else if (route === "friend" && r.code) say("Added. They'll show as online once they've added you back or come online.");
				else if (route === "invite" && r.merge) { const t = `${r.invited} is in ${r.leader_name || "another player"}'s party. They were asked to bring the whole party; you'll get their request to approve.`; say(t); toast(t); }
				else if (route === "accept" && r.asked) say(`Asked ${r.asked_name} to take your party. Your party moves once they approve.`);
				else if (route === "accept" && r.merged) say(`${r.merged_name}'s party of ${r.size || 2} is joining yours.`);
				else if (route === "accept" && r.leader) say(`You're in ${nameOf(r.leader)}'s party.`);
				else if (route === "joinparty" && r.leader) say(`You're in ${nameOf(r.leader)}'s party.`);
				else if (route === "accept" && r.friend) say("Friend added.");
			} else if (text.startsWith("social-error:")) {
				const [route, msg] = text.slice(13).split(/\|(.*)/s);
				play("error");
				if (route === "join" || route === "accept") { document.getElementById("curtain").classList.remove("on"); toast("Couldn't join: " + msg); }
				if (route === "start") error = "Friends need online play: " + msg;
				else say(msg || "Something went wrong.");
			} else if (text.startsWith("left-game:")) {
				// Back from a joined game that ended early (menu-overlay post_left_reason).
				const why = text.slice(10);
				toast(why === "host" ? "The host left the game." : why === "banned" ? "The host banned you from that game." : "The host removed you from that game.", 8000);
				play("error");
			} else if (text === "party-locked") {
				play("error");
				document.getElementById("curtain").classList.remove("on");
				toast(`You're in ${snap && snap.leader ? nameOf(snap.leader) : "someone"}'s party: only the party leader starts games.`, 6000);
			} else if (text.startsWith("social-follow:")) {
				followStopped = false;
				setLastGame(snap && snap.follow);
				document.getElementById("curtain").classList.add("on");
				close();
				toast(window.joinBanner = joiningText(snap && snap.leader ? nameOf(snap.leader) : "your party leader"), 8000);
			} else if (text.startsWith("social-follow-retry:")) {
				// The follow's join failed once: why, and the one automatic retry (menu-overlay online.rs).
				const [secs, why] = text.slice(20).split(/\|(.*)/s);
				document.getElementById("curtain").classList.remove("on");
				toast(`Couldn't join ${leaderName()}'s game. ${sentence(why)} Trying once more in ${+secs || 20} seconds.`, 10000);
			} else if (text.startsWith("social-follow-failed:")) {
				// It failed again: no more automatic joins of that game (until your leader moves on); Join Their
				// Game in Friends > Party tries once more.
				followStopped = true;
				play("error");
				document.getElementById("curtain").classList.remove("on");
				toast(`Couldn't join ${leaderName()}'s game. ${sentence(text.slice(21))} To try again: Friends (P) > Party > Join Their Game.`, 14000);
				render();
			} else if (text.startsWith("social-follow-stopped:")) {
				// You cancelled the mod download or left their game, or the host removed you: you stay here.
				followStopped = true;
				const how = text.slice(22);
				if (how === "left") toast(`You left ${leaderName()}'s game. Friends (P) > Party > Join Their Game takes you back.`, 8000);
				else if (how === "declined") toast(`You stayed in the menus. Friends (P) > Party > Join Their Game when you're ready.`, 8000);
				render();
			} else if (text.startsWith("social-follow-not:")) {
				play("error");
				// (not through sentence(): it capitalized the leader's player name)
				const who = snap && snap.leader ? nameOf(snap.leader) : "Your party leader";
				toast(text.slice(18) === "busy" ? `Already joining ${leaderName()}'s game.` : `${who} isn't in an online game you can join right now.`, 6000);
			}
		});
		// Presence starts with the menus, so friends see this player online without opening Friends.
		post("social?");
	}
	setInterval(() => { if (isOpen()) render(); }, 1000);
	// The player's own card (and a moderator's locked rank) on a timer of its own: `social:` now only
	// comes when the picture changed (menu-overlay online.rs, owner report 2026-10-19), and a new look
	// from the Armory or a move to another lobby must still reach the other players. The lobby's party
	// lines too: the leader line hides while the game menu is up (`ingame`), and no new picture says so.
	setInterval(() => { if (snap) { moderated(snap.moderation); syncCard(); lobbyParty(); } }, 2000);

	// (setState: demos and page tests, as Browser.setResult.)
	// Party privacy, picked from a list (Open: anyone joins from your card without asking; owner, 2026-10-17).
	function setPrivacy(p) {
		privacy = p;
		try { localStorage.setItem("rr.party.privacy", privacy); } catch (e) { }
		api("privacy", { privacy });
		toast("Party privacy: " + privacyName(privacy) + ".", 4000);
		lobbyParty();
		render();
	}
	function choosePrivacy(anchor) {
		if (snap && snap.leader) { toast("Only the party leader sets its privacy.", 4000); return; }
		if (window.Dropdown) {
			Dropdown.open({ title: "Party Privacy", value: privacy, anchor: anchor || null,
				options: [["open", "Open: anyone can join"], ["fof", "Friends of Friends"], ["friends", "Friends Only"], ["invite", "Invite Only"]],
				onPick: (v) => setPrivacy(v) });
		} else setPrivacy(PRIVACY[(PRIVACY.findIndex(x => x[0] === privacy) + 1) % PRIVACY.length][0]);
	}
	// Whether this player may join a friend's party from their card: its privacy lets them in.
	function canJoin(c) {
		if (!c || c.member || !c.online || c.kicked_me) return false;
		const leaderIsFriend = !c.party || (snap && (snap.friends || []).some(f => f.code === c.party));
		return c.party_privacy === "open" || c.party_privacy === "fof" || (c.party_privacy !== "invite" && leaderIsFriend);
	}
	// A on a friend's card outside your lobby: "Are you sure?", then join their party (owner, 2026-10-17).
	function joinFriend(c) {
		if (!c) return;
		const go = () => { api("joinparty", { code: c.code }); toast(`Joining ${c.name}'s party...`, 4000); };
		if (!canJoin(c)) {
			play("error");
			toast(c.kicked_me ? `${c.name}'s party leader removed you: they can invite you back.` : c.party_privacy === "invite"
				? `${c.name}'s party is invite only: ask for an invite.` : `${c.name}'s party isn't open to you: ask for an invite.`, 6000);
			return;
		}
		if (window.Dropdown) Dropdown.open({ title: `Join ${c.name}'s party?`, value: "no", options: [["no", "No"], ["yes", "Yes, join"]],
			onPick: (v) => { if (v === "yes") { play("select"); go(); } } });
		else go();
	}
	// Whether this player leads a party with other players in it.
	const leadsParty = () => !!snap && !snap.leader && party().some(m => !m.me);
	// A game is starting: a party leader is told when the party can't come along.
	function starting(hostable) {
		if (leadsParty() && !hostable) toast("Your party can't follow you into this game: host a Custom Game to play together.", 8000);
	}
	return { open, close, isOpen, action, setState: state, toggle() { isOpen() ? close() : open(); }, leadsParty, starting, say: (t) => toast(t, 6000),
		// The lobby (index.html renderParty): the cards after yours, picking one, wearing its look.
		cards, select, wear, emblemOf, rankOf, wearingOther: () => !!wearing,
		// The lobby's Invite Friend (index.html, Y on a friend's card outside your lobby).
		inviteToParty(c) { api("invite", { code: c.code, kind: "party" }); toast(`Party invite sent to ${c.name}.`, 4000); },
		choosePrivacy, joinFriend, canJoin, leading: () => !snap || !snap.leader,
		// Teams (index.html's lobby and game menu, scoreboard.js).
		TEAMS, teamRules, teamOf, myTeam, teamGame, canChangeTeam, chooseTeam, teams: () => teamsNow(),
		// In someone else's party: no games of your own until you lead or leave (owner, 2026-10-18); the
		// line says why (index.html greys Start Game out, browser.js refuses joins, menu-overlay refuses too).
		following: () => !!snap && !!snap.leader,
		followingNote: () => `You're in ${snap && snap.leader ? nameOf(snap.leader) : "someone"}'s party: only the party leader starts games. Leave the party to play on your own.`,
		// The in-game scoreboard (scoreboard.js): who a name in the match is, from the masters' list of the
		// players in this game ({code, name, friend}, or null), and a friend request to them.
		inGame(name) {
			const n = String(name || "").trim().toLowerCase();
			if (!n || !snap) return null;
			// (the game keeps 15 characters of a name)
			const same = (x) => { const m = String(x || "").trim().toLowerCase(); return m === n || (n.length >= 15 && m.startsWith(n)); };
			const found = (snap.in_game || []).filter(p => same(p.name));
			if (found.length !== 1) return null;
			const p = found[0];
			return { code: p.code, name: p.name, friend: p.friend || (snap.friends || []).some(f => f.code === p.code) };
		},
		addFriend(p) { api("friend", { code: p.code, add: true, name: p.name }); },
		// The waiting room (waiting-room.js): the last social picture, for the party and who is in this game.
		picture: () => snap,
		partyInfo: () => { const l = party().find(m => m.leader); return { count: party().length || 1, leader: l ? l.name : null, privacy: privacyName(privacy) }; } };
})();
