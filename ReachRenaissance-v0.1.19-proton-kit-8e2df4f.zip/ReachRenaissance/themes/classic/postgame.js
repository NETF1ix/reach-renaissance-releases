// CREDITS EARNED (owner, 2026-10-12): Reach's end-of-game screen, after every finished match. The
// Spartan does Reach's end-of-game victory animation on the right (owner, 2026-10-16: not turning); on the left each award comes in with its graphic and its
// credits counting up, then the total, then the player's rank bar fills. Clouds, arcs and streaks of
// text drift behind it, as on the 360.
//
// The overlay program sends `results:<minutes>|<results.json>` (host-probe's results.rs: every
// player's name, team, score, kills, deaths). Pictures come from Reach's own exit-experience screen
// (scripts/menu/extract_postgame.py, postgame/*.png). The credit amounts are this project's own (the
// 360 got them from Bungie's servers): game complete, time spent, a performance bonus for the top
// three or the winning team, and the commendation levels and challenges the game completed (career.js).
const Postgame = (() => {
	const css = `
	.pg { position: fixed; inset: 0; z-index: 1001; display: none; overflow: hidden; color: #f2f4f5; font-family: inherit;
		/* (opaque: the menus' live backdrop showed through on the right, the rain and rocks behind the Spartan;
		   owner, two-PC test 2026-10-17) */
		background: linear-gradient(270deg, rgb(22,34,48) 0%, rgb(14,26,40) 40%, rgb(8,18,30) 55%, rgb(8,18,30) 100%); }
	.pg.open { display: block; }
	.pg .pgfig { position: absolute; z-index: 3; pointer-events: none; transition: opacity 0.6s; }
	.pg .pgfig.out { opacity: 0; }
	body.postgame #figure { z-index: 1002; }
	body.postgame .screen, body.postgame .shade, body.postgame .tag, body.postgame .party, body.postgame .details,
	body.postgame .sm, body.postgame .ar { visibility: hidden; }
	/* The clouds drift by moving their layer (one picture's width a loop), not their background: a moving
	   background repainted both full-screen layers every frame, a core's worth of work (2026-10-17).
	   Everything here moves in steps of 1/30 s (the 360's own frame rate), all on the same beat: drawn at the
	   screen's rate, this screen kept half a core busy just putting its layers together.
	   No blend modes or masks on the moving layers either: each one needs a picture of its own, drawn off screen
	   and blended again at every step (2026-10-20 player batch, report 7: "laggy and choppy"). Over this dark
	   background plain blending looks like the screen blending they had (measured on the pictures): clouds1 is
	   white, so the same; clouds and the streaks are within 2/255; the arcs within 5/255 (99% of their pixels,
	   at the flicker's brightest). The mask faded the clouds' top: clouds1 fades there itself (the mask kept
	   96% of it); clouds' top edge (7vh down at 16:9) is a little brighter now. */
	.pg .clouds { position: absolute; top: -10%; bottom: -10%; left: -130vw; right: -10%; background: url(postgame/clouds1.png) repeat-x 0 30% / 120vw auto; opacity: 0.16;
		animation: pg-drift 30s steps(900) infinite; will-change: transform; }
	.pg .clouds.b { left: -80vw; background-image: url(postgame/clouds.png); background-size: 70vw auto; opacity: 0.10;
		animation-name: pg-drift-b; animation-duration: 26s; animation-timing-function: steps(780); animation-direction: reverse; }
	@keyframes pg-drift { from { transform: translateX(0); } to { transform: translateX(120vw); } }
	@keyframes pg-drift-b { from { transform: translateX(0); } to { transform: translateX(70vw); } }
	.pg .arcs { position: absolute; width: 22vw; height: 22vw; left: 34vw; top: 4vh; background: url(postgame/electric_arcs.png) center / contain no-repeat;
		opacity: 0; animation: pg-flicker 3.7s steps(1) infinite; }
	.pg .arcs.b { right: 30vw; top: 58vh; width: 16vw; height: 16vw; animation-delay: 1.6s; animation-duration: 4.3s; }
	@keyframes pg-flicker { 0% { opacity: 0; } 8% { opacity: 0.55; } 11% { opacity: 0.1; } 14% { opacity: 0.4; } 20% { opacity: 0; } }
	.pg .streak { position: absolute; left: -30vw; height: 1.4vh; width: 26vw; background: url(postgame/wordblur.png) center / 100% 100% no-repeat;
		opacity: 0.35; animation: pg-streak infinite; }
	@keyframes pg-streak { from { transform: translateX(0); } to { transform: translateX(160vw); } }
	.pg .words { position: absolute; left: 0; white-space: nowrap; font-size: 9vh; font-weight: 700; letter-spacing: 0.08em; text-transform: uppercase;
		color: rgba(160,200,235,0.035); animation: pg-words infinite; }
	@keyframes pg-words { from { transform: translateX(-50%); } to { transform: translateX(0); } }
	/* Still until the Spartan shows (.run, show() below): the menu game restarts under this screen, and its first
	   seconds are its slowest (2026-10-20 player batch, report 7). */
	.pg .clouds, .pg .words, .pg .streak, .pg .arcs { animation-play-state: paused; }
	.pg.run .clouds, .pg.run .words, .pg.run .streak, .pg.run .arcs { animation-play-state: running; }
	.pg .head { position: absolute; left: 8vw; top: 9vh; }
	.pg .head h1 { margin: 0; font-size: 6.4vh; font-weight: 700; letter-spacing: 0.02em; text-transform: uppercase; }
	.pg .head .sub { font-size: 2.6vh; color: #b9c2c8; text-transform: uppercase; letter-spacing: 0.04em; margin-top: 0.4vh; }
	.pg .rows { position: absolute; left: 8vw; top: 22vh; width: 40vw; }
	.pg .row { display: flex; align-items: center; height: 9vh; margin-bottom: 1vh; padding: 0 1vw 0 0; opacity: 0; transform: translateX(4vw);
		transition: opacity 0.35s, transform 0.35s; background: linear-gradient(90deg, rgba(255,255,255,0.10), rgba(255,255,255,0.02) 80%, transparent); }
	.pg .row.in { opacity: 1; transform: none; }
	/* five or six rows (commendations and challenges too): smaller, so they stay above the total */
	.pg .rows.many .row { height: 6.8vh; margin-bottom: 0.6vh; }
	.pg .rows.many .row .g { width: 6.8vh; height: 6.8vh; }
	.pg .rows.many .row .n { font-size: 2.8vh; }
	.pg .row .g { position: relative; width: 9vh; height: 9vh; flex: none; background: url(postgame/ring.png) center / 90% no-repeat; }
	.pg .row .g i { position: absolute; inset: 1.4vh; background: center / contain no-repeat; }
	.pg .row .g b { position: absolute; left: 50%; top: 22%; width: 0.6vh; height: 2.9vh; margin-left: -0.3vh; background: url(postgame/time_clock_hand.png) center / 100% 100%;
		transform-origin: 50% 100%; animation: pg-hand 1.2s steps(36) infinite; }
	@keyframes pg-hand { to { transform: rotate(360deg); } }
	.pg .row .n { flex: 1; margin-left: 1.2vw; font-size: 3.2vh; font-weight: 600; text-transform: uppercase; letter-spacing: 0.03em; }
	.pg .row .n small { display: block; font-size: 2vh; font-weight: 500; color: #b9c2c8; text-transform: none; letter-spacing: 0; }
	.pg .row .v { font-size: 3.6vh; font-weight: 700; font-variant-numeric: tabular-nums; }
	.pg .total { position: absolute; left: 8vw; top: 67vh; width: 40vw; display: flex; justify-content: space-between; align-items: baseline;
		border-top: 1px solid rgba(255,255,255,0.25); padding-top: 1.4vh; opacity: 0; transition: opacity 0.4s; }
	.pg .total.in { opacity: 1; }
	.pg .total .n { font-size: 3.4vh; font-weight: 700; text-transform: uppercase; }
	.pg .total .v { font-size: 5.4vh; font-weight: 700; color: #ffd36b; font-variant-numeric: tabular-nums; text-shadow: 0 0 2vh rgba(255,200,90,0.35); }
	.pg .bar { position: absolute; left: 8vw; top: 77vh; width: 40vw; height: 8vh; display: flex; align-items: center; gap: 1vw; opacity: 0; transition: opacity 0.4s; }
	.pg .bar.in { opacity: 1; }
	.pg .bar .rank { width: 8vh; height: 8vh; flex: none; }
	.pg .bar .who { flex: 1; }
	.pg .bar .who .nm { font-size: 3vh; font-weight: 700; }
	.pg .bar .who .rk { font-size: 2.2vh; color: #b9c2c8; text-transform: uppercase; }
	.pg .bar .track { height: 1.2vh; margin-top: 0.6vh; background: rgba(255,255,255,0.12); }
	.pg .bar .track i { display: block; height: 100%; width: 0; background: linear-gradient(90deg, #8fc6f0, #e9f5ff); transition: width 1.6s ease-out; }
	.pg .bar .cr { font-size: 2.2vh; color: #b9c2c8; text-align: right; margin-top: 0.4vh; font-variant-numeric: tabular-nums; }
	.pg .promoted { position: absolute; left: 8vw; top: 86vh; font-size: 3vh; font-weight: 700; color: #ffd36b; text-transform: uppercase; opacity: 0; transition: opacity 0.4s; }
	.pg .promoted.in { opacity: 1; }
	.pg .keys { position: absolute; left: 8vw; top: 91vh; display: flex; gap: 1.6vw; font-size: 2.7vh; }
	.pg .keys .hint { cursor: pointer; }
	`;
	// Reach's ranks and their credits (ranks.js).
	const STORE = "rr.credits";
	let root = null, timers = [], spin = null, finish = null, drift = null;

	function credits() { try { return +localStorage.getItem(STORE) || 0; } catch (e) { return 0; } }
	function saveCredits(n) { try { localStorage.setItem(STORE, String(n)); } catch (e) { } }
	const rankOf = (total) => Ranks.of(total);
	const nextOf = (rank) => Ranks.next(rank);
	const esc = (s) => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
	const fmt = (n) => Math.round(n).toLocaleString("en-US");
	const play = (n) => { if (typeof Sound !== "undefined") Sound.play(n); };

	// The awards for the local player from the results.
	function awards(results, minutes, playerName) {
		const players = results.players || [];
		// Our row: the one host-probe marks as ours (results.rs `local`, by user id), else the one with our name. Never
		// someone else's: player 0 (normally the host) stood in when no name matched, and a guest's Credits Earned
		// showed the host's name, place and awards (2026-10-20 player batch, report 20). Not found: our name and no
		// place (no Performance Bonus, not a win).
		const found = players.find(p => p.local) || players.find(p => p.name === playerName);
		const me = found || { name: playerName, score: 0, kills: 0, team: -1 };
		const teamGame = players.some(p => p.team >= 0 && p.team !== me.team) && new Set(players.map(p => p.team)).size > 1 && me.team >= 0 && me.team < 8;
		let place = 0;
		if (found && teamGame) {
			const scores = results.team_scores || [];
			const mine = scores[me.team] ?? 0;
			place = 1 + scores.filter((s, t) => t !== me.team && s > mine).length;
		} else if (found) {
			place = 1 + players.filter(p => p.score > me.score).length;
		}
		const kills = Math.max(0, Math.round(me.kills || 0));
		const list = [
			// (a game under 2 minutes pays a quarter: a solo 1-minute game paid 265 cR, easy to farm; bug sweep 2026-10-17)
			{ name: "Game Complete", note: (window.lastGame && window.lastGame.text) || "", value: minutes < 2 ? 25 : 100, g: "graphic_reach_wings" },
			{ name: "Time Spent", note: minutes + (minutes === 1 ? " minute" : " minutes"), value: Math.min(300, 15 * minutes), g: "time_clock_face", clock: true },
		];
		// (only with someone to beat: another player or team)
		const rivals = teamGame || players.length > 1;
		if (rivals && place >= 1 && place <= 3) list.push({ name: "Performance Bonus", note: teamGame ? (place === 1 ? "Your team won" : "Your team placed " + ordinal(place)) : ordinal(place) + " place",
			value: place === 1 ? 150 : 75, g: "graphic_winning_bonus" });
		// Commendation levels reached and challenges completed in this game (career.js), as on the 360's
		// exit experience; before career.js, credits for kills stood in.
		const lg = window.lastGame || {};
		if (typeof Career !== "undefined") list.push(...Career.record(me, { kind: lg.kind, map: lg.map, mode: lg.mode, difficulty: lg.difficulty,
			minutes, players: players.length, won: place === 1, place, teamGame, hosted: !!lg.hosted, mod: !!lg.mod }));
		else if (kills) list.push({ name: "Commendations", note: kills + (kills === 1 ? " kill" : " kills"), value: kills * 5, g: "graphic_commendation_wings" });
		return { list: list.filter(a => a.value > 0), me };
	}
	function ordinal(n) { return n + (n === 1 ? "st" : n === 2 ? "nd" : n === 3 ? "rd" : "th"); }

	function countUp(el, to, ms, prefix, suffix = "", from = 0) {
		const t0 = performance.now();
		const tick = (now) => {
			const k = Math.min(1, (now - t0) / ms);
			el.textContent = prefix + fmt(from + (to - from) * (1 - Math.pow(1 - k, 3))) + suffix;
			if (k < 1 && root.classList.contains("open")) requestAnimationFrame(tick);
		};
		requestAnimationFrame(tick);
	}
	const later = (ms, f) => timers.push(setTimeout(f, ms));

	function show(text, playerName) {
		const bar = text.indexOf("|");
		const minutes = Math.max(0, parseInt(text.slice(0, bar), 10) || 0);
		let results;
		try { results = JSON.parse(text.slice(bar + 1)); } catch (e) { return; }
		if (!root) {
			const style = document.createElement("style");
			style.textContent = css;
			document.head.appendChild(style);
			root = document.createElement("div");
			root.className = "pg";
			document.body.appendChild(root);
		}
		close(true);
		// (the match's pause menu, left open when the game ended, showed through with its player card and
		// Exit hint; owner, 2026-10-17)
		if (typeof StartMenu !== "undefined") StartMenu.dismiss();
		const { list, me } = awards(results, minutes, playerName);
		const total = list.reduce((s, a) => s + a.value, 0);
		const before = credits(), after = before + total;
		saveCredits(after);
		window.dispatchEvent(new Event("rr-credits"));
		const rank = rankOf(before), rankAfter = rankOf(after), next = nextOf(rankAfter);
		// (three of the nine streaks there were, a third of the screen apart; 2026-10-20 player batch, report 7)
		const streaks = [1, 4, 7].map(i => `<div class="streak" style="top:${8 + i * 10}vh;animation-duration:${3 + (i * 7) % 5}s;animation-timing-function:steps(${(3 + (i * 7) % 5) * 30});animation-delay:-${(i * 13) % 7}s;width:${14 + (i * 11) % 20}vw"></div>`).join("");
		const words = [30, 80].map((top, i) => `<div class="words" style="top:${top}vh;animation-duration:${40 + i * 15}s;animation-timing-function:steps(${(40 + i * 15) * 30})">${"Credits Earned &nbsp; ".repeat(12)}</div>`).join("");
		const cell = (r) => Ranks.picture(r);
		root.innerHTML = `<div class="clouds"></div><div class="clouds b"></div>${words}${streaks}<div class="arcs"></div><div class="arcs b"></div>
			<div class="head"><h1>Credits Earned</h1><div class="sub">${esc((window.lastGame && window.lastGame.title) || "Game Complete")}</div></div>
			<div class="rows${list.length > 4 ? " many" : ""}">${list.map(a => `<div class="row"><div class="g"><i style="background-image:url(postgame/${a.g}.png)"></i>${a.clock ? "<b></b>" : ""}</div>
				<div class="n">${esc(a.name)}<small>${esc(a.note)}</small></div><div class="v">+0</div></div>`).join("")}</div>
			<div class="total"><span class="n">Total:</span><span class="v">+0</span></div>
			<div class="bar"><div class="rank" style="${cell(rank)}"></div><div class="who"><div class="nm">${esc(me.name || playerName)}</div><div class="rk">${esc(rank.name)}</div>
				<div class="track"><i></i></div><div class="cr">${fmt(before)} cR${next ? " / " + fmt(next.at) + " cR" : ""}</div></div></div>
			<div class="promoted">Promoted: ${esc(rankAfter.name)}</div>
			<div class="keys"><span class="hint" data-a="select"><span class="btn a">A</span>Skip</span><span class="hint" data-a="back"><span class="btn b">B</span>Close</span></div>`;
		root.classList.add("open");
		document.body.classList.add("postgame");
		root.querySelectorAll("[data-a]").forEach(el => el.onclick = () => action(el.dataset.a));
		// The layers behind him start moving when he shows (Figure's shown()), past the menu game's slowest first
		// seconds (2026-10-20 player batch, report 7); at the latest 10 s in, for when no picture of him comes.
		const run = () => { if (root.classList.contains("open")) root.classList.add("run"); };
		drift = setTimeout(run, window.Figure ? 10000 : 0);
		// The Spartan on the right in Reach's end-of-game pose ("depot:rifle:end_game", the card
		// Spartan's Victory pose, all_scenes.py POSES 7), from the texture camera as on the player card.
		if (typeof post === "function") { post("pose-now:7"); post("pose-replay"); }
		if (window.Figure) {
			Figure.fitTo({ top: 0.14, bottom: 0.9, cx: 0.74 });
			// Shown once dressed: the menu game restarts after a match and dresses him in stages; host-probe
			// says when he's done (armory.rs mark_dressed, `.dressed`, Figure.dressed), else 8 s after the
			// first picture.
			// (owner, 2026-10-17: still too slow) His cut-out from last time (or from the menus before the
			// match) shows at once, fading out as the live one comes in; the live one is kept for next time.
			const key = typeof StartMenu !== "undefined" && StartMenu.lookKey ? StartMenu.lookKey() : "";
			// (your undersuit color on him: index.html's `card-own:1`; the lobby backdrop stays on behind him)
			if (typeof window.ownSpartanShown === "function") window.ownSpartanShown("postgame", true);
			const was = key && Figure.cached(key);
			if (was) {
				const img = document.createElement("img");
				img.className = "pgfig";
				img.src = was.url;
				const h = 0.76, w = h * innerHeight * was.w / was.h / innerWidth;
				img.style.cssText = `height:${h * 100}vh;left:${(0.74 - w / 2) * 100}vw;top:14vh`;
				root.appendChild(img);
			}
			Figure.want("texcam", { hold: 8000, dressed: true, cacheKey: key, shown() {
				const img = root.querySelector(".pgfig");
				if (img) { img.classList.add("out"); setTimeout(() => img.remove(), 700); }
				run();
			} });
		}
		const rows = [...root.querySelectorAll(".row")];
		const step = 1100;
		rows.forEach((row, i) => later(600 + i * step, () => { row.classList.add("in"); play("change"); countUp(row.querySelector(".v"), list[i].value, 700, "+"); }));
		const end = 600 + rows.length * step;
		const totalEl = root.querySelector(".total"), barEl = root.querySelector(".bar"), fill = root.querySelector(".bar .track i");
		const showTotal = () => { totalEl.classList.add("in"); countUp(totalEl.querySelector(".v"), total, 1100, "+"); };
		const showBar = () => {
			barEl.classList.add("in");
			const from = rank.at, to = (next || rankAfter).at;
			const pct = (n) => to > from ? Math.max(0, Math.min(100, (n - from) / (to - from) * 100)) : 100;
			fill.style.width = pct(before) + "%";
			requestAnimationFrame(() => requestAnimationFrame(() => { fill.style.width = (rankAfter !== rank ? 100 : pct(after)) + "%"; }));
			const goal = nextOf(rankAfter);
			countUp(root.querySelector(".bar .cr"), after, 1600, "", " cR" + (goal ? " / " + fmt(goal.at) + " cR" : ""), before);
			if (rankAfter !== rank) later(1700, () => {
				root.querySelector(".promoted").classList.add("in");
				root.querySelector(".bar .rank").style.cssText = cell(rankAfter);
				root.querySelector(".bar .rk").textContent = rankAfter.name;
				play("select");
			});
		};
		later(end, showTotal);
		later(end + 1300, showBar);
		// A: everything at once.
		finish = () => {
			timers.forEach(clearTimeout); timers = [];
			rows.forEach((row, i) => { row.classList.add("in"); row.querySelector(".v").textContent = "+" + fmt(list[i].value); });
			totalEl.classList.add("in"); totalEl.querySelector(".v").textContent = "+" + fmt(total);
			showBar();
			finish = null;
		};
	}

	function close(quiet) {
		timers.forEach(clearTimeout); timers = [];
		clearInterval(spin); spin = null;
		clearTimeout(drift); drift = null;
		if (!root || !root.classList.contains("open")) return;
		if (typeof post === "function") post("pose-now:-");
		if (typeof window.ownSpartanShown === "function") window.ownSpartanShown("postgame", false);
		if (window.Figure) { Figure.fitTo(null); Figure.want(null); }
		root.classList.remove("open", "run");
		document.body.classList.remove("postgame");
		if (!quiet) { play("back"); if (typeof window.onPostgameClosed === "function") window.onPostgameClosed(); }
	}

	// Controller and keyboard while the screen is up: A skips the counting, B (or Start) closes it.
	function action(a) {
		if (a === "select" && finish) { play("select"); finish(); return true; }
		if (a === "select" || a === "back" || a === "start") { close(false); return true; }
		return true;
	}

	return { show, action, isOpen: () => !!root && root.classList.contains("open") };
})();
