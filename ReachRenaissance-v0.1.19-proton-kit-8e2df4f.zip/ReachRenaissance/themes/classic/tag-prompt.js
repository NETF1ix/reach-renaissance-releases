// The service tag (owner, 2026-10-13: "players can choose a 4 character service tag ... also add
// special symbols"): four boxes, as on the 360's tag entry. Typing fills them; the controller's up and
// down run through the characters, left and right move between boxes; a click on a symbol puts it in
// the box. Saved with `setting:tag=<tag>` (settings.rs `valid_tag`: capital letters, digits and the
// symbols below, which Bahnschrift, the font the game's text is drawn with, has); games get it as
// host-probe --service-tag and show it on the scoreboard.
window.TagPrompt = (() => {
	const SYMBOLS = "ΩΣΔΛλΨΦπ†‡§¤©®™°±×÷¥£€¢¿¡«»";
	const CHARS = [..."ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789", ...SYMBOLS];
	const css = document.createElement("style");
	css.textContent = `
	.tp { position: fixed; inset: 0; z-index: 1003; display: none; align-items: center; justify-content: center;
		background: radial-gradient(ellipse at 50% 45%, rgba(20, 40, 54, 0.92), rgba(4, 8, 12, 0.96)); font-family: var(--font); color: var(--text); }
	.tp.open { display: flex; }
	.tp .box { width: 46vw; padding: 4vh 3vw; background: linear-gradient(180deg, rgba(40, 56, 70, 0.92), rgba(22, 32, 42, 0.92));
		box-shadow: inset 0.25vw 0 0 #f2f4f5, 0 1vh 4vh rgba(0, 0, 0, 0.6); }
	.tp h1 { margin: 0 0 1vh; font-size: 5vh; font-weight: 700; letter-spacing: 0.02em; text-transform: uppercase; }
	.tp p { margin: 0 0 3vh; font-size: 2.4vh; color: #b9c2c8; }
	.tp .slots { display: flex; gap: 1.2vw; justify-content: center; }
	.tp .slot { position: relative; width: 9vh; height: 11vh; display: flex; align-items: center; justify-content: center; cursor: pointer;
		font-size: 7vh; font-weight: 700; color: #fff; background: rgba(0, 0, 0, 0.35); border: 1px solid rgba(255, 255, 255, 0.3); }
	.tp .slot.sel { border-color: #f2f4f5; box-shadow: 0 0 0 0.25vh rgba(242, 244, 245, 0.5); animation: rrPulse 1.5s ease-in-out infinite; }
	.tp .slot.sel::before, .tp .slot.sel::after { position: absolute; left: 0; right: 0; text-align: center; font-size: 2vh; color: rgba(255, 255, 255, 0.6); }
	.tp .slot.sel::before { content: "\\25B2"; top: -3vh; }
	.tp .slot.sel::after { content: "\\25BC"; bottom: -3vh; }
	.tp .syms { margin-top: 4.5vh; display: grid; grid-template-columns: repeat(14, 1fr); gap: 0.5vh 0.3vw; }
	.tp .sym { text-align: center; padding: 0.6vh 0; font-size: 2.8vh; font-weight: 600; cursor: pointer; background: rgba(255, 255, 255, 0.06); }
	.tp .sym:hover { background: rgba(255, 255, 255, 0.2); color: #fff; }
	.tp .err { min-height: 2.6vh; margin-top: 1.6vh; font-size: 2.2vh; color: #e8a33a; }
	.tp .keys { margin-top: 1.4vh; display: flex; gap: 1.6vw; font-size: 2.6vh; }
	.tp .keys .hint { cursor: pointer; }`;
	document.head.appendChild(css);
	const root = document.createElement("div");
	root.className = "tp";
	root.innerHTML = `<div class="box"><h1>Service Tag</h1>
		<p>Up to four letters, numbers or symbols. Other players see it on the scoreboard.</p>
		<div class="slots">${[0, 1, 2, 3].map(i => `<div class="slot" data-s="${i}"></div>`).join("")}</div>
		<div class="syms">${[...SYMBOLS].map(c => `<span class="sym">${c}</span>`).join("")}</div><div class="err"></div>
		<div class="keys"><span class="hint" data-a="ok"><span class="btn a">A</span>Accept</span><span class="hint" data-a="cancel"><span class="btn b">B</span>Cancel</span></div></div>`;
	document.body.appendChild(root);
	const err = root.querySelector(".err");
	let open = false, slots = ["", "", "", ""], at = 0, done = null;
	const sound = (n) => { if (typeof Sound !== "undefined") Sound.play(n); };

	function render() {
		root.querySelectorAll(".slot").forEach((el, i) => { el.textContent = slots[i] || ""; el.classList.toggle("sel", i === at); });
	}
	function show(current, after) {
		open = true;
		done = after || null;
		slots = [0, 1, 2, 3].map(i => [...(current || "")][i] || "");
		at = Math.min(3, slots.filter(Boolean).length);
		err.textContent = "";
		root.classList.add("open");
		render();
	}
	function put(c) {
		slots[at] = c;
		if (at < 3) at++;
		err.textContent = "";
		sound("change");
		render();
	}
	function cycle(step) {
		const now = CHARS.indexOf(slots[at]);
		slots[at] = CHARS[now < 0 ? (step > 0 ? 0 : CHARS.length - 1) : (now + step + CHARS.length) % CHARS.length];
		sound("move");
		render();
	}
	function accept() {
		// (a gap in the middle closes up)
		const tag = slots.filter(Boolean).join("");
		if (!tag) {
			err.textContent = "Pick at least one character.";
			return sound("error");
		}
		close();
		try { window.chrome.webview.postMessage("setting:tag=" + tag); } catch (e) { }
		sound("select");
		if (done) done(tag);
	}
	function close() {
		open = false;
		root.classList.remove("open");
	}
	function action(a) {
		if (a === "select") accept();
		else if (a === "back") { sound("back"); close(); }
		else if (a === "left" || a === "right") { at = (at + (a === "right" ? 1 : 3)) % 4; sound("move"); render(); }
		else if (a === "up" || a === "down") cycle(a === "up" ? 1 : -1);
		else if (a === "star") { slots[at] = ""; sound("change"); render(); } // X clears a box
	}
	// Keyboard: every key goes to the tag while it's open (the menus' letter keys included).
	window.addEventListener("keydown", (e) => {
		if (!open) return;
		e.preventDefault();
		e.stopImmediatePropagation();
		const key = e.key;
		if (key === "Enter") accept();
		else if (key === "Escape") action("back");
		else if (key === "ArrowLeft") action("left");
		else if (key === "ArrowRight") action("right");
		else if (key === "ArrowUp") action("up");
		else if (key === "ArrowDown") action("down");
		else if (key === "Backspace") { if (!slots[at] && at > 0) at--; slots[at] = ""; sound("change"); render(); }
		else if (key === "Delete") action("star");
		else if (key.length === 1 && CHARS.includes(key.toUpperCase())) put(key.toUpperCase());
		else if (key.length === 1) { err.textContent = "Letters, numbers and the symbols below."; sound("error"); }
	}, true);
	root.querySelectorAll(".slot").forEach(el => el.onclick = () => { at = +el.dataset.s; sound("move"); render(); });
	root.querySelectorAll(".sym").forEach(el => el.onclick = () => put(el.textContent));
	root.querySelectorAll("[data-a]").forEach(el => el.onclick = () => el.dataset.a === "ok" ? accept() : action("back"));
	return { show, action, get open() { return open; } };
})();
