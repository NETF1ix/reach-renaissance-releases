// Getting a server's Steam Workshop mods before a join (owner, 2026-10-18). Every join (Server
// Browser, an invite, following the party) first checks the mods the server lists; when this PC
// lacks one, menu-overlay has Steam download it (src/workshop.rs) and this screen shows the bar.
// The game starts only once Steam has installed it; B (Esc) cancels the join.
//
// Messages from menu-overlay:
//   mods-fetch:{"request":"<token>","items":[{id,title,done,total,installed}],"note":"..."}  progress
//   mods-fetch-done                                                     installed: the join goes on
//   mods-fetch-end:<text>                                               no join (text: why; empty: cancelled)
// Cancel replies with mods-cancel:<token>, so a delayed message cannot stop a later join.
//
// A party member's menus also get the mod in their leader's lobby before the leader's game starts
// (workshop.rs pre-download; 2026-10-20 owner, player report 36: the party came in one by one, each after
// its own download): a line in the corner shows it, how far and how long, without stopping anything.
//   mods-pre:{"id","title","done","total","secs","state":"run|done|failed|stopped","note"}
// A mod that carries files that aren't game data (programs, scripts, archives) is still played (owner,
// 2026-10-21: warn only); a line like that one, just under it, names them for a while and says not to
// open them.
//   mods-warn:{"title","count","files":[up to 3 paths in the mod folder]}
"use strict";

// index.html checks window.ModFetch before routing keyboard/controller actions here.
const ModFetch = window.ModFetch = (() => {
	const css = `
	.mf { position: fixed; inset: 0; z-index: 1200; display: none; align-items: center; justify-content: center; font-family: var(--font);
		color: var(--text); background: rgba(0, 0, 0, 0.55); }
	.mf.on { display: flex; }
	.mf .box { width: 44vw; background: linear-gradient(180deg, rgba(34, 43, 52, 0.97), rgba(24, 31, 38, 0.97));
		border: 1px solid rgba(220, 228, 234, 0.3); box-shadow: 0 1vh 4vh rgba(0, 0, 0, 0.6); padding: 2.4vh 2vw 1.8vh; }
	.mf h2 { margin: 0 0 1.6vh; font-size: 3vh; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; color: #fff; }
	.mf .item { margin-bottom: 1.6vh; }
	.mf .item .t { display: flex; justify-content: space-between; gap: 1vw; font-size: 2.1vh; font-weight: 600; margin-bottom: 0.6vh; }
	.mf .item .t span:first-child { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
	.mf .item .t span:last-child { color: var(--text-dim); white-space: nowrap; font-weight: 500; }
	.mf .bar { height: 1.1vh; background: rgba(255, 255, 255, 0.12); overflow: hidden; }
	.mf .bar i { display: block; height: 100%; width: 0; background: #35c9c0; transition: width 0.25s; }
	.mf .bar.wait i { width: 30%; animation: mf-wait 1.4s ease-in-out infinite; }
	@keyframes mf-wait { from { transform: translateX(-100%); } to { transform: translateX(340%); } }
	.mf .note { font-size: 1.9vh; line-height: 1.35; color: var(--text-dim); margin-top: 0.4vh; }
	.mf .keys { margin-top: 1.8vh; display: flex; justify-content: flex-end; font-size: 1.9vh; }
	.mf .keys .clock { margin-right: auto; color: var(--text-dim); }
	.mf .keys .hint { cursor: pointer; }`;
	let root = null;
	let open = false;
	let finishing = false;
	let cancelling = false;
	let request = "";
	let closing = 0;
	// How long this download has taken, on the screen each second (a big mod took almost 4 minutes).
	let since = 0;
	let ticking = 0;

	function build() {
		if (root) return;
		const style = document.createElement("style");
		style.textContent = css;
		document.head.appendChild(style);
		root = document.createElement("div");
		root.className = "mf";
		root.innerHTML = `<div class="box"><h2>Downloading Mods</h2><div class="items"></div><div class="note"></div>
			<div class="keys"><span class="clock"></span><span class="hint" data-a="back"><span class="btn b">B</span>Cancel</span></div></div>`;
		root.querySelector(".keys .hint").onclick = () => action("back");
		document.body.appendChild(root);
	}
	const mb = (n) => (n / 1048576).toFixed(n < 10485760 ? 1 : 0) + " MB";
	const clock = (secs) => Math.floor(secs / 60) + ":" + String(Math.floor(secs % 60)).padStart(2, "0");
	function tick() {
		clearTimeout(ticking);
		if (!open || !root) return;
		root.querySelector(".keys .clock").textContent = clock((Date.now() - since) / 1000);
		ticking = setTimeout(tick, 1000);
	}

	function show(state) {
		// Keep Cancel one-shot until the worker acknowledges it. Progress already queued before
		// cancellation must not restore the button or send more unscoped cancellation commands.
		if (open && cancelling && state.request === request) return;
		build();
		clearTimeout(closing);
		if (!open || state.request !== request) since = Date.now();
		open = true;
		finishing = false;
		cancelling = false;
		// Keep the native u64 token as text; JavaScript numbers would lose high bits.
		request = typeof state.request === "string" && state.request.length > 0 && !/[^0-9]/.test(state.request) ? state.request : "";
		root.classList.add("on");
		root.querySelector(".keys .hint").style.visibility = "";
		const items = root.querySelector(".items");
		items.innerHTML = "";
		for (const it of state.items || []) {
			const d = document.createElement("div");
			d.className = "item";
			const t = document.createElement("div");
			t.className = "t";
			const name = document.createElement("span");
			name.textContent = it.title || "Workshop item " + it.id;
			const size = document.createElement("span");
			size.textContent = it.installed ? "Installed" : it.total > 0 ? `${Math.floor(Math.min(100, (100 * it.done) / it.total))}% · ${mb(it.done)} / ${mb(it.total)}` : "Waiting for Steam";
			t.append(name, size);
			const bar = document.createElement("div");
			bar.className = "bar" + (!it.installed && !(it.total > 0) ? " wait" : "");
			const fill = document.createElement("i");
			if (it.installed) fill.style.width = "100%";
			else if (it.total > 0) fill.style.width = Math.min(100, (100 * it.done) / it.total).toFixed(1) + "%";
			bar.appendChild(fill);
			d.append(t, bar);
			items.appendChild(d);
		}
		root.querySelector(".note").textContent = (state.note || "") + " This server plays with this mod, so you need it to join.";
		tick();
	}
	function close() {
		open = false;
		if (root) root.classList.remove("on");
	}
	function action(a) {
		if (!open || finishing || cancelling || !request) return true;
		if (a === "back") {
			cancelling = true;
			Sound.play("back");
			if (root) {
				root.querySelector(".note").textContent = "Cancelling...";
				root.querySelector(".keys .hint").style.visibility = "hidden";
			}
			if (window.chrome && window.chrome.webview) window.chrome.webview.postMessage("mods-cancel:" + request);
		}
		return true;
	}

	// The party leader's mod downloading before their game (`mods-pre:`): a line in the top right corner, over
	// the menus and the startup screen (1000), under this download screen (a join waiting for it shows it here).
	const preCss = `
	.mfp { position: fixed; right: 2vw; top: 3vh; z-index: 1100; display: none; width: 26vw; padding: 1.1vh 1.2vw; font-family: var(--font);
		color: #fff; background: linear-gradient(180deg, rgba(40, 56, 70, 0.96), rgba(22, 32, 42, 0.96));
		box-shadow: inset 0.25vw 0 0 #35c9c0, 0 1vh 3vh rgba(0, 0, 0, 0.5); pointer-events: none; }
	.mfp.on { display: block; }
	.mfp .l1 { font-size: 2.1vh; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
	.mfp .l2 { font-size: 1.8vh; color: var(--text-dim); margin-top: 0.4vh; }
	.mfp .bar { height: 0.6vh; margin-top: 0.8vh; background: rgba(255, 255, 255, 0.12); overflow: hidden; }
	.mfp .bar i { display: block; height: 100%; width: 0; background: #35c9c0; transition: width 0.25s; }
	.mfp.warn { top: 13vh; box-shadow: inset 0.25vw 0 0 #e0a030, 0 1vh 3vh rgba(0, 0, 0, 0.5); }
	.mfp.warn .l2 { white-space: normal; }`;
	let pre = null;
	let preState = null;
	let preAt = 0;
	let preTimer = 0;
	let preHide = 0;
	// (Steam's and the overlay's reasons as a sentence: some end without a full stop)
	const sentence = (t) => { t = String(t || "").trim() || "Steam stopped"; t = t[0].toUpperCase() + t.slice(1); return /[.!?]$/.test(t) ? t : t + "."; };
	function preShow() {
		const s = preState;
		const secs = (+s.secs || 0) + (s.state === "run" ? (Date.now() - preAt) / 1000 : 0);
		const name = s.title || "Workshop item " + s.id;
		const pct = s.state === "done" ? 100 : s.total > 0 ? Math.min(100, (100 * s.done) / s.total) : 0;
		pre.querySelector(".l1").textContent = s.state === "done" ? `${name} is ready` : s.state === "failed" ? `Couldn't download ${name}` : `Downloading ${name}...`;
		pre.querySelector(".l2").textContent = s.state === "done" ? `Your party leader's mod, downloaded in ${clock(secs)}.`
			: s.state === "failed" ? `${sentence(s.note)} It downloads when you join instead.`
			: `${s.total > 0 ? `${Math.floor(pct)}% · ${mb(s.done)} / ${mb(s.total)}` : "Waiting for Steam"} · ${clock(secs)} · your party leader's mod`;
		pre.querySelector(".bar i").style.width = pct.toFixed(1) + "%";
	}
	function preTick() {
		if (!preState || preState.state !== "run") return;
		preShow();
		preTimer = setTimeout(preTick, 1000);
	}
	let warn = null;
	let warnHide = 0;
	function warnMessage(w) {
		if (!pre) preMessage({ state: "stopped" });
		if (!warn) {
			warn = document.createElement("div");
			warn.className = "mfp warn";
			warn.innerHTML = `<div class="l1"></div><div class="l2"></div>`;
			document.body.appendChild(warn);
		}
		const files = w.files || [];
		const more = w.count > files.length ? ` and ${w.count - files.length} more` : "";
		warn.querySelector(".l1").textContent = `${w.title || "This server's mod"} has files that aren't game data`;
		warn.querySelector(".l2").textContent = `${files.join(", ")}${more}. The game never runs them. Don't open them yourself.`;
		warn.classList.add("on");
		clearTimeout(warnHide);
		warnHide = setTimeout(() => warn.classList.remove("on"), 20000);
	}
	function preMessage(state) {
		if (!pre) {
			const style = document.createElement("style");
			style.textContent = preCss;
			document.head.appendChild(style);
			pre = document.createElement("div");
			pre.className = "mfp";
			pre.innerHTML = `<div class="l1"></div><div class="l2"></div><div class="bar"><i></i></div>`;
			document.body.appendChild(pre);
		}
		clearTimeout(preTimer);
		clearTimeout(preHide);
		// (stopped: a match started, or the player cancelled; nothing to say)
		if (state.state === "stopped") { preState = null; pre.classList.remove("on"); return; }
		preState = state;
		preAt = Date.now();
		pre.classList.add("on");
		preShow();
		if (state.state === "run") preTimer = setTimeout(preTick, 1000);
		else preHide = setTimeout(() => pre.classList.remove("on"), state.state === "done" ? 6000 : 12000);
	}

	if (window.chrome && window.chrome.webview) {
		window.chrome.webview.addEventListener("message", (e) => {
			const text = String(e.data);
			if (text.startsWith("mods-pre:")) {
				try { preMessage(JSON.parse(text.slice(9))); } catch (err) { }
			} else if (text.startsWith("mods-warn:")) {
				try { warnMessage(JSON.parse(text.slice(10))); } catch (err) { }
			} else if (text.startsWith("mods-fetch:")) {
				try { show(JSON.parse(text.slice(11))); } catch (err) { }
			} else if (text === "mods-fetch-done") {
				// The join starts now (its own "Joining" screen comes up under this one).
				finishing = true;
				if (root) {
					root.querySelector(".note").textContent = "Installed. Joining...";
					root.querySelector(".keys .hint").style.visibility = "hidden";
				}
				closing = setTimeout(close, 800);
			} else if (text.startsWith("mods-fetch-end:")) {
				const why = text.slice(15);
				close();
				if (why && typeof Browser !== "undefined") Browser.joinFailed("Couldn't get the server's mod: " + why);
				else document.getElementById("curtain").classList.remove("on");
			}
		});
	}
	return { isOpen: () => open, action, show, close };
})();
