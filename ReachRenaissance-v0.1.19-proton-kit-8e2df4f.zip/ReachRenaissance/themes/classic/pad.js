// The controllers the menus read (index.html pollPad, start-menu.js padNow), and what of theirs counts as a
// press. Its own file so tests can run it in node (tests/pad.test.js).
//
// 2026-10-20 player batch, reports 3, 4 and 26: the menus scrolled up by themselves, with no controller
// plugged in too, and some ignored an Xbox controller the game read. The page read only the first pad
// navigator.getGamepads() listed, whatever it was: a wheel, pedals, a HOTAS or a leftover virtual pad
// (vJoy, ViGEm) can come first, and Chromium reads an axis resting at its lowest as -1, which is up.
//
// choose(pads): every standard-mapped pad (one whose layout Chromium knows, as an Xbox controller's), or
// when none is connected, the others (index.html PAD's button numbers are a guess for those anyway).
// read(pads, now): what they press together. An axis counts only once it has been seen at rest (|v| <
// REST), so one stuck away from it never moves the menus. A button already down when its pad first shows
// is a tap if let go within TAP ms, acting then (the page sees no pad until a button is pressed or a stick
// pushed on one, the Gamepad API's user gesture, so the press that showed it is usually still down), and
// held longer it is stuck down and never acts. After forget(now) (the page has focus again, or shows over a
// match again), whatever is held when each pad shows up within FRESH ms waits to be let go: the Start
// that opened the game menu isn't a press in it. For the first SETTLE ms nothing counts, what is held then
// waits to be let go too, and no stick is seen at rest: the page gets the controller only while it has the
// focus (commit 2c8e01ac), so its first readings back can still be the blank ones from before, and a Start
// or stick held through them then looked like a new press.
(function (root) {
	const REST = 0.3, TAP = 1000, FRESH = 1000, SETTLE = 100;
	// pad index -> { id, rested: axes seen at rest, stale: buttons that wait to be let go, tap: button -> since }
	const known = new Map();
	let strictUntil = -Infinity, settleUntil = -Infinity;
	const down = (b) => !!b && (b.pressed || b.value > 0.5);

	function choose(pads) {
		const all = Array.from(pads || []).filter(p => p && p.connected !== false);
		const standard = all.filter(p => p.mapping === "standard");
		return standard.length ? standard : all;
	}

	// { buttons: [i] true while pressed, axes: [i] the strongest of the chosen pads' (0 until at rest) }, or
	// null with no pad.
	function read(pads, now) {
		const list = choose(pads);
		for (const index of [...known.keys()]) if (!list.some(p => p.index === index)) known.delete(index);
		if (!list.length) return null;
		const buttons = [], axes = [], settling = now < settleUntil;
		for (const p of list) {
			let s = known.get(p.index);
			if (!s || s.id !== p.id) {
				s = { id: p.id, rested: new Set(), stale: new Set(), tap: new Map() };
				const strict = now < strictUntil;
				p.buttons.forEach((b, i) => { if (down(b)) { if (strict) s.stale.add(i); else s.tap.set(i, now); } });
				known.set(p.index, s);
			}
			p.buttons.forEach((b, i) => {
				if (down(b) && settling) s.stale.add(i);
				if (down(b)) { if (!s.stale.has(i) && !s.tap.has(i)) buttons[i] = true; return; }
				if (s.tap.has(i) && now - s.tap.get(i) <= TAP) buttons[i] = true;
				s.tap.delete(i);
				s.stale.delete(i);
			});
			p.axes.forEach((v, i) => {
				if (Math.abs(v) < REST && !settling) s.rested.add(i);
				if (s.rested.has(i) && Math.abs(v) > Math.abs(axes[i] || 0)) axes[i] = v;
			});
		}
		return { buttons, axes };
	}

	function forget(now) {
		known.clear();
		strictUntil = now + FRESH;
		settleUntil = now + SETTLE;
	}

	// For the overlay log (index.html, on gamepadconnected and gamepaddisconnected).
	function describe(p, connected) {
		return `pad ${p.index} ${connected ? "connected" : "disconnected"}: ${String(p.id).slice(0, 80)} mapping=${p.mapping || "none"}`
			+ (connected ? ` axes=${Array.from(p.axes || []).slice(0, 8).map(v => v.toFixed(2)).join(",")}` : "");
	}

	const api = { choose, read, forget, describe, REST, TAP, FRESH, SETTLE };
	if (typeof module === "object" && module.exports) module.exports = api;
	else root.MenuPad = api;
})(typeof window !== "undefined" ? window : globalThis);
