// CHAT in the menus (PLAN-021, owner 2026-10-17): party chat, whispers to friends, and the global room on
// every menu screen (owner, 2026-10-19: it was the main menus only). A dock at the bottom right (clear of the menu lists on the left) that the player can minimize to a small "Chat" pill or
// turn off; the choice is kept (localStorage `rr.chat.mode`: open, min or off). T opens it (and turns it
// back on), Enter sends, Esc leaves the box. A click on a name offers Add Friend, Whisper, Mute, Block and
// Report (to the moderators, `chat-api:report|{code, reason}`).
//
// Moderation (owner, 2026-10-18; the masters enforce it): a moderator's announcement is a global line
// marked `staff`; lines the moderators took down come as `removed` ids and go; a moderator's mute (from
// the `social:` picture's `moderation.muted`) shows in the box instead of letting the player type.
//
// The overlay program carries everything (online.rs chat_get, chat_call): the page asks with
// `chat-get:<since>|<global 0/1>` and gets `chat:<json>` ({lines, next, blocked, error}); it sends with
// `chat-api:chat|{channel, code, text}` and `chat-api:block|{code, name, add}`, answered by
// `chat-reply:<route>|<json>` or `chat-error:<route>|<text>`. In a match the dock shows only with the
// game menu (Esc; owner, 2026-10-19) and is silent and asks for nothing while the game is played; the
// match's own chat (General, Team) is host-probe's (PLAN-021, below), and its whole history is the
// dock's Match tab there: taller, filtered to All, General or Team, with sending and name mutes
// (owner, 2026-10-21: "the chat goes into the pause menu and you have more view of the chat").
"use strict";

// The match chat's names, team colors and look (below; here as the dock below them runs first).
const MATCH_NAMES = { all: "General", team: "Team", server: "Server", staff: "Staff" };
// Reach's team colors (red, blue, green, orange, purple, gold, brown, pink) for names in a team game.
const TEAM_COLORS = ["#e84a4a", "#4a8ae8", "#5cc75c", "#f0913a", "#a66be0", "#e8c547", "#a8794e", "#f08ac8"];
// The look settings (`chat.*`, settings.rs; the Keyboard page's TEXT CHAT).
const MATCH_LOOK = { lines: 6, fade: 8000, width: "normal", size: "medium", opacity: 80, team: 84, general: 89, toggle: 191 };
function matchLook(st = {}) {
	const lines = Math.round(+st["chat.lines"]);
	return {
		lines: lines >= 4 && lines <= 15 ? lines : MATCH_LOOK.lines,
		fade: st["chat.fade"] === "never" ? Infinity : ["5", "8", "15"].includes(st["chat.fade"]) ? +st["chat.fade"] * 1000 : MATCH_LOOK.fade,
		width: ["narrow", "normal", "wide"].includes(st["chat.width"]) ? st["chat.width"] : MATCH_LOOK.width,
		size: ["small", "medium", "large"].includes(st["chat.size"]) ? st["chat.size"] : MATCH_LOOK.size,
		opacity: /^(100|[1-9]?0)$/.test(st["chat.opacity"] ?? "") ? +st["chat.opacity"] : MATCH_LOOK.opacity,
		// (the chat keys, for the game menu: there the page has the keyboard, not host-probe)
		team: +st["chat.team"] || MATCH_LOOK.team,
		general: +st["chat.general"] || MATCH_LOOK.general,
		toggle: +st["chat.toggle"] || MATCH_LOOK.toggle,
	};
}

if (typeof window !== "undefined") window.Chat = (() => {
	const post = (m) => { if (window.chrome && window.chrome.webview) window.chrome.webview.postMessage(m); };
	const esc = (s) => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
	const load = (k, d) => { try { return localStorage.getItem(k) ?? d; } catch (e) { return d; } };
	const save = (k, v) => { try { localStorage.setItem(k, v); } catch (e) { } };
	// In a match the menus' window is hidden unless the game menu (Esc) is up: no chat sound over the game
	// then (Sound has no match check and the window isn't muted).
	const hidden = () => document.body.classList.contains("inmatch") && !document.body.classList.contains("ingame");
	const play = (s) => { if (typeof Sound !== "undefined" && !hidden()) Sound.play(s); };

	let mode = load("rr.chat.mode", "min"); // open | min | off
	const muted = new Set((() => { try { return JSON.parse(load("rr.chat.muted", "[]")); } catch (e) { return []; } })());
	let lines = [];
	let since = 0;
	let tab = "global";
	let whisperTo = null; // {code, name}
	let unread = 0;
	// Lines from others per tab not seen yet (the tab shows the count). A whisper landed in the Whispers tab
	// with nothing saying so, behind Global or Party (owner, 2026-10-18: "players seem to have no way of
	// seeing who whispers to them and what they said").
	const unseen = { global: 0, party: 0, whispers: 0 };
	let error = "";
	let notice = "";
	let noticeUntil = 0;
	let menu = null; // {code, name, x, y}
	let maxChars = 120;
	let lastLen = -1;
	let friends = []; // from the overlay's `social:<json>` (social.js has the same picture)
	let inParty = false;
	let modMute = null; // a moderator's mute: {scope: global|all, until_unix, reason}
	const REPORTS = [["cheating", "Cheating"], ["abuse", "Abuse"], ["name", "Offensive Name"], ["spam", "Spam"]];
	const match = createMatchChat({ window, document, post, load, save,
		isMuted: l => muted.has(l.code) || muted.has(l.from),
		mode: () => mode, enable: () => { },
	});
	window.MatchChat = match;
	// The Match tab: which lines it shows, and where a line from it goes.
	let matchFilter = "all"; // all | general | team
	let matchCh = "all";

	const css = document.createElement("style");
	css.textContent = `
	.chat { position: fixed; right: 2vw; bottom: 9vh; text-align: left; z-index: 999; /* under the boot screen (1000) and every full-screen panel */ font-family: var(--font); color: var(--text); font-size: 1.9vh; }
	.chat.off, body.inmatch:not(.ingame) .chat { display: none; }
	/* (over the loading screen while it is a Campaign or Firefight waiting room: waiting-room.js) */
	body.waitroom .chat { z-index: 1001; }
	/* (the game menu: clear of its key row at 87vh, whose Exit hint is at the right end; the shorter log keeps
	   the top edge where it is in the menus; review, 2026-10-19) */
	body.ingame .chat { bottom: 14vh; }
	body.ingame .chat .log { height: 17vh; }
	/* (the Match tab: more of the match's chat; its top edge stays under the game menu's match info,
	   start-menu.js .match, which ends near 40vh) */
	body.ingame .chat.matchtab .panel { width: 34vw; }
	body.ingame .chat.matchtab .log { height: 30vh; }
	.chat .filt { display: flex; gap: 0.4vw; padding: 0.5vh 0.8vw 0.4vh; font-size: 1.5vh; text-transform: uppercase; letter-spacing: 0.05em; }
	.chat .filt span { padding: 0.2vh 0.6vw; cursor: pointer; color: rgba(185, 194, 200, 0.7); border: 1px solid rgba(160, 200, 235, 0.2); }
	.chat .filt span.on { color: #fff; border-color: rgba(255, 255, 255, 0.6); }
	.chat .ln .mtag { color: #c8c8c8; }
	.chat .ln.team .mtag { color: #9edbff; }
	.chat .ln.server, .chat .ln.server .mtag, .chat .ln.staff .mtag { color: #ffdc8e; }
	.chat .say .to.mch { color: #c8c8c8; font-weight: 700; }
	.chat .say .to.mch.team { color: #9edbff; }
	.chat .pill { display: none; align-items: center; gap: 0.6vw; padding: 0.7vh 1vw; cursor: pointer;
		background: rgba(8, 16, 24, 0.82); border: 1px solid rgba(160, 200, 235, 0.25); text-transform: uppercase; letter-spacing: 0.05em; font-weight: 600; }
	.chat .pill:hover { border-color: rgba(255, 255, 255, 0.6); }
	.chat .pill .n { background: #3a8ee6; color: #fff; border-radius: 1vh; padding: 0 0.5vw; font-size: 1.6vh; }
	.chat.min .pill { display: inline-flex; }
	.chat.min .panel { display: none; }
	.chat .panel { width: 30vw; display: flex; flex-direction: column; background: rgba(8, 16, 24, 0.86); border: 1px solid rgba(160, 200, 235, 0.25); }
	.chat .top { display: flex; align-items: center; border-bottom: 1px solid rgba(160, 200, 235, 0.18); }
	.chat .tab { padding: 0.8vh 0.9vw; cursor: pointer; text-transform: uppercase; font-size: 1.6vh; font-weight: 600; letter-spacing: 0.05em; color: rgba(185, 194, 200, 0.6); }
	.chat .tab.on { color: #fff; box-shadow: inset 0 -0.3vh 0 #f2f4f5; }
	.chat .tab .n { color: #6fb6ff; margin-left: 0.3vw; }
	.chat .top .sp { flex: 1; }
	.chat .top button { background: none; border: 0; color: rgba(220, 228, 234, 0.75); font: inherit; font-size: 2.2vh; line-height: 1; padding: 0.4vh 0.7vw; cursor: pointer; }
	.chat .top button:hover { color: #fff; }
	.chat .log { height: 22vh; overflow-y: auto; padding: 0.6vh 0.8vw; line-height: 1.35; overflow-wrap: anywhere; }
	.chat .ln { margin: 0.25vh 0; }
	.chat .ln .who { font-weight: 700; cursor: pointer; color: #9fd0ff; }
	.chat .ln.mine .who { color: #ffd36b; cursor: default; }
	.chat .ln .who:hover { text-decoration: underline; }
	.chat .ln.mine .who:hover { text-decoration: none; }
	.chat .ln .wh { color: #c9a6ff; }
	.chat .ln.staff { color: #ffe7a8; }
	.chat .ln.staff .who { color: #ffd36b; cursor: default; }
	.chat .ln.staff .who:hover { text-decoration: none; }
	.chat .ln .staff-tag { font-size: 1.4vh; font-weight: 700; letter-spacing: 0.05em; text-transform: uppercase; color: #1a1408; background: #ffd36b; padding: 0 0.3vw; margin-right: 0.3vw; }
	.chat .empty, .chat .err { color: var(--text-dim); font-style: italic; }
	.chat .err { color: #ffb3a6; }
	.chat .say { display: flex; align-items: center; gap: 0.5vw; border-top: 1px solid rgba(160, 200, 235, 0.18); padding: 0.5vh 0.6vw; }
	.chat .say .to { color: #c9a6ff; white-space: nowrap; cursor: pointer; }
	.chat .say input { flex: 1; min-width: 0; background: rgba(255, 255, 255, 0.06); border: 1px solid rgba(255, 255, 255, 0.15); color: #fff; font: inherit; padding: 0.5vh 0.5vw; outline: none; }
	.chat .say input:focus { border-color: rgba(255, 255, 255, 0.55); }
	.chat .note { padding: 0.3vh 0.8vw 0.6vh; color: #ffd36b; font-size: 1.6vh; }
	.chat-menu { position: fixed; z-index: 1003; background: rgba(10, 20, 30, 0.97); border: 1px solid rgba(160, 200, 235, 0.35); font-family: var(--font); font-size: 1.9vh; color: var(--text); min-width: 12vw; }
	.chat-menu .h { padding: 0.7vh 0.9vw; font-weight: 700; border-bottom: 1px solid rgba(160, 200, 235, 0.2); }
	.chat-menu div.i { padding: 0.7vh 0.9vw; cursor: pointer; }
	.chat-menu div.i:hover { background: rgba(255, 255, 255, 0.1); }
	`;
	document.head.appendChild(css);

	const root = document.createElement("div");
	root.className = "chat";
	document.body.appendChild(root);
	const pop = document.createElement("div");
	pop.className = "chat-menu";
	pop.style.display = "none";
	document.body.appendChild(pop);

	const TABS = ["global", "party", "whispers"];
	// (Match first while a match with its chat is on)
	const tabs = () => match.active() ? ["match", ...TABS] : TABS;
	const inTab = (l, t) => t === "global" ? l.channel === "global" : t === "party" ? l.channel === "party" : l.channel === "direct";
	const shown = () => lines.filter(l => !muted.has(l.from) || l.mine);
	const TAB_NAME = { match: "Match", global: "Global", party: "Party", whispers: "Whispers" };
	const MATCH_TAG = { all: "General", team: "Team", server: "Server", staff: "Staff" };

	function setMode(m) {
		mode = m;
		roomOpened = false;
		save("rr.chat.mode", m);
		if (m === "open") {
			unread = 0;
			// (opened with a whisper waiting: straight to it)
			if (unseen.whispers) tab = "whispers";
		}
		closeMenu();
		render();
		if (window.WaitingRoom) WaitingRoom.redraw();
		match.refresh();
	}

	// The waiting room over a Campaign or Firefight load (waiting-room.js, 2026-10-20 owner request: "hopefully
	// text chat ... still visible"): the dock stays up over the loading screen and takes typing (its keys never
	// reach bootSkip), on Party in a party. A minimized dock opens for it and goes back to its pill after,
	// unless the player changed it meanwhile; one turned off stays off (T still opens it).
	let roomOpened = false;
	function room(on) {
		if (on) {
			if (mode === "min") { mode = "open"; unread = 0; roomOpened = true; }
			if (inParty) tab = "party";
		} else {
			if (roomOpened && mode === "open") mode = "min";
			roomOpened = false;
		}
		closeMenu();
		render();
	}

	function say(text) {
		notice = text;
		noticeUntil = Date.now() + 6000;
		render();
	}

	function render() {
		if (tab === "match" && !match.active()) tab = "global";
		root.className = "chat " + mode + (tab === "match" ? " matchtab" : "");
		if (mode === "off") { root.innerHTML = ""; lastLen = -1; return; }
		const input = root.querySelector("input");
		const draft = input ? input.value : "";
		const focused = input && document.activeElement === input;
		const log = root.querySelector(".log");
		const atBottom = !log || log.scrollTop + log.clientHeight >= log.scrollHeight - 4;
		const list = tab === "match" ? matchLines() : shown().filter(l => inTab(l, tab));
		const target = tab === "whispers" ? whisperTo : null;
		if (mode === "open") unseen[tab] = 0;
		const rows = tab === "match" ? list.map(matchRow).join("") : list.map(l => {
			const who = l.mine ? "You" : esc(l.name || "Player");
			const wh = l.channel === "direct" ? `<span class="wh">${l.mine ? "to " + esc(nameOf(l.with)) : "whispers"}</span> ` : "";
			if (l.staff) return `<div class="ln staff"><span class="staff-tag">Staff</span><span class="who">${who}</span> ${esc(l.text)}</div>`;
			return `<div class="ln${l.mine ? " mine" : ""}"><span class="who" data-code="${esc(l.from)}" data-name="${esc(l.name)}">${who}</span> ${wh}${esc(l.text)}</div>`;
		}).join("");
		const empty = { match: "Everything said in this game shows here. Y talks to everyone, T to your team.", global: "Everyone online is here. Say hi.", party: "Lines you send here reach your party.", whispers: "Click a friend's name in any chat to whisper to them." }[tab];
		const silenced = tab !== "match" && modMute && (modMute.scope === "all" || tab === "global");
		if (tab === "match" && matchCh === "team" && !match.available("team")) matchCh = "all";
		const closed = tab === "match" && !match.available(matchCh);
		const placeholder = silenced ? "You're muted" : closed ? match.unavailable(matchCh) : tab === "whispers" && !target ? "Pick a name to whisper to"
			: tab === "match" ? `Say something to ${matchCh === "team" ? "your team" : "everyone"} (Tab switches)` : `Say something (${maxChars} characters)`;
		const filters = tab !== "match" ? "" : `<div class="filt">${[["all", "All"], ["general", "General"], ["team", "Team"]].filter(([k]) => k !== "team" || match.teams())
			.map(([k, t]) => `<span class="${k === matchFilter ? "on" : ""}" data-filt="${k}">${t}</span>`).join("")}</div>`;
		const to = tab === "match" ? `<span class="to mch ${matchCh}" title="Switch between General and Team (Tab)">${MATCH_TAG[matchCh]}:</span>`
			: target ? `<span class="to" title="Stop whispering">To ${esc(target.name)}:</span>` : "";
		root.innerHTML = `
			<div class="pill" title="Open chat (T)">Chat${unread ? `<span class="n">${unread}</span>` : ""}</div>
			<div class="panel">
				<div class="top">${tabs().map(t => `<div class="tab${t === tab ? " on" : ""}" data-tab="${t}">${TAB_NAME[t]}${unseen[t] ? `<span class="n">${unseen[t]}</span>` : ""}</div>`).join("")}
					<span class="sp"></span><button class="mn" title="Minimize">&#8211;</button><button class="x" title="Turn chat off (T turns it back on)">&#215;</button></div>
				${filters}<div class="log">${rows || `<div class="empty">${empty}</div>`}${error && tab !== "match" ? `<div class="err">${esc(error)}</div>` : ""}</div>
				${Date.now() < noticeUntil ? `<div class="note">${esc(notice)}</div>` : silenced ? `<div class="note">${esc(muteText())}.</div>` : ""}
				<div class="say">${to}<input maxlength="${tab === "match" ? 120 : maxChars}" placeholder="${esc(placeholder)}" ${(tab === "whispers" && !target) || silenced || closed ? "disabled" : ""}></div>
			</div>`;
		const box = root.querySelector("input");
		box.value = draft;
		if (focused) { box.focus(); box.setSelectionRange(draft.length, draft.length); }
		const newLog = root.querySelector(".log");
		if (atBottom || list.length !== lastLen) newLog.scrollTop = newLog.scrollHeight;
		lastLen = list.length;
	}

	// The Match tab's lines (match.history(): General, Team, server and staff lines, mutes and blocks applied).
	function matchLines() {
		return match.history().filter(l => matchFilter === "all" || (matchFilter === "team" ? l.channel === "team" : l.channel !== "team"));
	}
	function matchRow(l) {
		const who = l.channel === "server" ? "" : `<span class="who" style="color:${match.color(l)}" data-mname="${esc(l.name)}">${esc(l.name)}</span>: `;
		return `<div class="ln ${l.channel}${l.mine || l.channel === "staff" ? " mine" : ""}"><span class="mtag">[${MATCH_TAG[l.channel]}]</span> ${who}${esc(l.text)}</div>`;
	}

	function muteText() {
		if (!modMute) return "";
		const left = modMute.until_unix ? Math.max(1, Math.ceil((modMute.until_unix * 1000 - Date.now()) / 60000)) : 0;
		const span = !left ? "" : left >= 120 ? ` for ${Math.ceil(left / 60)} more hours` : ` for ${left} more minute${left === 1 ? "" : "s"}`;
		return `A moderator muted you in ${modMute.scope === "all" ? "chat" : "global chat"}${span}` + (modMute.reason ? `: ${modMute.reason}` : "");
	}

	function nameOf(code) {
		const l = lines.find(x => x.from === code && !x.mine);
		if (l) return l.name;
		const fr = friends.find(x => x.code === code);
		return fr ? fr.name : code;
	}

	function send() {
		const box = root.querySelector("input");
		const text = box.value.trim();
		if (!text) return;
		if (tab === "match") {
			const err = match.say(matchCh, text);
			if (err) return say(err);
			box.value = "";
			return;
		}
		const body = tab === "whispers" ? { channel: "direct", code: whisperTo && whisperTo.code, text } : { channel: tab, text };
		if (tab === "whispers" && !whisperTo) return;
		post("chat-api:chat|" + JSON.stringify(body));
		box.value = "";
	}

	function closeMenu() { menu = null; pop.style.display = "none"; }
	// A name in the Match tab: the match carries names, not friend codes, so Mute (by name) is what there is.
	function openMatchMenu(name, x, y) {
		if (!name) return;
		menu = { name };
		const on = match.nameMuted(name);
		pop.innerHTML = `<div class="h">${esc(name)}</div><div class="i" data-k="${on ? "munmute" : "mmute"}">${on ? "Unmute" : "Mute"}</div>`;
		pop.style.display = "block";
		pop.style.left = Math.min(x, innerWidth - pop.offsetWidth - 8) + "px";
		pop.style.top = Math.max(8, y - pop.offsetHeight) + "px";
	}
	function openMenu(code, name, x, y) {
		if (!code) return;
		menu = { code, name };
		const friend = friends.some(f => f.code === code);
		const items = [
			friend ? null : ["add", "Add Friend"],
			friend ? ["whisper", "Whisper"] : null,
			[muted.has(code) ? "unmute" : "mute", muted.has(code) ? "Unmute" : "Mute"],
			["block", "Block"],
			["report", "Report..."],
		].filter(Boolean);
		pop.innerHTML = `<div class="h">${esc(name)}</div>` + items.map(([k, t]) => `<div class="i" data-k="${k}">${t}</div>`).join("");
		pop.style.display = "block";
		pop.style.left = Math.min(x, innerWidth - pop.offsetWidth - 8) + "px";
		pop.style.top = Math.max(8, y - pop.offsetHeight) + "px";
	}

	function act(k) {
		if (!menu) return;
		const { code, name } = menu;
		if (k === "mmute" || k === "munmute") { closeMenu(); say(match.muteName(name, k === "mmute")); render(); return; }
		if (k === "report") {
			// A second list: why (the moderators see the reason with the player's recent global lines).
			pop.innerHTML = `<div class="h">Report ${esc(name)} for</div>` + REPORTS.map(([r, t]) => `<div class="i" data-k="report:${r}">${t}</div>`).join("");
			return;
		}
		closeMenu();
		if (k.startsWith("report:")) {
			post("chat-api:report|" + JSON.stringify({ code, reason: k.slice(7) }));
			return;
		}
		if (k === "add") { post("social-api:friend|" + JSON.stringify({ code, add: true })); say(`Friend request sent to ${name}.`); }
		else if (k === "whisper") { whisperTo = { code, name }; tab = "whispers"; render(); root.querySelector("input").focus(); }
		else if (k === "mute" || k === "unmute") {
			if (k === "mute") muted.add(code); else muted.delete(code);
			save("rr.chat.muted", JSON.stringify([...muted]));
			match.refresh();
			say(k === "mute" ? `${name} is muted. Their lines are hidden.` : `${name} is unmuted.`);
		} else if (k === "block") {
			post("chat-api:block|" + JSON.stringify({ code, name, add: true }));
			lines = lines.filter(l => l.from !== code);
			if (whisperTo && whisperTo.code === code) whisperTo = null;
			say(`${name} is blocked: no chat, whispers or invites from them.`);
		}
	}

	root.addEventListener("click", (e) => {
		const t = e.target;
		if (t.closest(".pill")) return setMode("open");
		if (t.closest(".mn")) return setMode("min");
		if (t.closest(".x")) { setMode("off"); if (window.Social && Social.say) Social.say("Chat is off. Press T to turn it back on."); return; }
		const tb = t.closest(".tab");
		if (tb) { tab = tb.dataset.tab; render(); return; }
		const filt = t.closest("[data-filt]");
		if (filt) { matchFilter = filt.dataset.filt; render(); return; }
		if (t.closest(".mch")) { cycleMatch(); return; }
		if (t.closest(".to")) { whisperTo = null; render(); return; }
		const who = t.closest(".who");
		if (who && !who.closest(".mine") && who.dataset.mname !== undefined) { e.stopPropagation(); openMatchMenu(who.dataset.mname, e.clientX, e.clientY); }
		else if (who && !who.closest(".mine")) { e.stopPropagation(); openMenu(who.dataset.code, who.dataset.name, e.clientX, e.clientY); }
	});
	pop.addEventListener("click", (e) => { const i = e.target.closest(".i"); if (i) act(i.dataset.k); });
	document.addEventListener("click", (e) => { if (menu && !pop.contains(e.target)) closeMenu(); }, true);
	// Typing in the box never reaches the menus' own keys (W/A/S/D, Q/E, Enter and the rest).
	root.addEventListener("keydown", (e) => {
		if (e.target.tagName !== "INPUT") return;
		e.stopPropagation();
		if (e.key === "Enter") { e.preventDefault(); send(); }
		else if (e.key === "Escape") { e.preventDefault(); e.target.blur(); }
		else if (e.key === "Tab" && tab === "match") { e.preventDefault(); cycleMatch(); }
	});
	function cycleMatch() {
		matchCh = matchCh === "all" && match.available("team") ? "team" : "all";
		render();
		const box = root.querySelector("input");
		if (box && !box.disabled) box.focus();
	}
	// The match chat changed (a line, a send's answer): the Match tab follows while it shows.
	match.onChange(() => {
		const r = match.reply();
		if (r && !r.ok) {
			say(r.error);
			const box = root.querySelector("input");
			if (box && !box.value && tab === "match") box.value = r.draft || "";
		}
		if (tab === "match" && mode === "open" && !hidden()) render();
	});
	// T: open the chat (turning it on if it was off) and put the cursor in the box (in a match too, while
	// the game menu is up). On the game menu itself the match chat's keys (T Team, Y General, as the player
	// set them) open the Match tab on that channel (owner, 2026-10-21: "pressing the chat buttons like T,Y
	// should work in the pause menu").
	document.addEventListener("keydown", (e) => {
		if (hidden() || (e.target && /INPUT|TEXTAREA/.test(e.target.tagName))) return;
		const ch = document.body.classList.contains("ingame") && match.active() && typeof StartMenu !== "undefined" && StartMenu.pageKind && StartMenu.pageKind() === "game"
			? match.keyChannel(e.keyCode) : null;
		if (ch && !e.repeat) {
			e.preventDefault(); e.stopImmediatePropagation();
			tab = "match"; matchCh = ch === "team" && match.available("team") ? "team" : "all";
			if (mode !== "open") setMode("open"); else render();
			const box = root.querySelector("input");
			if (box && !box.disabled) box.focus();
			return;
		}
		// The show/hide chat key (/ unless the player set another) in the menus: the dock goes and comes back
		// as it was, open or a pill (owner, 2026-10-21: "'/' button in main menus needs to show/hide the text
		// chat"). In a match the same key is host-probe's, for the match chat's lines.
		if (e.keyCode === match.toggleKey() && !e.ctrlKey && !e.altKey && !e.metaKey) {
			e.preventDefault();
			if (e.repeat) return;
			if (mode === "off") setMode(load("rr.chat.shown", "min") === "open" ? "open" : "min");
			else {
				save("rr.chat.shown", mode); setMode("off");
				if (window.Social && Social.say) Social.say(`Chat hidden. Press ${match.toggleKey() === 191 ? "/" : "your Show/Hide Chat key"} to show it.`);
			}
			return;
		}
		if (e.key !== "t" && e.key !== "T") return;
		e.preventDefault();
		if (mode !== "open") setMode("open");
		const box = root.querySelector("input");
		if (box && !box.disabled) box.focus();
	}, true);

	function received(json) {
		let r;
		try { r = JSON.parse(json); } catch (e) { return; }
		match.social(r);
		maxChars = r.max_chars || maxChars;
		const err = r.error ? "Chat: " + r.error : "";
		const changed = err !== error;
		error = err;
		// Lines the moderators took down.
		const gone = new Set(r.removed || []);
		const before = lines.length;
		if (gone.size) lines = lines.filter(l => !gone.has(l.id));
		const removed = lines.length !== before;
		const fresh = (r.lines || []).filter(l => !lines.some(x => x.id === l.id) && !gone.has(l.id));
		if (fresh.length) {
			lines = lines.concat(fresh).slice(-200);
			const theirs = fresh.filter(l => !l.mine && !muted.has(l.from) && (l.channel !== "global" || mode === "open"));
			if (mode !== "open") unread += theirs.length;
			for (const l of theirs) {
				const t = l.channel === "direct" ? "whispers" : l.channel;
				if (t in unseen && (mode !== "open" || t !== tab)) unseen[t]++;
			}
			const whispers = theirs.filter(l => l.channel === "direct");
			if (whispers.length) {
				play("select");
				const w = whispers[whispers.length - 1];
				// Who and what, wherever the player is looking (the dock may be minimized or on another tab),
				// and a reply goes back to them.
				const line = `${w.name || "A friend"} whispers: ${w.text}`;
				// (no toast while the game is played, e.g. a poll answered after Resume: it waits in Whispers)
				if (window.Social && Social.say && !hidden()) Social.say(line);
				notice = line;
				noticeUntil = Date.now() + 8000;
				if (!whisperTo) whisperTo = { code: w.from, name: w.name || w.from };
			}
		}
		since = Math.max(since, r.next || 0);
		post(`match-chat:since|${since}`);
		// Only when something changed: a redraw under the cursor would break typing (an IME's half-made word).
		if (fresh.length || changed || removed) render();
	}

	if (window.chrome && window.chrome.webview) {
		window.chrome.webview.addEventListener("message", (e) => {
			const text = String(e.data);
			if (match.message(text)) return;
			if (text.startsWith("chat:")) received(text.slice(5));
			else if (text.startsWith("social:")) {
				try {
					const s = JSON.parse(text.slice(7));
					friends = s.friends || [];
					inParty = !!s.leader || (s.party || []).length > 1;
					const m = (s.moderation && s.moderation.muted) || null;
					if (JSON.stringify(m) !== JSON.stringify(modMute)) { modMute = m; render(); }
				} catch (err) { }
				match.refresh();
			}
			else if (text.startsWith("chat-reply:")) {
				const [route, json] = text.slice(11).split(/\|(.*)/s);
				if (route === "chat") { try { const r = JSON.parse(json); if (r.line) received(JSON.stringify({ lines: [r.line], next: since })); } catch (err) { } }
				else if (route === "report") say("Thanks. The moderators will look at it.");
			} else if (text.startsWith("chat-error:")) {
				play("error");
				say(text.slice(11).split(/\|(.*)/s)[1] || "Chat didn't send.");
			}
		});
	}

	// Every 2 s while the dock is open or minimized (the global room only while it shows); nothing when off,
	// nor in a match unless the game menu is up (the menus' CPU budget while hidden).
	setInterval(() => {
		if (mode === "off" || hidden()) return;
		post(`chat-get:${since}|${mode === "open" && tab === "global" ? 1 : 0}`);
	}, 2000);
	// Leaving the main menu for a lobby in a party starts on Party, as it did when Global was on the main
	// menus only; a player who then picks Global keeps it from lobby to lobby, and one with no party stays.
	new MutationObserver((m) => {
		const was = m[0].oldValue || "main", now = document.body.dataset.screen || "main";
		if (was === "main" && now !== "main" && inParty && tab === "global") { tab = "party"; render(); }
	}).observe(document.body, { attributes: true, attributeFilter: ["data-screen"], attributeOldValue: true });
	// A name menu (Add Friend, Whisper...) goes when the game is played or the game menu comes or goes: it is
	// outside the dock, so after Resume it stayed open unseen and came back at the next Esc or in the lobby
	// (review, 2026-10-19), and the dock moves with the game menu.
	let inGameMenu = document.body.classList.contains("ingame");
	let inMatch = document.body.classList.contains("inmatch");
	new MutationObserver(() => {
		const now = document.body.classList.contains("ingame");
		if (menu && (hidden() || now !== inGameMenu)) closeMenu();
		// The game menu opens on the Match tab (when the match has its chat); the lobby goes back to Global.
		if (now && !inGameMenu && match.active()) { tab = "match"; render(); }
		const playing = document.body.classList.contains("inmatch");
		if (!playing && inMatch && tab === "match") { tab = "global"; render(); }
		inGameMenu = now; inMatch = playing;
	}).observe(document.body, { attributes: true, attributeFilter: ["class"] });
	render();

	return { setMode, mode: () => mode, open: () => setMode("open"), room };
})();

// The match's own text chat (PLAN-021; owner, 2026-10-21): middle right of the game, Y General
// (everyone in the game; the host's room keeps it from map to map), T Team, / shows or hides the lines
// (remembered, with a count of what came meanwhile). The full history is the game menu's Match tab in
// the dock above. Inert until menu-overlay advertises --ingame-chat. General and Team require a fresh
// host capability, never a client-side roster filter or a fallback to Global. Squad (Invasion's
// fireteams, U) comes later.
// Exported for headless tests; no second test implementation.
function chatClean(value, limit = 120) {
	return Array.from(String(value ?? "").slice(0, 2048)
		.replace(/[\u0000-\u001f\u007f-\u009f؜᠎​-‏‪-‮⁠-⁤⁦-⁩﻿]/g, "")
		.replace(/\s+/gu, " ").trim()).slice(0, limit).join("");
}

function createMatchChatModel(now = () => Date.now()) {
	let enabled = false, scope = "", ready = false, teams = false;
	// Match lines are the host's (each snapshot is the whole list); staff announcements come from the menus' poll.
	let lines = [], staff = [], seen = new Set(), order = [], tokens = 4, refill = now(), recent = [];
	let blocked = new Set();
	// The times the player was alt-tabbed out of the game ([from, to], to null while away): the HUD's fade
	// waits through them, as the overlay's rows do (ingame_chat.rs hold_fade).
	let away = [];
	const shown = (l, t) => t - l.at - away.reduce((sum, [from, to]) => sum + Math.max(0, Math.min(to ?? t, t) - Math.max(from, l.at)), 0);
	const id = v => typeof v === "string" && /^[0-9]{1,20}$/.test(v);
	function remember(key) {
		if (seen.has(key)) return false;
		seen.add(key); order.push(key);
		if (order.length > 512) seen.delete(order.shift());
		return true;
	}
	const all = () => lines.concat(staff).sort((a, b) => a.at - b.at || (a.sequence !== undefined && b.sequence !== undefined ? (BigInt(a.sequence) < BigInt(b.sequence) ? -1 : 1) : 0));
	return {
		configure(on) { enabled = on === true; if (!enabled) this.reset(); },
		reset() { scope = ""; ready = teams = false; lines = []; staff = []; seen.clear(); order = []; recent = []; tokens = 4; refill = now(); away = []; },
		away(on) {
			const t = now(), last = away[away.length - 1];
			if (on && !(last && last[1] === null)) away = away.slice(-19).concat([[t, null]]);
			else if (!on && last && last[1] === null) last[1] = t;
		},
		active: () => enabled,
		teams: () => teams,
		available(ch) { return enabled && ready && (ch === "all" || ch === "team" && teams); },
		unavailable(ch) { return !ready ? "Match chat works in online games (hosted or joined), once the host is connected." : "There are no teams in this game."; },
		snapshot(data) {
			if (!enabled || !data || data.version !== 1 || typeof data.epoch !== "string" || data.epoch.length > 96) return;
			// The overlay's own "host went quiet" note has no session: General and Team close, the lines stay.
			if (typeof data.session !== "string") { ready = false; return; }
			ready = data.ready === true; teams = data.team === true;
			// The host's room outlives a rotation; a new room (another host) starts over.
			const room = typeof data.room === "string" && data.room && data.room.length <= 96 ? data.room : data.epoch;
			if (room !== scope) { lines = []; scope = room; }
			const before = new Map(lines.map(l => [l.key, l]));
			const next = [];
			for (const l of (Array.isArray(data.lines) ? data.lines : []).slice(-200)) {
				if (!l || !id(l.id) || !["all", "team", "server"].includes(l.channel)) continue;
				const text = chatClean(l.text); if (!text) continue;
				const key = `m:${scope}:${l.id}`;
				if (next.some(x => x.key === key)) continue;
				// The host supplies age; a repeated snapshot keeps the first time, so old lines never flash again.
				const at = before.has(key) ? before.get(key).at : now() - (Number.isFinite(l.age_ms) && l.age_ms >= 0 ? l.age_ms : 60000);
				next.push({ key, sequence: l.id, channel: l.channel, text, name: chatClean(l.name, 32) || "Player",
					code: chatClean(l.code, 80), sender: chatClean(l.sender, 32), mine: l.mine === true,
					team: Number.isInteger(l.team) && l.team >= 0 && l.team < 8 ? l.team : -1, at });
			}
			next.sort((a, b) => BigInt(a.sequence) < BigInt(b.sequence) ? -1 : BigInt(a.sequence) > BigInt(b.sequence) ? 1 : 0);
			lines = next;
		},
		social(data) {
			if (!enabled || !data) return;
			// This is the player's local list, already bounded by the HTTP response limit.
			// Truncating it here silently unblocks players in match chat only.
			if (Array.isArray(data.blocked)) blocked = new Set(data.blocked.filter(b => b && typeof b.code === "string").map(b => b.code));
			const removed = new Set((Array.isArray(data.removed) ? data.removed : []).map(n => `s:${n}`));
			staff = staff.filter(l => !removed.has(l.key));
			// A takedown can precede a delayed reply or be included with the line itself.
			for (const key of [...removed].slice(-512)) remember(key);
			for (const l of (Array.isArray(data.lines) ? data.lines : []).slice(-200)) {
				if (!l || !Number.isSafeInteger(l.id) || l.id < 0 || l.channel !== "global" || l.staff !== true) continue;
				const text = chatClean(l.text); if (!text || !remember(`s:${l.id}`)) continue;
				staff.push({ key: `s:${l.id}`, channel: "staff", text, name: chatClean(l.name, 32) || "Staff", code: chatClean(l.from, 80),
					mine: false, team: -1, at: Number.isFinite(l.unix) ? Math.min(now(), l.unix * 1000) : now() - 60000 });
			}
			staff = staff.slice(-20);
		},
		visible(isMuted) { return all().filter(l => l.mine || l.channel === "server" || l.channel === "staff" || !blocked.has(l.code) && !isMuted(l)); },
		// The HUD's rows: the newest `look.lines` that are still within their time (`chat.fade`; never = held).
		feed(isMuted, look = MATCH_LOOK) {
			const t = now();
			return this.visible(isMuted).filter(l => shown(l, t) < look.fade).slice(-look.lines)
				.map(l => look.fade === Infinity ? { ...l, hold: true } : { ...l, remaining_ms: Math.max(0, look.fade - shown(l, t)) });
		},
		prepare(channel, raw) {
			if (!this.available(channel)) return { error: this.unavailable(channel) };
			const text = chatClean(raw); if (!text) return { error: "Type a message first." };
			const t = now(); tokens = Math.min(4, tokens + Math.max(0, t - refill) / 1500); refill = t;
			recent = recent.filter(l => t - l.at < 10000);
			if (tokens < 1 || recent.filter(l => l.text === text).length >= 2) return { error: "You're sending too fast. Wait a moment." };
			tokens--; recent.push({ text, at: t });
			return { channel, text };
		},
	};
}

// A line's name color: yours gold, a team game's by team, otherwise white.
function matchNameColor(l, teams) {
	if (l.mine) return "#ffd36b";
	if (l.channel === "server" || l.channel === "staff") return "#ffdc8e";
	return teams && l.team >= 0 ? TEAM_COLORS[l.team] : "#f2f4f5";
}

function createMatchChat({ window, document, post, load, save, isMuted, mode, enable, now = () => Date.now() }) {
	const model = createMatchChatModel(now);
	let root, input, log, label, note, opened = false, channel = "all", composing = false, waitingRelease = false;
	let pending = null, draft = "", error = "", lastFeed = "", request = "", feedback = null, sendSequence = 0;
	let legacyMutes = new Set();
	let lastMode = "";
	let guardedAction = null;
	let dock = null; // the Match tab's last send result
	let look = { ...MATCH_LOOK };
	// `/`: the lines hidden (kept between games), and when, for the count of what came since.
	let hidden = load("rr.matchchat.hidden", "0") === "1", hiddenAt = now();
	const listeners = new Set();
	const changed = () => { for (const fn of listeners) { try { fn(); } catch { } } };
	const inMatch = () => document.body.classList.contains("inmatch");
	function nameMutes() { try { const a = JSON.parse(load("rr-muted", "[]")); return new Set(Array.isArray(a) ? a : []); } catch { return new Set(); } }
	function muted(l) { return isMuted(l) || legacyMutes.has(l.name); }
	const WIDTHS = { narrow: "26vw", normal: "34vw", wide: "44vw" };
	const SIZES = { small: "1.5vh", medium: "1.9vh", large: "2.4vh" };
	function build() {
		if (root) return;
		const css = document.createElement("style");
		css.textContent = `
		.match-chat { display:none; position:fixed; right:2vw; bottom:30vh; width:34vw;
			font:clamp(12px,1.9vh,40px) var(--font); color:#e8f3fc; z-index:1004; text-shadow:0 1px 2px #000; }
		body.inmatch:not(.ingame):not(.sbopen) > .match-chat.open { display:block; visibility:visible !important; }
		.match-chat .history { max-height:40vh; overflow-y:auto; background:rgba(8,18,28,calc(var(--mc-bg,.8)*1.1)); padding:1vh 1vw; overflow-wrap:anywhere; }
		.match-chat .row { margin:.35vh 0; }
		.match-chat .tag { color:#c8c8c8; } .match-chat .row.team .tag { color:#9edbff; }
		.match-chat .row.server, .match-chat .row.staff, .match-chat .row.server .tag, .match-chat .row.staff .tag { color:#ffdc8e; }
		.match-chat .who { font-weight:700; }
		.match-chat .entry { display:flex; align-items:center; gap:.6vw; padding:.6vh .8vw; background:rgba(8,18,28,calc(var(--mc-bg,.8)*1.12)); border-left:3px solid #c8c8c8; }
		.match-chat.team .entry { border-left-color:#9edbff; }
		.match-chat input { min-width:0; flex:1; font:inherit; color:#fff; background:transparent; border:0; outline:0; user-select:text; }
		.match-chat button { font:inherit; color:inherit; border:0; background:transparent; cursor:pointer; font-weight:700; }
		.match-chat.team button { color:#9edbff; }
		.match-chat .help { background:rgba(8,18,28,calc(var(--mc-bg,.8)*1.06)); color:#becdd9; padding:.4vh .8vw; font-size:.85em; }
		.match-chat .notice { color:#ffdc8e; }
		`;
		document.head.appendChild(css);
		root = document.createElement("section"); root.className = "match-chat"; root.setAttribute("aria-label", "Match chat");
		log = document.createElement("div"); log.className = "history"; log.setAttribute("role", "log");
		const entry = document.createElement("div"); entry.className = "entry";
		label = document.createElement("button"); label.type = "button"; label.addEventListener("click", cycle);
		input = document.createElement("input"); input.type = "text"; input.maxLength = 240; input.autocomplete = "off";
		input.setAttribute("aria-label", "Chat message");
		const help = document.createElement("div"); help.className = "help";
		help.textContent = "Enter send  ·  Esc close  ·  Tab General/Team  ·  /mute name  ·  /unmute name  ·  Esc menu: full chat";
		note = document.createElement("div"); note.className = "help notice"; note.setAttribute("role", "status");
		entry.appendChild(label); entry.appendChild(input); root.appendChild(log); root.appendChild(entry); root.appendChild(help); root.appendChild(note);
		document.body.appendChild(root);
		input.addEventListener("compositionstart", () => { composing = true; });
		input.addEventListener("compositionend", () => { composing = false; });
		input.addEventListener("input", () => { draft = input.value; });
	}
	// One line as text nodes: [Tag] Name: text (never HTML).
	function row(l) {
		const r = document.createElement("div"); r.className = "row " + l.channel;
		const tag = document.createElement("span"); tag.className = "tag"; tag.textContent = `[${MATCH_NAMES[l.channel]}] `;
		const body = document.createElement("span"); body.textContent = l.text;
		r.appendChild(tag);
		if (l.channel !== "server") {
			const who = document.createElement("span"); who.className = "who"; who.textContent = `${l.name}: `;
			who.style.color = matchNameColor(l, model.teams()); r.appendChild(who);
		}
		r.appendChild(body);
		return r;
	}
	const unread = () => model.visible(muted).filter(l => !l.mine && l.at > hiddenAt).length;
	function refresh() {
		if (!model.active()) return;
		if (mode() !== lastMode) { lastMode = mode(); post("match-chat:mode|" + lastMode); }
		legacyMutes = nameMutes();
		if (root) {
			root.style.width = WIDTHS[look.width]; root.style.fontSize = SIZES[look.size];
			if (root.style.setProperty) root.style.setProperty("--mc-bg", String(look.opacity / 100));
		}
		if (opened) {
			const scrollTop = log.scrollTop;
			const atBottom = log.scrollTop + log.clientHeight >= log.scrollHeight - 4;
			log.replaceChildren(...model.visible(muted).slice(-look.lines).map(row));
			log.scrollTop = atBottom ? log.scrollHeight : scrollTop;
			root.className = "match-chat open " + channel;
			label.textContent = MATCH_NAMES[channel] + ":";
			input.placeholder = model.available(channel) ? `Say something to ${channel === "team" ? "your team" : "everyone"}` : model.unavailable(channel);
			// Keep the input node, selection and IME composition intact on every received line.
			note.textContent = error || (pending ? "Sending…" : hidden ? "Chat lines are hidden (/ shows them)." : "");
		}
		const teams = model.teams();
		let feed = hidden ? [] : model.feed(muted, look).map(l => ({ key: l.key, channel: l.channel, tag: `[${MATCH_NAMES[l.channel]}]`,
			name: l.channel === "server" ? "" : l.name, color: matchNameColor(l, teams), text: l.text,
			...(l.hold ? { hold: true } : { remaining_ms: l.remaining_ms }) }));
		if (hidden) {
			const n = unread();
			if (n) feed.push({ key: `hidden:${n}`, channel: "notice", tag: "", name: "", text: `Chat hidden · ${n} new · / shows it`, hold: true });
		}
		if (feedback && now() < feedback.until) {
			feed.push({ key: feedback.key, channel: "notice", tag: "", name: "", text: feedback.text, remaining_ms: feedback.until - now() });
			if (feed.length > look.lines) feed.shift();
		}
		// Native HUD owns fading, so there is no page animation or per-frame WebView polling.
		const serial = JSON.stringify(feed);
		if (serial !== lastFeed) { lastFeed = serial; post("match-chat:feed|" + serial); }
		changed();
	}
	function close(notify = true) {
		if (!opened) return;
		draft = input.value; input.blur(); opened = false; composing = false;
		root.className = "match-chat";
		if (notify) { waitingRelease = true; post("match-chat:close"); }
	}
	function open(ch, token) {
		if (!model.active() || !inMatch() || document.body.classList.contains("ingame") || document.body.classList.contains("sbopen")) return;
		// index.html's controller poll calls the global action dispatcher directly, bypassing DOM
		// keyboard capture. Install only on the first opt-in open, after that script has loaded.
		// Keep the shared page untouched; its actions resume after the native close-key release.
		if (typeof window.action === "function" && window.action !== guardedAction) {
			const dispatch = window.action;
			guardedAction = function (...args) { if (!model.active() || !inMatch() || !opened && !waitingRelease) return dispatch.apply(this, args); };
			window.action = guardedAction;
		}
		build(); enable(); opened = true; waitingRelease = false;
		if (ch === "all" || ch === "team") channel = ch;
		error = ""; input.value = draft; refresh();
		post("match-chat:shown|" + token);
	}
	function cycle() {
		const channels = ["all", "team"].filter(c => model.available(c));
		if (channels.length) channel = channels[(channels.indexOf(channel) + 1) % channels.length];
		error = ""; refresh(); input.focus();
	}
	function toggle() {
		hidden = !hidden; hiddenAt = now(); save("rr.matchchat.hidden", hidden ? "1" : "0");
		feedback = { text: hidden ? "Chat hidden. Press / to show it." : "Chat shown.", key: `notice:${now()}`, until: now() + 3000 };
		refresh();
	}
	// `/mute name` and `/unmute name` (names, for players whose friend code the match doesn't carry).
	function muteName(name, on) {
		const mutes = nameMutes(); name = chatClean(name, 32);
		if (on && !mutes.has(name) && mutes.size >= 256) return "Mute list is full. Unmute a player before adding another.";
		if (on) mutes.add(name); else mutes.delete(name);
		save("rr-muted", JSON.stringify([...mutes])); refresh();
		return `${name} ${on ? "muted" : "unmuted"}.`;
	}
	// Sends for the composer or the game menu's Match tab; the reply (sent/error) comes back to `from`.
	function submit(ch, text, from) {
		// (a send the overlay never answered, e.g. the game menu closed under it, doesn't block the next)
		if (pending && now() - pending.at > 7000) pending = null;
		if (pending) return "A message is still being sent.";
		const out = model.prepare(ch, text);
		if (out.error) return out.error;
		pending = { channel: ch, draft: text, request: String(++sendSequence), from, at: now() };
		post("match-chat:send|" + JSON.stringify(out));
		return "";
	}
	function send() {
		const command = input.value.trim().match(/^\/(unmute|mute)\s+(.+)$/i);
		if (command) {
			error = muteName(command[2], command[1].toLowerCase() === "mute");
			if (!/full/.test(error)) draft = input.value = "";
			refresh(); return;
		}
		if (pending) return;
		const err = submit(channel, input.value, "composer");
		if (err) { error = err; refresh(); return; }
		error = "";
		// Return control immediately; keep the draft until the authoritative reply arrives.
		close(); refresh();
	}
	function sent() {
		if (!pending) return;
		const p = pending; pending = null;
		if (p.from === "composer") {
			if (draft === p.draft) draft = "";
			if (input && input.value === p.draft) input.value = "";
		}
		dock = { ok: true, from: p.from, draft: p.draft };
		refresh();
	}
	function failed(text) {
		const p = pending; pending = null; error = chatClean(text, 200);
		dock = { ok: false, from: p && p.from, error, draft: p && p.draft };
		if (!p || p.from === "composer") feedback = { text: "Chat: " + error, key: `notice:${now()}`, until: now() + 8000 };
		refresh();
	}
	// Capture before document/menu handlers, including Esc and Tab. Ignore IME confirm/cancel keys.
	window.addEventListener("keydown", e => {
		if (waitingRelease) { e.stopImmediatePropagation(); e.preventDefault(); return; }
		if (!opened) return;
		e.stopImmediatePropagation();
		if (composing || e.isComposing || e.keyCode === 229) return;
		if (e.key === "Escape") { e.preventDefault(); close(); }
		else if (e.key === "Enter") { e.preventDefault(); if (!e.repeat) send(); }
		else if (e.key === "Tab") { e.preventDefault(); cycle(); }
		else if (e.key === "PageUp" || e.key === "PageDown") { e.preventDefault(); log.scrollTop += log.clientHeight * (e.key === "PageUp" ? -1 : 1); }
	}, true);
	let wasInMatch = inMatch();
	new window.MutationObserver(() => {
		const playing = inMatch();
		if (playing && !wasInMatch && model.active()) post("match-chat:sync");
		wasInMatch = playing;
		if (!playing) { close(false); model.reset(); lastFeed = ""; changed(); }
		else if (document.body.classList.contains("ingame") || document.body.classList.contains("sbopen")) close();
	}).observe(document.body, { attributes: true, attributeFilter: ["class"] });
	post("match-chat:ready");
	return {
		refresh,
		isOpen: () => opened || waitingRelease,
		// For the dock's Match tab (the game menu): the whole history, sending, and name mutes.
		active: () => model.active() && inMatch(),
		history: () => model.visible(muted),
		available: ch => model.available(ch),
		unavailable: ch => model.unavailable(ch),
		teams: () => model.teams(),
		color: l => matchNameColor(l, model.teams()),
		// A key's channel: the player's Team or General key ("team", "all"), else null.
		keyChannel: code => !model.active() ? null : code === look.team ? "team" : code === look.general ? "all" : null,
		say: (ch, text) => submit(ch, text, "dock"),
		// The dock's last send: {ok, draft} or {ok: false, error}, taken once.
		reply() { if (!dock || dock.from !== "dock") return null; const r = dock; dock = null; return r; },
		muteName,
		nameMuted: name => nameMutes().has(name),
		onChange(fn) { listeners.add(fn); },
		// The look settings from `settings-state:` (start-menu.js passes every one).
		settings(st) { look = matchLook(st); refresh(); },
		// The show/hide chat key, which the dock uses in the menus.
		toggleKey: () => look.toggle,
		social(data) {
			// Keep moderation state learned in menus before the first match snapshot arrives.
			model.social(inMatch() ? data : { blocked: data?.blocked, removed: data?.removed });
			if (inMatch()) refresh();
		},
		message(text) {
			if (!text.startsWith("match-chat:")) return false;
			const [kind, data = ""] = text.slice(11).split(/\|(.*)/s);
			try {
				if (kind === "config") { model.configure(data === "1"); if (!model.active()) close(false); else refresh(); }
				else if (kind === "state" && inMatch()) { model.snapshot(JSON.parse(data)); refresh(); }
				else if (kind === "open") { const o = JSON.parse(data); request = o.token; open(o.channel, o.token); }
				else if (kind === "focus" && opened && data === request) input.focus();
				else if (kind === "toggle" && model.active()) toggle();
				else if (kind === "cancel") close(false);
				else if (kind === "released") waitingRelease = false;
				else if (kind === "away") { model.away(data === "1"); refresh(); }
				else if (kind === "reset") { close(false); waitingRelease = false; pending = null; feedback = null; model.reset(); lastFeed = ""; changed(); }
				else if (kind === "sent" && pending) sent();
				else if (kind === "error" && pending) failed(data);
			} catch { /* malformed local snapshot: ignore, keep the draft */ }
			return true;
		},
	};
}

if (typeof module !== "undefined") module.exports = { chatClean, createMatchChatModel, createMatchChat, matchLook };
