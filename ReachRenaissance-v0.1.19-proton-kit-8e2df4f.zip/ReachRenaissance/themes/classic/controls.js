// Shared menu controls (owner, 2026-10-16: "a dropdown should pop up where you can select different
// match length times if you click on it with a mouse or press A on it with a controller").
//
// Dropdown.open({ title, options, value, anchor, onPick, onClose }): a list of choices beside the
// value that opened it, instead of stepping through them one press at a time.
//   options: [[value, label], ...] (or plain labels: the value is then the label's index)
//   value:   the current value (highlighted and marked)
//   anchor:  the element the list drops from (its value box), or null for the middle of the screen
//   onPick(value, index), onClose(): called when a choice is made / when it closes without one
// Mouse: hover moves the highlight, a click picks, a click outside or the wheel past the ends closes
// or scrolls. Keyboard and controller go through the page's actions: the page's action() asks
// Dropdown.action(a) first while a list is open (up/down move, left/right page, select picks, back
// closes). Every menu uses this one, so they all behave the same.
// Shared list scrolling (owner, 2026-10-17: "if you scroll down while your mouse is hovering over a
// menu item it locks you there instead of scrolling down - every single menu that has more settings
// that you need to scroll down to see NEEDS a scroll bar"). Every menu's lists use these:
// - MenuScroll.hoverOk(): whether a hover may move the highlight. False from a wheel turn, a key or a
//   controller press (MenuScroll.still(), the page's pad polling) until the mouse really moves: when a
//   list moves under a still cursor the browser reports the item now under it as hovered, and that used
//   to pull the highlight straight back (the "lock"). With a controller it raced: each move scrolled the
//   list, the item now under the forgotten cursor took the highlight, which scrolled again, until the
//   list stopped (player report, 2026-10-18: Forge's map list "spazzing across the selections").
// - class MenuScroll.CLASS ("rr-scroll") on a box that scrolls itself: a scroll bar that is always
//   visible while there is more to see.
// - MenuScroll.bar(first, shown, total, style): the HTML of a scroll bar for a list drawn a window at
//   a time (empty when it all fits); `style` places it (left/top/height). A click on its track pages
//   (MenuScroll.wire(root, act): act("up"|"down") per click above/below the thumb).
// - MenuScroll.keep(el, fn): runs fn (which rebuilds el's contents) keeping el's scroll position.
const MenuScroll = (() => {
	let moved = true, lastX = null, lastY = null;
	window.addEventListener("wheel", () => { moved = false; }, { capture: true, passive: true });
	window.addEventListener("keydown", () => { moved = false; }, true);
	window.addEventListener("mousemove", (e) => {
		if (lastX !== null && (e.screenX !== lastX || e.screenY !== lastY)) moved = true;
		lastX = e.screenX;
		lastY = e.screenY;
	}, true);
	const style = document.createElement("style");
	style.textContent = `
	.rr-scroll { overflow-y: auto !important; overflow-x: hidden; scrollbar-width: auto !important; scrollbar-color: auto !important; }
	.rr-scroll::-webkit-scrollbar { width: 0.9vh; }
	.rr-scroll::-webkit-scrollbar-track { background: rgba(255,255,255,0.08); border-radius: 0.45vh; }
	.rr-scroll::-webkit-scrollbar-thumb { background: rgba(235,240,245,0.55); border-radius: 0.45vh; }
	.rr-scroll::-webkit-scrollbar-thumb:hover { background: rgba(235,240,245,0.85); }
	.rr-bar { position: absolute; width: 0.9vh; background: rgba(255,255,255,0.08); border-radius: 0.45vh; cursor: pointer; z-index: 3; }
	.rr-bar i { position: absolute; left: 0; right: 0; background: rgba(235,240,245,0.6); border-radius: 0.45vh; pointer-events: none; }
	`;
	(document.head || document.documentElement).appendChild(style);
	function bar(first, shown, total, place) {
		if (total <= shown) return "";
		const top = (first / total * 100).toFixed(2), height = Math.max(6, shown / total * 100).toFixed(2);
		return `<div class="rr-bar" style="${place || ""}"><i style="top:${top}%;height:${height}%"></i></div>`;
	}
	function wire(root, act) {
		root.querySelectorAll(".rr-bar").forEach(b => b.onclick = (ev) => {
			ev.stopPropagation();
			const r = b.getBoundingClientRect(), thumb = b.querySelector("i").getBoundingClientRect();
			act(ev.clientY < thumb.top ? "up" : ev.clientY > thumb.bottom ? "down" : null, r);
		});
	}
	function keep(el, fn) {
		const at = el ? el.scrollTop : 0;
		fn();
		if (el && el.isConnected) el.scrollTop = at;
	}
	return { hoverOk: () => moved, still() { moved = false; }, CLASS: "rr-scroll", bar, wire, keep };
})();
window.MenuScroll = MenuScroll;

const Dropdown = (() => {
	const SHOWN = 9; // rows visible at once; longer lists scroll
	let state = null; // { options, sel, top, onPick, onClose, anchor }
	const root = document.createElement("div");
	root.className = "rrdrop";
	const style = document.createElement("style");
	style.textContent = `
	.rrdrop { position: fixed; z-index: 1001; display: none; min-width: 12vw; max-width: 40vw;
		font-family: var(--font, "Bahnschrift", "Segoe UI", sans-serif); color: #e8ecef;
		background: rgba(8,14,20,0.96); border: 1px solid rgba(255,255,255,0.55);
		box-shadow: 0 1.2vh 3vh rgba(0,0,0,0.6), inset 0 0 0 1px rgba(110,160,200,0.18); }
	.rrdrop.open { display: block; animation: rrdropin 0.12s ease-out; }
	@keyframes rrdropin { from { opacity: 0; transform: translateY(-0.6vh); } to { opacity: 1; transform: none; } }
	.rrdrop .t { padding: 0.8vh 1vw 0.6vh; font-size: 1.7vh; font-weight: 600; letter-spacing: 0.14em; text-transform: uppercase;
		color: rgba(160,190,214,0.9); border-bottom: 1px solid rgba(255,255,255,0.14); }
	.rrdrop ul { list-style: none; margin: 0; padding: 0.4vh 0; }
	.rrdrop li { display: flex; align-items: center; gap: 0.8vw; padding: 0.55vh 1vw 0.55vh 1.4vw; font-size: 2.3vh; font-weight: 500;
		white-space: nowrap; cursor: pointer; }
	.rrdrop li.sel { color: #fff; background: linear-gradient(90deg, rgba(255,255,255,0.18), rgba(255,255,255,0.05) 85%, transparent);
		box-shadow: inset 0.22vw 0 0 #f2f4f5; }
	.rrdrop li.cur::after { content: "\\2713"; margin-left: auto; padding-left: 1vw; font-size: 1.9vh; color: rgba(160,200,230,0.95); }
	.rrdrop .more { text-align: center; font-size: 1.6vh; line-height: 1.6vh; color: rgba(214,222,228,0.55); height: 1.6vh; }
	.rrdrop .rr-bar { right: 0.25vw; }
	`;
	const esc = (s) => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
	const play = (n) => { if (typeof Sound !== "undefined") Sound.play(n); };

	function render() {
		const { options, sel } = state;
		if (sel < state.top) state.top = sel;
		if (sel >= state.top + SHOWN) state.top = sel - SHOWN + 1;
		const top = state.top;
		root.innerHTML = (state.title ? `<div class="t">${esc(state.title)}</div>` : "")
			+ `<div class="more">${top > 0 ? "&#8963;" : ""}</div><ul>`
			+ options.slice(top, top + SHOWN).map((o, k) => `<li data-i="${top + k}" class="${top + k === sel ? "sel" : ""}${o[0] === state.value ? " cur" : ""}">${esc(o[1])}</li>`).join("")
			+ `</ul><div class="more">${top + SHOWN < options.length ? "&#8964;" : ""}</div>`
			+ MenuScroll.bar(top, SHOWN, options.length, "top:4.2vh;bottom:2vh");
		MenuScroll.wire(root, (dir) => { if (dir) { state.top = Math.max(0, Math.min(options.length - SHOWN, state.top + (dir === "down" ? SHOWN : -SHOWN))); state.sel = Math.max(state.top, Math.min(state.sel, state.top + SHOWN - 1)); render(); } });
		root.querySelectorAll("li").forEach(li => {
			const i = +li.dataset.i;
			li.onmouseenter = () => { if (state && state.sel !== i && MenuScroll.hoverOk()) { state.sel = i; play("move"); render(); } };
			li.onclick = (ev) => { ev.stopPropagation(); if (state) { state.sel = i; pick(); } };
		});
	}
	// Under the anchor's value box (above it when there is no room below), kept on screen.
	function place() {
		const box = root.getBoundingClientRect();
		const a = state.anchor && state.anchor.isConnected ? state.anchor.getBoundingClientRect() : null;
		let left = a ? a.left : (innerWidth - box.width) / 2;
		let top = a ? a.bottom + 4 : (innerHeight - box.height) / 2;
		if (a && top + box.height > innerHeight - 8) top = Math.max(8, a.top - box.height - 4);
		left = Math.max(8, Math.min(left, innerWidth - box.width - 8));
		root.style.left = left + "px";
		root.style.top = top + "px";
		if (a) root.style.minWidth = Math.max(a.width, innerWidth * 0.12) + "px";
	}
	function open(spec) {
		if (!root.isConnected) { document.head.appendChild(style); document.body.appendChild(root); }
		const options = (spec.options || []).map((o, i) => Array.isArray(o) ? o : [i, o]);
		if (!options.length) return false;
		const at = options.findIndex(o => o[0] === spec.value);
		state = { options, sel: Math.max(0, at), top: 0, value: spec.value, title: spec.title || "", anchor: spec.anchor || null,
			onPick: spec.onPick || (() => {}), onClose: spec.onClose || (() => {}) };
		state.top = Math.max(0, Math.min(state.sel - Math.floor(SHOWN / 2), options.length - SHOWN));
		root.classList.add("open");
		render();
		place();
		play("select");
		return true;
	}
	function close(picked) {
		if (!state) return;
		const s = state;
		state = null;
		root.classList.remove("open");
		if (!picked) s.onClose();
	}
	function pick() {
		const s = state, o = s.options[s.sel];
		close(true);
		play("change");
		s.onPick(o[0], s.sel);
	}
	function action(a) {
		if (!state) return false;
		const n = state.options.length;
		if (a === "up" || a === "down") { state.sel = (state.sel + (a === "down" ? 1 : n - 1)) % n; play("move"); render(); }
		else if (a === "left" || a === "right") { state.sel = Math.max(0, Math.min(n - 1, state.sel + (a === "right" ? SHOWN : -SHOWN))); play("move"); render(); }
		else if (a === "select") pick();
		else if (a === "back" || a === "start") { play("back"); close(false); }
		return true; // (every other button does nothing while the list is open)
	}
	// A click anywhere else closes the list (before the page sees that click).
	window.addEventListener("mousedown", (ev) => {
		if (state && !root.contains(ev.target)) { ev.stopPropagation(); ev.preventDefault(); close(false); swallow = true; }
	}, true);
	let swallow = false;
	window.addEventListener("click", (ev) => { if (swallow) { swallow = false; ev.stopPropagation(); ev.preventDefault(); } }, true);
	root.addEventListener("wheel", (ev) => { ev.stopPropagation(); ev.preventDefault(); action(ev.deltaY > 0 ? "down" : "up"); }, { passive: false });
	window.addEventListener("resize", () => { if (state) place(); });
	return { open, close: () => close(false), action, isOpen: () => !!state };
})();
window.Dropdown = Dropdown;
