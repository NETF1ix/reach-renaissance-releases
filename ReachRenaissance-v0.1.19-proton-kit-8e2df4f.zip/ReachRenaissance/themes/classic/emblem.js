// Reach's emblems drawn as the 360 drew them (owner, 2026-10-12: the player's emblem behind the
// Armory Spartan). Shapes are 64x64 distance fields (emblems-data.js, extract_emblems.py) placed by
// the library's shape and layer transforms and combined as in player_emblem.hlsl_include
// (calc_emblem_reach_original): the back emblem's layer, then the front emblem's layer 1, then its
// layer 0, each as saturate(shape0 * multiplier0 + shape1 * multiplier1) in its own color.
//
// Coordinates, worked out from the library's own shapes (their inverse transforms): the emblem is
// p in [-1, 1] (y down); a transform maps it back with (p - offset), un-rotated, un-sheared and
// divided by scale; the shape's bitmap is read at (T + 1) / 2 with its address modes (a "circle" at
// scale 0.5, offset 0.5 is a quarter circle mirrored four ways; "half" bitmaps hold two shapes, the
// offset 1 or -1 picks which, mirrored about the texture's edge).
//
// Colors: the front emblem's "primary layer" (layer 0 for most, layer 1 for 16 of them, the library's
// own field) takes the primary color and its other layer the secondary; the 360's "Toggle Emblem"
// (supply_depot_emblem: "Toggle Emblem Secondary Color", "Foreground (Toggled)") leaves that other
// layer out.
//
// Emblem.player(): the player's emblem { front, back, toggle, colors: [primary, secondary, background] }
// (localStorage rr.emblem; Armory > Emblem and Armory > Colors set it with Emblem.save).
// Emblem.current(): the emblem a page is trying out (Emblem.preview), else the player's.
// Emblem.draw(canvas, emblem, opts): draws it into the canvas (opts.alpha scales the coverage).
// Emblem.code(emblem): `<front>.<back>.<toggle>.<primary>.<secondary>.<background>`, library indices
// and rgb hex, as the menus send it to the overlay (the appearance file's `emblem=` line).
window.Emblem = (() => {
	const STORE = "rr.emblem";
	const DEFAULT = { front: "smiley", back: "cog", colors: ["c23b33", "2fa59a", "6a5aa8"] };
	const fields = [];

	function field(index) {
		if (!fields[index]) {
			const d = window.EMBLEM_DATA, bin = atob(d.fields[index] || "");
			const f = new Float32Array(d.size * d.size);
			for (let i = 0; i < bin.length; i++) f[i] = bin.charCodeAt(i) / 255;
			fields[index] = f;
		}
		return fields[index];
	}

	// 2x2 inverse of rotation * shear * scale, applied to (p - offset).
	function inverse(tr) {
		const a = (tr.rotation || 0) * Math.PI / 180, c = Math.cos(a), s = Math.sin(a);
		const [sx, sy] = tr.scale, [hx, hy] = tr.shear;
		// M = R * H * S, H = [[1, hx], [hy, 1]]
		const h = [[sx, hx * sy], [hy * sx, sy]];
		const m = [[c * h[0][0] - s * h[1][0], c * h[0][1] - s * h[1][1]], [s * h[0][0] + c * h[1][0], s * h[0][1] + c * h[1][1]]];
		const det = m[0][0] * m[1][1] - m[0][1] * m[1][0] || 1e-6;
		const inv = [[m[1][1] / det, -m[0][1] / det], [-m[1][0] / det, m[0][0] / det]];
		const [ox, oy] = tr.offset;
		return { f: (x, y) => [inv[0][0] * (x - ox) + inv[0][1] * (y - oy), inv[1][0] * (x - ox) + inv[1][1] * (y - oy)],
			scale: Math.sqrt(Math.abs(det)) };
	}

	function address(t, mode) {
		if (mode === "wrap") return t - Math.floor(t);
		if (mode === "mirror") { const u = ((t % 2) + 2) % 2; return u > 1 ? 2 - u : u; }
		if (mode === "mirroronce") return Math.min(Math.abs(t), 1);
		return Math.min(Math.max(t, 0), 1);
	}

	function sample(f, n, u, v) {
		const x = u * n - 0.5, y = v * n - 0.5;
		const x0 = Math.max(0, Math.min(n - 1, Math.floor(x))), y0 = Math.max(0, Math.min(n - 1, Math.floor(y)));
		const x1 = Math.min(n - 1, x0 + 1), y1 = Math.min(n - 1, y0 + 1), fx = Math.min(1, Math.max(0, x - x0)), fy = Math.min(1, Math.max(0, y - y0));
		const a = f[y0 * n + x0] * (1 - fx) + f[y0 * n + x1] * fx, b = f[y1 * n + x0] * (1 - fx) + f[y1 * n + x1] * fx;
		return a * (1 - fy) + b * fy;
	}

	// One layer: a function of p giving its coverage 0..1.
	function layerFn(layer, px) {
		const d = window.EMBLEM_DATA, parts = [];
		for (const [shapeName, mult, ltr] of layer) {
			const shape = shapeName && d.shapes[shapeName];
			// (a zero scale is an empty part, the library's "blank" filler: inverted with a tiny determinant it read
			// the bitmap's clamped edge everywhere, a square behind "Power Is On"; JANK_HUNT.md 12)
			if (!shape || !shape.bitmap || !mult || !ltr.scale[0] || !ltr.scale[1]) continue;
			const bm = d.bitmaps[shape.bitmap];
			if (!bm) continue;
			const L = inverse(ltr), S = inverse(shape.transform), f = field(bm.index);
			const expand = (ltr.expand || 0) + (shape.transform.expand || 0);
			// Edge sharpness: the field changes by 1/(2 * gradient) a texel; about one output pixel wide.
			const texelsPerPx = d.size / (px * L.scale * S.scale);
			const blur = (ltr.blur || 0) + (shape.transform.blur || 0);
			const k = Math.min(2 * bm.gradient / Math.max(texelsPerPx, 1e-3), 400) / (1 + blur * 8);
			parts.push((x, y) => {
				const [qx, qy] = L.f(x, y), [tx, ty] = S.f(qx, qy);
				const u = address((tx + 1) / 2, shape.x), v = address((ty + 1) / 2, shape.y);
				const dist = sample(f, d.size, u, v) + expand * 0.25;
				return mult * Math.min(1, Math.max(0, (dist - 0.5) * k + 0.5));
			});
		}
		return (x, y) => { let s = 0; for (const p of parts) s += p(x, y); return Math.min(1, Math.max(0, s)); };
	}

	function rgb(hex) { const n = parseInt(hex, 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }

	function draw(canvas, emblem, opts = {}) {
		const d = window.EMBLEM_DATA;
		if (!d || !canvas) return false;
		const g = canvas.getContext("2d"), n = canvas.width;
		const front = d.front.find(e => e.name === emblem.front), back = d.back.find(e => e.name === emblem.back);
		const [c0, c1, c2] = (emblem.colors || DEFAULT.colors).map(rgb);
		// back (background color), front layer 1, front layer 0; the primary layer in the primary color
		const layers = [];
		if (back && emblem.backOn !== false) layers.push([layerFn(back.layers[0], n), c2]);
		if (front) {
			const primary = /layer 1/i.test(front.primary || "") ? 1 : 0;
			for (const i of [1, 0]) if (i === primary || !emblem.toggle) layers.push([layerFn(front.layers[i], n), i === primary ? c0 : c1]);
		}
		const img = g.createImageData(n, n), alpha = opts.alpha ?? 1;
		for (let j = 0; j < n; j++) for (let i = 0; i < n; i++) {
			const x = (i + 0.5) / n * 2 - 1, y = (j + 0.5) / n * 2 - 1;
			let r = 0, gg = 0, b = 0, a = 0;
			for (const [fn, c] of layers) {
				const v = fn(x, y);
				if (!v) continue;
				r = r * (1 - v) + c[0] * v; gg = gg * (1 - v) + c[1] * v; b = b * (1 - v) + c[2] * v; a = a * (1 - v) + v;
			}
			const o = (j * n + i) * 4;
			// ImageData is straight alpha.
			img.data[o] = a ? r / a : 0; img.data[o + 1] = a ? gg / a : 0; img.data[o + 2] = a ? b / a : 0; img.data[o + 3] = a * alpha * 255;
		}
		g.putImageData(img, 0, 0);
		return true;
	}

	function player() {
		try { return Object.assign({}, DEFAULT, JSON.parse(localStorage.getItem(STORE) || "{}")); } catch (e) { return Object.assign({}, DEFAULT); }
	}
	function save(changes) {
		const e = Object.assign(player(), changes);
		try { localStorage.setItem(STORE, JSON.stringify(e)); } catch (err) { }
		// The party list's own row paints its emblem only when the settings arrive (the menus' start, after a
		// game), so a new one showed the old there until then (stranger test, 2026-10-17; JANK_HUNT.md 11).
		for (const el of document.querySelectorAll(".party .row.player .pemblem")) paint(el, e);
		return e;
	}
	let trying = null;
	function preview(emblem) { trying = emblem || null; }
	function current() { return trying || player(); }
	function code(emblem = player()) {
		const d = window.EMBLEM_DATA, at = (list, name) => Math.max(0, d ? d[list].findIndex(x => x.name === name) : 0);
		return [at("front", emblem.front), at("back", emblem.back), emblem.toggle ? 1 : 0, ...(emblem.colors || DEFAULT.colors)].join(".");
	}

	// Draws the emblem (the current one unless given) into a canvas, or into a canvas inside an element
	// (the plate's and the player panel's emblem spots), cached per size.
	// The cache holds pixels (ImageData), not canvases: when the WebView's GPU process restarts (a player's
	// PC after a long campaign mission, 0.1.7) every canvas loses its picture, and cached canvases drew
	// nothing from then on (the player card's and the party list's emblems vanished). A canvas on the page
	// paints again when the browser gives it back (contextrestored).
	const cache = new Map();
	function paint(el, which) {
		if (!el || !window.EMBLEM_DATA) return;
		let canvas = el;
		if (el.tagName !== "CANVAS") {
			canvas = el.querySelector("canvas.embc");
			if (!canvas) {
				canvas = document.createElement("canvas");
				canvas.className = "embc";
				canvas.style.cssText = "width:100%;height:100%;display:block";
				el.appendChild(canvas);
			}
			el.classList.add("painted");
			const px = Math.max(32, Math.min(512, Math.round(Math.max(el.clientWidth, el.clientHeight) * (window.devicePixelRatio || 1)) || 128));
			if (canvas.width !== px) { canvas.width = px; canvas.height = px; }
		}
		const emblem = which && which.front !== undefined ? which : current(), key = JSON.stringify(emblem) + "@" + canvas.width;
		if (!cache.has(key)) {
			if (cache.size > 200) cache.clear();
			const c = document.createElement("canvas");
			c.width = c.height = canvas.width;
			draw(c, emblem);
			cache.set(key, c.getContext("2d").getImageData(0, 0, c.width, c.height));
		}
		const g = canvas.getContext("2d");
		g.putImageData(cache.get(key), 0, 0);
		canvas.rrEmblem = which && which.front !== undefined ? which : null;
		if (!canvas.rrRestore) {
			canvas.rrRestore = true;
			canvas.addEventListener("contextrestored", () => { if (canvas.isConnected) paint(canvas, canvas.rrEmblem); });
		}
	}

	return { draw, paint, player, save, preview, current, code, DEFAULT };
})();
