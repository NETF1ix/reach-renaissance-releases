// The first run's WELCOME TO NOBLE TEAM screen, as on the 360 (owner's screenshot, 2026-10-17): Noble
// Six holding his helmet on the left (ui\cui\alert\new_user_image, scripts/menu/extract_ui_pictures.py),
// Reach's own words on a slate panel (ui\cui\strings\alert_strings), "First things first:" and MALE /
// FEMALE, and "Select and Continue to the Armory". Ours also asks for the player's name there (owner:
// "it doesn't let you move forward until you do that"): Continue waits for a valid one.
// Saves the name with `setting:name=` (settings.rs) and the gender in the profile (StartMenu.setGender).
window.Welcome = (() => {
	const css = document.createElement("style");
	css.textContent = `
	.wl { position: fixed; inset: 0; z-index: 1003; display: none; font-family: var(--font); color: #c9d0d5;
		background: radial-gradient(ellipse at 30% 40%, #3a4855 0%, #1f2a34 45%, #10161c 100%); }
	.wl.open { display: block; }
	.wl .six { position: absolute; left: 6vw; top: 7vh; height: 88vh; width: 30vw; object-fit: contain; object-position: center bottom;
		filter: drop-shadow(0 1vh 2vh rgba(0, 0, 0, 0.6)); }
	.wl .panel { position: absolute; left: 36vw; right: 4vw; top: 22vh; height: 68vh;
		background: linear-gradient(90deg, rgba(44, 54, 64, 0.88), rgba(34, 43, 52, 0.82) 70%, rgba(34, 43, 52, 0.5)); overflow: hidden; }
	.wl .panel::before, .wl .panel::after { content: ""; position: absolute; left: 0; right: 0; height: 1px;
		background: linear-gradient(90deg, transparent, rgba(220, 228, 234, 0.75) 12%, rgba(220, 228, 234, 0.75) 80%, transparent); }
	.wl .panel::before { top: 0; }
	.wl .panel::after { bottom: 0; }
	.wl .mark { position: absolute; right: -4vw; top: 6vh; width: 34vw; height: 50vh; opacity: 0.05; pointer-events: none; }
	.wl h1 { position: relative; margin: 4vh 0 2.4vh 3vw; font-size: 6.4vh; font-weight: 700; letter-spacing: 0.01em; color: #dfe4e8;
		text-transform: uppercase; text-shadow: 0 0.3vh 0.8vh rgba(0, 0, 0, 0.6); }
	.wl .say { position: relative; margin: 0 6vw 0 3vw; font-size: 2.55vh; line-height: 1.35; color: #a9b3ba; }
	.wl .say p { margin: 0 0 2vh; }
	.wl .first { position: relative; margin: 3vh 0 1.2vh 3vw; font-size: 2.8vh; color: #e8ecef; }
	.wl ul { position: relative; list-style: none; margin: 0 0 0 3vw; padding: 0; width: 22vw; }
	.wl li { position: relative; display: flex; align-items: center; height: 4.4vh; padding-left: 1vw; font-size: 2.9vh; font-weight: 600;
		text-transform: uppercase; color: rgba(220, 228, 234, 0.55); cursor: pointer; }
	.wl li.sel { background: linear-gradient(90deg, rgba(220, 228, 234, 0.2), rgba(220, 228, 234, 0.06)); color: #fff; }
	.wl li.sel::before { content: ""; position: absolute; left: 0; top: 0; bottom: 0; width: 0.25vw; background: #f2f4f5; }
	.wl li.on::after { content: "\\25C6"; margin-left: 1.2vw; font-size: 1.8vh; color: #9fd0ff; }
	/* The on-screen keyboard (a controller has no keys to type a name with; bug sweep, 2026-10-17) */
	.wl .osk { position: absolute; inset: 0; display: none; flex-direction: column; justify-content: center;
		align-items: center; gap: 1vh; background: #161e26; z-index: 2; }
	.wl .osk.open { display: flex; }
	.wl .osk .typed { font-size: 4vh; font-weight: 700; min-height: 5vh; letter-spacing: 0.04em; color: #fff; border-bottom: 1px solid rgba(220,228,234,0.4);
		min-width: 40%; text-align: center; margin-bottom: 1.5vh; }
	.wl .osk .row { display: flex; gap: 0.5vw; }
	.wl .osk .k { min-width: 4.4vh; height: 4.8vh; padding: 0 0.6vw; display: flex; align-items: center; justify-content: center; font-size: 2.4vh;
		font-weight: 600; background: rgba(220, 228, 234, 0.08); border: 1px solid rgba(220, 228, 234, 0.15); cursor: pointer; }
	.wl .osk .k.sel { background: rgba(220, 228, 234, 0.85); color: #10161c; }
	.wl .osk .help { margin-top: 1.5vh; font-size: 2vh; color: #a9b3ba; }
	.wl li.name { width: 30vw; margin-bottom: 1.4vh; }
	.wl li.name input { flex: 1; margin-left: 1vw; font: 600 2.9vh var(--font); letter-spacing: 0.03em; padding: 0.3vh 0.6vw; color: #fff;
		background: rgba(0, 0, 0, 0.35); border: 1px solid rgba(255, 255, 255, 0.3); outline: none; text-transform: none; }
	.wl li.name input::placeholder { color: rgba(220, 228, 234, 0.4); }
	.wl li.sel input { border-color: #f2f4f5; }
	.wl .err { position: relative; min-height: 2.6vh; margin: 1vh 0 0 3vw; font-size: 2.2vh; color: #e8a33a; }
	.wl .keys { position: absolute; right: 4vw; top: 91.5vh; display: flex; gap: 1.6vw; font-size: 2.6vh; color: #e8ecef; }
	.wl .keys .hint { cursor: pointer; }
	.wl .keys .hint.off { opacity: 0.45; }`;
	document.head.appendChild(css);
	const root = document.createElement("div");
	root.className = "wl";
	// (Reach's alert_strings, English, word for word; its two spaces between sentences kept)
	root.innerHTML = `<img class="six" src="ui/new_user.png" alt="" onerror="this.remove()">
		<div class="panel">
			<svg class="mark" viewBox="0 0 100 100"><path d="M50 8 L92 34 L92 50 L50 24 L8 50 L8 34 Z M50 40 L92 66 L92 82 L50 56 L8 82 L8 66 Z" fill="#fff"/></svg>
			<h1>Welcome to Noble Team</h1>
			<div class="say"><p>Welcome to Reach, Spartan.&nbsp; More importantly, welcome to Noble Team.&nbsp; I need you to hit the ground running, so it's time to get you outfitted with your own personalized Spartan armor.</p>
			<p>You'll find upgrades in the Armory.&nbsp; Some are available to you from the get-go, but you're going to have to earn the rest.&nbsp; Time to get your boots in the mud.&nbsp; Question is, which boots?</p></div>
			<div class="first">First things first:</div>
			<ul><li class="name" data-i="0">Name<input maxlength="15" spellcheck="false" autocomplete="off" placeholder="Your Spartan's name"></li>
				<li data-i="1">Male</li><li data-i="2">Female</li></ul>
			<div class="err"></div>
			<div class="osk"><div class="typed"></div><div class="keys2"></div>
				<div class="help"><span class="btn a">A</span> Type &nbsp; <span class="btn b">B</span> Delete &nbsp; <span class="btn x">X</span> Space &nbsp; <span class="btn start">&#9776;</span> Done</div></div>
		</div>
		<div class="keys"><span class="hint" data-a="select"><span class="btn a">A</span>Select and Continue to the Armory</span></div>`;
	document.body.appendChild(root);
	const input = root.querySelector("input"), err = root.querySelector(".err"), go = root.querySelector(".keys .hint");
	let open = false, sel = 0, female = false, done = null;
	const valid = (n) => /^[A-Za-z0-9 _-]{1,15}$/.test(n) && n.trim() === n;
	const play = (n) => { if (typeof Sound !== "undefined") Sound.play(n); };

	// The on-screen keyboard: open (A on the Name row from a controller) types into the name box.
	const OSK = ["1234567890", "QWERTYUIOP", "ASDFGHJKL-", "ZXCVBNM_", ["Shift", "Space", "Delete", "Done"]];
	const osk = { open: false, r: 1, c: 0, lower: false };
	const oskEl = root.querySelector(".osk");
	function oskKeys() { return OSK.map(row => typeof row === "string" ? [...row].map(ch => osk.lower && /[A-Z]/.test(ch) ? ch.toLowerCase() : ch) : row); }
	function oskRender() {
		oskEl.classList.toggle("open", osk.open);
		if (!osk.open) return;
		oskEl.querySelector(".typed").textContent = input.value || " ";
		oskEl.querySelector(".keys2").innerHTML = oskKeys().map((row, r) => `<div class="row">${row.map((k, c) =>
			`<div class="k${r === osk.r && c === osk.c ? " sel" : ""}" data-r="${r}" data-c="${c}">${k}</div>`).join("")}</div>`).join("");
		oskEl.querySelectorAll(".k").forEach(el => el.onclick = () => { osk.r = +el.dataset.r; osk.c = +el.dataset.c; oskAct("select"); });
	}
	function oskType(key) {
		if (key === "Shift") osk.lower = !osk.lower;
		else if (key === "Delete") input.value = input.value.slice(0, -1);
		else if (key === "Done") { osk.open = false; pick(input.value.trim() ? (female ? 2 : 1) : 0); }
		else if (input.value.length < 15) input.value += key === "Space" ? " " : key;
		err.textContent = "";
	}
	function oskAct(a) {
		const keys = oskKeys();
		if (a === "up" || a === "down") { osk.r = (osk.r + (a === "down" ? 1 : keys.length - 1)) % keys.length; osk.c = Math.min(osk.c, keys[osk.r].length - 1); play("move"); }
		else if (a === "left" || a === "right") { const n = keys[osk.r].length; osk.c = (osk.c + (a === "right" ? 1 : n - 1)) % n; play("move"); }
		else if (a === "select") { oskType(keys[osk.r][osk.c]); play("change"); }
		else if (a === "back") { oskType("Delete"); play("back"); }
		else if (a === "star") { oskType("Space"); play("change"); }
		else if (a === "start") { oskType("Done"); play("select"); }
		oskRender();
		render();
	}
	function render() {
		root.querySelectorAll("li").forEach((li, i) => {
			li.classList.toggle("sel", i === sel);
			li.classList.toggle("on", i === (female ? 2 : 1));
		});
		go.classList.toggle("off", !valid(input.value.trim()));
		if (sel === 0 && !osk.open) input.focus(); else input.blur();
	}
	function show(current, isFemale, after) {
		open = true;
		done = after || null;
		input.value = current && current !== "Player" ? current : "";
		female = !!isFemale;
		sel = valid(input.value) ? (female ? 2 : 1) : 0;
		err.textContent = "";
		root.classList.add("open");
		setTimeout(render, 0);
	}
	function pick(i) {
		sel = i;
		if (i > 0) {
			female = i === 2;
			if (typeof StartMenu !== "undefined") StartMenu.setGender(female);
		}
		render();
	}
	function accept() {
		const name = input.value.trim();
		input.value = name;
		if (!valid(name)) {
			err.textContent = name ? "Names are 1 to 15 letters, numbers, spaces, - or _." : "Enter your name to continue.";
			play("error");
			pick(0);
			return;
		}
		open = false;
		root.classList.remove("open");
		input.blur();
		document.getElementById("player").textContent = name;
		// (the service tag under it follows the name, as host-probe makes it, unless one is saved; it had kept
		// the one made from the launch name, and the party card went out with it)
		const tag = document.getElementById("player-tag");
		if (tag && !(window.savedTag)) tag.textContent = name.replace(/[^A-Za-z0-9]/g, "").slice(0, 4).toUpperCase();
		try { window.chrome.webview.postMessage("setting:name=" + name); } catch (e) { }
		if (typeof StartMenu !== "undefined") StartMenu.setGender(female);
		play("select");
		if (done) done(name, female);
	}
	input.addEventListener("keydown", (e) => {
		e.stopPropagation();
		if (e.key === "Enter") { e.preventDefault(); accept(); }
		else if (e.key === "ArrowDown" || e.key === "Tab") { e.preventDefault(); play("move"); pick(1); }
		else if (e.key === "ArrowUp") { e.preventDefault(); play("move"); pick(2); }
	});
	input.addEventListener("input", () => { err.textContent = ""; render(); });
	root.querySelectorAll("li").forEach(li => li.onclick = (ev) => {
		const i = +li.dataset.i;
		if (i === 0) { sel = 0; return render(); }
		play("change");
		pick(i);
	});
	go.onclick = accept;

	return {
		show,
		get open() { return open; },
		// Controller and arrows: up and down move between the name and the two genders (a gender is
		// chosen as soon as it is highlighted, as Reach does); A continues. No Back: a name is needed.
		action(a) {
			if (osk.open) return oskAct(a);
			// (A on the Name row: the on-screen keyboard, as a controller can't type; Enter in the box still accepts)
			if (a === "select" && sel === 0) { osk.open = true; osk.r = 1; osk.c = 0; play("select"); oskRender(); render(); return; }
			if (a === "up" || a === "down") {
				play("move");
				pick((sel + (a === "down" ? 1 : 2)) % 3);
			} else if (a === "select") accept();
			else if (a === "back") play("error");
		},
	};
})();
