// The Spartan as a picture in the page (owner, 2026-10-12). The Armory showed the game's black void
// around the Spartan, the page covered his front, and the player panel froze the backdrop. The overlay
// program now sends the game window's pixels (figure.rs, WebView2 shared memory); this page keys out
// the black backdrop and draws the Spartan over its own background and emblem, in front of the plate.
//
// Figure.want("live"):  frames as they come (The Armory, the Start menu's Armory section): the game's
//                       main view (his lighting and armor effects) inside the outline of Reach's
//                       texture camera's picture (EXP-045: aimed like the backdrop's own camera, him
//                       alone on pure black; owner 2026-10-13, option 1), or the game window when no
//                       picture comes. The piece pages' close views (a clip box) use the texture
//                       camera's own colours, as only it turns there.
// Figure.want("still", { ready, back, strict, settle, hidden }): the player panel's Spartan over the live
//                       backdrop (strict: figure-mask.js's strict keying, for the Armory's black void; settle:
//                       ms of frames skipped first; hidden: not shown while recording, only the loop). Two seconds
//                       of him are recorded, then ready() (time to move the camera back), and once
//                       the frames show the backdrop again (back()) the recording plays in a loop, its
//                       end blended into its start, so he keeps breathing and his armor effect keeps
//                       moving (owner, 2026-10-12: a still picture stopped the animation).
// Figure.want("texcam", { fallback }): the player panel's Spartan from Reach's own texture camera
//                       (EXP-045): the game renders him live into a picture of his own (framed like
//                       the roster camera) while its main camera keeps showing the lobby, so he moves
//                       and the backdrop moves, with no recording (owner, 2026-10-13); fallback()
//                       when no picture comes (an older game program or menu map).
// Figure.want(null):    nothing.
// Figure.clip(el):      only inside that element (the card pages' preview box), or null.
// Figure.fitTo(box):    the player card: him (his outline's extent in the first frames) scaled and moved
//                       so his head is at box.top, his feet at box.bottom and his middle at box.cx
//                       (fractions of the page), as the 360's card (owner, 2026-10-13). null: none.
// Figure.keepRightOf(x): his left edge at least at x (a fraction of the page's width): a customization
//                       page's panels end there, so he stands in the clear space beside them instead of
//                       behind or in front of them (owner, 2026-10-13); measured on the first frames, then
//                       held while the page is open (turning him doesn't slide him). null: no shift.
// Figure.grab(ms, done): a picture of the game window as it is in ms milliseconds, unkeyed and
//                       small (done(jpeg data URL)): the Theme page's previews.
// Figure.windowPictures: false when the overlay takes no pictures of the game window (`?windowpictures=0`,
//                       under Wine, where they come out black: figure.rs). Then grab never answers, and
//                       "still" never records.
// While a picture is up, <body> has the class "figure" (pages make themselves opaque with it).
window.Figure = (() => {
	const windowPictures = !(typeof location !== "undefined" && /[?&]windowpictures=0(&|$)/.test(location.search));
	let canvas = document.createElement("canvas");
	canvas.id = "figure";
	const css = document.createElement("style");
	css.textContent = `
	#figure, #figloop { position: fixed; left: 0; top: 0; width: 100vw; height: 100vh; z-index: 3; pointer-events: none; display: none; }
	body.figure #figure, body.figloop #figloop { display: block; }`;
	document.head.appendChild(css);
	document.body.appendChild(canvas);
	const loopCanvas = document.createElement("canvas");
	loopCanvas.id = "figloop";
	document.body.appendChild(loopCanvas);
	// (preserveDrawingBuffer: the recording copies frames out of the canvas)
	const GL_OPTIONS = { premultipliedAlpha: true, alpha: true, antialias: false, preserveDrawingBuffer: true };
	let gl = canvas.getContext("webgl", GL_OPTIONS);
	// The WebView's GPU process can restart under the game (a player's PC after a 32-minute campaign
	// mission, 0.1.7): the WebGL context is lost and the canvas showed as a white sheet wherever the
	// Spartan goes (Credits Earned, the player card, the Armory). Now he is hidden while the context is
	// lost and drawn again once the browser gives it back; if it doesn't within LOST_WAIT ms (Chromium
	// can turn WebGL off after GPU crashes), a new canvas takes this one's place, and with no WebGL at
	// all he is drawn with the 2D canvas instead (`flat`: the picture's own cut-out, no shader).
	let flat = gl ? null : canvas.getContext("2d"), lostTimer = null;
	const LOST_WAIT = 3000;
	function watchContext(c) {
		c.addEventListener("webglcontextlost", (e) => {
			e.preventDefault(); // (so the browser may restore it)
			program = texture = maskTexture = glowTexture = mainTexture = null;
			textureSize = [0, 0];
			lastMask = null;
			show(false);
			post("page-note: figure: the WebGL context was lost (the GPU process restarted?); the Spartan is hidden until it is back");
			clearTimeout(lostTimer);
			lostTimer = setTimeout(newCanvas, LOST_WAIT);
		});
		c.addEventListener("webglcontextrestored", () => {
			clearTimeout(lostTimer);
			lostTimer = null;
			post("page-note: figure: the WebGL context is back");
		});
	}
	function newCanvas() {
		lostTimer = null;
		if (gl && !gl.isContextLost()) return;
		const c = document.createElement("canvas");
		c.id = "figure";
		c.style.cssText = canvas.style.cssText;
		canvas.replaceWith(c);
		canvas = c;
		gl = canvas.getContext("webgl", GL_OPTIONS);
		flat = gl ? null : canvas.getContext("2d");
		if (gl) watchContext(canvas);
		program = texture = maskTexture = glowTexture = mainTexture = null;
		textureSize = [0, 0];
		lastMask = null;
		post(gl ? "page-note: figure: a new WebGL canvas" : "page-note: figure: no WebGL; drawing the Spartan with the 2D canvas");
	}
	if (gl) watchContext(canvas);
	else post("page-note: figure: no WebGL; drawing the Spartan with the 2D canvas");
	const RECORD = 60, BLEND = 12; // frames recorded (about 2 s), frames blended at the loop's seam
	let loop = null; // { frames: [ImageBitmap], box, timer } while the recording plays
	let mode = null, clipEl = null, shown = false, texture = null, maskTexture = null, glowTexture = null, mainTexture = null, program = null;
	let still = null; // { ready, back, good, done } in "still" mode
	let grabbing = null; // { at, done } while a Theme preview is wanted
	let hold = null; // { ms, until, dressed }: frames are drawn but not shown until `until` (want's `hold`)
	let dressed = false; // host-probe's word that the menu game's Spartan is in his pieces and colors
	// A cut-out of the dressed Spartan kept for the next Credits Earned (want's `cacheKey`: the look it
	// shows; localStorage rr.figcache {key, url, w, h}), and want's `shown`, called when he first shows.
	let cache = null, onShown = null, hidden = false;
	const CACHE = "rr.figcache";
	function maybeCache() {
		if (!cache || cache.done || !dressed || !fit || !fit.ext || fit.frames < 8) return;
		cache.done = true;
		const [t, b, l, r] = fit.ext, W = canvas.width, H = canvas.height;
		const x = Math.max(0, Math.floor(l * W)), y = Math.max(0, Math.floor(t * H));
		const w = Math.min(W - x, Math.ceil((r - l) * W)), h = Math.min(H - y, Math.ceil((b - t) * H));
		if (w < 8 || h < 8) return;
		const key = cache.key;
		createImageBitmap(canvas, x, y, w, h).then(bmp => {
			const c = document.createElement("canvas");
			c.width = w; c.height = h;
			c.getContext("2d").drawImage(bmp, 0, 0);
			bmp.close();
			try { localStorage.setItem(CACHE, JSON.stringify({ key, url: c.toDataURL("image/webp", 0.85), w, h })); } catch (e) { }
		}).catch(() => { });
	}
	let texcamWait = null; // timer until the first texture camera picture
	let keep = null; // { x, frames, shift } for keepRightOf
	let fit = null; // { box, frames, ext } for fitTo
	let texcamFrom = 0; // (pictures before this still show the previous backdrop's framing)

	// The frame as a small JPEG (BGRA -> RGBA, then scaled down by the browser).
	function picture(px, w, h) {
		const full = document.createElement("canvas");
		full.width = w; full.height = h;
		const img = new ImageData(w, h), d = img.data;
		for (let i = 0; i < d.length; i += 4) { d[i] = px[i + 2]; d[i + 1] = px[i + 1]; d[i + 2] = px[i]; d[i + 3] = 255; }
		full.getContext("2d").putImageData(img, 0, 0);
		const small = document.createElement("canvas");
		small.width = 640; small.height = Math.round(640 * h / w);
		const g = small.getContext("2d");
		g.imageSmoothingQuality = "high";
		g.drawImage(full, 0, 0, small.width, small.height);
		return small.toDataURL("image/jpeg", 0.85);
	}

	// Black keyed out. Brightness alone could not tell his dark armor from the black backdrop: black
	// armor came out see-through and ragged, and the glow the game draws around bright armor came out
	// as a dark outline (owner, 2026-10-13). So the backdrop is found by where it is: `outsideMask`
	// floods in from the frame's edge through the black and through his glow (which rises smoothly, or
	// is no brighter than the glow his bright armor throws there), and stops at his outline. Outside
	// counts as light only (premultiplied colour, no coverage); inside he is solid, except a smooth
	// pixel the glow explains (a gap between arm and body), which keeps only its brightness against
	// the armor near it.
	const VS = `attribute vec2 p; varying vec2 uv; void main() { uv = vec2(p.x * 0.5 + 0.5, 0.5 - p.y * 0.5); gl_Position = vec4(p, 0.0, 1.0); }`;
	const FS = `precision mediump float; varying vec2 uv; uniform sampler2D tex, outside, glow, mainview; uniform float black, rgba, usemain, mainrgba, strict; uniform vec2 texel, shift;
		vec3 pick(vec4 t) { return mix(t.bgr, t.rgb, rgba); }
		float level(vec2 at) {
			vec3 c = max(pick(texture2D(tex, at)) - black, 0.0) / (1.0 - black);
			return max(max(c.r, c.g), c.b);
		}
		void main() {
			vec3 raw = pick(texture2D(tex, uv));
			vec3 c = max(raw - black, 0.0) / (1.0 - black);
			float m = max(max(c.r, c.g), c.b);
			float v = max(max(raw.r, raw.g), raw.b);
			float lit = 1.0 - smoothstep(texture2D(glow, uv).r + 0.012, texture2D(glow, uv).r + 0.05, v);
			float near_lo = m, near_hi = m, wide_hi = m;
			for (int y = -1; y <= 1; y++) for (int x = -1; x <= 1; x++) {
				float s = level(uv + vec2(float(x), float(y)) * texel);
				near_lo = min(near_lo, s); near_hi = max(near_hi, s);
			}
			for (int r = 1; r <= 4; r++) for (int k = 0; k < 8; k++) {
				float ang = float(k) * 0.785398;
				wide_hi = max(wide_hi, level(uv + vec2(cos(ang), sin(ang)) * float(r * 4) * texel));
			}
			float haze = lit * (1.0 - smoothstep(0.02, 0.06, near_hi - near_lo)) * (1.0 - rgba) * (1.0 - strict);
			float a = wide_hi > 0.0 ? mix(1.0, clamp(m / wide_hi, 0.0, 1.0), haze) : 0.0;
			// The outline (the flood mask, half size) softened over a few pixels, so edges aren't jagged.
			float o = 0.0;
			for (int y = -1; y <= 1; y++) for (int x = -1; x <= 1; x++) o += texture2D(outside, uv - shift * usemain + vec2(float(x), float(y)) * texel * 1.5).r;
			a *= 1.0 - o / 9.0;
			// (the texture camera's own cut-out, its alpha: smooth along his outline, full res)
			a *= mix(1.0, texture2D(tex, uv - shift * usemain).a, rgba);
			if (strict > 0.5) {
				// (strict: the dim speckle of the game's glow just outside him fades instead of a dark rim)
				float rim = 0.0;
				// (a ring about 12 pixels wide: the game's dim glow around his helmet left a dark smudge at 6)
				for (int y = -3; y <= 3; y++) for (int x = -3; x <= 3; x++) rim = max(rim, texture2D(outside, uv + vec2(float(x), float(y)) * texel * 4.0).r);
				a *= mix(1.0, smoothstep(0.03, 0.1, v), rim);
			}
			if (usemain > 0.5) {
				// The main view's colours: inside the outline he is solid, outside its light (his glow and
				// armor effects) only adds, as on the 360.
				vec4 mv = texture2D(mainview, uv);
				vec3 mc = mix(mv.bgr, mv.rgb, mainrgba);
				// Near the outline (the two cameras don't line up to the pixel) a pixel the main view shows as
				// backdrop black is backdrop, not a dark rim.
				float near = 0.0;
				for (int y = -2; y <= 2; y++) for (int x = -2; x <= 2; x++) near = max(near, texture2D(outside, uv - shift + vec2(float(x), float(y)) * texel * 3.0).r);
				a *= mix(1.0, smoothstep(0.03, 0.12, max(max(mc.r, mc.g), mc.b)), near);
				// Outside him his armor effects (flames, lightning, smoke on the Armory's black) add as light
				// over the page: cutting them at his outline made them look painted on him (owner, 2026-10-13).
				float fx = 0.6 * smoothstep(0.02, 0.5, max(max(mc.r, mc.g), mc.b));
				gl_FragColor = vec4(mc, max(a, fx));
			} else {
				gl_FragColor = vec4(c * a, a);
			}
		}`;
	function setup() {
		if (!gl || gl.isContextLost()) return false;
		if (program) return true;
		const shader = (type, src) => { const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s); return s; };
		program = gl.createProgram();
		gl.attachShader(program, shader(gl.VERTEX_SHADER, VS));
		gl.attachShader(program, shader(gl.FRAGMENT_SHADER, FS));
		gl.linkProgram(program);
		gl.useProgram(program);
		const quad = gl.createBuffer();
		gl.bindBuffer(gl.ARRAY_BUFFER, quad);
		gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
		const p = gl.getAttribLocation(program, "p");
		gl.enableVertexAttribArray(p);
		gl.vertexAttribPointer(p, 2, gl.FLOAT, false, 0, 0);
		const make = (unit, name) => {
			const t = gl.createTexture();
			gl.activeTexture(gl.TEXTURE0 + unit);
			gl.bindTexture(gl.TEXTURE_2D, t);
			for (const [k, v] of [[gl.TEXTURE_MIN_FILTER, gl.LINEAR], [gl.TEXTURE_MAG_FILTER, gl.LINEAR], [gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE], [gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE]])
				gl.texParameteri(gl.TEXTURE_2D, k, v);
			gl.uniform1i(gl.getUniformLocation(program, name), unit);
			return t;
		};
		texture = make(0, "tex");
		maskTexture = make(1, "outside");
		glowTexture = make(2, "glow");
		mainTexture = make(3, "mainview");
		return true;
	}

	// The backdrop mask (figure-mask.js).
	const outsideMask = (...args) => window.FigureMask.outsideMask(...args);

	// A frame of the Spartan's backdrop: the left third is black (every Armory and player-panel camera
	// has him on the right), so a frame still showing a lobby backdrop (the camera not cut yet) is
	// skipped; nearly black, as the night city backdrop is dark too. Returns the black level, or -1.
	function blackLevel(px, w, h) {
		let bright = 0, n = 0, low = 255;
		for (let y = Math.floor(h * 0.05); y < h * 0.95; y += 23) for (let x = 4; x < w * 0.33; x += 23) {
			const o = (y * w + x) * 4, m = Math.max(px[o], px[o + 1], px[o + 2]);
			n++;
			if (m > 14) bright++;
			if (m < low) low = m;
		}
		return n && bright / n < 0.005 ? low : -1;
	}

	// How much Spartan a frame holds (brightness summed over a sparse grid of the right two thirds).
	// A window capture now and then catches the game between draws, with him missing or half drawn;
	// those frames made him flicker (owner, 2026-10-13), so a frame well below the recent ones is
	// skipped and the last good one stays.
	let mass = 0, dropped = 0;
	function frameMass(px, w, h) {
		let sum = 0;
		for (let y = 8; y < h; y += 17) for (let x = Math.floor(w / 3); x < w; x += 17) {
			const o = (y * w + x) * 4;
			sum += px[o] + px[o + 1] + px[o + 2];
		}
		return sum;
	}

	// A texture camera picture keeps its own shape on a page wider than it. The menus' camera zooms to fill
	// a window wider than 16:9 (host-probe menuzoom.rs; owner, 2026-10-21: zoom and fill), so the 16:9
	// picture (the player panel, Credits Earned) is 100vw wide, as tall as its shape makes it and centred:
	// he isn't stretched sideways and stands where the zoomed main view has him. The Armory's picture comes
	// cut to the main view's shape (host-probe texcam.rs), window captures and the main view are the page's
	// own shape, and a page taller than the picture still stretches it, as before.
	let tall = 1; // the canvas's height in page heights
	function keepAspect(aspect) {
		const k = aspect > 0 && innerHeight > 0 ? innerWidth / innerHeight / aspect : 1;
		const next = k > 1.001 ? k : 1;
		if (Math.abs(next - tall) < 1e-4) return;
		tall = next;
		canvas.style.height = tall === 1 ? "" : `${(tall * 100).toFixed(3)}vh`;
		canvas.style.top = tall === 1 ? "" : `${((1 - tall) * 50).toFixed(3)}vh`;
		// (a resized window: a fit already measured is laid out again for the new shape)
		if (fit && fit.ext) placeFit();
	}

	const MAIN_SHIFT = 0.005;
	// (the texture camera's mask is worked out on every MASK_EVERY-th frame at most; draw)
	const MASK_EVERY = 3;
	let lastMask = null, textureSize = [0, 0];
	function draw(px, w, h, rgba, main) {
		// (The texture camera draws him on pure black, so no check that the frame shows his backdrop.)
		const black = rgba ? 0 : blackLevel(px, w, h);
		const strict = !!(still && still.strict) && !rgba;
		if (black < 0 || !(flat || setup())) return false;
		const m = frameMass(px, w, h);
		// (The reference sinks with each skip, so a new camera framing with less of him is taken after a few frames.)
		if (m < mass * 0.7) { dropped++; mass *= 0.93; return null; }
		mass = Math.max(m, mass * 0.9);
		// (with the main view, the canvas at its size: the game's own pixels, not resampled twice)
		const onMain = !flat && main && main.w && !clipEl;
		const [cw, ch] = onMain ? [main.w, main.h] : [w, h];
		if (canvas.width !== cw || canvas.height !== ch) { canvas.width = cw; canvas.height = ch; }
		keepAspect(rgba && !onMain ? w / h : 0);
		if (!flat) gl.viewport(0, 0, cw, ch);
		// The texture camera's picture carries its own exact outline (its alpha, applied at full size in
		// the shader), so its mask may be one or two frames old while he only breathes: worked out for every
		// frame at 1920 x 1080, it kept the page's thread fully busy on Credits Earned (2026-10-17). A new
		// one whenever his picture's mass moves (dressing, turning) and while he is being measured.
		const measuring = (keep && keep.frames < 8) || (fit && fit.frames < 8);
		const reuse = rgba && lastMask && lastMask.w === w && lastMask.h === h && !measuring &&
			++lastMask.age < MASK_EVERY && Math.abs(m - lastMask.mass) <= 0.02 * lastMask.mass;
		if (!reuse) {
			const mask = outsideMask(px, w, h, black, rgba, strict);
			lastMask = { w, h, mass: m, age: 0, mask };
			if (keep && keep.frames < 8) measureKeep(mask);
			if (fit && fit.frames < 8) measureFit(mask);
		}
		if (flat) {
			drawFlat(px, w, h, rgba, lastMask.mask);
			applyClip();
			return true;
		}
		if (!reuse) {
			const mask = lastMask.mask;
			gl.pixelStorei(gl.UNPACK_ALIGNMENT, 1);
			gl.activeTexture(gl.TEXTURE1);
			gl.bindTexture(gl.TEXTURE_2D, maskTexture);
			gl.texImage2D(gl.TEXTURE_2D, 0, gl.LUMINANCE, mask.W, mask.H, 0, gl.LUMINANCE, gl.UNSIGNED_BYTE, mask.out);
			gl.activeTexture(gl.TEXTURE2);
			gl.bindTexture(gl.TEXTURE_2D, glowTexture);
			gl.texImage2D(gl.TEXTURE_2D, 0, gl.LUMINANCE, mask.Q, mask.R, 0, gl.LUMINANCE, gl.UNSIGNED_BYTE, mask.glow);
		}
		gl.activeTexture(gl.TEXTURE0);
		gl.bindTexture(gl.TEXTURE_2D, texture);
		gl.pixelStorei(gl.UNPACK_ALIGNMENT, 4);
		// (the same size as the last frame: written into the texture in place, not made again)
		if (textureSize[0] === w && textureSize[1] === h) gl.texSubImage2D(gl.TEXTURE_2D, 0, 0, 0, w, h, gl.RGBA, gl.UNSIGNED_BYTE, px);
		else { gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, w, h, 0, gl.RGBA, gl.UNSIGNED_BYTE, px); textureSize = [w, h]; }
		gl.uniform1f(gl.getUniformLocation(program, "black"), rgba ? 0 : strict ? black / 255 : Math.min(black + 12, 34) / 255);
		gl.uniform1f(gl.getUniformLocation(program, "strict"), strict ? 1 : 0);
		gl.uniform2f(gl.getUniformLocation(program, "texel"), 1 / w, 1 / h);
		gl.uniform1f(gl.getUniformLocation(program, "rgba"), rgba ? 1 : 0);
		// The main view after the picture in the same buffer (`figure:armory`), DXGI 28/29 RGBA, else BGRA.
		const useMain = !!(main && main.w && !clipEl);
		gl.uniform1f(gl.getUniformLocation(program, "usemain"), useMain ? 1 : 0);
		// (the main view sits about 0.5% right of the texture camera's picture; measured, EXP-045)
		gl.uniform2f(gl.getUniformLocation(program, "shift"), MAIN_SHIFT, 0);
		if (useMain) {
			gl.activeTexture(gl.TEXTURE3);
			gl.bindTexture(gl.TEXTURE_2D, mainTexture);
			gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, main.w, main.h, 0, gl.RGBA, gl.UNSIGNED_BYTE, px.subarray(w * h * 4, w * h * 4 + main.w * main.h * 4));
			gl.activeTexture(gl.TEXTURE0);
			gl.uniform1f(gl.getUniformLocation(program, "mainrgba"), main.format === 28 || main.format === 29 ? 1 : 0);
		}
		gl.clearColor(0, 0, 0, 0);
		gl.clear(gl.COLOR_BUFFER_BIT);
		gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
		applyClip();
		return true;
	}

	// Without WebGL (newCanvas): the frame on the 2D canvas, cut out by the outline mask (half size) and,
	// for the texture camera's picture, its own alpha. No glow or main view: the piece pages' look.
	let flatImage = null;
	function drawFlat(px, w, h, rgba, mask) {
		if (!flatImage || flatImage.width !== w || flatImage.height !== h) flatImage = new ImageData(w, h);
		const d = flatImage.data, { out, W, H } = mask;
		for (let y = 0; y < h; y++) {
			const mrow = Math.min(H - 1, y >> 1) * W;
			for (let x = 0; x < w; x++) {
				const i = (y * w + x) * 4, keyed = 255 - out[mrow + Math.min(W - 1, x >> 1)];
				d[i] = px[i + (rgba ? 0 : 2)]; d[i + 1] = px[i + 1]; d[i + 2] = px[i + (rgba ? 2 : 0)];
				d[i + 3] = rgba ? Math.min(px[i + 3], keyed) : keyed;
			}
		}
		flat.putImageData(flatImage, 0, 0);
	}

	// His left edge in this frame (from the outline mask), and the shift that keeps it right of keep.x.
	function measureKeep(mask) {
		let left = mask.W;
		for (let y = 0; y < mask.H; y += 4) {
			const row = y * mask.W;
			for (let x = 0; x < left; x += 2) if (!mask.out[row + x]) { left = x; break; }
		}
		if (left >= mask.W) return;
		keep.frames++;
		const shift = Math.max(0, keep.x - left / mask.W);
		keep.shift = keep.frames === 1 ? shift : Math.max(keep.shift, shift);
		canvas.style.transform = keep.shift > 0 ? `translateX(${(keep.shift * 100).toFixed(2)}vw)` : "";
	}

	// His extent (top, bottom, left, right as fractions) over the first frames, then the transform that
	// lays it on fit.box.
	// Him only: the biggest run of rows (then of columns) holding any of the outline, so small things far
	// off in the camera's picture (other menu figures, 2026-10-14) don't count.
	function biggestRun(counts) {
		let best = null, start = -1, sum = 0;
		for (let i = 0; i <= counts.length; i++) {
			if (i < counts.length && counts[i]) { if (start < 0) { start = i; sum = 0; } sum += counts[i]; continue; }
			if (start >= 0 && (!best || sum > best[2])) best = [start, i - 1, sum];
			start = -1;
		}
		return best;
	}
	function measureFit(mask) {
		const rows = new Uint32Array(mask.H >> 1), cols = new Uint32Array(mask.W >> 1);
		for (let y = 0; y < mask.H; y += 2) {
			const row = y * mask.W;
			for (let x = 0; x < mask.W; x += 2) if (!mask.out[row + x]) rows[y >> 1]++;
		}
		const ry = biggestRun(rows);
		if (!ry) return;
		for (let y = ry[0] * 2; y <= ry[1] * 2; y += 2) {
			const row = y * mask.W;
			for (let x = 0; x < mask.W; x += 2) if (!mask.out[row + x]) cols[x >> 1]++;
		}
		const rx = biggestRun(cols);
		const top = ry[0] * 2, bottom = ry[1] * 2, left = rx[0] * 2, right = rx[1] * 2;
		const e = [top / mask.H, (bottom + 2) / mask.H, left / mask.W, (right + 2) / mask.W];
		fit.ext = fit.ext ? [Math.min(fit.ext[0], e[0]), Math.max(fit.ext[1], e[1]), Math.min(fit.ext[2], e[2]), Math.max(fit.ext[3], e[3])] : e;
		fit.frames++;
		const s = placeFit();
		// (in the log: the scale above 1 means his picture is enlarged, so its edges show steps)
		if (fit.frames === 8) post(`figure-fit: scale ${s.toFixed(3)}, his height ${(fit.ext[1] - fit.ext[0]).toFixed(3)} of the picture`);
	}

	// fit.ext laid on fit.box (measureFit; keepAspect again when the canvas's shape changes). Returns the scale.
	function placeFit() {
		const [t, b, l, r] = fit.ext, box = fit.box;
		// (box.maxw: no wider than that, so a wide figure, the Elite with his weapon out, stays off the stats)
		// (the canvas is `tall` page heights high, keepAspect: his height on the page is s * tall * (b - t))
		const s = Math.min((box.bottom - box.top) / (tall * Math.max(0.05, b - t)), box.maxw ? box.maxw / Math.max(0.05, r - l) : Infinity);
		// (canvas 100vw wide from the page's left, `tall` page heights high from (1 - tall) / 2: a point at
		// fraction (x, y) of it lands at (tx + s * x, (1 - tall) / 2 + ty + s * tall * y))
		// (box.left: his left edge at least there, right of a page's panels)
		// (narrowed by maxw he is shorter than the box: his feet stay on box.bottom, not his head on box.top, or he
		// floated in the card's top half with his crest in the name bar; PC 2, 2026-10-17)
		const tx = Math.max(box.cx - s * (l + r) / 2, box.left === undefined ? -Infinity : box.left - s * l);
		const ty = box.bottom - (1 - tall) / 2 - s * tall * b;
		canvas.style.transformOrigin = "0 0";
		canvas.style.transform = `translate(${(tx * 100).toFixed(2)}vw, ${(ty * 100).toFixed(2)}vh) scale(${s.toFixed(4)})`;
		return s;
	}

	function applyClip() {
		// (fitTo with clip: only his extent shows, not the other things in the camera's picture)
		if ((!clipEl || !clipEl.isConnected) && fit && fit.box.clip && fit.ext) {
			const [t, b, l, r] = fit.ext, m = 0.02;
			canvas.style.clipPath = `inset(${Math.max(0, t - m) * 100}% ${Math.max(0, 1 - r - m) * 100}% ${Math.max(0, 1 - b - m) * 100}% ${Math.max(0, l - m) * 100}%)`;
			return;
		}
		if (!clipEl || !clipEl.isConnected) { canvas.style.clipPath = ""; return; }
		// (from the canvas's own box: `tall` page heights high from (1 - tall) / 2, keepAspect)
		const r = clipEl.getBoundingClientRect(), top = (1 - tall) / 2 * innerHeight, bottom = top + tall * innerHeight;
		canvas.style.clipPath = `inset(${r.top - top}px ${innerWidth - r.right}px ${bottom - r.bottom}px ${r.left}px)`;
	}

	function show(on) {
		if (on && !shown && onShown) { const f = onShown; onShown = null; f(); }
		shown = on;
		document.body.classList.toggle("figure", on);
	}

	if (window.chrome && window.chrome.webview) {
		window.chrome.webview.addEventListener("sharedbufferreceived", (e) => {
			const info = e.additionalData || {};
			const buffer = e.getBuffer();
			try {
				if (info.figure === undefined) return;
				if (grabbing && performance.now() >= grabbing.at) {
					const done = grabbing.done;
					grabbing = null;
					if (!mode || (still && still.done)) post("figure:off");
					done(picture(new Uint8Array(buffer), info.w, info.h));
					return;
				}
				if (!mode || (still && still.done)) return;
				// (still.settle: the figure dressed and still before anything is drawn or measured)
				if (still && performance.now() < still.from) return;
				if (info.rgba && performance.now() < texcamFrom) return;
				const ok = draw(new Uint8Array(buffer), info.w, info.h, info.rgba, info.mw ? { w: info.mw, h: info.mh, format: info.mformat } : null);
				if (ok && texcamWait) { clearTimeout(texcamWait); texcamWait = null; }
				if (ok === null) return; // (a half-drawn capture: skipped)
				// (hold: Credits Earned shows the Spartan only once he's dressed; the menu game puts him on in
				// stages after a match: the default Spartan, his armor, then his own colors; owner, 2026-10-17)
				if (ok && hold && !hold.until) hold.until = performance.now() + hold.ms;
				// (hold.dressed: shown as soon as host-probe says he's dressed, Figure.dressed, else at `ms`)
				const held = hold && performance.now() < hold.until && !(hold.dressed && dressed);
				if (ok && !shown && !held && !hidden && !(still && still.hidden)) show(true);
				if (ok && !held) maybeCache();
				if (still) {
					if (ok) record();
					if (!ok && still.frames.length >= RECORD) {
						still.done = true;
						post("figure:off");
						play();
						if (still.back) still.back();
					}
				}
			} finally {
				window.chrome.webview.releaseBuffer(buffer);
			}
		});
	}

	function post(text) { if (window.chrome && window.chrome.webview) window.chrome.webview.postMessage(text); }

	// Player panel: after a few frames to settle, the Spartan's box (from the first frame's coverage,
	// with room for his idle movement) and RECORD frames of it.
	function record() {
		still.good++;
		if (still.good < 6 || still.frames.length >= RECORD) return;
		if (!still.box) {
			const w = canvas.width, h = canvas.height;
			let px = new Uint8Array(w * h * 4);
			if (flat) px = flat.getImageData(0, 0, w, h).data; // (rows top-down)
			else gl.readPixels(0, 0, w, h, gl.RGBA, gl.UNSIGNED_BYTE, px); // (rows bottom-up)
			let x0 = w, x1 = 0, y0 = h, y1 = 0;
			for (let y = 0; y < h; y += 2) for (let x = 0; x < w; x += 2) {
				const row = flat ? y : h - 1 - y;
				if (px[(y * w + x) * 4 + 3] > 8) { x0 = Math.min(x0, x); x1 = Math.max(x1, x); y0 = Math.min(y0, row); y1 = Math.max(y1, row); }
			}
			if (x1 <= x0) return;
			const mx = Math.round(w * 0.04), my = Math.round(h * 0.04);
			x0 = Math.max(0, x0 - mx); y0 = Math.max(0, y0 - my); x1 = Math.min(w, x1 + mx); y1 = Math.min(h, y1 + my);
			still.box = [x0, y0, x1 - x0, y1 - y0];
		}
		const [x, y, bw, bh] = still.box;
		still.frames.push(createImageBitmap(canvas, x, y, bw, bh));
		if (still.frames.length === RECORD && still.ready) still.ready();
	}

	async function play() {
		const frames = await Promise.all(still.frames);
		if (mode !== "still") { frames.forEach(f => f.close()); return; }
		const box = still.box, [w, h] = [canvas.width, canvas.height];
		loopCanvas.width = w; loopCanvas.height = h;
		// (fitTo's placement holds for the recording too: the Elite's player card, which is recorded)
		loopCanvas.style.transformOrigin = canvas.style.transformOrigin;
		loopCanvas.style.transform = canvas.style.transform;
		loopCanvas.style.clipPath = canvas.style.clipPath;
		loopCanvas.style.top = canvas.style.top;
		loopCanvas.style.height = canvas.style.height;
		const g = loopCanvas.getContext("2d");
		loop = { frames, i: BLEND };
		const step = () => {
			const n = frames.length, i = loop.i;
			g.clearRect(box[0], box[1], box[2], box[3]);
			if (i >= n - BLEND) {
				// The seam: the last frames fade into the first ones, which the loop goes on from.
				const t = (i - (n - BLEND) + 1) / (BLEND + 1);
				g.globalAlpha = 1 - t; g.drawImage(frames[i], box[0], box[1]);
				g.globalAlpha = t; g.drawImage(frames[i - (n - BLEND)], box[0], box[1]);
				g.globalAlpha = 1;
			} else {
				g.drawImage(frames[i], box[0], box[1]);
			}
			loop.i = i + 1 >= n ? BLEND : i + 1;
		};
		step();
		loop.timer = setInterval(step, 1000 / 30);
		document.body.classList.add("figloop");
		show(false);
	}

	function stopLoop() {
		if (!loop) return;
		clearInterval(loop.timer);
		loop.frames.forEach(f => f.close());
		loop = null;
		loopCanvas.style.transform = loopCanvas.style.clipPath = loopCanvas.style.top = loopCanvas.style.height = "";
		document.body.classList.remove("figloop");
	}

	return {
		want(next, events) {
			if (next === mode && next !== "still") {
				// The same camera asked for by someone else (Credits Earned while the menus' hidden capture of
				// him for later, or the player card, still had it): take on their wishes, or Credits Earned's
				// old cut-out never left, next to the live Spartan (player report, 2026-10-18: two Spartans).
				if ((next === "texcam" || next === "live") && events) {
					hold = events.hold && !shown ? { ms: events.hold, until: 0, dressed: !!events.dressed } : null;
					cache = events.cacheKey ? { key: events.cacheKey, done: false } : null;
					hidden = !!events.hidden;
					onShown = events.shown || null;
					if (shown && onShown) { const f = onShown; onShown = null; f(); }
				}
				return;
			}
			mode = next;
			const texcam = next === "texcam" || next === "live";
			hold = texcam && events && events.hold ? { ms: events.hold, until: 0, dressed: !!events.dressed } : null;
			cache = texcam && events && events.cacheKey ? { key: events.cacheKey, done: false } : null;
			onShown = texcam && events && events.shown ? events.shown : null;
			hidden = !!(texcam && events && events.hidden);
			if (texcamWait) { clearTimeout(texcamWait); texcamWait = null; }
			if (texcam) texcamWait = setTimeout(() => {
				texcamWait = null;
				if (mode !== next) return;
				post("page-note: no texture camera picture; filming the game window instead");
				if (next === "live") post("figure:on");
				else if (events && events.fallback) events.fallback();
			}, 2500);
			texcamFrom = performance.now() + 250;
			if (dropped) post("page-note: figure skipped " + dropped + " half-drawn frames");
			mass = 0; dropped = 0; lastMask = null;
			stopLoop();
			if (still && still.frames) Promise.all(still.frames).then(fs => { if (!loop || loop.frames !== fs) fs.forEach(f => f.close()); });
			still = next === "still" ? Object.assign({ good: 0, done: false, frames: [], box: null }, events || {}) : null;
			if (still) still.from = performance.now() + (still.settle || 0);
			if (!next) { show(false); clipEl = null; }
			post(next === "live" ? "figure:armory" : texcam ? "figure:texcam" : next ? "figure:on" : "figure:off");
		},
		// The menu game's Spartan is dressed (overlay: window.figureDressed), or a new menu game starts.
		dressed() { dressed = true; },
		// The cut-out kept for this look ({ url, w, h }), or null; whether a hidden capture is running.
		cached(key) {
			try { const c = JSON.parse(localStorage.getItem(CACHE) || "null"); return c && c.key === key ? c : null; } catch (e) { return null; }
		},
		capturing: () => hidden && !!cache,
		idle: () => mode === null,
		undressed() { dressed = false; },
		clip(el) { clipEl = el; applyClip(); },
		fitTo(box) {
			// (the same box again, as each page redraw asks: keep the fit, no new measuring)
			if (fit && box && JSON.stringify(fit.box) === JSON.stringify(box)) return;
			if (!fit && !box) return;
			fit = box ? { box, frames: 0, ext: null } : null;
			canvas.style.transform = "";
		},
		keepRightOf(x) {
			if (keep && x !== null && keep.x === x) return;
			keep = x === null ? null : { x, frames: 0, shift: 0 };
			canvas.style.transform = "";
		},
		// (tests: a BGRA frame as the overlay program would send it)
		feed(px, w, h, rgba, main) { if (draw(px, w, h, rgba, main)) show(true); },
		grab(ms, done) {
			if (!windowPictures) return;
			grabbing = { at: performance.now() + ms, done };
			post("figure:on");
		},
		windowPictures,
		get mode() { return mode; },
		get shown() { return shown; },
	};
})();
