// IN-GAME SCOREBOARD (owner, 2026-10-16): Reach's own Tab scoreboard lists 16 players (its Firefight HUD
// panel 4), so ours lists every player in the match. Tab opens it over the game and Tab (or Esc) closes it;
// while it is open the mouse and keys work here and the game gets no input, as with the game menu.
//
// The overlay program sends `scoreboard:<json>` twice a second while it is open, from the scoreboard.json
// host-probe writes (its scoreboard.rs): {host, mode, players:[{number, name, team, score, kills, deaths,
// assists, alive, left, local}], team_scores}. Each player keeps the number they joined with. Mute is kept here
// per name (the game has no voice or text chat yet; this is the list chat will use). The host also gets
// Kick and Ban (asked twice): `scoreboard:kick:<number>` / `scoreboard:ban:<number>`, which host-probe
// carries out.
const Scoreboard = (() => {
	const css = `
	.sb { position: fixed; inset: 0; z-index: 1002; display: none; align-items: flex-start; justify-content: center;
		background: rgba(4,10,18,0.55); color: #eef2f4; font-family: inherit; }
	.sb.open { display: flex; }
	body.inmatch:not(.ingame) > .sb.open { visibility: visible !important; }
	.sb .panel { margin-top: 7vh; width: min(78vw, 1100px); max-height: 84vh; display: flex; flex-direction: column;
		background: linear-gradient(180deg, rgba(14,28,44,0.94), rgba(8,16,28,0.94)); border: 1px solid rgba(160,200,235,0.25);
		box-shadow: 0 0 4vh rgba(0,0,0,0.6); }
	.sb .top { display: flex; align-items: baseline; justify-content: space-between; padding: 1.6vh 1.6vw 1vh;
		border-bottom: 1px solid rgba(160,200,235,0.2); }
	.sb .top h1 { margin: 0; font-size: 3.4vh; font-weight: 700; letter-spacing: 0.06em; text-transform: uppercase; }
	.sb .top .sub { font-size: 1.9vh; color: #a9b6c0; }
	.sb .head, .sb .row { display: grid; grid-template-columns: 4.5vh 1fr 8vh 6.5vh 6.5vh 6.5vh 15vh 18vh; align-items: center; column-gap: 0.8vw; }
	.sb .head { padding: 0.8vh 1.6vw; font-size: 1.6vh; color: #8fa1ad; text-transform: uppercase; letter-spacing: 0.05em; }
	.sb .head span:not(:nth-child(2)), .sb .row > span:not(.nm) { text-align: center; }
	.sb .list { overflow-y: auto; padding: 0 0.8vw 1.2vh; display: grid; grid-auto-flow: column; column-gap: 1.2vw; }
	/* More than 16 players: two columns of smaller rows (half the players each), so 32 or 64 fit without scrolling. */
	.sb.wide .panel { width: min(96vw, 1800px); }
	.sb.wide .head, .sb.wide .row { grid-template-columns: 3.4vh 1fr 5.6vh 4vh 4vh 4vh 6.5vh 10vh; column-gap: 0.4vw; }
	.sb.wide .row { height: var(--rowh, 3.4vh); margin: 0.1vh 0; font-size: calc(var(--rowh, 3.4vh) * 0.55); }
	.sb.wide .row .nm small { font-size: calc(var(--rowh, 3.4vh) * 0.45); }
	.sb.wide .row button { font-size: calc(var(--rowh, 3.4vh) * 0.34); padding: 0.1vh 0.35vw; }
	.sb.wide .head { font-size: 1.4vh; padding: 0.6vh 0.8vw; }
	.sb .row { height: 4.6vh; padding: 0 0.8vw; margin: 0.35vh 0; font-size: 2.2vh; font-variant-numeric: tabular-nums;
		background: linear-gradient(90deg, var(--team, rgba(255,255,255,0.10)), rgba(255,255,255,0.03) 70%); border-left: 0.5vh solid var(--edge, #8fa1ad); }
	.sb .row.sel { outline: 1px solid rgba(255,255,255,0.7); }
	.sb .row.me .nm { color: #ffd36b; }
	.sb .row.dead .nm { opacity: 0.6; }
	.sb .row .num { font-weight: 700; color: #cfd8de; }
	.sb .row .nm { font-weight: 600; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
	.sb .row .nm small { margin-left: 0.6vw; font-size: 1.6vh; font-weight: 500; color: #a9b6c0; }
	.sb .row .score { font-weight: 700; }
	.sb .row button { font: inherit; font-size: 1.6vh; padding: 0.4vh 0.6vw; margin: 0 0.2vw; cursor: pointer; color: #eef2f4;
		background: rgba(255,255,255,0.08); border: 1px solid rgba(255,255,255,0.25); text-transform: uppercase; letter-spacing: 0.04em; }
	.sb .row button:hover { background: rgba(255,255,255,0.18); }
	.sb .row button.on { background: rgba(255,120,90,0.35); border-color: rgba(255,140,110,0.7); }
	.sb .row button.ask { background: rgba(220,60,40,0.6); border-color: #ff8a70; }
	.sb .teams { display: flex; gap: 1.2vw; padding: 0.6vh 1.6vw 1.2vh; font-size: 1.9vh; color: #cfd8de; }
	.sb .teams b { font-size: 2.4vh; margin-left: 0.4vw; }
	.sb .foot { padding: 0.8vh 1.6vw 1.2vh; font-size: 1.7vh; color: #8fa1ad; border-top: 1px solid rgba(160,200,235,0.15); }
	.sb .foot b { color: #eef2f4; font-weight: 600; margin-right: 1.2vw; }
	.sb .row .nm { cursor: pointer; }
	.sb .row .nm:hover { text-decoration: underline; }
	/* A player's menu (controls.js Dropdown) over the scoreboard, in a match too. */
	body.sbopen .rrdrop { z-index: 1003; }
	body.inmatch:not(.ingame) > .rrdrop.open { visibility: visible !important; }
	`;
	// Reach's team colors: red, blue, green, orange, purple, gold, brown, pink.
	const TEAMS = [["Red", "#c8352e"], ["Blue", "#2f6fd0"], ["Green", "#3c9a3c"], ["Orange", "#e07a1e"], ["Purple", "#7b46b8"], ["Gold", "#d6a623"], ["Brown", "#7a5233"], ["Pink", "#e06aa8"]];
	let root, data = null, open = false, sel = 0, asked = null, me = "", said = "", saidUntil = 0;
	const requested = new Set();
	const muted = new Set((() => { try { return JSON.parse(localStorage.getItem("rr-muted") || "[]"); } catch (e) { return []; } })());
	function saveMuted() { try { localStorage.setItem("rr-muted", JSON.stringify([...muted])); } catch (e) { } }
	function post(m) { if (window.chrome && window.chrome.webview) window.chrome.webview.postMessage(m); }
	function build() {
		if (root) return;
		const style = document.createElement("style");
		style.textContent = css;
		document.head.appendChild(style);
		root = document.createElement("div");
		root.className = "sb";
		root.innerHTML = `<div class="panel"><div class="top"><h1>Scoreboard</h1><span class="sub"></span></div>
			<div class="teams"></div>
			<div class="list"></div><div class="foot"></div></div>`;
		root.addEventListener("mousedown", (e) => { if (e.target === root) close(); });
		document.body.appendChild(root);
	}
	// Our row: the one host-probe marks (scoreboard.rs `local`, by user id), else the one with our name (an older
	// host-probe, or before it has found the user id; 2026-10-20 player batch, report 20).
	function isMe(p) { return data && (data.players || []).some(x => x.local) ? !!p.local : p.name === me; }
	// Teams when the players are on more than one team (Firefight and free-for-all are not).
	function teamGame(players) { return new Set(players.map(p => p.team)).size > 1 && players.every(p => p.team >= 0 && p.team < 8); }
	function sorted() {
		const players = (data && data.players || []).filter(p => !p.left);
		const teams = teamGame(players);
		return players.slice().sort((a, b) => (teams ? a.team - b.team : 0) || b.score - a.score || b.kills - a.kills || a.number - b.number);
	}
	function render() {
		if (!root || !open) return;
		const players = sorted();
		const isHost = !!(data && data.host);
		const teams = teamGame(players);
		root.querySelector(".sub").textContent = data ? `${players.length} player${players.length === 1 ? "" : "s"}${data.mode === 5 ? " · Firefight" : data.mode === 1 ? " · Campaign" : ""}` : "Waiting for the game…";
		root.querySelector(".teams").innerHTML = teams ? [...new Set(players.map(p => p.team))].map(t =>
			`<span style="color:${TEAMS[t][1]}">${TEAMS[t][0]}<b>${data.team_scores ? data.team_scores[t] : ""}</b></span>`).join("") : "";
		if (sel >= players.length) sel = Math.max(0, players.length - 1);
		const list = root.querySelector(".list");
		list.innerHTML = "";
		const columns = players.length > 16 ? 2 : 1;
		const perColumn = Math.max(1, Math.ceil(players.length / columns));
		root.classList.toggle("wide", columns > 1);
		root.style.setProperty("--rowh", Math.min(3.4, 58 / perColumn - 0.2).toFixed(2) + "vh");
		list.style.gridTemplateRows = `repeat(${perColumn + 1}, auto)`;
		list.style.gridTemplateColumns = `repeat(${columns}, 1fr)`;
		const head = () => {
			const h = document.createElement("div");
			h.className = "head";
			h.innerHTML = `<span>#</span><span>Player</span><span>Score</span><span>K</span><span>D</span><span>A</span><span>Voice/chat</span><span>${isHost ? "Host" : ""}</span>`;
			list.appendChild(h);
		};
		players.forEach((p, i) => {
			if (i % perColumn === 0) head();
			const row = document.createElement("div");
			const color = teams ? TEAMS[p.team][1] : "#8fa1ad";
			row.className = "row" + (i === sel ? " sel" : "") + (isMe(p) ? " me" : "") + (p.alive ? "" : " dead");
			row.style.setProperty("--edge", color);
			if (teams) row.style.setProperty("--team", color + "55");
			const kd = (v) => Math.round(v || 0);
			row.innerHTML = `<span class="num">${p.number}</span><span class="nm"></span><span class="score">${p.score}</span>
				<span>${kd(p.kills)}</span><span>${kd(p.deaths)}</span><span>${kd(p.assists)}</span><span class="m"></span><span class="h"></span>`;
			row.querySelector(".nm").textContent = p.name;
			if (!p.alive) row.querySelector(".nm").insertAdjacentHTML("beforeend", "<small>dead</small>");
			const who = !isMe(p) && window.Social && Social.inGame ? Social.inGame(p.name) : null;
			if (who && who.friend) row.querySelector(".nm").insertAdjacentHTML("beforeend", "<small>friend</small>");
			// Clicking a name opens that player's menu (Send Friend Request, Mute; owner, 2026-10-17).
			if (!isMe(p) || teams) row.querySelector(".nm").onclick = (e) => { e.stopPropagation(); sel = i; playerMenu(p, row.querySelector(".nm")); };
			if (!isMe(p)) {
				const mute = document.createElement("button");
				mute.textContent = muted.has(p.name) ? "Muted" : "Mute";
				mute.className = muted.has(p.name) ? "on" : "";
				mute.onclick = (e) => { e.stopPropagation(); toggleMute(p); };
				row.querySelector(".m").appendChild(mute);
				if (isHost) for (const kind of ["kick", "ban"]) {
					const b = document.createElement("button");
					const asking = asked && asked.kind === kind && asked.number === p.number;
					b.textContent = asking ? `${kind}?` : kind;
					b.className = asking ? "ask" : "";
					b.title = asking ? "Click again to " + kind + " " + p.name : (kind === "ban" ? "Remove and keep out for this session" : "Remove from the game");
					b.onclick = (e) => { e.stopPropagation(); hostAction(kind, p); };
					row.querySelector(".h").appendChild(b);
				}
			}
			row.onmouseenter = () => { if (!(!window.MenuScroll || MenuScroll.hoverOk())) return; sel = i; for (const r of list.querySelectorAll(".row")) r.classList.toggle("sel", r === row); };
			list.appendChild(row);
		});
	}
	function say(text) { said = text; saidUntil = performance.now() + 5000; foot(); }
	function foot() {
		if (!root) return;
		const el = root.querySelector(".foot");
		el.innerHTML = "";
		if (said && performance.now() < saidUntil) { const b = document.createElement("b"); b.textContent = said; el.appendChild(b); }
		el.appendChild(document.createTextNode("A or click a name: player options" + (teamGame((data && data.players || []).filter(p => !p.left)) ? " (Change Team)" : "") + " · Tab or Esc to close"));
	}
	// The teams a player may be put on in this game: the lobby's game type's (index.html lastGame.teams), else
	// Red and Blue and the teams players are on now.
	function teamChoices() {
		const known = window.lastGame && window.lastGame.teams && window.lastGame.teams.mask;
		const mask = known || (data && data.players || []).reduce((m, p) => p.team >= 0 && p.team < 8 ? m | 1 << p.team : m, 3);
		return TEAMS.map((t, i) => [i, t[0]]).filter(([i]) => mask >> i & 1);
	}
	// Change Team in a team game: the host moves anyone (host-probe teams.rs, `scoreboard:team:`); a player
	// moves themselves when the game type's Team Changing allows it (`game-menu:team:`, the game checks).
	function teamMenu(p, anchor) {
		const isHost = !!(data && data.host);
		Dropdown.open({ title: isMe(p) ? "Your Team" : p.name + "'s Team", value: String(p.team), anchor: anchor || null,
			options: teamChoices().map(([i, n]) => [String(i), n + " Team"]), onPick: (v) => {
				if (+v === p.team) return;
				post(isHost ? `scoreboard:team:${p.number}:${v}` : `game-menu:team:${v}`);
				if (window.Sound) Sound.play("select");
				say(isMe(p) ? (isHost ? `Moving you to ${TEAMS[+v][0]} Team.` : `Asked for ${TEAMS[+v][0]} Team: the game moves you if this game type's Team Changing allows it.`) : `Moving ${p.name} to ${TEAMS[+v][0]} Team.`);
			} });
	}
	// A player's menu: a friend request (when the friends service knows who they are in this game), mute, and
	// in a team game Change Team (the host's for anyone, a player's own for themselves).
	function playerMenu(p, anchor) {
		if (!window.Dropdown) return;
		const isHost = !!(data && data.host);
		const teams = teamGame((data && data.players || []).filter(x => !x.left));
		const options = [];
		if (teams && (isHost || isMe(p))) options.push(["team", "Change Team"]);
		if (isMe(p) && !options.length) return;
		const who = !isMe(p) && window.Social && Social.inGame ? Social.inGame(p.name) : null;
		if (!isMe(p) && !(who && who.friend)) options.push(["friend", requested.has(p.name) ? "Friend Request Sent" : "Send Friend Request"]);
		if (!isMe(p)) options.push(["mute", muted.has(p.name) ? "Unmute" : "Mute"]);
		options.push(["cancel", "Cancel"]);
		Dropdown.open({ title: p.name, value: null, anchor: anchor || null, options, onPick: (v) => {
			if (v === "team") setTimeout(() => teamMenu(p, anchor), 0);
			else if (v === "mute") toggleMute(p);
			else if (v === "friend") {
				if (requested.has(p.name)) say(`You already sent ${p.name} a friend request.`);
				else if (!who) { say(`${p.name} isn't on the friends service right now, so a request can't be sent.`); if (window.Sound) Sound.play("error"); }
				else { Social.addFriend(who); requested.add(p.name); say(`Friend request sent to ${p.name}.`); }
			}
		} });
	}
	function toggleMute(p) {
		if (muted.has(p.name)) muted.delete(p.name); else muted.add(p.name);
		saveMuted();
		render();
	}
	// Kick and Ban act on the second click (or second A press), within 4 s.
	function hostAction(kind, p) {
		if (asked && asked.kind === kind && asked.number === p.number && performance.now() - asked.at < 4000) {
			asked = null;
			post(`scoreboard:${kind}:${p.number}`);
			if (window.Sound) Sound.play("select");
		} else asked = { kind, number: p.number, at: performance.now() };
		render();
	}
	function show() {
		build();
		open = true;
		asked = null;
		me = (document.getElementById("player") || {}).textContent || "";
		me = me.trim();
		root.classList.add("open");
		document.body.classList.add("sbopen");
		foot();
		render();
		requestAnimationFrame(() => requestAnimationFrame(() => post("scoreboard:shown")));
	}
	function hide() {
		if (!open) return false;
		open = false;
		root.classList.remove("open");
		document.body.classList.remove("sbopen");
		if (window.Dropdown && Dropdown.isOpen()) Dropdown.close();
		return true;
	}
	function close() {
		if (hide()) post("scoreboard:close");
	}
	return {
		isOpen: () => open,
		toggle: () => (open ? close() : show()),
		// The match ended under it (index.html onGameReturn): closed with nothing sent to the overlay.
		reset: hide,
		update(text) {
			try { data = JSON.parse(text); } catch (e) { return; }
			render();
			foot();
		},
		// Keys and controller: up/down choose a player, A opens their menu (friend request, mute), X kicks and
		// Y bans (host), Tab/Esc/B/Start close.
		action(a) {
			const players = sorted();
			if (a === "back" || a === "start") return close();
			if (a === "down") sel = Math.min(players.length - 1, sel + 1);
			else if (a === "up") sel = Math.max(0, sel - 1);
			else if (a === "select" && players[sel]) {
				const row = root.querySelectorAll(".row")[sel];
				return playerMenu(players[sel], row && row.querySelector(".nm"));
			}
			else if (a === "star" && data && data.host && players[sel] && !isMe(players[sel])) hostAction("kick", players[sel]);
			else if (a === "refresh" && data && data.host && players[sel] && !isMe(players[sel])) hostAction("ban", players[sel]);
			render();
		},
	};
})();
