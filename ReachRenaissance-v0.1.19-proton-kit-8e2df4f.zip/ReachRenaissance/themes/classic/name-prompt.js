// The player's name (owner via coordinator, 2026-10-13: the single exe asks for one on the first
// run). Shown when the overlay program's settings have no `name` yet, and from SETTINGS > Network.
// Saved with `setting:name=<name>` (settings.rs: 1-15 letters, digits, spaces, - or _); the games
// get it as host-probe --user-name.
// With `ask` ({ title, text, max }) it asks for another name in the same box: Save Map As in the game
// menu (start-menu.js; 2026-10-20 player batch, report 13). That name only goes to `after`.
window.NamePrompt = (() => {
	const css = document.createElement("style");
	css.textContent = `
	.np { position: fixed; inset: 0; z-index: 1003; display: none; align-items: center; justify-content: center;
		background: radial-gradient(ellipse at 50% 45%, rgba(20, 40, 54, 0.92), rgba(4, 8, 12, 0.96)); font-family: var(--font); color: var(--text); }
	.np.open { display: flex; }
	.np .box { width: 44vw; padding: 4vh 3vw; background: linear-gradient(180deg, rgba(40, 56, 70, 0.92), rgba(22, 32, 42, 0.92));
		box-shadow: inset 0.25vw 0 0 #f2f4f5, 0 1vh 4vh rgba(0, 0, 0, 0.6); }
	.np h1 { margin: 0 0 1vh; font-size: 5vh; font-weight: 700; letter-spacing: 0.02em; text-transform: uppercase; }
	.np p { margin: 0 0 3vh; font-size: 2.4vh; color: #b9c2c8; }
	.np input { width: 100%; box-sizing: border-box; font: 600 4vh var(--font); letter-spacing: 0.03em; padding: 1vh 1vw; color: #fff;
		background: rgba(0, 0, 0, 0.35); border: 1px solid rgba(255, 255, 255, 0.35); outline: none; }
	.np input:focus { border-color: #f2f4f5; box-shadow: 0 0 0 0.2vh rgba(242, 244, 245, 0.4); }
	.np .err { min-height: 2.6vh; margin-top: 1vh; font-size: 2.2vh; color: #e8a33a; }
	.np .keys { margin-top: 2vh; display: flex; gap: 1.6vw; font-size: 2.6vh; }
	.np .keys .hint { cursor: pointer; }`;
	document.head.appendChild(css);
	const root = document.createElement("div");
	root.className = "np";
	root.innerHTML = `<div class="box"><h1>Choose Your Name</h1>
		<p>Other players see it in lobbies, on the scoreboard and over your Spartan.</p>
		<input maxlength="15" spellcheck="false" autocomplete="off"><div class="err"></div>
		<div class="keys"><span class="hint" data-a="ok"><span class="btn a">A</span>Accept</span><span class="hint cancel" data-a="cancel"><span class="btn b">B</span>Cancel</span></div></div>`;
	document.body.appendChild(root);
	const input = root.querySelector("input"), err = root.querySelector(".err");
	const title = root.querySelector("h1"), about = root.querySelector("p"), own = [title.textContent, about.textContent];
	let open = false, required = false, done = null, asking = null;
	const valid = (n) => asking ? n.length >= 1 && n.length <= asking.max && n.trim() === n && !/[\u0000-\u001f\u007f-\u009f]/.test(n)
		: /^[A-Za-z0-9 _-]{1,15}$/.test(n) && n.trim() === n;

	function show(current, mustChoose, after, ask) {
		open = true;
		required = mustChoose;
		done = after || null;
		asking = ask || null;
		title.textContent = asking ? asking.title : own[0];
		about.textContent = asking ? asking.text : own[1];
		input.maxLength = asking ? asking.max : 15;
		root.querySelector(".cancel").style.display = mustChoose ? "none" : "";
		input.value = asking ? String(current || "").slice(0, asking.max) : current && current !== "Player" ? current : "";
		err.textContent = "";
		root.classList.add("open");
		setTimeout(() => input.focus(), 0);
	}
	function accept() {
		const name = input.value.trim();
		input.value = name;
		if (!valid(name)) {
			err.textContent = asking ? "1 to " + asking.max + " characters." : "1 to 15 letters, numbers, spaces, - or _.";
			if (typeof Sound !== "undefined") Sound.play("error");
			return;
		}
		close();
		if (asking) {
			if (typeof Sound !== "undefined") Sound.play("select");
			if (done) done(name);
			return;
		}
		document.getElementById("player").textContent = name;
		try { window.chrome.webview.postMessage("setting:name=" + name); } catch (e) { }
		if (typeof Sound !== "undefined") Sound.play("select");
		if (done) done(name);
	}
	function close() {
		open = false;
		root.classList.remove("open");
		input.blur();
	}
	input.addEventListener("keydown", (e) => {
		e.stopPropagation();
		if (e.key === "Enter") { e.preventDefault(); accept(); }
		else if (e.key === "Escape" && !required) { e.preventDefault(); close(); }
	});
	root.querySelectorAll("[data-a]").forEach(el => el.onclick = () => el.dataset.a === "ok" ? accept() : (!required && close()));

	return {
		show,
		get open() { return open; },
		// Controller: A accepts, B cancels (typing needs a keyboard; Windows' touch keyboard works too).
		action(a) {
			if (a === "select") accept();
			else if (a === "back" && !required) close();
		},
	};
})();
