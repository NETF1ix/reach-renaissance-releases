// UPDATE banner (owner, 2026-10-17: "an update button would appear at the top of the screen"). The
// launcher checks GitHub for a newer signed release at start and passes its version as `?update=`;
// the banner's button posts `update-now`, menu-overlay starts the launcher with --update and closes,
// and the launcher installs the release and starts it (client/launcher/src/update.rs).
(() => {
	const version = new URLSearchParams(location.search).get("update");
	if (!version || !/^[0-9.]{1,16}$/.test(version)) return;
	const css = document.createElement("style");
	css.textContent = `
	.upd { position: fixed; top: 1.4vh; left: 50%; transform: translateX(-50%); z-index: 1100; display: flex; align-items: center;
		gap: 1.6vw; padding: 0.9vh 1.2vw 0.9vh 1.6vw; font-family: var(--font); font-size: 2.1vh; color: #dfe4e8;
		background: linear-gradient(90deg, rgba(34, 43, 52, 0.94), rgba(44, 54, 64, 0.94)); border: 1px solid rgba(220, 228, 234, 0.35);
		box-shadow: 0 0.6vh 2vh rgba(0, 0, 0, 0.5); }
	.upd b { font-weight: 700; letter-spacing: 0.03em; }
	.upd button { font: inherit; font-weight: 700; text-transform: uppercase; letter-spacing: 0.04em; color: #10161c; cursor: pointer;
		background: #dfe4e8; border: 0; padding: 0.6vh 1.1vw; }
	.upd button:hover { background: #fff; }
	.upd button.later { background: transparent; color: #a9b3ba; font-weight: 600; }
	.upd button.later:hover { color: #fff; background: transparent; }`;
	document.head.appendChild(css);
	const bar = document.createElement("div");
	bar.className = "upd";
	bar.innerHTML = `<span><b>Reach Renaissance ${version}</b> is available. <small style="color:#a9b3ba">(&#9776; Menu &gt; Update)</small></span><button class="go">Update and restart</button><button class="later">Later</button>`;
	bar.querySelector(".go").onclick = () => {
		bar.querySelector("span").textContent = "Updating: the game closes and comes back on the new version...";
		bar.querySelectorAll("button").forEach((b) => b.remove());
		try { window.chrome.webview.postMessage("update-now"); } catch (e) { }
	};
	bar.querySelector(".later").onclick = () => bar.remove();
	const show = () => document.body.appendChild(bar);
	if (document.body) show(); else document.addEventListener("DOMContentLoaded", show);
})();
