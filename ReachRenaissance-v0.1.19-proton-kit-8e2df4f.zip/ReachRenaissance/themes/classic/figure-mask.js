// Which pixels of a frame are the Spartan's backdrop (figure.js draws the rest as him). Its own file so
// tests can run it in node (tests/figure-mask.test.js): it kept regressing (owner, 2026-10-13: "partially
// see through", glitchy knees, holes all over the Armory Spartan).
//
// outsideMask(px, w, h, black, exact): px is a frame (4 bytes a pixel, colour order doesn't matter),
// worked at half size. Returns { out, W, H, glow, Q, R }: out[i] is 255 where the backdrop is (half
// size), glow the estimate of his glow at quarter size.
//
// The game window (exact false): the flood from the frame's edge through the black and his glow (steps
// may rise by DELTA up to CAP, or to anything no brighter than the glow estimate there); the black itself
// (black level + 3) counts wherever it is. The texture camera's picture (exact true): him alone on pure
// black, no glow, and its alpha is the game's own cut-out: 0 where nothing was drawn, 1 on him and on
// the sky (black). So alpha 0 is backdrop wherever it is; black with alpha (sky) is backdrop where the
// flood from the edge reaches it, plus enclosed patches of it at least GAP half-size pixels big (a gap
// between arm and body against the sky). Smaller ones are his own deepest shadows (knees, undersuit),
// which counting as backdrop made him see-through. With no sky in view (the player card's camera looks
// a little down, all_scenes.py CARD_TEXCAM) the alpha alone is the cut-out.
//
// strict (the game window on the Armory's pure-black void, the Elite's player card): only pixels within
// STRICT of the black level flood, with no rising steps and no glow rule. The Elite's undersuit is a dark
// grey that rises smoothly from the black between his legs and under his helmet, and the usual flood went
// in through it: his legs and neck came out see-through, and the fit, measuring a body cut at the waist,
// blew him up past the card (owner, 2026-10-17).
(function (root) {
	const DELTA = 3, CAP = 30, GLOW = 0.25, BLUR = 6, GAP = 400, STRICT = 6;
	let work = null;

	function outsideMask(px, w, h, black, exact, strict) {
		const W = w >> 1, H = h >> 1, Q = W >> 1, R = H >> 1;
		if (!work || work.W !== W || work.H !== H) {
			work = { W, H, v: new Int16Array(W * H), out: new Uint8Array(W * H), queue: new Int32Array(W * H), lit: new Uint8Array(W * H),
				small: new Float32Array(Q * R), tmp: new Float32Array(Q * R), glow: new Uint8Array(Q * R) };
		}
		const { out, queue, lit, small, tmp, glow } = work;
		const v = work.v;
		for (let y = 0; y < H; y++) {
			const row0 = 2 * y * w * 4;
			for (let x = 0; x < W; x++) {
				let m = 0, o = row0 + x * 8, c;
				for (let k = 0; k < 3; k++) { c = px[o + k]; if (c > m) m = c; c = px[o + 4 + k]; if (c > m) m = c; c = px[o + w * 4 + k]; if (c > m) m = c; c = px[o + w * 4 + 4 + k]; if (c > m) m = c; }
				// (exact: nothing drawn here at all, by the alpha; -1 so it floods and seeds like black)
				if (exact && !(px[o + 3] | px[o + 7] | px[o + w * 4 + 3] | px[o + w * 4 + 7])) m = -1;
				v[y * W + x] = m;
			}
		}
		// The glow estimate only matters to the game window's usual flood (exact and strict don't use it,
		// nor does figure.js's shader then): skipping it there saves a fifth of each frame's work.
		if (exact || strict) glow.fill(0);
		else estimateGlow();
		out.fill(0);
		const floor = exact ? -1 : black + (strict ? STRICT : 3), cap = exact ? 0 : strict ? black + STRICT : CAP, delta = exact || strict ? 0 : DELTA;
		let head = 0, tail = 0, sky = false;
		for (let y = 0; y < H; y++) {
			const gy = Math.min(R - 1, y >> 1) * Q;
			for (let x = 0; x < W; x++) {
				const i = y * W + x;
				lit[i] = exact || strict ? 0 : Math.min(255, glow[gy + Math.min(Q - 1, x >> 1)] + 3);
				const edge = x === 0 || y === 0 || x === W - 1 || y === H - 1;
				if (edge && v[i] === 0) sky = true;
				if (v[i] <= floor || v[i] < 0 || (edge && v[i] <= cap)) { out[i] = 255; queue[tail++] = i; }
			}
		}
		flood(head, tail, cap, delta);
		if (exact) {
			// Enclosed black patches: big ones are backdrop seen through a gap, small ones his shadows.
			for (let s = 0; s < W * H; s++) {
				if (out[s] || v[s] > 0) continue;
				head = 0; tail = 0;
				out[s] = 128; queue[tail++] = s;
				while (head < tail) {
					const i = queue[head++], x = i % W;
					// (the four neighbours written out: a small array per pixel was most of this loop's time)
					let n = i - 1;
					if (x > 0 && !out[n] && v[n] <= 0) { out[n] = 128; queue[tail++] = n; }
					n = i + 1;
					if (x < W - 1 && !out[n] && v[n] <= 0) { out[n] = 128; queue[tail++] = n; }
					n = i - W;
					if (n >= 0 && !out[n] && v[n] <= 0) { out[n] = 128; queue[tail++] = n; }
					n = i + W;
					if (n < W * H && !out[n] && v[n] <= 0) { out[n] = 128; queue[tail++] = n; }
				}
				// (with no sky in the picture, black the game drew is all his)
				const keep = sky && tail >= GAP ? 255 : 1; // (1: looked at, his)
				for (let k = 0; k < tail; k++) out[queue[k]] = keep;
			}
			for (let i = 0; i < W * H; i++) if (out[i] === 1) out[i] = 0;
		}
		return { out, W, H, glow, Q, R };

		// His glow, at quarter size: the brightest of each block, blurred.
		function estimateGlow() {
			small.fill(0);
			for (let y = 0; y < R * 2; y++) for (let x = 0; x < Q * 2; x++) {
				const j = (y >> 1) * Q + (x >> 1), m = v[y * W + x];
				if (m > small[j]) small[j] = m;
			}
			for (let pass = 0; pass < 2; pass++) {
				for (let y = 0; y < R; y++) {
					let sum = 0;
					for (let x = -BLUR; x < Q + BLUR; x++) {
						if (x + BLUR < Q) sum += small[y * Q + x + BLUR];
						if (x - BLUR - 1 >= 0) sum -= small[y * Q + x - BLUR - 1];
						if (x >= 0 && x < Q) tmp[y * Q + x] = sum / (Math.min(Q - 1, x + BLUR) - Math.max(0, x - BLUR) + 1);
					}
				}
				for (let x = 0; x < Q; x++) {
					let sum = 0;
					for (let y = -BLUR; y < R + BLUR; y++) {
						if (y + BLUR < R) sum += tmp[(y + BLUR) * Q + x];
						if (y - BLUR - 1 >= 0) sum -= tmp[(y - BLUR - 1) * Q + x];
						if (y >= 0 && y < R) small[y * Q + x] = sum / (Math.min(R - 1, y + BLUR) - Math.max(0, y - BLUR) + 1);
					}
				}
			}
			for (let j = 0; j < Q * R; j++) glow[j] = Math.min(255, GLOW * small[j]);
		}

		function flood(head, tail, cap, delta) {
			while (head < tail) {
				const i = queue[head++], x = i % W, lim = Math.min(cap, v[i] + delta);
				let n = i - 1;
				if (x > 0 && !out[n] && (v[n] <= lim || v[n] <= lit[n])) { out[n] = 255; queue[tail++] = n; }
				n = i + 1;
				if (x < W - 1 && !out[n] && (v[n] <= lim || v[n] <= lit[n])) { out[n] = 255; queue[tail++] = n; }
				n = i - W;
				if (n >= 0 && !out[n] && (v[n] <= lim || v[n] <= lit[n])) { out[n] = 255; queue[tail++] = n; }
				n = i + W;
				if (n < W * H && !out[n] && (v[n] <= lim || v[n] <= lit[n])) { out[n] = 255; queue[tail++] = n; }
			}
		}
	}

	const api = { outsideMask, GAP, STRICT };
	if (typeof module === "object" && module.exports) module.exports = api;
	else root.FigureMask = api;
})(typeof window !== "undefined" ? window : globalThis);
