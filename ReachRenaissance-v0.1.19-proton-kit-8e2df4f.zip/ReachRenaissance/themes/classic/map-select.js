// SELECT MAP (owner, 2026-10-13: the flat list hid most maps and Forge World's 165 variants): the maps as
// pictures in a scrolling grid, a Recent row of the map and game type pairs played last, and Forge World
// up front (the map most games start from) with its variants in a browser that filters them by where
// they came from and searches them by name. Pictures, loading screens and overhead maps come from
// extract_maps.py (MCC's own texture packs), variants from extract_variants.py. index.html opens it from
// a lobby's Map row and hands it the input while it is open.
window.MapSelect = (() => {
	const STORE = "rr.recentGames";
	const RECENT_SHOWN = 8;
	const FORGE = "Forge World";
	// The multiplayer maps by where they came from (Reach, its map packs, the Anniversary pack).
	const GROUPS = [
		["Reach", ["Boardwalk", "Boneyard", "Countdown", "Powerhouse", "Reflection", "Spire", "Sword Base", "Zealot"]],
		["Map Packs", ["Anchor 9", "Breakpoint", "Tempest", "Condemned", "Highlands"]],
		["Anniversary", ["Battle Canyon", "Penance", "Ridgeline", "Solitary", "High Noon", "Breakneck"]],
	];
	// Variant tabs: where a variant came from (extract_variants.py's groups).
	// (File Share: the Forge maps of games the player joined, kept by host-probe fileshare.rs; 2026-10-21)
	const TABS = [["all", "All"], ["mine", "My Maps"], ["share", "File Share"], ["mods", "Mods"], ["builtin", "Built-in"], ["mm", "Matchmaking"]];
	const tabOf = (v) => v.group === "My Files" || v.group === "Downloads" ? "mine" : v.group === "File Share" ? "share" : v.group.startsWith("Mod:") ? "mods"
		: v.group === "Built-in" ? "builtin" : v.group === "Matchmaking" ? "mm" : "other";
	const ORDER = ["mine", "share", "mods", "builtin", "mm", "other"];
	// A File Share variant's host and the Workshop mod its game was played with (gamesetup.rs reads them from
	// the file's .share sidecar). Another player's text: only ever drawn through esc() or textContent.
	const fromOf = (v) => v.group === "File Share" && v.from ? "From " + v.from : "";
	const needsOf = (v) => { const m = v.group === "File Share" && v.mod && (v.mod.title || v.mod.id); return m ? "Needs " + m : ""; };
	const style = document.createElement("style");
	style.textContent = `
	.ms { position: fixed; inset: 0; display: none; z-index: 20; background: rgb(12, 18, 24); color: var(--text); font-family: var(--font); }
	.ms.open { display: block; }
	.ms-bg i { position: absolute; inset: 0; background: center / cover no-repeat; opacity: 0; transition: opacity 0.5s; }
	.ms-bg i.on { opacity: 1; }
	.ms-shade { position: absolute; inset: 0; background:
		linear-gradient(90deg, rgba(8, 12, 16, 0.95) 0%, rgba(8, 12, 16, 0.88) 58%, rgba(8, 12, 16, 0.6) 76%, rgba(8, 12, 16, 0.42) 100%),
		linear-gradient(0deg, rgba(8, 12, 16, 0.9) 0%, rgba(8, 12, 16, 0) 30%); }
	.ms-head { position: absolute; left: 6vw; top: 4.5vh; }
	.ms-head .crumb { font-size: 2vh; color: var(--text-dim); text-transform: uppercase; letter-spacing: 0.08em; }
	.ms-head h1 { margin: 0.2vh 0 0; font-size: 5.6vh; font-weight: 700; text-transform: uppercase; display: flex; align-items: baseline; gap: 1.2vw; }
	.ms-head h1 small { font-size: 2.2vh; font-weight: 500; color: var(--text-dim); text-transform: none; }
	.ms-scroll { position: absolute; left: 6vw; top: 15vh; width: 59vw; bottom: 11vh; overflow-y: auto; overflow-x: hidden; padding: 0.5vh 1vw 2vh 0.4vh; }
	.ms-scroll.under-tabs { top: 21vh; }
	.ms-scroll::-webkit-scrollbar { width: 1vh; }
	.ms-scroll::-webkit-scrollbar-track { background: rgba(255, 255, 255, 0.06); border-radius: 0.5vh; }
	.ms-scroll::-webkit-scrollbar-thumb { background: rgba(255, 255, 255, 0.38); border-radius: 0.5vh; }
	.ms-scroll::-webkit-scrollbar-thumb:hover { background: rgba(255, 255, 255, 0.62); }
	.ms section { margin-bottom: 2.8vh; }
	.ms h2 { margin: 0 0 1.2vh; padding-bottom: 0.6vh; border-bottom: 1px solid rgba(255, 255, 255, 0.16); font-size: 2.3vh; font-weight: 700;
		text-transform: uppercase; letter-spacing: 0.06em; color: #dfe5ea; display: flex; align-items: baseline; gap: 0.8vw; }
	.ms h2 small { font-size: 1.7vh; font-weight: 500; letter-spacing: 0; text-transform: none; color: var(--text-dim); }
	.ms .grid { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 1.6vh 0.9vw; }
	.ms-cell { position: relative; cursor: pointer; scroll-margin: 6vh 0 3vh; }
	.ms .tile .pic { aspect-ratio: 2 / 1; background: #1c2630 center / cover no-repeat; box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.18); }
	.ms .tile .tx { padding: 0.6vh 0.2vw 0; }
	.ms .tile b { display: block; font-size: 2.2vh; font-weight: 600; text-transform: uppercase; color: var(--text-dim); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
	.ms .tile span { display: block; font-size: 1.7vh; color: var(--text-dim); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
	.ms .tile em { position: absolute; right: 0.4vw; top: 0.6vh; padding: 0.2vh 0.5vw; border-radius: 0.3vh; font-style: normal; font-size: 1.6vh; font-weight: 700;
		background: rgba(8, 12, 16, 0.8); }
	.ms .tile.sel .pic, .ms .tile:hover .pic { box-shadow: 0 0 0 0.35vh #f2f4f5; }
	.ms .tile.sel b, .ms .tile:hover b { color: #fff; }
	.ms .tile.sel, .ms .chip.sel, .ms .row.sel { animation: rrPulse 1.5s ease-in-out infinite; }
	.ms .tile.wide { grid-column: span 2; }
	.ms .tile.wide .pic { aspect-ratio: 4.13 / 1; }
	.ms .chips { grid-column: span 2; display: grid; grid-template-columns: minmax(0, 1fr) minmax(0, 1fr); gap: 1vh 0.9vw; align-content: start; }
	.ms .chip, .ms .row { background: rgba(255, 255, 255, 0.05); box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.12); }
	.ms .chip { padding: 0.9vh 0.8vw; }
	.ms .chip b { display: block; font-size: 2.1vh; font-weight: 600; text-transform: uppercase; }
	.ms .chip span { display: block; font-size: 1.7vh; color: var(--text-dim); }
	.ms .chip.sel, .ms .chip:hover, .ms .row.sel, .ms .row:hover { color: #fff; background: linear-gradient(90deg, rgba(255, 255, 255, 0.2), rgba(255, 255, 255, 0.07) 85%, rgba(255, 255, 255, 0.04));
		box-shadow: inset 0.25vw 0 0 #f2f4f5; }
	.ms .list { display: grid; grid-template-columns: minmax(0, 1fr) minmax(0, 1fr); gap: 0.5vh 0.9vw; }
	.ms .list h3 { grid-column: 1 / -1; margin: 1.6vh 0 0.3vh; font-size: 1.9vh; font-weight: 700; text-transform: uppercase; letter-spacing: 0.06em; color: #dfe5ea; }
	.ms .list h3:first-child { margin-top: 0; }
	.ms .row { display: flex; justify-content: space-between; align-items: baseline; gap: 0.6vw; padding: 0.75vh 0.7vw; font-size: 2.2vh; font-weight: 600;
		text-transform: uppercase; color: var(--text-dim); }
	.ms .row b { font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
	/* (a File Share row names its host, another player's name of up to 64 characters: it ends in an ellipsis
	   rather than squeeze the variant's name; 2026-10-21) */
	.ms .row span { flex: none; max-width: 55%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-size: 1.7vh; text-transform: none; }
	.ms .row.base { grid-column: 1 / -1; }
	.ms-empty { color: var(--text-dim); font-size: 2.3vh; padding: 2vh 0; }
	.ms-tabs { position: absolute; left: 6vw; top: 14.5vh; width: 59vw; display: flex; align-items: center; gap: 0.4vw; }
	.ms-tabs .tab { padding: 0.7vh 0.9vw; font-size: 2.1vh; font-weight: 600; text-transform: uppercase; color: var(--text-dim); cursor: pointer;
		border-bottom: 0.3vh solid transparent; }
	.ms-tabs .tab small { margin-left: 0.4vw; font-size: 1.6vh; font-weight: 500; }
	.ms-tabs .tab:hover { color: #fff; }
	.ms-tabs .tab.on { color: #fff; border-color: #f2f4f5; background: rgba(255, 255, 255, 0.08); }
	.ms-tabs input { margin-left: auto; width: 15vw; padding: 0.7vh 0.7vw; font: 500 2vh var(--font); color: #fff; background: rgba(0, 0, 0, 0.4);
		border: 1px solid rgba(255, 255, 255, 0.25); outline: none; }
	.ms-tabs input:focus { border-color: #f2f4f5; box-shadow: 0 0 0 0.2vh rgba(242, 244, 245, 0.4); }
	.ms-tabs input::placeholder { color: rgba(255, 255, 255, 0.45); }
	/* The maps page's search, top right of the list, beside the first heading (owner, 2026-10-15). */
	.ms-search { position: absolute; left: calc(65vw - 17vw); top: 14.2vh; width: 16vw; z-index: 1; padding: 0.6vh 0.7vw 0.6vh 2.2vw; font: 500 2vh var(--font);
		color: #fff; background: rgba(0, 0, 0, 0.45) no-repeat 0.6vw 50% / 1.8vh; border: 1px solid rgba(255, 255, 255, 0.25); outline: none; box-sizing: border-box;
		background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 20 20'%3E%3Ccircle cx='8' cy='8' r='6' fill='none' stroke='%23b9c2c8' stroke-width='2'/%3E%3Cpath d='M12.5 12.5 L18 18' stroke='%23b9c2c8' stroke-width='2'/%3E%3C/svg%3E"); }
	.ms-search:focus { border-color: #f2f4f5; box-shadow: 0 0 0 0.2vh rgba(242, 244, 245, 0.4); }
	.ms-search::placeholder { color: rgba(255, 255, 255, 0.45); }
	.ms-info { position: absolute; left: 68vw; top: 15vh; width: 26vw; }
	.ms-info .pic { height: 34vh; background: rgba(8, 12, 16, 0.55) center / contain no-repeat; background-origin: content-box; padding: 1.5vh;
		box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.15); }
	.ms-info .pic.photo { height: auto; aspect-ratio: 2 / 1; background-size: cover; padding: 0; }
	.ms-info .nm { margin-top: 2vh; font-size: 3.6vh; font-weight: 600; text-transform: uppercase; line-height: 1.1; }
	.ms-info .pl { margin-top: 0.8vh; font-size: 2.2vh; line-height: 1.3; color: var(--text-dim); }
	.ms-info .ab { margin-top: 1.4vh; padding-top: 1.4vh; border-top: 1px solid rgba(255, 255, 255, 0.2); font-size: 2.3vh; line-height: 1.35; color: #dfe5ea;
		max-height: 24vh; overflow: hidden; -webkit-mask-image: linear-gradient(black 80%, transparent); }
	.ms-keys { position: absolute; left: 6vw; right: 6vw; top: 90.5vh; padding-top: 1.2vh; border-top: 1px solid rgba(255, 255, 255, 0.18);
		display: flex; gap: 1.6vw; font-size: 2.5vh; }
	.ms-keys .hint { cursor: pointer; }
	.ms-keys .hint:hover { filter: brightness(1.3); }
	.ms .btn.lr { width: auto; padding: 0 0.6vh; border-radius: 1.35vh; font-size: 1.4vh; background: rgba(255, 255, 255, 0.18); }
	body.kbm .ms .btn.lr::after { content: "Q / E"; }
	body.kbm .ms .btn.y::after { content: "R"; }
	`;
	document.head.appendChild(style);
	const root = document.createElement("div");
	root.className = "ms";
	document.body.appendChild(root);
	let o = null;     // what open() was given: { lobbyKey, lobbyTitle, item, gameItem, mapInfo, mapIds, variants, done }
	let page = null;  // { kind: "maps" } or { kind: "variants", map, tab, query, from }
	let cells = {};   // a cell's key (data-k) -> { info, pick }
	let sel = null;
	const esc = (s) => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
	const sound = (name) => { if (typeof Sound !== "undefined") Sound.play(name); };
	// (a mod's maps have no Forge variants here, even one named like an MCC map)
	// A map's Forge variants. With a mod picked (its maps only), a map the mod replaces has the original
	// map's variants, and a new map of the mod has the variants made on a map that isn't one of MCC's
	// (their map id is no built-in one). Before 2026-10-17 a mod hid every variant (player report).
	const variantsOf = (name) => {
		const all = o.variants.maps || [];
		if (!o.modName) return all.filter(v => v.map === o.mapIds[name]);
		const x = (o.item.modMaps || []).find(m => m.name === name);
		if (x && x.native) return all.filter(v => v.map === o.mapIds[x.native]);
		// (its own map id when the mod has a map info, extract_variants.py; else any map MCC doesn't ship)
		if (x && x.mapId) return all.filter(v => v.map === x.mapId);
		const known = new Set(Object.values(o.mapIds));
		return all.filter(v => v.map && !known.has(v.map));
	};
	const tileOf = (info) => info.tile || info.thumb || info.banner || "";
	const playersOf = (v) => { const m = /(\d+)\s*-\s*(\d+)\s*players?/i.exec(v.text || ""); return m ? m[1] + "-" + m[2] : ""; };
	const plural = (n, word) => n + " " + word + (n === 1 ? "" : "s");

	// Recent: the map and game type of each game started from a lobby, newest first (localStorage).
	function recent() {
		try { const list = JSON.parse(localStorage.getItem(STORE) || "[]"); return Array.isArray(list) ? list : []; } catch (e) { return []; }
	}
	function remember(lobbyKey, lobby, modded) {
		if (modded) return; // (a mod's maps aren't there without the mod)
		const mapItem = lobby.items.find(i => i.name === "Map" && i.options);
		if (!mapItem) return;
		const gt = lobby.items.find(i => i.name === "Game Type");
		const r = { lobby: lobbyKey, map: mapItem.options[mapItem.pick], v: mapItem.variant ? mapItem.variant.path : "", vName: mapItem.variant ? mapItem.variant.name : "",
			gt: gt ? (gt.variant ? gt.variant.name : gt.options ? gt.options[gt.pick] : gt.value || "") : "", gtPath: gt && gt.variant ? gt.variant.path : "" };
		const same = (x) => x.lobby === r.lobby && x.map === r.map && x.v === r.v && x.gt === r.gt && x.gtPath === r.gtPath;
		try { localStorage.setItem(STORE, JSON.stringify([r, ...recent().filter(x => !same(x))].slice(0, 30))); } catch (e) { }
	}
	const variantAt = (path) => (o.variants.maps || []).find(v => v.path === path);
	function recentHere() {
		return recent().filter(r => r.lobby === o.lobbyKey && o.item.options.includes(r.map) && (!r.v || variantAt(r.v))).slice(0, RECENT_SHOWN);
	}
	function pickRecent(r) {
		finish(() => {
			o.item.pick = o.item.options.indexOf(r.map);
			o.item.variant = r.v ? variantAt(r.v) : null;
			const gt = o.gameItem;
			if (!gt || !gt.options) return;
			const g = r.gtPath && (o.variants.games || []).find(x => x.path === r.gtPath);
			if (g) gt.variant = g;
			else if (gt.options.includes(r.gt)) { gt.pick = gt.options.indexOf(r.gt); gt.variant = null; }
		});
	}

	// What the side panel shows for a map, and for one of its variants.
	function mapInfoOf(name) {
		const info = o.mapInfo(name) || {};
		const n = variantsOf(name).length;
		return { name: info.name || name, players: [info.players, n ? plural(n, "variant") : ""].filter(Boolean).join(" · "), text: info.text,
			layout: info.layout, pic: tileOf(info), photo: info.banner || tileOf(info), backdrop: info.backdrop || info.banner || tileOf(info) };
	}
	// The same for a mod's map (index.html's modMapInfo: the mod's picture and text, else the base map's).
	function modInfoOf(info, modName) {
		return { name: info.name, players: "Plays with the mod " + modName, text: info.text, layout: info.layout,
			pic: tileOf(info), photo: info.banner || tileOf(info), backdrop: info.backdrop || info.banner || tileOf(info) };
	}
	function variantInfo(name, v) {
		const base = mapInfoOf(name);
		return { ...base, name: v.name, players: [name, v.group, fromOf(v), needsOf(v), playersOf(v) && playersOf(v) + " players"].filter(Boolean).join(" · "), text: v.text || base.text };
	}

	function cell(k, cls, inner, spec) {
		cells[k] = spec;
		return `<div class="ms-cell ${cls}" data-k="${esc(k)}">${inner}</div>`;
	}
	function tile(k, cls, pic, title, sub, badge, spec) {
		return cell(k, "tile " + cls, `<div class="pic" style="background-image:url('${esc(pic)}')"></div>${badge ? `<em>${esc(badge)}</em>` : ""}
			<div class="tx"><b>${esc(title)}</b><span>${esc(sub || " ")}</span></div>`, spec);
	}
	function mapTile(name) {
		const info = mapInfoOf(name);
		const n = variantsOf(name).length;
		return tile("m:" + name, "", info.pic, info.name, (o.mapInfo(name) || {}).players || "", n ? String(n) : "",
			{ info, pick: () => n ? variantsPage(name, "all", "m:" + name) : finish(() => { o.item.pick = o.item.options.indexOf(name); o.item.variant = null; }) });
	}
	function shell(crumb, title, count, body, keys, tabs) {
		root.innerHTML = `<div class="ms-bg"><i></i><i></i></div><div class="ms-shade"></div>
			<div class="ms-head"><div class="crumb">${esc(crumb)}</div><h1>${esc(title)}<small>${esc(count)}</small></h1></div>
			${tabs || ""}<div class="ms-scroll${tabs ? " under-tabs" : ""}">${body}</div>
			<aside class="ms-info"><div class="pic"></div><div class="nm"></div><div class="pl"></div><div class="ab"></div></aside>
			<div class="ms-keys">${keys.map(([btn, label, a]) => `<span class="hint" data-a="${a}"><span class="btn ${btn}">${btn === "lr" ? "LB RB" : btn.toUpperCase()}</span>${esc(label)}</span>`).join("")}</div>`;
		root.querySelectorAll(".ms-keys [data-a]").forEach(el => el.onclick = () => action(el.dataset.a));
	}

	// The maps: Recent, Forge World and its variants by kind, then every other map by where it came from.
	function mapsPage(focus) {
		page = { kind: "maps" };
		cells = {};
		if (focus === "m:" + FORGE) focus = "fw";
		const names = o.item.options;
		let body = "";
		// With a mod chosen: only its maps (the Map row lists only those), and a way back to every map.
		if (o.modName) {
			body = `<section><h2>${esc(o.modName)}<small>${plural(names.length, "map")} from this mod</small></h2><div class="grid">${names.map(n => {
				const info = modInfoOf(o.mapInfo(n) || { name: n }, o.modName);
				// (its Forge variants behind it, as on the other maps' tiles)
				const count = variantsOf(n).length;
				return tile("m:" + n, "", info.pic, n, count ? "From this mod · " + plural(count, "variant") : "From this mod", count ? String(count) : "",
					{ info, pick: () => count ? variantsPage(n, "all", "m:" + n) : finish(() => { o.item.pick = names.indexOf(n); o.item.variant = null; }) });
			}).join("")}</div></section>
			<section><div class="grid"><div class="chips">${cell("nomod", "chip", `<b>No Mod</b><span>Every map, without ${esc(o.modName)}</span>`,
				{ info: { name: "No Mod", text: "Play the maps as MCC ships them; the mod's maps need the mod." }, pick: () => { finish(null); o.clearMod(); } })}</div></div></section>`;
			shell(o.lobbyTitle, "Select Map", plural(names.length, "map"), body, [["a", "Select", "select"], ["b", "Back", "back"], ["y", "Search", "refresh"]]);
			addSearch();
			focusCell(cells[focus] ? focus : Object.keys(cells)[0], true, true);
			return;
		}
		const recents = recentHere();
		if (recents.length) {
			body += `<section><h2>Recent<small>the maps and game types you played last</small></h2><div class="grid">${recents.map((r, i) => {
				const v = r.v ? variantAt(r.v) : null;
				const info = v ? variantInfo(r.map, v) : mapInfoOf(r.map);
				return tile("r:" + i, "", info.pic, r.vName || r.map, [r.gt, r.vName ? r.map : ""].filter(Boolean).join(" · "), "",
					{ info: { ...info, players: [r.gt, info.players].filter(Boolean).join(" · ") }, pick: () => pickRecent(r) });
			}).join("")}</div></section>`;
		}
		if (names.includes(FORGE)) {
			const list = variantsOf(FORGE);
			const info = mapInfoOf(FORGE);
			const count = (tab) => list.filter(v => tabOf(v) === tab).length;
			const chips = [["base", "Original Map", "Forge World as it ships"], ...TABS.filter(([t]) => t !== "all" && count(t)).map(([t, label]) => [t, label, plural(count(t), "variant")])];
			body += `<section><h2>Forge World<small>the canvas most maps are built on</small></h2><div class="grid">
				${tile("fw", "wide", (o.mapInfo(FORGE) || {}).banner || info.pic, "Forge World", "Browse all " + plural(list.length, "variant"), String(list.length),
					{ info, pick: () => variantsPage(FORGE, "all", "fw") })}
				<div class="chips">${chips.map(([t, label, sub]) => cell("fw:" + t, "chip", `<b>${esc(label)}</b><span>${esc(sub)}</span>`,
					t === "base" ? { info, pick: () => finish(() => { o.item.pick = names.indexOf(FORGE); o.item.variant = null; }) }
						: { info: { ...info, players: label + " · " + sub }, pick: () => variantsPage(FORGE, t, "fw:" + t) })).join("")}</div>
			</div></section>`;
		}
		const rest = names.filter(n => n !== FORGE);
		const grouped = new Set();
		for (const [title, members] of GROUPS) {
			const here = members.filter(n => rest.includes(n));
			here.forEach(n => grouped.add(n));
			if (here.length) body += `<section><h2>${esc(title)}<small>${plural(here.length, "map")}</small></h2><div class="grid">${here.map(mapTile).join("")}</div></section>`;
		}
		const others = rest.filter(n => !grouped.has(n));
		if (others.length) body += `<section><h2>${grouped.size ? "More Maps" : "Maps"}<small>${plural(others.length, "map")}</small></h2><div class="grid">${others.map(mapTile).join("")}</div></section>`;
		// Workshop mods' maps, each with its mod (owner, 2026-10-14: a mod's maps only play with the
		// mod): picking one picks the mod too.
		const mods = (o.mods || []).filter(m => m.maps.length);
		if (mods.length) {
			body += `<section><h2>Mods<small>${plural(mods.length, "mod")} with maps for this mode · a map picks its mod too</small></h2></section>`;
			mods.forEach((m) => {
				body += `<section><h2>${esc(m.name)}<small>${plural(m.maps.length, "map")}</small></h2><div class="grid">${m.maps.map((x) => {
					const info = modInfoOf(x.info, m.name);
					return tile("x:" + m.index + ":" + x.name, "", info.pic, x.name, m.name, "", { info, pick: () => { finish(null); o.pickModMap(m.index, x.name); } });
				}).join("")}</div></section>`;
			});
		}
		const total = names.reduce((sum, n) => sum + variantsOf(n).length, 0);
		shell(o.lobbyTitle, "Select Map", [plural(names.length, "map"), total ? plural(total, "variant") : ""].filter(Boolean).join(" · "), body,
			[["a", "Select", "select"], ["b", "Back", "back"], ["y", "Search", "refresh"]]);
		addSearch();
		const k = cells[focus] ? focus : Object.keys(cells)[0];
		focusCell(k, true, true);
	}

	// Search on the maps page (owner, 2026-10-15): typing lists the maps, Forge variants and mod maps
	// whose names hold the text, in place of the page; clearing it brings the page back.
	function addSearch() {
		page.body = root.querySelector(".ms-scroll").innerHTML;
		page.cells = cells;
		const input = document.createElement("input");
		input.className = "ms-search";
		input.placeholder = "Search maps and variants";
		input.spellcheck = false;
		input.autocomplete = "off";
		root.appendChild(input);
		input.addEventListener("keydown", (e) => {
			e.stopPropagation(); // the letters are for the search, not the menu's keys
			if (e.key === "Enter" || e.key === "ArrowDown" || e.key === "Escape") {
				e.preventDefault();
				if (e.key === "Escape" && input.value) { input.value = ""; searchFor(""); return; }
				input.blur();
				if (e.key === "Enter" && cells[sel]) { sound("select"); cells[sel].pick(); }
			}
		});
		input.addEventListener("input", () => searchFor(input.value.trim().toLowerCase()));
	}
	function searchFor(query) {
		const scroll = root.querySelector(".ms-scroll");
		if (!query) {
			cells = page.cells;
			scroll.innerHTML = page.body;
			scroll.scrollTop = 0;
			return focusCell(Object.keys(cells)[0], true, true);
		}
		cells = {};
		const has = (s) => String(s || "").toLowerCase().includes(query);
		const names = o.item.options;
		let body = "";
		const maps = names.filter(n => has(n) || has((o.mapInfo(n) || {}).name));
		if (maps.length) {
			body += `<section><h2>Maps<small>${plural(maps.length, "map")}</small></h2><div class="grid">${maps.map(n => o.modName
				? (() => { const info = modInfoOf(o.mapInfo(n) || { name: n }, o.modName); return tile("m:" + n, "", info.pic, n, "From this mod", "", { info, pick: () => finish(() => { o.item.pick = names.indexOf(n); o.item.variant = null; }) }); })()
				: mapTile(n)).join("")}</div></section>`;
		}
		const found = [];
		for (const n of names) variantsOf(n).forEach(v => { if (has(v.name)) found.push([n, v]); });
		found.sort(([, a], [, b]) => ORDER.indexOf(tabOf(a)) - ORDER.indexOf(tabOf(b)) || a.name.localeCompare(b.name));
		if (found.length) {
			body += `<section><h2>Forge Variants<small>${plural(found.length, "variant")}${found.length > 80 ? " · the first 80" : ""}</small></h2><div class="list">${found.slice(0, 80).map(([n, v], i) =>
				cell("s:" + i, "row", `<b>${esc(v.name)}</b><span>${esc([n, v.group.replace(/^Mod: /, ""), fromOf(v), playersOf(v)].filter(Boolean).join(" · "))}</span>`,
					{ info: variantInfo(n, v), pick: () => finish(() => { o.item.pick = names.indexOf(n); o.item.variant = v; }) })).join("")}</div></section>`;
		}
		const modMaps = [];
		for (const m of o.mods || []) for (const x of m.maps) if (has(x.name) || has(m.name)) modMaps.push([m, x]);
		if (modMaps.length) {
			body += `<section><h2>Mod Maps<small>${plural(modMaps.length, "map")} · a map picks its mod too</small></h2><div class="grid">${modMaps.map(([m, x]) => {
				const info = modInfoOf(x.info, m.name);
				return tile("x:" + m.index + ":" + x.name, "", info.pic, x.name, m.name, "", { info, pick: () => { finish(null); o.pickModMap(m.index, x.name); } });
			}).join("")}</div></section>`;
		}
		scroll.innerHTML = body || `<div class="ms-empty">Nothing is called that. Try part of a name, like "cage" or "sword".</div>`;
		scroll.scrollTop = 0;
		const k = Object.keys(cells)[0];
		if (k) focusCell(k, false, true);
	}

	// A map's variants: tabs by where they came from, a search by name, the map itself first.
	function variantsPage(name, tab, from) {
		page = { kind: "variants", map: name, tab, query: "", from };
		const list = variantsOf(name);
		const tabs = TABS.filter(([t]) => t === "all" || list.some(v => tabOf(v) === t));
		shell(o.lobbyTitle + " · Select Map", name, plural(list.length, "variant"), "",
			[["a", "Select", "select"], ["b", "Back", "back"], ["lr", "Filter", "tabr"], ["y", "Search", "refresh"]],
			`<div class="ms-tabs">${tabs.map(([t, label]) => `<span class="tab" data-t="${t}">${esc(label)}<small>${t === "all" ? list.length : list.filter(v => tabOf(v) === t).length}</small></span>`).join("")}
			<input placeholder="Search" spellcheck="false" autocomplete="off"></div>`);
		root.querySelectorAll(".ms-tabs .tab").forEach(el => el.onclick = () => { page.tab = el.dataset.t; sound("bumper"); fillVariants(); });
		const input = root.querySelector(".ms-tabs input");
		input.addEventListener("keydown", (e) => {
			e.stopPropagation(); // the letters are for the search, not the menu's keys
			if (e.key === "Enter" || e.key === "ArrowDown" || e.key === "Escape") {
				e.preventDefault();
				if (e.key === "Escape" && input.value) { input.value = ""; page.query = ""; fillVariants(); return; }
				input.blur();
				if (e.key === "Enter" && cells[sel]) { sound("select"); cells[sel].pick(); }
			}
		});
		input.addEventListener("input", () => { page.query = input.value.trim().toLowerCase(); fillVariants(); });
		const at = o.item.options[o.item.pick] === name && o.item.variant ? "v:" + list.indexOf(o.item.variant) : "base";
		fillVariants(at);
	}
	function fillVariants(focus) {
		cells = {};
		const { map: name, tab, query } = page;
		const all = variantsOf(name);
		root.querySelectorAll(".ms-tabs .tab").forEach(el => el.classList.toggle("on", el.dataset.t === tab));
		const shown = all.map((v, i) => [v, i]).filter(([v]) => (tab === "all" || tabOf(v) === tab) && (!query || v.name.toLowerCase().includes(query)))
			.sort(([a], [b]) => ORDER.indexOf(tabOf(a)) - ORDER.indexOf(tabOf(b)) || a.name.localeCompare(b.name));
		const pickMap = (v) => finish(() => { o.item.pick = o.item.options.indexOf(name); o.item.variant = v; });
		let body = "";
		if (tab === "all" && !query) body += cell("base", "row base", `<b>${esc(name)}</b><span>Original map</span>`, { info: mapInfoOf(name), pick: () => pickMap(null) });
		let heading = null;
		for (const [v, i] of shown) {
			if (tab === "all" && tabOf(v) !== heading) {
				heading = tabOf(v);
				body += `<h3>${esc((TABS.find(t => t[0] === heading) || [0, "Other"])[1])}</h3>`;
			}
			body += cell("v:" + i, "row", `<b>${esc(v.name)}</b><span>${esc([fromOf(v), playersOf(v)].filter(Boolean).join(" · "))}</span>`, { info: variantInfo(name, v), pick: () => pickMap(v) });
		}
		const scroll = root.querySelector(".ms-scroll");
		scroll.innerHTML = body ? `<div class="list">${body}</div>` : `<div class="ms-empty">No variants match.</div>`;
		scroll.scrollTop = 0;
		const k = cells[focus] ? focus : cells[sel] && focus === undefined ? sel : Object.keys(cells)[0];
		if (k) focusCell(k, true, true);
		else showInfo(mapInfoOf(name));
	}

	function focusCell(k, scroll, instant) {
		if (!cells[k]) return;
		sel = k;
		root.querySelectorAll(".ms-cell.sel").forEach(e => e.classList.remove("sel"));
		const el = root.querySelector(`[data-k="${CSS.escape(k)}"]`);
		if (!el) return;
		el.classList.add("sel");
		if (scroll) el.scrollIntoView({ block: "nearest", behavior: instant ? "auto" : "smooth" });
		showInfo(cells[k].info, instant);
	}
	// The side panel, and the map's loading screen behind the page (cross-faded, after a moment so that
	// running down a list doesn't load every picture on the way).
	let bgTimer = null, bgNow = "";
	function showInfo(info, instant) {
		const pic = root.querySelector(".ms-info .pic");
		const image = info.layout || info.photo || info.pic;
		pic.classList.toggle("photo", !info.layout);
		pic.style.backgroundImage = image ? `url('${image.replace(/'/g, "%27")}')` : "none";
		root.querySelector(".ms-info .nm").textContent = info.name || "";
		root.querySelector(".ms-info .pl").textContent = info.players || "";
		const ab = root.querySelector(".ms-info .ab");
		ab.textContent = info.text || "";
		ab.style.display = info.text ? "" : "none";
		clearTimeout(bgTimer);
		bgTimer = setTimeout(() => backdrop(info.backdrop || ""), instant ? 0 : 160);
	}
	function backdrop(url) {
		const layers = root.querySelectorAll(".ms-bg i");
		if (!layers.length || (url === bgNow && root.querySelector(".ms-bg i.on"))) return;
		bgNow = url;
		const next = [...layers].find(l => !l.classList.contains("on")) || layers[0];
		layers.forEach(l => l.classList.remove("on"));
		if (!url) return;
		next.style.backgroundImage = `url('${url.replace(/'/g, "%27")}')`;
		next.classList.add("on");
	}

	// The controller and arrow keys move to the nearest cell that way: the next row down (or up), then
	// the cell in it nearest across; left and right stay in the row.
	function move(dir) {
		const els = [...root.querySelectorAll("[data-k]")];
		const cur = root.querySelector(`[data-k="${CSS.escape(sel || "")}"]`);
		if (!cur) { if (els[0]) focusCell(els[0].dataset.k, true); return false; }
		const r = cur.getBoundingClientRect();
		const cx = (r.left + r.right) / 2, cy = (r.top + r.bottom) / 2;
		const found = [];
		for (const el of els) {
			if (el === cur) continue;
			const q = el.getBoundingClientRect();
			const across = dir === "up" || dir === "down" ? Math.abs((q.left + q.right) / 2 - cx) : Math.abs((q.top + q.bottom) / 2 - cy);
			let gap;
			if (dir === "down") gap = q.top >= r.bottom - 2 ? q.top - r.bottom : null;
			else if (dir === "up") gap = q.bottom <= r.top + 2 ? r.top - q.bottom : null;
			else if (q.bottom <= r.top || q.top >= r.bottom) gap = null;
			else if (dir === "right") gap = q.left >= r.right - 2 ? q.left - r.right : null;
			else gap = q.right <= r.left + 2 ? r.left - q.right : null;
			if (gap !== null) found.push({ el, gap, across });
		}
		if (!found.length) return false;
		const nearest = Math.min(...found.map(f => f.gap));
		const row = found.filter(f => f.gap <= nearest + r.height * 0.5);
		row.sort((a, b) => (dir === "left" || dir === "right" ? a.gap - b.gap : a.across - b.across));
		focusCell(row[0].el.dataset.k, true);
		return true;
	}

	function action(a) {
		if (!page) return false;
		if (["up", "down", "left", "right"].includes(a)) { if (move(a)) sound("move"); return true; }
		if (a === "select") { if (cells[sel]) { sound("select"); cells[sel].pick(); } return true; }
		if (a === "back") {
			sound("back");
			if (page.kind === "variants") mapsPage(page.from);
			else finish(null);
			return true;
		}
		if (page.kind === "variants" && (a === "tabl" || a === "tabr")) {
			const tabs = [...root.querySelectorAll(".ms-tabs .tab")].map(el => el.dataset.t);
			const at = tabs.indexOf(page.tab);
			page.tab = tabs[(at + (a === "tabr" ? 1 : tabs.length - 1)) % tabs.length];
			sound("bumper");
			fillVariants();
			return true;
		}
		if (a === "refresh") { const box = root.querySelector(page.kind === "variants" ? ".ms-tabs input" : ".ms-search"); if (box) box.focus(); return true; }
		return true;
	}

	// Mouse: hovering highlights (the list never moves under the mouse), a click picks, the wheel and the
	// scrollbar scroll.
	root.addEventListener("mouseover", (e) => {
		const el = e.target.closest("[data-k]");
		if (el && el.dataset.k !== sel && (!window.MenuScroll || MenuScroll.hoverOk())) { focusCell(el.dataset.k, false); sound("move"); }
	});
	root.addEventListener("click", (e) => {
		const el = e.target.closest("[data-k]");
		if (el && cells[el.dataset.k]) { sel = el.dataset.k; sound("select"); cells[sel].pick(); }
	});

	function open(opts) {
		o = opts;
		root.classList.add("open");
		bgNow = "";
		mapsPage("m:" + o.item.options[o.item.pick]);
	}
	function finish(apply) {
		if (apply) apply();
		page = null;
		cells = {};
		clearTimeout(bgTimer);
		root.classList.remove("open");
		root.innerHTML = "";
		o.done();
	}
	return { open, action, remember, isOpen: () => !!page };
})();
