// Reach's 50 multiplayer ranks (owner, 2026-10-12: a rank button that shows every rank). Names and the
// credits each needs are the retail game's (Halopedia's table); the pictures are cells of the Mod
// Tools' exit-experience sheet postgame/rank_temp.png (10 x 5), matched to the ranks by eye against
// the retail insignia. The player's credits are the ones the Credits Earned screen keeps (rr.credits).
const Ranks = (() => {
	// [name, credits, sheet column, sheet row]
	const LIST = [
		["Recruit", 0, 9, 4], ["Private", 7500, 8, 4], ["Corporal", 10000, 4, 4], ["Corporal, Grade 1", 15000, 6, 4],
		["Sergeant", 20000, 5, 4], ["Sergeant, Grade 1", 26250, 1, 4], ["Sergeant, Grade 2", 32500, 3, 4],
		["Warrant Officer", 45000, 2, 4], ["Warrant Officer, Grade 1", 78000, 8, 3], ["Warrant Officer, Grade 2", 111000, 9, 3], ["Warrant Officer, Grade 3", 144000, 0, 4],
		["Captain", 210000, 5, 3], ["Captain, Grade 1", 233000, 7, 3], ["Captain, Grade 2", 256000, 6, 3], ["Captain, Grade 3", 279000, 2, 3],
		["Major", 325000, 4, 3], ["Major, Grade 1", 350000, 3, 3], ["Major, Grade 2", 370000, 9, 2], ["Major, Grade 3", 400000, 1, 3],
		["Lt. Colonel", 450000, 0, 3], ["Lt. Colonel, Grade 1", 480000, 7, 4], ["Lt. Colonel, Grade 2", 510000, 0, 0], ["Lt. Colonel, Grade 3", 540000, 7, 2],
		["Commander", 600000, 9, 1], ["Commander, Grade 1", 650000, 9, 0], ["Commander, Grade 2", 700000, 8, 2], ["Commander, Grade 3", 750000, 4, 2],
		["Colonel", 850000, 3, 2], ["Colonel, Grade 1", 960000, 1, 2], ["Colonel, Grade 2", 1070000, 2, 2], ["Colonel, Grade 3", 1180000, 6, 2],
		["Brigadier", 1400000, 5, 2], ["Brigadier, Grade 1", 1520000, 8, 1], ["Brigadier, Grade 2", 1640000, 7, 1], ["Brigadier, Grade 3", 1760000, 0, 2],
		["General", 2000000, 4, 1], ["General, Grade 1", 2200000, 5, 1], ["General, Grade 2", 2350000, 2, 1], ["General, Grade 3", 2500000, 6, 1], ["General, Grade 4", 2650000, 1, 1],
		["Field Marshal", 3000000, 3, 1], ["Hero", 3700000, 8, 0], ["Legend", 4600000, 7, 0], ["Mythic", 5650000, 0, 1], ["Noble", 7000000, 5, 0],
		["Eclipse", 8500000, 4, 0], ["Nova", 11000000, 6, 0], ["Forerunner", 13000000, 2, 0], ["Reclaimer", 16500000, 1, 0], ["Inheritor", 20000000, 3, 0],
	].map(([name, at, col, row], index) => ({ name, at, col, row, index }));
	const STORE = "rr.credits";
	const credits = () => { try { return Math.max(0, +localStorage.getItem(STORE) || 0); } catch (e) { return 0; } };
	const of = (cr) => { let r = LIST[0]; for (const k of LIST) if (cr >= k.at) r = k; return r; };
	const next = (rank) => LIST[rank.index + 1] || null;
	// CSS background for a rank's picture (the element sets its own size).
	const picture = (rank) => `background:url(postgame/rank_temp.png) ${rank.col / 9 * 100}% ${rank.row / 4 * 100}% / 1000% 500% no-repeat`;
	const fmt = (n) => n.toLocaleString("en-US");
	const esc = (s) => String(s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

	const css = `
	.rk { position: fixed; inset: 0; z-index: 1002; display: none; color: #f2f4f5; background: linear-gradient(180deg, rgb(8,16,26), rgb(12,22,34)); } /* (opaque: the Start menu showed through; bug sweep) */
	.rk.open { display: block; }
	.rk .head { position: absolute; left: 8vw; top: 6vh; display: flex; align-items: center; gap: 2vw; }
	.rk .head .big { width: 14vh; height: 14vh; }
	.rk .head h1 { margin: 0; font-size: 5.4vh; font-weight: 700; text-transform: uppercase; }
	.rk .head .sub { font-size: 2.6vh; color: #b9c2c8; margin-top: 0.4vh; }
	.rk .head .track { width: 34vw; height: 1.2vh; margin-top: 1.2vh; background: rgba(255,255,255,0.12); }
	.rk .head .track i { display: block; height: 100%; background: linear-gradient(90deg, #8fc6f0, #e9f5ff); }
	.rk .grid { position: absolute; left: 8vw; right: 8vw; top: 26vh; bottom: 11vh; display: grid; grid-template-columns: repeat(10, 1fr); gap: 0.6vh 0.6vw; }
	.rk .cell { display: flex; flex-direction: column; align-items: center; padding: 0.6vh 0.2vw; background: rgba(255,255,255,0.04); cursor: pointer; }
	.rk .cell.sel { background: rgba(255,255,255,0.16); box-shadow: inset 0 0 0 0.2vh #f2f4f5; }
	.rk .cell.got { background: rgba(143,198,240,0.10); }
	.rk .cell.got.sel { background: rgba(143,198,240,0.24); }
	.rk .cell .pic { width: 6.4vh; height: 6.4vh; }
	.rk .cell:not(.got) .pic { opacity: 0.45; filter: grayscale(0.6); }
	.rk .cell .n { font-size: 1.45vh; font-weight: 600; text-align: center; line-height: 1.1; margin-top: 0.3vh; text-transform: uppercase; }
	.rk .cell .c { font-size: 1.35vh; color: #b9c2c8; }
	.rk .cell.me .n::after { content: " \\25C6"; color: #ffd36b; }
	.rk .keys { position: absolute; left: 8vw; top: 91vh; display: flex; gap: 1.6vw; font-size: 2.7vh; }
	.rk .keys .hint { cursor: pointer; }
	`;
	let root = null, sel = 0;

	function render() {
		const cr = credits(), me = of(cr), up = next(me);
		const pct = up ? Math.max(0, Math.min(100, (cr - me.at) / (up.at - me.at) * 100)) : 100;
		const s = LIST[sel];
		root.innerHTML = `<div class="head"><div class="big" style="${picture(s)}"></div><div>
				<h1>${esc(s.name)}</h1><div class="sub">${s === me ? "Your rank" : cr >= s.at ? "Reached" : fmt(s.at - cr) + " cR to go"} &middot; ${fmt(s.at)} cR</div>
				<div class="sub">You: ${esc(me.name)} &middot; ${fmt(cr)} cR${up ? " &middot; next: " + esc(up.name) + " at " + fmt(up.at) + " cR" : ""}</div>
				<div class="track"><i style="width:${pct}%"></i></div></div></div>
			<div class="grid">${LIST.map(r => `<div class="cell${r === s ? " sel" : ""}${cr >= r.at ? " got" : ""}${r === me ? " me" : ""}" data-i="${r.index}">
				<div class="pic" style="${picture(r)}"></div><div class="n">${esc(r.name)}</div><div class="c">${fmt(r.at)} cR</div></div>`).join("")}</div>
			<div class="keys"><span class="hint" data-a="back"><span class="btn b">B</span>Back</span></div>`;
		root.querySelectorAll("[data-i]").forEach(el => {
			el.onmouseenter = () => { if (sel !== +el.dataset.i && (!window.MenuScroll || MenuScroll.hoverOk())) { sel = +el.dataset.i; render(); } };
			el.onclick = () => { sel = +el.dataset.i; render(); };
		});
		root.querySelectorAll("[data-a]").forEach(el => el.onclick = () => action(el.dataset.a));
	}
	function show() {
		if (!root) {
			const style = document.createElement("style");
			style.textContent = css;
			document.head.appendChild(style);
			root = document.createElement("div");
			root.className = "rk";
			document.body.appendChild(root);
		}
		sel = of(credits()).index;
		render();
		root.classList.add("open");
		if (typeof Sound !== "undefined") Sound.play("select");
	}
	function close() {
		if (root) root.classList.remove("open");
		if (typeof Sound !== "undefined") Sound.play("back");
	}
	// Arrows move over the grid (10 across), B / Start / Esc close.
	function action(a) {
		const step = { left: -1, right: 1, up: -10, down: 10 }[a];
		if (step) {
			sel = Math.max(0, Math.min(LIST.length - 1, sel + step));
			if (typeof Sound !== "undefined") Sound.play("move");
			render();
		} else if (a === "back" || a === "start") close();
		return true;
	}
	return { LIST, of, next, credits, picture, show, action, isOpen: () => !!root && root.classList.contains("open") };
})();
// (a top-level const isn't a window property; the Start menu checks window.Ranks before using it)
window.Ranks = Ranks;
