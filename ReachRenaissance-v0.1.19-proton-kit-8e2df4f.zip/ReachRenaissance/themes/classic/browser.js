// Server Browser screen for the Classic 360 theme, inside Matchmaking (the multiplayer menu).
// Laid out like Reach's 360 lobby screens: title and bumper tabs, a list with the lit selection
// bar, a details panel styled like the party panel, button hints.
//
// Data and rules are the original server browser's (client/menus-prototype app.js +
// live-directory.js): rows from `rr-browser serve` GET /api/servers (every master, each server's
// own signed status, ping, compatibility, favorites), the same filter tabs, favorites-then-ping
// order, the same status labels, and joins refused for incompatible, unanswering or full servers.
"use strict";

const Browser = (() => {
	const FILTERS = [
		["All", () => true],
		["Multiplayer", (s) => (s.kind || "multiplayer") === "multiplayer"],
		["Forge", (s) => s.kind === "forge"],
		["Campaign", (s) => s.kind === "campaign" || s.kind === "firefight"],
		["Compatible", (s) => s.compatOk],
		["Ping < 100", (s) => s.ping != null && s.ping < 100],
		["Has Players", (s) => s.players > 0],
		["Not Full", (s) => s.players < s.max],
	];
	const COMPAT = {
		compatible: "Compatible",
		different_protocol: "Different directory protocol",
		different_game_build: "Different MCC build",
		older_client: "Runs an older client",
		newer_client: "Runs a newer client; update",
	};
	let tab = 0;
	let row = 0;
	let servers = [];
	let status = "Looking for games...";
	let joinError = "";
	// When the last join was sent (0: none under way). A second press while it starts sent a second join,
	// and a second game joined the same server (owner, 2026-10-21); joinFailed ends it, and after 20 s
	// (a game that started) a press joins again.
	let joinSent = 0;
	// This client's version (rr-browser's answer) and the server a join was just refused for (its address).
	let clientVersion = "";
	let refused = null;
	let lastRefresh = 0;
	let loading = false;
	let mastersText = "";

	const css = `
	.br { position: fixed; inset: 0; display: none; font-family: var(--font); color: var(--text); pointer-events: none; }
	.br.on { display: block; }
	/* (and never in a match: the lobby's state can still say "browser" after a guest's join, and a page opened over
	   the match must not find it under the in-game menu: owner report, 0.1.18) */
	body.inmatch .br.on { display: none; }
	/* (keyboard: the keys that switch the filters, Q and E) */
	body.kbm .br .tabs .bump { font-size: 0 !important; }
	body.kbm .br .tabs .bump::after { font-size: 1.5vh; content: "Q"; }
	body.kbm .br .tabs .bump:last-child::after { content: "E"; }
	.br .tabs { position: absolute; left: 13.8vw; top: 41vh; width: 48vw; display: flex; align-items: center; gap: 0.75vw; font-size: 1.75vh;
		text-transform: uppercase; font-weight: 600; letter-spacing: 0.04em; }
	.br .tabs .t { color: rgba(185, 194, 200, 0.55); white-space: nowrap; }
	.br .tabs .t.on { color: #fff; border-bottom: 0.35vh solid #f2f4f5; padding-bottom: 0.2vh; }
	.br .bump { font-size: 1.5vh; padding: 0.1vh 0.45vw; border-radius: 0.4vh; background: rgba(255,255,255,0.14); color: #fff; }
	.br .table { position: absolute; left: 13.3vw; top: 47.5vh; width: 48vw; }
	.br .head, .br .row { display: grid; grid-template-columns: 2.5fr 1.25fr 1.5fr 0.75fr 0.7fr; column-gap: 0.9vw; padding: 0.5vh 0.6vw; }
	.br .head { font-size: 1.6vh; color: rgba(185, 194, 200, 0.7); text-transform: uppercase; letter-spacing: 0.08em;
		border-bottom: 1px solid rgba(255,255,255,0.18); margin-bottom: 0.4vh; }
	.br .head .num, .br .row .num { text-align: right; }
	.br .row { font-size: 2.3vh; font-weight: 600; text-transform: uppercase; letter-spacing: 0.03em; color: var(--text-dim); }
	.br .row span { white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
	.br .row .star { color: #e8c35a; }
	.br .row .vtag { margin-left: 0.7vw; font-size: 1.6vh; color: #e8c35a; letter-spacing: 0.05em; }
	.br .row .mtag { margin-left: 0.7vw; font-size: 1.6vh; color: #35c9c0; letter-spacing: 0.05em; }
	.br .row.sel { color: #fff; background: linear-gradient(90deg, rgba(255,255,255,0.16), rgba(255,255,255,0.06) 80%, transparent);
		box-shadow: inset 0.25vw 0 0 #f2f4f5; }
	.br .row.bad { color: rgba(185, 194, 200, 0.45); }
	.br .empty { font-size: 2.2vh; color: var(--text); padding: 1.2vh 0.6vw; }
	/* (at the top of the screen, left of My Party: at 33vh it ran over the SERVER BROWSER title; owner, 2026-10-21) */
	.br .join-error { position: absolute; left: 13.8vw; top: 2.5vh; width: 44vw; max-height: 14vh; overflow: auto;
		padding: 0.8vh 1vw; background: rgba(12, 14, 16, 0.86); box-shadow: inset 0.3vw 0 0 #e07a6e;
		font-size: 1.9vh; line-height: 1.3; color: #f3d6d2; pointer-events: auto; }
	.br .join-error:empty { display: none; }
	.br .panel { position: absolute; left: 63vw; top: 41vh; width: 24vw; }
	.br .panel .h { background: var(--panel); padding: 0.6vh 0.7vw; font-size: 2.3vh; font-weight: 700; text-transform: uppercase;
		white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
	.br .panel .r { margin-left: 1.6vw; background: var(--panel-row); padding: 0.4vh 0.7vw; display: flex; justify-content: space-between;
		gap: 1vw; font-size: 1.95vh; margin-top: 0.25vh; }
	.br .panel .r b { font-weight: 600; color: var(--text-dim); text-transform: uppercase; font-size: 1.6vh; padding-top: 0.2vh; white-space: nowrap; }
	.br .panel .r span { text-align: right; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
	.br .panel .badge { margin: 0.8vh 0 0 1.6vw; display: inline-block; padding: 0.3vh 0.6vw; font-size: 1.9vh; font-weight: 700;
		text-transform: uppercase; letter-spacing: 0.05em; }
	.br .ok { color: #7ad08a; } .br .warn { color: #e8c35a; } .br .bad2 { color: #e07a6e; }
	.br .badge.ok { background: rgba(122, 208, 138, 0.16); } .br .badge.warn { background: rgba(232, 195, 90, 0.16); } .br .badge.bad2 { background: rgba(224, 122, 110, 0.16); }
	.br .vmsg { margin: 0.8vh 1vw 0 1.6vw; font-size: 1.9vh; line-height: 1.3; color: #e8c35a; }
	.br .vmsg.on { color: #fff; background: rgba(224, 122, 110, 0.22); padding: 0.5vh 0.6vw; }
	.br .note { margin: 0.8vh 0 0 1.6vw; font-size: 1.6vh; color: var(--text-dim); }
	.br .count { position: absolute; left: 13.8vw; top: 84vh; font-size: 1.9vh; color: var(--text-dim); }
	`;
	const root = document.createElement("div");
	root.className = "br";
	root.innerHTML = `<div class="join-error" role="alert"></div><div class="tabs"></div><div class="table"></div><div class="panel"></div><div class="count"></div>`;
	const style = document.createElement("style");
	style.textContent = css;

	// One row of rr-browser's result in the shape the original menus use (live-directory.js toRow).
	function toRow(r) {
		const l = r.listing || {};
		return {
			address: r.address, name: l.name, host: l.host_name, map: l.map, gametype: l.gametype, kind: l.kind,
			players: l.players ?? 0, max: l.max_players ?? 0, ping: r.ping_ms, version: l.client_version, region: l.region,
			password: l.password, maxPing: l.max_ping, mock: l.mock, answered: r.answered, error: r.error,
			favorite: r.favorite, sources: r.sources || [], reachable: r.reachable, publicKey: r.public_key || "",
			// Steam Workshop mods the server plays with (a join gets them from Steam first: mods-download.js).
			mods: Array.isArray(l.mods) ? l.mods : [],
			compatOk: r.compat && r.compat.status === "compatible", compatStatus: r.compat ? r.compat.status : "",
			compatText: r.compat ? (COMPAT[r.compat.status] || r.compat.status) + (r.compat.detail && r.compat.status !== "compatible" ? ` (${r.compat.detail})` : "") : "",
		};
	}
	// Same verdicts as the original browser (app.js compat()).
	function verdict(s) {
		if (!s.answered) return ["bad2", "Not answering"];
		// (owner, 2026-10-17: a newer server only played the error sound) Newer: "Update needed".
		if (s.compatStatus === "newer_client") return ["bad2", "Update needed"];
		if (s.compatStatus === "older_client") return ["bad2", "Older version"];
		if (!s.compatOk) return ["bad2", s.compatText.startsWith("Different MCC") ? "Different MCC build" : "Version mismatch"];
		if (s.players >= s.max) return ["warn", "Full"];
		if (s.maxPing && s.ping > s.maxPing) return ["warn", "Ping too high"];
		return ["ok", "Ready"];
	}
	// Why a join to this server can't work, in words, for its version verdicts.
	function versionMessage(s) {
		const mine = clientVersion ? "you have " + clientVersion : "yours is older";
		if (s.compatStatus === "newer_client") return `This server runs Reach Renaissance ${s.version}; ${mine}. Update to join.`;
		if (s.compatStatus === "older_client") return `This server runs Reach Renaissance ${s.version}, older than yours${clientVersion ? " (" + clientVersion + ")" : ""}. Its host needs to update before you can join.`;
		return "";
	}
	function visible() {
		const ping = (s) => (s.ping == null ? Infinity : s.ping);
		return servers.filter(FILTERS[tab][1]).sort((a, b) => (b.favorite ? 1 : 0) - (a.favorite ? 1 : 0) || ping(a) - ping(b));
	}
	function nice(s) {
		const map = MAPS.find(m => m.replace(/ /g, "").toLowerCase() === String(s.map || "").toLowerCase()) || s.map || "?";
		const mode = (MODES.find(m => m[1] === s.gametype) || FF_MODES.find(m => m[1] === s.gametype) || (s.gametype === "00_basic_editing_054" && ["Basic Editing"]) || [s.gametype || "?"])[0];
		return { map, mode };
	}
	const pingText = (s) => (s.ping == null ? "–" : `${s.ping} ms`);

	function render() {
		// Inside the lobby's .screen, as part of the lobby: whatever covers or hides the lobby (a page such as
		// the in-game menu, the Start menu, Credits Earned, a match) covers or hides it too. On its own in
		// <body> it showed through the guest's in-game menu (Esc after a join) and over the Start menu
		// (owner report, 2026-10-20).
		if (!root.isConnected) { document.head.appendChild(style); (document.querySelector(".screen") || document.body).appendChild(root); }
		root.querySelector(".join-error").textContent = joinError;
		const tabs = root.querySelector(".tabs");
		tabs.innerHTML = `<span class="bump">LB</span>` + FILTERS.map((f, i) => `<span class="t${i === tab ? " on" : ""}">${f[0]}</span>`).join("") + `<span class="bump">RB</span>`;
		const list = visible();
		row = Math.min(row, Math.max(0, list.length - 1));
		const table = root.querySelector(".table");
		table.innerHTML = `<div class="head"><span>Game</span><span>Map</span><span>Game Type</span><span class="num">Players</span><span class="num">Ping</span></div>`;
		if (!list.length) {
			const e = document.createElement("div");
			e.className = "empty";
			e.textContent = status || (servers.length ? "No games match this filter." : "No games listed. Host one from Custom Games, or press Y to refresh.");
			table.appendChild(e);
		}
		const first = Math.max(0, Math.min(row - 3, list.length - 8));
		list.slice(first, first + 8).forEach((s, k) => {
			const i = first + k, n = nice(s);
			const r = document.createElement("div");
			r.className = "row" + (i === row ? " sel" : "") + (verdict(s)[0] === "bad2" ? " bad" : "");
			const name = document.createElement("span");
			if (s.favorite) { const st = document.createElement("span"); st.className = "star"; st.textContent = "★ "; name.appendChild(st); }
			name.appendChild(document.createTextNode((s.name || "Reach game") + (s.password ? " (password)" : "")));
			// A newer or older version says so on its row ("Update needed" / "Older version").
			if (s.compatStatus === "newer_client" || s.compatStatus === "older_client") {
				const t = document.createElement("span");
				t.className = "vtag";
				t.textContent = verdict(s)[1];
				name.appendChild(t);
			}
			if (s.mods.length) {
				const t = document.createElement("span");
				t.className = "mtag";
				t.textContent = "Mod";
				name.appendChild(t);
			}
			r.appendChild(name);
			for (const [text, cls] of [[n.map], [n.mode], [`${s.players}/${s.max}`, "num"], [pingText(s), "num"]]) {
				const c = document.createElement("span");
				c.textContent = text;
				if (cls) c.className = cls;
				r.appendChild(c);
			}
			table.appendChild(r);
		});
		const panel = root.querySelector(".panel");
		panel.innerHTML = "";
		const s = list[row];
		if (s) {
			const n = nice(s);
			const add = (label, value, cls) => {
				const d = document.createElement("div");
				d.className = label ? "r" : "h";
				if (label) { const b = document.createElement("b"); b.textContent = label; d.appendChild(b); }
				const v = document.createElement("span");
				v.textContent = value;
				if (cls) v.className = cls;
				d.appendChild(v);
				panel.appendChild(d);
			};
			add(null, (s.favorite ? "★ " : "") + (s.name || "Reach game"));
			add("Host", s.host || "Unknown");
			if (s.region) add("Region", s.region);
			add("Map", n.map);
			add("Game Type", n.mode);
			for (const m of s.mods) add("Mod", (m.title || "Workshop item " + m.workshop_id) + (m.version ? " " + m.version : ""));
			add("Players", `${s.players} / ${s.max}`);
			add("Ping", pingText(s) + (s.maxPing ? ` (limit ${s.maxPing} ms)` : ""));
			add("Version", s.version || "?", s.compatOk ? "ok" : "bad2");
			if (!s.compatOk) add("Build", s.compatText, "bad2");
			add("Listed By", `${s.sources.length} server list${s.sources.length === 1 ? "" : "s"}`);
			add("Internet", s.reachable === true ? "Reachable" : s.reachable === false ? "Lists couldn't reach it" : "Not checked yet", s.reachable === false ? "warn" : "");
			const [cls, label] = verdict(s);
			const b = document.createElement("div");
			b.className = "badge " + cls;
			b.textContent = label;
			panel.appendChild(b);
			const why = versionMessage(s);
			if (why) {
				const m = document.createElement("div");
				m.className = "vmsg" + (refused === s.address ? " on" : "");
				m.textContent = why;
				panel.appendChild(m);
				// (room for the Public release thread's in-menu update button)
				const slot = document.createElement("div");
				slot.className = "update-slot";
				panel.appendChild(slot);
			}
			const notes = [];
			if (!s.answered) notes.push(s.error || "The server did not answer this refresh.");
			if (s.mock) notes.push("Mock host (rr-fakehost): no game behind it.");
			if (s.mods.length) notes.push("Plays with a Steam Workshop mod: if you don't have it, Steam downloads it when you join.");
			notes.push("Details are reported by the host.");
			const note = document.createElement("div");
			note.className = "note";
			note.textContent = notes.join(" ");
			panel.appendChild(note);
		}
		const age = lastRefresh ? Math.round((Date.now() - lastRefresh) / 1000) : null;
		root.querySelector(".count").textContent = (loading ? "Refreshing... " : "") + (servers.length ? `${list.length} of ${servers.length} games` : "") +
			(mastersText ? `  ·  ${mastersText}` : "") + (age != null && !loading ? `  ·  updated ${age} s ago` : "");
		document.getElementById("description").textContent = "";
	}

	// Refresh like the original: every 15 s while the browser is open, retry every 3 s until one works.
	// (not in a match, where the page is hidden: after a join from the browser the list was fetched every 15 s
	// through the whole match; 2026-10-20 player batch, report 17)
	setInterval(() => {
		if (!root.classList.contains("on") || loading || document.body.classList.contains("inmatch")) return;
		if (!lastRefresh || Date.now() - lastRefresh > 15000) refreshServers();
		else render();
	}, 3000);

	return {
		show(on) { if (on) { root.classList.add("on"); render(); } else root.classList.remove("on"); },
		// `result`: rr-browser's {masters, rows}, or null with an error text.
		setResult(result, error) {
			loading = false;
			if (result) {
				servers = (result.rows || []).map(toRow);
				if (result.client_version) clientVersion = result.client_version;
				const ok = (result.masters || []).filter(m => !m.error).length;
				mastersText = `${ok} of ${(result.masters || []).length} server list${(result.masters || []).length === 1 ? "" : "s"} answered`;
				status = "";
				lastRefresh = Date.now();
			} else status = "Couldn't reach the server list: " + error;
			render();
		},
		loading() { loading = true; if (!servers.length) status = "Looking for games..."; render(); },
		joinFailed(text) {
			Sound.play("error"); joinError = text; joinSent = 0;
			document.getElementById("curtain").classList.remove("on"); render();
			if (!root.classList.contains("on") && typeof Social !== "undefined") Social.say(text);
		},
		action(a) {
			const list = visible();
			const s = list[row];
			if (a === "down" && list.length) { row = (row + 1) % list.length; Sound.play("move"); }
			else if (a === "up" && list.length) { row = (row + list.length - 1) % list.length; Sound.play("move"); }
			else if (a === "tabl" || a === "left") { tab = (tab + FILTERS.length - 1) % FILTERS.length; row = 0; Sound.play("bumper"); }
			else if (a === "tabr" || a === "right") { tab = (tab + 1) % FILTERS.length; row = 0; Sound.play("bumper"); }
			else if (a === "star") {
				if (!s) return true;
				s.favorite = !s.favorite;
				Sound.play("change");
				post("star:" + s.address + ":" + (s.favorite ? "1" : "0"));
			}
			else if (a === "select") {
				if (!s) { Sound.play("error"); return true; }
				const [cls, label] = verdict(s);
				if (cls === "bad2" || label === "Full") {
					Sound.play("error");
					// A version mismatch says why (versionMessage), highlighted in the details panel.
					if (versionMessage(s)) { refused = s.address; render(); }
					return true;
				}
				if (window.Social && Social.following()) { Sound.play("error"); Social.say(Social.followingNote()); return true; }
				if (joinSent && Date.now() - joinSent < 20000) return true;
				joinSent = Date.now();
				joinError = "";
				render();
				Sound.play("select");
				// What Credits Earned and the challenges count the game as (a join kept the last game played
				// on this PC, or none: "Game Complete" and no multiplayer challenge progress; bug sweep).
				const { map, mode } = nice(s);
				window.lastGame = { title: mode + " on " + map, text: s.name || "Online Game", map, mode, difficulty: -1, hosted: false, mod: s.mods.length > 0,
					modName: s.mods.map(m => m.title || "Workshop item " + m.workshop_id).join(", "),
					kind: { firefight: "ff", campaign: "camp", forge: "forge" }[s.kind] || "mp" };
				// (the loading screen's banner, boot.js)
				window.joinBanner = `Joining ${s.name || "game"}...`;
				document.getElementById("curtain").classList.add("on");
				post("join:" + s.address + "|" + s.sources.join(","));
				return true;
			}
			else if (a === "refresh") { Sound.play("y"); refreshServers(); return true; }
			else return false;
			render();
			return true;
		},
	};
})();
